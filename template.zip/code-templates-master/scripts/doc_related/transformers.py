"""Transformation module for outliers."""

from sklearn.base import BaseEstimator, TransformerMixin


class Outlier(BaseEstimator, TransformerMixin):
    """Tranformer to treat outliers by either capping them or dropping them.

    Parameters
    ----------
    method: str, default is percentile.
        Accepted values are mean, median, threshold, percentile
        The method that is used to determine the upper/lower bounds
        * If percentile - bounds are quantiles (0-1). Default bounds are (0.01, 0.99)
        * If mean - bounds are no. of standard deviations from mean. Default bounds are (3, 3)
        * If median - bounds are no. of IQRs away from median. Default bounds are  (1.5, 1.5)
        * If threshold - Fixed values for capping. No default bounds.
    lb: numeric, default is none
        lb is the lower bound
        * If not None, pass a dictonary of columns with lower limits for each
    ub: numeric, default is none
        ub is the upper bound
        * If not None, pass a dictonary of columns with upper limits for each
    drop: bool, default is False.
        if the rows to be dropped then the value should be set to ``True`` and ``False`` if it needs to be capped.
        Beware of setting this to True.
    """

    def __init__(
        self,
        method="percentile",
        lb=None,
        ub=None,
    ):
        """Initialize Estimator."""

        default_limits = {
            "percentile": (0.01, 0.99),
            "mean": (3, 3),
            "median": (1.5, 1.5),
        }
        self.method = method
        if lb is None:
            lb = default_limits[method][0]
        if ub is None:
            ub = default_limits[method][1]

        self.lb = lb
        self.ub = ub

    def fit(self, X, cols=None):
        """Compute outlier limits from X.

        Parameters
        ----------
        X : pd.DataFrame or np.Array
            Dataframe/2D Array consisting of independent features
        cols : list, optional
            List of column names for features relevant when X is Arrays, by default None

        """
        (self.lb, self.ub) = self.compute_outlier_bounds(
            X, cols, self.method, self.lb, self.ub
        )
        return self

    def transform(self, X, drop=False):
        """Treat outliers for X.

        Parameters
        ----------
        X : pd.DataFrame or np.Array
            Dataframe/2D Array consisting of independent features.
        drop: bool, optional
            By default False.
            When True, outlier records are dropped.

        Returns
        -------
        np.Array
            Predictions for the input data
        """
        df = X.copy()
        for (col, lb) in self.lb.items():
            fil_lower = df[col] < lb
            if drop is True:
                df = df[~fil_lower]
            else:
                df.loc[fil_lower, col] = lb
        for (col, ub) in self.ub.items():
            fil_upper = df[col] > ub
            if drop is True:
                df = df[~fil_upper]
            else:
                df.loc[fil_upper, col] = ub
        return df

    def fit_transform(
        self,
        X,
        drop=False,
        cols=None,
    ):
        """Fit to data, then transform it.

        Parameters
        ----------
        X: pd.DataFrame or np.Array
            Dataframe/2D Array consisting of independent features
        drop: bool, optional
            By default False.
            When True, outlier records are dropped.
        cols: list, optional
            List of column names of features, by default None

        Returns
        -------
        pd.DataFrame
            Transformed dataframe is returned
        """

        return self.fit(X, cols).transform(X, drop)

    def compute_outlier_bounds(  # noqa
        self,
        df,
        cols=None,
        method="mean",
        lb=None,
        ub=None,
    ):
        """Compute outlier bounds for each column.

        Parameters
        ----------
        df: pd.DataFrame or np.Array
            Dataframe/2D Array consisting of independent features.
        cols: list, optional
            List of column names of features, by default None
        method: str, default is mean
            Accepted values are mean, median, threshold, percentile
        lb: numeric, default is none
            lb is the lower bound
            * If not None, pass a dictonary of columns with lower limits for each
        ub: numeric, default is none
            ub is the upper bound
            * If not None, pass a dictonary of columns with upper limits for each

        Returns
        -------
        pd.DataFrame
            outlier treated dataframe is returned.
        """

        if cols is None:
            cols = df.select_dtypes("number").columns.to_list()

        num_df = df[cols]
        if method == "mean":
            mean = num_df.mean()
            std = num_df.std()
            lb = (mean - lb * std).to_dict()
            ub = (mean + ub * std).to_dict()
        elif method == "median":
            fst_quant = num_df.quantile(0.25)
            thrd_quant = num_df.quantile(0.75)
            iqr = thrd_quant - fst_quant
            lb = (fst_quant - lb * iqr).to_dict()
            ub = (thrd_quant + ub * iqr).to_dict()
        elif method == "percentile":
            lb = num_df.quantile(lb).to_dict()
            ub = num_df.quantile(ub).to_dict()
        elif method == "threshold":
            pass
        else:
            raise ValueError("Unsupported outlier method : " + method)

        return (lb, ub)
