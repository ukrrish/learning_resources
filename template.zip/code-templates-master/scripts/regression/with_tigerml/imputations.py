"""
Author: Sarath Malipeddi <sarath.malipeddi@tigeranalytics.com>
"""

import copy

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.experimental import enable_iterative_imputer
from sklearn.feature_selection import RFE, mutual_info_classif
from sklearn.impute import IterativeImputer, KNNImputer
from sklearn.linear_model import Lasso, LinearRegression, LogisticRegression
from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import (
    OrdinalEncoder,
    StandardScaler,
    power_transform,
)
from sklearn.tree import DecisionTreeRegressor

# from fancyimpute import KNN


enable_iterative_imputer  # noqa


def _get_num_cols(data):
    """Internal function to list numerical columns in a dataframe

    Parameters:
    ----------
        data: data frame

    Returns:
    --------
        num_cols: numerical columns
    """
    num_cols = list(data._get_numeric_data().columns)
    bool_cols = _get_bool_cols(data)
    num_cols = list(set(num_cols) - set(bool_cols))
    return num_cols


def _get_cat_cols(data):
    """Internal function to list the categorical columns in a dataframe

    Parameters:
    ----------
        data: data frame

    Returns:
    --------
        num_cols: categorical columns
    """
    num_cols = _get_num_cols(data)
    dt_cols = _get_dt_cols(data)
    return list(set(data.columns) - set(num_cols) - set(dt_cols))


def _get_dt_cols(data):
    """Internal function to list the date columns in a dataframe

    Parameters:
    ----------
        data: data frame

    Returns:
    --------
        list: date columns
    """
    return list(data.select_dtypes(include=[np.datetime64]).columns)


def _get_bool_cols(data):
    """Internal function to list the boolean columns in a dataframe

    Parameters:
    ----------
        data: data frame

    Returns:
    --------
        list: bool columns
    """
    dtypes = data.dtypes
    bool_cols = dtypes[dtypes == "bool"].index.tolist()
    for col in data.columns:
        if col not in bool_cols:
            if data[col].dropna().nunique() == 2:
                bool_cols.append(col)
    return bool_cols


def impute_num(feature, impute_method="mean", missing_str=0, prefix="", suffix=""):
    """This method will impute the missing values in a continuous variable. 

    This transformation will impute in inplace.

    Parameters:
    -----------
    feature : str 
        Name of the continuous variable to be encoded.
    impute_method : str, Default='mean'
        Other options include - 'mode', 'median' and 'constant'.
    missing_str : int, Default=0
        Value that you want impute when method is 'constant'.
    prefix : str 
        prefix for the imputed column
    suffix : str 
        prefix for the imputed column

    Returns:
    --------
    dataframe : Modified dataframe will be returned.

    """
    imputed_name = prefix + feature.name + suffix

    feature = feature.replace(r"^\s*$", np.nan, regex=True)

    temp = feature.dtype
    no_of_missing = feature.isnull().values.sum()
    print(
        "There are {} missing values in the variable - {}".format(
            no_of_missing, feature.name
        )
    )
    if impute_method == "median":
        impute_value = feature.median()
    elif impute_method == "mean":
        impute_value = feature.mean()
    elif impute_method == "mode":
        impute_value = feature.mode()[0]
    elif impute_method == "constant":
        impute_value = missing_str
    else:
        raise Exception(
            'Supported values for "impute_method" are - mean, median, mode & constant'
        )

    imputed_feature = feature.fillna(impute_value)
    imputed_feature.rename(imputed_name)
    imputed_feature = imputed_feature.astype(temp)
    return (imputed_feature, impute_value)


def impute_cat(
    feature, impute_method="constant", missing_str="Missing", prefix="", suffix=""
):
    """This method will impute the missing values in a categorical variable.
     This transformation will impute in inplace.

    Parameters:
    -----------
    feature : str 
        Name of the category variable to be encoded.
    impute_method : str 
        Default is 'constant'. Other options include - 'mode'.
    missing_str : str 
        Default is 'Missing'. Value that you want impute in the missing values.
    prefix : str 
        prefix for the inputed column
    suffix : str 
        prefix for the inputed column

    Returns:
    --------
    dataframe : Modified dataframe will be returned.
    """
    imputed_name = prefix + feature.name + suffix
    no_of_missing = feature.isnull().values.sum()
    imputed_feature = feature.replace(r"^\s*$", np.nan, regex=True)

    print(
        "There are {} missing values in the variable - {}".format(
            no_of_missing, feature.name
        )
    )
    if impute_method == "constant":
        impute_value = missing_str
    elif impute_method == "mode":
        impute_value = feature.mode().values[0]
    else:
        raise Exception('Incorrect input. Should be either "constant" or "mode".')

    imputed_feature = imputed_feature.fillna(impute_value)
    imputed_feature.rename(imputed_name)
    return (imputed_feature, impute_value)


def impute_MICE(data, random_state=42, initial_strategy="mean"):
    """This method will impute the missing values by creating equations for each variable.
    
    This equations are either linear or logistic equations.

    Parameters:
    -----------
    data: dataframe 
        data with missing values and variables used for estimating missing values.

    Returns:
    --------
    dataframe : Modified dataframe will be returned.
    """
    temp = data.dtypes.tolist()
    imputer = IterativeImputer(
        missing_values=np.nan,
        random_state=random_state,
        n_nearest_features=5,
        sample_posterior=True,
        initial_strategy=initial_strategy,
    )
    imputer.fit(data)
    imputed_df = pd.DataFrame(
        imputer.transform(data), columns=data.columns, index=data.index
    )
    for i, column in enumerate(imputed_df.columns):
        imputed_df[column] = imputed_df[column].astype(temp[i])
    return imputed_df, imputer


def numerical_decision_impute(data, random_state=42, initial_strategy="decision"):
    """This method will impute the missing values by creating equations for each variable.
    
    This equations are based on decision tree.

    Parameters:
    -----------
    data: dataframe 
        data with missing values and variables used for estimating missing values.

    Returns:
    --------
    dataframe : Modified dataframe will be returned.
    imputer: imputer
    """
    temp = data.dtypes.tolist()
    estimator_ = DecisionTreeRegressor(max_features="sqrt", random_state=random_state)
    imputer = IterativeImputer(
        missing_values=np.nan, random_state=random_state, estimator=estimator_
    )
    imputer.fit(data)
    imputed_df = pd.DataFrame(
        imputer.transform(data), columns=data.columns, index=data.index
    )
    for i, column in enumerate(imputed_df.columns):
        imputed_df[column] = imputed_df[column].astype(temp[i])
    return imputed_df, imputer


def numerical_knn_impute(data, num_corr_cols=10, min_thres=0.1):
    """This method will impute the missing values by KNN for each variable.

    Parameters
    ----------
    data : DataFrame 
        data with missing values and variables used for estimating missing values.
    num_corr_cols : int,Default is 10
         How many top correlated column it should take.
    min_thres: float,Default=0.4
         Minimum threshold for taking columns.

    Returns
    -------
    dataframe : Modified dataframe will be returned.
    imputer: dict
         e.g. {"A":{"imputer":sklearn_object, "feature_cols":["c", "d"]}, "B":{"imputer":sklearn_object,
            "feature_cols":["c"]}}
    """
    num_cols = _get_num_cols(data)
    missing_cols = list(data.columns[data.isnull().any()])
    missing_cols = [i for i in num_cols if i in missing_cols]
    missing_cols = list(data[missing_cols].isnull().sum().sort_values().index)
    imputed_df = data.copy(deep=True)
    imputer = {}
    for col in missing_cols:
        knn_imputer = KNNImputer(n_neighbors=int(round(np.sqrt(data.shape[0]))),)
        num_df = data[list(set(num_cols) - set(missing_cols))].copy(deep=True)
        num_df[col] = data[col].copy(deep=True)
        corr_df = num_df.corr(method="pearson")
        top_corr_cols = (
            pd.DataFrame(corr_df.loc[:, col])
            .sort_values(by=col, ascending=False)
            .iloc[1 : (num_corr_cols + 1), :]
        )
        top_num_cols = (top_corr_cols[top_corr_cols.values >= min_thres].dropna()).index
        cols = list(list(top_num_cols) + [col])
        impute_df = data[cols].copy(deep=True)
        # print(impute_df.columns)
        knn_imputer.fit(impute_df.values)
        imputed_col = pd.DataFrame(
            knn_imputer.transform(impute_df.values),
            columns=impute_df.columns,
            index=impute_df.index,
        )
        imputed_df[col] = imputed_col
        imputer.update({col: {"imputer": knn_imputer, "feature_cols": cols}})
        # print(cols)
    return imputed_df, imputer


def impute(
    data,
    num_impute_method="mean",
    cat_impute_method="mode",
    num_impute_constant="Missing",
    cat_impute_constant="Missing",
    random_state=42,
):
    """This method will impute the missing values

    Parameters:
    -----------
    data: dataframe 
        data with missing values and variables used for estimating missing values.
    impute_method: str 
        mice or none
    num_impute_method: str 
         numerical impute method(mean, median, mode, mice-mean, mice-mode, mice-median, knn)
    cat_impute_method: str
        categorical impute method(mode)
    num_impute_constant: str
        constant value to be filled the missing values
    cat_impute_constant: str
        constant value to be filled the missing values
    random_state: int
        set seed for reproducibility

    Returns:
    --------
    dataframe : Modified dataframe will be returned.
    """
    imputed_data = data.copy()
    num_cols_list = list(_get_num_cols(data))
    cat_cols_list = list(_get_cat_cols(data))
    num_imputer = {}
    cat_imputer = {}
    if not ((num_impute_method == "") or (num_impute_method is None)):
        if "mice" in num_impute_method:
            num_imputed_df, imputer = impute_MICE(
                data[num_cols_list],
                random_state=random_state,
                initial_strategy=num_impute_method.split("-")[1],
            )
            imputed_data[num_cols_list] = num_imputed_df[num_cols_list]
            num_imputer.update({"imputer": imputer})

        elif "knn" in num_impute_method:
            imputed_data, imputer = numerical_knn_impute(data)
            num_imputer.update({"imputer": imputer})

        elif "decision" in num_impute_method:
            imputed_data, imputer = numerical_decision_impute(data)
            num_imputer.update({"imputer": imputer})
        else:
            for col in num_cols_list:
                imputed_data[col], imputer_value = impute_num(
                    data[col],
                    impute_method=num_impute_method,
                    missing_str=num_impute_constant,
                )
                num_imputer.update({col: imputer_value})

    if not ((cat_impute_method == "") or (cat_impute_method is None)):
        if "knn_norm" in cat_impute_method:
            encoder, imputer, imputed_data = categorical_impute(imputed_data)
            cat_imputer.update({"imputer": imputer, "encoder": encoder})

        elif "knn_pca" in cat_impute_method:
            encoder, imputer, sc, pca, imputed_data = categorical_impute_pca(
                imputed_data
            )
            cat_imputer.update(
                {"imputer": imputer, "encoder": encoder, "sc": sc, "pca": pca}
            )

        else:
            for col in cat_cols_list:
                imputed_data[col], imputer_value = impute_cat(
                    data[col],
                    impute_method=cat_impute_method,
                    missing_str=cat_impute_constant,
                )
                cat_imputer.update({col: imputer_value})
    imputer = {
        "num_imputer": num_imputer,
        "cat_imputer": cat_imputer,
        "columns": data.columns,
    }
    return imputed_data, imputer


def impute_transform(test_data, imputer, num_impute_method, cat_impute_method):
    """This function is to impute the missing values in the test dataset using the imputer from the training

    Parameters:
    -----------
        test_data: pandas data frame 
        imputer: imputer object 
            contains the imputation values based on the method
        num_impute_method: str
            numerical imputation method used in training
        cat_impute_method: str
            categorical imputation method used in training

    Returns:
    --------
        data: imputed data frame
    """
    data = test_data[imputer["columns"]].copy(deep=True)
    num_cols_list = list(_get_num_cols(data))
    if not ((num_impute_method == "") or (num_impute_method is None)):
        if "mice" in num_impute_method:
            num_data = data[num_cols_list].copy(deep=True)
            imputer_obj = imputer["num_imputer"]["imputer"]
            imputed_df = pd.DataFrame(
                imputer_obj.transform(num_data),
                columns=num_data.columns,
                index=num_data.index,
            )
            data[num_cols_list] = imputed_df[num_cols_list]

        elif "knn" in num_impute_method:
            for col in list(imputer["num_imputer"]["imputer"].keys()):
                imputer_obj = imputer["num_imputer"]["imputer"][col]["imputer"]
                impute_df = data[
                    list(imputer["num_imputer"]["imputer"][col]["feature_cols"])
                ].copy(deep=True)
                imputed_col = pd.DataFrame(
                    imputer_obj.transform(impute_df.values),
                    columns=impute_df.columns,
                    index=impute_df.index,
                )
                data[col] = imputed_col[col]

        else:
            data = data.fillna(imputer["num_imputer"])

    if not ((cat_impute_method == "") or (cat_impute_method is None)):
        # categorical
        if "knn_norm" in cat_impute_method:
            data = categorical_impute_test(
                data,
                encoder=imputer["cat_imputer"]["encoder"],
                imputer=imputer["cat_imputer"]["imputer"],
            )
        elif "knn_pca" in cat_impute_method:
            data = categorical_impute_pca_test(
                data,
                encoder=imputer["cat_imputer"]["encoder"],
                imputer=imputer["cat_imputer"]["imputer"],
                sc=imputer["cat_imputer"]["sc"],
                pca=imputer["cat_imputer"]["pca"],
            )
        else:
            if (cat_impute_method == "") or (cat_impute_method == None):
                pass
            else:
                data = data.fillna(imputer["cat_imputer"])
    test_data[imputer["columns"]] = data[imputer["columns"]]
    return test_data


def encode(col):
    """Encode categorical data to ordinal encoding for imputation

    Parameters:
    ----------
    col : pd.Series/np.array
        array of that data/column that needs to be encoded

    Returns:
    --------
    col_out : list
        list of ordinal encoded cols
    encoder : encoder
        encoder used for encoding

    """

    temp = np.array(col.dropna())
    temp = temp.reshape(-1, 1)
    encoder = OrdinalEncoder()
    encoder = encoder.fit(temp)
    temp = encoder.transform(temp)
    col_out = col.copy()
    col_out.loc[col_out.notnull()] = np.squeeze(temp)
    return encoder, col_out


def encode_test(col, encoder, col_):
    """Encode categorical data to ordinal encoding for imputation on test data

    Parameters:
    ----------
    col : pd.Series/np.array
        array of that data/column that needs to be encoded
    encoder : encoder
        encoder used on the train dataset

    Returns:
    --------
    col_out : list
        list of ordinal encoded cols
    """
    temp = np.array(col.dropna())
    temp = temp.reshape(-1, 1)
    encode = encoder[col_]
    temp = encode.transform(temp)
    col_out = col.copy()
    col_out.loc[col_out.notnull()] = np.squeeze(temp)
    return col_out


def categorical_impute(data):
    """This method will impute the missing values by KNN for each categorical variable.

    Parameters
    ----------
    data : DataFrame 
        data with missing values and variables used for estimating missing values.

    Returns
    -------
    dataframe : pd.DataFrame
        Modified dataframe will be returned.
    imputer : dict
        e.g. {"A":{"imputer":sklearn_object, "feature_cols":["c", "d"]}, "B":{"imputer":sklearn_object,
            "feature_cols":["c"]}}
    encoder : dict
         e.g {"A":encoder}
    """
    cat_cols = _get_cat_cols(data)
    missing_cols = list(data.columns[data.isnull().any()])
    cat_missing_cols = [i for i in cat_cols if i in missing_cols]
    num_cols = _get_num_cols(data)

    encoded_data = data.copy()
    encoder = {}
    for col_ in cat_missing_cols:
        encoder[col_], encoded_data[col_] = encode(encoded_data[col_])

    imputed_data = encoded_data.copy()
    imputer = {}
    for col_ in cat_missing_cols:
        imputer_knn_cat = IterativeImputer(
            KNeighborsRegressor(n_neighbors=int(np.sqrt(imputed_data.shape[0])))
        )
        temp_df = encoded_data[list(num_cols) + [col_]]
        imputer_knn_cat = imputer_knn_cat.fit(temp_df)
        temp_df = pd.DataFrame(
            np.round(imputer_knn_cat.transform(temp_df)), columns=temp_df.columns
        )
        imputed_data[col_] = encoder[col_].inverse_transform(
            np.array(temp_df[col_]).reshape(-1, 1)
        )
        imputer.update(
            {
                col_: {
                    "imputer": imputer_knn_cat,
                    "feature_cols": list(num_cols) + [col_],
                }
            }
        )

    return encoder, imputer, imputed_data


def categorical_impute_test(data, encoder, imputer):
    """This method will impute the missing values by KNN for each categorical variable for the test data.

    Parameters
    ----------
    data : DataFrame 
        data with missing values and variables used for estimating missing values for test data
    imputer : dict 
        e.g. {"A":{"imputer":sklearn_object, "feature_cols":["c", "d"]}, "B":{"imputer":sklearn_object,
            "feature_cols":["c"]}}
    encoder : dict
         e.g {"A":encoder}

    Returns
    -------
    dataframe : Modified dataframe will be returned

    """

    cat_cols = _get_cat_cols(data)
    missing_cols = list(data.columns[data.isnull().any()])
    cat_missing_cols = [i for i in cat_cols if i in missing_cols]

    encoded_data = data.copy()
    for col_ in cat_missing_cols:
        encoded_data[col_] = encode_test(encoded_data[col_], encoder, col_)

    imputed_data = encoded_data.copy()
    for col_ in cat_missing_cols:
        imputer_knn_cat = imputer[col_].get("imputer")
        temp_df = encoded_data[imputer[col_].get("feature_cols")]
        imputer_knn_cat = imputer_knn_cat.fit(temp_df)
        temp_df = pd.DataFrame(
            np.round(imputer_knn_cat.transform(temp_df)), columns=temp_df.columns
        )
        imputed_data[col_] = encoder[col_].inverse_transform(
            np.array(temp_df[col_]).reshape(-1, 1)
        )
    return imputed_data


def categorical_impute_pca(data):
    """This method will impute the missing values by KNN for each categorical variable,\
        features are provided using pca

    Parameters
    ----------
    data : DataFrame 
        data with missing values and variables used for estimating missing values.

    Returns
    -------
    dataframe : DataFrame
        Modified dataframe will be returned.
    imputer : dict
        e.g. {"A":{"imputer":sklearn_object, "feature_cols":["c", "d"]}, "B":{"imputer":sklearn_object,
            "feature_cols":["c"]}}
    encoder : dict
        e.g {"A":encoder}
    pca : pca object
    sc : standardisation object
    """
    cat_cols = _get_cat_cols(data)
    missing_cols = list(data.columns[data.isnull().any()])
    cat_missing_cols = [i for i in cat_cols if i in missing_cols]
    num_cols = _get_num_cols(data)
    num_non_missing_cols = [i for i in num_cols if i not in missing_cols]

    # Principal components creation
    pca_df = data[num_non_missing_cols]

    sc = StandardScaler()
    pca_df = sc.fit_transform(pca_df)

    n_components = (pca_df.shape[1] - 2) if (pca_df.shape[1] < 10) else 10
    pca = PCA(n_components=n_components).fit(pca_df)
    pca_df = pd.DataFrame(
        pca.transform(pca_df), columns=pd.Series(range(1, (n_components + 1))).to_list()
    )

    # encoding
    encoded_data = data.copy()
    encoder = {}
    for col_ in cat_missing_cols:
        encoder[col_], encoded_data[col_] = encode(encoded_data[col_])

    # Imputation
    imputed_data = encoded_data.copy()
    imputer = {}
    for col_ in cat_missing_cols:
        imputer_knn_cat = IterativeImputer(
            KNeighborsRegressor(n_neighbors=int(np.sqrt(imputed_data.shape[0])))
        )

        temp_df = pca_df.copy()
        temp_df.insert(
            loc=temp_df.shape[1], column=col_, value=encoded_data[col_].values
        )

        imputer_knn_cat = imputer_knn_cat.fit(temp_df)
        temp_df = pd.DataFrame(
            np.round(imputer_knn_cat.transform(temp_df)), columns=temp_df.columns
        )
        imputed_data[col_] = encoder[col_].inverse_transform(
            np.array(temp_df[col_]).reshape(-1, 1)
        )
        imputer.update(
            {col_: {"imputer": imputer_knn_cat, "feature_cols": temp_df.columns}}
        )

    return encoder, imputer, sc, pca, imputed_data


def categorical_impute_pca_test(data, sc, pca, imputer, encoder):
    """
    This method will impute the missing values by KNN for each categorical variable on test data,\
    features are provided using pca

    Parameters
    ----------
    data : DataFrame 
        data with missing values and variables used for estimating missing values.
    imputer : dict
        e.g. {"A":{"imputer":sklearn_object, "feature_cols":["c", "d"]}, "B":{"imputer":sklearn_object,
            "feature_cols":["c"]}}
    encoder : dict
         e.g {"A":encoder}
    pca : pca object
    sc : standardisation object

    Returns
    -------
    dataframe : Modified dataframe will be returned

    """
    cat_cols = _get_cat_cols(data)
    missing_cols = list(data.columns[data.isnull().any()])
    cat_missing_cols = [i for i in cat_cols if i in missing_cols]
    num_cols = _get_num_cols(data)
    num_non_missing_cols = [i for i in num_cols if i not in missing_cols]

    # Principal components creation
    pca_df = data[num_non_missing_cols]

    pca_df = sc.transform(pca_df)

    n_components = (pca_df.shape[1] - 2) if (pca_df.shape[1] < 10) else 10
    pca_df = pd.DataFrame(
        pca.transform(pca_df), columns=pd.Series(range(1, (n_components + 1))).to_list()
    )

    # encoding
    encoded_data = data.copy()
    for col_ in cat_missing_cols:
        encoded_data[col_] = encode_test(encoded_data[col_], encoder, col_)

    # Imputation
    imputed_data = encoded_data.copy()

    for col_ in cat_missing_cols:
        temp_df = pca_df.copy()
        temp_df.insert(
            loc=temp_df.shape[1], column=col_, value=encoded_data[col_].values
        )
        imputer_knn_cat = imputer[col_].get("imputer")
        temp_df = pd.DataFrame(
            np.round(imputer_knn_cat.transform(temp_df)), columns=temp_df.columns
        )
        imputed_data[col_] = encoder[col_].inverse_transform(
            np.array(temp_df[col_]).reshape(-1, 1)
        )
        imputer.update(
            {col_: {"imputer": imputer_knn_cat, "feature_cols": temp_df.columns}}
        )

    return imputed_data
