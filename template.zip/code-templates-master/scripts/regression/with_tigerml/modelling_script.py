import importlib
from collections import defaultdict

import fsspec
import numpy as np
import pandas as pd
import yaml
from sklearn.model_selection import GridSearchCV, train_test_split

import tigerml.dataframe as td
from tigerml.automl import *
from tigerml.dp import prep_data
from tigerml.eda import Analyser
from tigerml.model_eval import RegressionReport


def load_yml(path, *, ctxt=None, **kwargs):
    """
    Read yaml file 
    """
    fs = fsspec if ctxt is None else ctxt.fs(path)
    with fs.open(path, mode="r") as fp:
        return yaml.safe_load(fp, **kwargs)


def load_class(qual_cls_name):
    """
    Load the estimator class from string specified
    """
    module_name, cls_name = qual_cls_name.rsplit(".", 1)
    try:
        mod = importlib.import_module(module_name)
    except Exception:
        logger.exception(f"Failed to import module : {module_name}")
    else:
        return getattr(mod, cls_name)


def load_dataset(path_):
    """
    Load the dataset as tiger dataset
    """
    df = td.read_csv(path_)
    return df


def score_summary(grid_searches, sort_by="mean_score"):
    """
    Compile the metrics for each model and parameters
    """

    def row(key, scores, params):
        d = {
            "estimator": key,
            "min_score": min(scores),
            "max_score": max(scores),
            "mean_score": np.mean(scores),
            "std_score": np.std(scores),
        }
        return pd.Series({**params, **d})

    rows = []
    for k in grid_searches:
        print(k)
        params = grid_searches[k].cv_results_["params"]
        scores = []
        for i in range(grid_searches[k].cv):
            key = "split{}_test_score".format(i)
            r = grid_searches[k].cv_results_[key]
            scores.append(r.reshape(len(params), 1))

        all_scores = np.hstack(scores)
        for p, s in zip(params, all_scores):
            rows.append((row(k, s, p)))

    df = pd.concat(rows, axis=1).T.sort_values([sort_by], ascending=False)

    columns = ["estimator", "min_score", "mean_score", "max_score", "std_score"]
    columns = columns + [c for c in df.columns if c not in columns]

    return df[columns]


def perform_eda(cfg_path):
    """
    Performs EDA task. 
    Takes 2 arguments, dataset path and dependent variable name
    """

    cfg = load_yml(cfg_path)
    df = load_dataset(cfg["dataset_path"])
    an = Analyser(df, y=cfg["target_column"])
    an.get_report(quick=True)


def train_model(cfg_path):
    """

    train the model by creating a pipeline that cleans data, treat outliers, 

    """
    cfg = load_yml(cfg_path)

    df = load_dataset(cfg["dataset_path"])
    x_train, x_test, y_train, y_test = prep_data(df, dv_name=cfg["target_column"])
    estimators_cfg = load_yml(cfg["estimator_config_path"])
    grid_searches = defaultdict()
    estimators = []
    param_grid = defaultdict()
    for estimator_name, estimator_ in estimators_cfg["regressors"].items():
        estimator_ = load_class(estimator_)
        params_grid = estimators_cfg["params"][estimator_name]
        print(estimator_)
        grid_search = GridSearchCV(
            estimator_(),
            param_grid=params_grid,
            cv=5,
            scoring="neg_mean_squared_error",
            return_train_score=True,
            verbose=100,
        )
        grid_search.fit(x_train, y_train)
        print(f"Best estimator : {grid_search.best_estimator_}")
        grid_searches[estimator_name] = grid_search
        report = RegressionReport(grid_search.best_estimator_)
        report.fit(x_train, y_train)
        report.score(x_test, y_test)
        report.get_report()
    summary = score_summary(grid_searches)
    summary.to_csv(cfg["output_path"], index=False)


if __name__ == "__main__":
    cfg_path = "D:/tiger_ml_package/TigerML/examples/eda/config.yml"
    # perform_eda(cfg_path)
    train_model(cfg_path)
