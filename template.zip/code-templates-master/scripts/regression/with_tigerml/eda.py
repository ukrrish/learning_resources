"""Module for conducting any EDA for the data"""
# EDA

import numpy as np
import pandas as pd

from tigerml.dp.encoder import Encoder
from tigerml.eda import Analyser, DataExplorer
from tigerml.eda.base import EDAReport
from tigerml.eda.plotters.feature_interactions.interaction import (
    CorrelationTable,
)


def check_duplicate_column(df_train, dv_name, drop_na=True):
    """Checks if the columns in a dataframe are duplicates with target encoding

    Parameters:
    -----------
    df_train: DataFrame
        training dataframe
    dv_name: str:
        target variable name
    drop_na: bool
        whether to drop the null values 
    
    Results:
    --------
    df_temp: DataFrame
        a target encoded dataframe with removed duplicate columns
    dup_cols: list
        a list of duplicate columns
    """
    df = df_train.copy()
    if drop_na:
        df = df.dropna()
    target = df[dv_name]
    X = df[list(set(df.columns) - set([dv_name]))]
    df_temp = pd.DataFrame()
    for col_ in X.columns:
        df_temp[col_] = np.round(
            Encoder.targetEncode(feature=X[col_], target=target)[0], 3
        )
    df_temp = df_temp.T.drop_duplicates().T
    df_temp[dv_name] = target
    dup_cols = set(df.columns) - set(df_temp.columns)
    if len(dup_cols):
        print("Duplicate columns are {}".format(dup_cols))
    else:
        print("There are no duplicate columns")
    return df_temp, dup_cols
