"""
Module for methods used for data prep in the project
# data read
# data clean
# data prep and processing
# outlier treatment
# missing value imputation
"""

import re

import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import FunctionTransformer

import imputations as ip
import tigerml.dataframe as tiger_dataframe
from tigerml.dp.base import DataProcessor
from tigerml.dp.binning import binning
from tigerml.dp.encoder import Encoder
from tigerml.dp.imputer import Imputer
from tigerml.dp.text import string_cleaning, string_diff
from tigerml.utils import DictObject


class DataPrep(BaseEstimator, TransformerMixin):
    """Base class that transforms the cleaning of data based on config 
    
    Parameters:
    -----------
    cfg: dict
        config dictionary that has the cleaning parameters like outlier treatments, train_test_split
    """

    def __init__(self, cfg):
        self.cfg = cfg

    def fit(self, X, y=None):
        self.func_transformed = FunctionTransformer(
            clean_data, kw_args={"cfg": self.cfg}
        )
        self.func_transformed.fit(X, y)
        return self

    def transform(self, X, y=None):
        output = self.func_transformed.transform(X)
        return output


def clean_data(df, cfg=None):
    """
    This function prepares data as required for modeling

    Parameters:
    -----------
    df: DataFrame
    cfg: dict

    Returns:
    --------
    splitting : dataframe, length=2 * len(dataframe)
    List containing train-test split of inputs.

    """
    df = df.drop_duplicates()
    dp = DataProcessor(df, y=cfg["data"]["input"]["target_column"])

    if cfg["data"]["outlier"]["handle"]:
        df = dp.handle_outliers(
            remove_outliers=cfg["data"]["outlier"]["remove"],
            impute_outliers=cfg["data"]["outlier"]["impute"],
        )
    if cfg["data"]["imputation"]["drop"]:
        df = df.dropna()
        message = "Dropped {} rows with missing values.".format(no_of_rows - len(df))
        print(message)
    if cfg["data"]["outlier"]["inf_is_outlier"]:
        df = dp.drop_inf(df)
    dp.data = df.reset_index(drop=True)
    dp.is_cleaned = True
    data = dp.data[dp.get_numeric_columns()]
    target = data[[cfg["data"]["input"]["target_column"]]]
    data = data.drop(cfg["data"]["input"]["target_column"], axis=1)
    x_train, x_test, y_train, y_test = train_test_split(
        data,
        target,
        train_size=cfg["data"]["train_test_split"]["train"],
        test_size=(1 - cfg["data"]["train_test_split"]["train"]),
        random_state=cfg["data"]["train_test_split"]["random_state"],
        shuffle=cfg["data"]["train_test_split"]["shuffle"],
    )
    return x_train, x_test, y_train, y_test


class MiceImputer(BaseEstimator, TransformerMixin):

    """Base class that imputates the missing data based on chosen methods

    Parameters:
    ----------
    num_impute_method: str
        numerical input method (mean, median, mode, mice-mean, mice-mode, mice-median, knn)
    cat_impute_method: str
        categorical input method (mode)
    num_impute_constant: str
        constant value to be filled the missing values
    cat_impute_constant: str
        constant value to be filled the missing values
    random_state: int
        set seed for reproducibility
    """

    MEAN = "mean"
    MEDIAN = "median"
    MODE = "mode"
    CONSTANT = "constant"
    REGRESSION = "regression"
    REGRESSION = "regression"

    METHODS = DictObject(
        {
            MEAN: "mean",
            MEDIAN: "median",
            MODE: "mode",
            CONSTANT: "constant",
            REGRESSION: "regression",
        }
    )

    def __init__(
        self,
        num_impute_method="mean",
        cat_impute_method="mode",
        num_impute_constant="Missing",
        cat_impute_constant="Missing",
        random_state=42,
    ):
        self.num_impute_method = num_impute_method
        self.cat_impute_method = cat_impute_method
        self.num_impute_constant = num_impute_constant
        self.cat_impute_constant = cat_impute_constant
        self.random_state = random_state
        self.imputation_rules = []

    def fit(self, X, y=None):
        imputed_data, self.imputer = ip.impute(
            X,
            self.num_impute_method,
            self.cat_impute_method,
            self.num_impute_constant,
            self.cat_impute_constant,
            self.random_state,
            self.imputation_rules,
        )
        return self

    def transform(self, X, y=None):
        X = ip.impute_transform(
            X,
            self.imputer,
            self.num_impute_method,
            self.cat_impute_method,
            self.imputation_rules,
        )
        return X


def clean_col_names(
    col_list,
    special_chars_to_keep="._,$&",
    remove_chars_in_braces=True,
    strip=True,
    lower=False,
):
    """
    Function to clean strings

    Removes special character, characters between square/
    round braces, multiple spaces, leading/tailing spaces

    Parameters:
        col_list         : list
        special_chars_to_keep : string having special characters that have to
                                be kept
        remove_chars_in_braces: Logical if to keep strings in braces.
                                e.g: "Packages (8oz)" will be "Packages"
        strip                 : True(default), if False it will not remove
                                extra/leading/tailing spaces
        lower                 : False(default), if True it will convert all
                                characters to lowercase
    Returns list
    """
    # FIXME: Handle Key Error Runtime Exception
    changed_list = []
    for col_name in col_list:
        try:
            str_value = str(col_name)
            if strip:
                # Remove multiple spaces
                str_value = re.sub(r"\s+", " ", str_value)
                # Remove leading and trailing spaces
                str_value = str_value.strip()
            if lower:
                # Convert names to lowercase
                str_value = str_value.lower()
            if remove_chars_in_braces:
                # Remove characters between square and round braces
                str_value = re.sub(r"\(.*\)|\[.*\]", "", str_value)
            else:
                # Add braces to special character list, so that they will not be
                # removed further
                special_chars_to_keep = special_chars_to_keep + "()[]"
            if special_chars_to_keep:
                # Keep only alphanumeric character and some special
                # characters(.,_-&)
                reg_str = "[^\\w" + "\\".join(list(special_chars_to_keep)) + " ]"
                str_value = re.sub(reg_str, "", str_value)
            changed_list.append(str_value)
        except AttributeError:
            print("{} datatype is not string".format(col_name))
            changed_list.append(col_name)
        except KeyError:
            print("{} name mismatch".format(col_name))
            changed_list.append(col_name)
    return changed_list

def date_features(inputdf,date_col=''):
    """
    This method adds features that are attributing by date like week_day_num, weekofmonth
    
    Input: input DataFrame, date_column
    
    Output: DataFrame with additional columns(week_day_num,weekofmonth).

    """

    inputdf['week_day_num'] = inputdf[date_col].dt.weekday+1#monday=1 and sunday =7
    inputdf['wom'] = inputdf.eval(f'({date_col}.dt.day-1) // 7 + 1')
    return inputdf
