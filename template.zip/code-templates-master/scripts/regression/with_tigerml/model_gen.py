""" Module for Generating and Building the models """
import importlib

import numpy as np
import pandas as pd
import statsmodels.api as sm
from sklearn.linear_model import Ridge
from sklearn.model_selection import (
    GridSearchCV,
    ParameterGrid,
    train_test_split,
)
from sklearn.pipeline import Pipeline
from statsmodels.stats.outliers_influence import variance_inflation_factor


def load_class(qual_cls_name):
    """Load the estimator class from string specified

    Parameters:
    -----------
    qual_cls_name: str
        str object that contains string the Class or package name

    Returns:
    --------
    Object: an object of the qual_cls_name is returned

    """
    module_name, cls_name = qual_cls_name.rsplit(".", 1)
    mod = importlib.import_module(module_name)
    return getattr(mod, cls_name)


def list_models_from_config(cfg):
    """List all combinations of models from the config

    Parameters:
    ----------
    cfg: dict
        dictonary that contains the configuration details of models

    Returns:
    --------
    models: list
        List of models along with params grid are returned
    """
    models = []
    assert cfg["models"] is not None, "No models specified in config in config"
    for algo, algo_spec in cfg["models"].items():
        _estimator = load_class(algo_spec["estimator"])
        if algo_spec["params"] is not None:
            grid_params = list(ParameterGrid(algo_spec["params"]))
            for params in grid_params:
                models.append(_estimator(**params))
        else:
            models.append(_estimator())
    return models


def get_best_model(cfg):
    """To get a gridsearch object which is used to find the best estimator using the models in config dict.

    Parameters:
    ----------
    cfg: dict
        dictonary that contains the configuration details of models

    Returns:
    --------
    gridsearch_models: GridsearchCV model that needs to be fit to get best model
    """
    pipe = Pipeline(steps=[("estimator", Ridge())])

    # Add a dict of estimator and estimator related parameters in this list
    params_grid = []
    for algo, algo_spec in cfg["models"].items():
        estimator_dict = {}
        _estimator = load_class(algo_spec["estimator"])
        estimator_dict.update({"estimator": [_estimator()]})
        if algo_spec["params"] is not None:
            for spec_ in algo_spec["params"]:
                estimator_dict.update(
                    {f"estimator__{spec_}": sorted(list(algo_spec["params"][spec_]))}
                )
        params_grid.append(estimator_dict)

    grid = GridSearchCV(
        pipe,
        params_grid,
        cv=5,
        scoring=cfg["scoring"],
        return_train_score=True,
        verbose=100,
    )
    return grid


def calc_vif(X):
    """This function finds the multicollinearity between X variables using variance inflation factor

    Parameters:
    -----------
    X : DataFrame
        Train DataFrame

    Returns:
    --------
    vif: DataFrame
        A dataframe that contains the variables and their inflation factor with each of other variables
    """
    # Calculating VIF
    vif = pd.DataFrame()
    vif["variables"] = X.columns
    vif["VIF"] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]

    return vif


def load_linear_model(x_train, y_train):
    """Fits a Linear Regression Model
    Parameters:
    -----------
    x_train: DataFrame
        exogenous variables to train
    y_train: Series
        endogenous variables to train

    Results:
    --------
    print_model: statsmodel summary
    """
    model = sm.OLS(np.array(y_train), x_train).fit()
    predictions = model.predict(x_train)
    print_model = model.summary()
    return print_model
