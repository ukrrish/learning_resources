import fsspec
import yaml


def load_yml(path, *, ctxt=None, **kwargs):
    """
    Read yaml file 
    """
    fs = fsspec if ctxt is None else ctxt.fs(path)
    with fs.open(path, mode="r") as fp:
        return yaml.safe_load(fp, **kwargs)
