# Imports
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive

# Authorising Drive API Access 
gauth = GoogleAuth()
gauth.LoadCredentialsFile("token.txt")

if gauth.credentials is None:
    # Authenticate if they're not there
    gauth.LocalWebserverAuth()
elif gauth.access_token_expired:
    # Refresh them if expired
    gauth.Refresh()
else:
    # Initialize the saved creds
    gauth.Authorize()
# Save the current credentials to a file
gauth.SaveCredentialsFile("token.txt")

drive = GoogleDrive(gauth)


# ID of the file to be updated
file_id = "1-x3K8Uhdqupg3y-xQDLUSuw7ciHsJiMo"

# path of the file in local to be uploaded to gdrive
path_to_file = r"C:\Users\saikrishna.kallu\Documents\TA\Repos\code-templates\scripts\code_archive\classification-py.zip"
file_name = "classification-py.zip"

# creating file object and assigning file params 
file = drive.CreateFile()
file['id'] = file_id
file['title'] = file_name
file.SetContentFile(path_to_file)
file.Upload()