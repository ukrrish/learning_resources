
# Pre-requisites

* Make sure you have the following packages in the conda environment google-api-core-1.23.0 google-api-python-client-1.12.4 google-auth-httplib2-0.0.4 googleapis-common-protos-1.52.0 httplib2-0.18.1 uritemplate-3.0.1 oauth2client-4.1.3 pydrive-1.3.1


# Enabling Google Drive API and Generation of Token

* As instructed in the following link https://developers.google.com/drive/api/v3/quickstart/python
	- Click on `Enable the Drive API`
	- Give a name to to the project.
	- In the dropdown box that appears, select the option of Desktop App and click on Create.
	- Download the client configurations. This should download a credentials.json in your system. Please rename it to client_secrets.json and place it in the working directory (code_archive -> scripts -> automatic_upload_to_gdrive folder in our scenario)
* In sample_test.py, update the path to the local file that you want to upload to Google drive
* Run sample_test.py to make sure the gdrive api integration is working.
    - While running for the first time, a browser pops up so as to login to google and authenticate this API.
    - This generates a `token.txt` file, This token will be valid for 1 hour and post that re-authentication is required.
    - This creds.txt file can be leveraged to upload files into g-drive. 