# Introduction

This is a reference code for writing test cases for python scripts.


# Pre-requisites

* Ensure you have `Miniconda` installed and can be run from your shell. If not, download the installer for your platform here: https://docs.conda.io/en/latest/miniconda.html

     **NOTE**
     
     * If you already have `Anaconda` installed, pls. still go ahead and install `Miniconda` and use it for development. 
     * If `conda` cmd is not in your path, you can configure your shell by running `conda init`. 


# Getting started

* [Download the repo from gdrive](https://drive.google.com/file/d/1E3zYxlwqNmahnZsdXCVEwZLaQWfJyr1q/view?usp=sharing), unzip and switch to the root folder

* Setup a development environment and switch to it by running:
```
(base):~/$ conda env create -f environment.yml 
(base):~/$ conda activate testcase-dev
```

The above command should create a conda python environment named `testcase-dev` 

In case of installation issues, remove and recreate. You can remove by running:
```
(base):~/code-templates$ conda remove --name testcase-dev --all -y
```


# Code and related Test cases

* Code that has to be testes is present in  `tsttemplate/analysis.py`
* Module level unit test cases can be present as ``tests`` in project level or with codes in  package level. Here we created Project level unit test cases as present in `tests/unittests/tsttemplate/test_analysis.py`
* Modules to generate synthetic data are present in `test_data` directory. If we have light weight data, they can also be placed in this directory.
* Pytest package provides wide range of utitlities to test our functions. Pytest recommends to have `test` as prefix for test modules and `test` for test functions.

# Running Test cases

* We can run all the test cases present in the test folder by using pytest command:
```
(testcase-dev):~/tests/unittests/tsttemplate$ pytest -v
```

* To run a specific test case or function:
```
(testcase-dev):~/tests/unittests/tsttemplate$ pytest -v <test_module>.py::<test_function>
```
Example:
```
(testcase-dev):~/tests/unittests/tsttemplate$ pytest -v test_analysis.py::test_string_cleaning
```

# More on Testing using Pytest and Hypothesis

Pytest package provides handy utilities to ease the complexity of writing test cases
    
* **Fixtures**

To prevent repeating code in your unit tests we use fixtures from pytest
When creating these test cases we often want to run some code before every test case. Instead of repeating the same code in every test, we create fixtures that establish a baseline code for our tests.


* **Parametrize**

We can run multiple test cases with Parametrize
If we want to test for many different scenarios it would cumbersome to create many duplicates of a test. To prevent that, we can use Pytest’s parametrize function.
Parameterize extends a test function by allowing us to test for multiple scenarios. We simply add the parametrize decorator and state the different scenarios.

This is demonstrated in `tests/unittests/tsttemplate/test_analysis.py`


Similarly Hypothesis is also a widely used package with handy decorators and functions

* When we are not sure on different possibilities of data to test, we can make use of `strategies` to generate synthetic data to test. This is demonstrated in `tests/unittests/tsttemplate/test_analysis.py`

* Another widely used feature of Hypothesis is `given` decorator used to specify which arguments of a function should be parametrized over. The use of this decorator is demonstrated in `tests/unittests/tsttemplate/test_analysis.py`.


### References
Go through the links below for more detailed test case generation:
1. [Getting started testing with pytest](https://nedbatchelder.com/blog/202002/getting_started_testing_with_pytest.html)
2. [More on testing with hypothesis](https://hypothesis.readthedocs.io/en/latest/index.html)
3. [Sklearn provides built-in test cases to test Estimators, Transformers]( `<)https://scikit-learn.org/stable/modules/generated/sklearn.utils.estimator_checks.check_estimator.html)