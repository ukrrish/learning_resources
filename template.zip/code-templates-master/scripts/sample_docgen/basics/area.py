def print_pattern(n=5):
    """Prints n patterns in the screen based on th euser input of value ``n``.

    Args:
        n (int, optional): Integer number representing number of lines to be printed in a pattern.::
        
            If n=3 it will print,
                 * 
                 ** 
                 *** 
            If n=4, it will print,
                *
                **
                ***
                ****

    .. note::
        
        Default value for n is 5. So if function caller doesn't supply the input number then it will assume it to be 5
    
    :return: None. 
    """    
    # we need to run two for loops. Outer loop prints patterns line by line
    # where as inner loop print the content of that specific lines
    for i in range(n):
        s = ''
        for j in range(i+1):
            s = s + '*'
        print(s)

def calculate_area(dimension1,dimension2,shape="triangle"):
    """Calculate the area of either triangle or rectangle using the dimensions specified.

    Args:
        dimension1 (int/float): In case of triangle it is **base**. For rectangle it is **length**.

        dimension2 (int/float): In case of triangle it is **height**. For rectangle it is **width**.
        
        shape (str, optional): Either **triangle** or **rectangle**. Defaults to "triangle".

    Returns:
        float: Area of the shape
    """    
    if shape=="triangle":
        area=1/2*(dimension1*dimension2) # Triangle area is : 1/2(Base*Height)
    elif shape=="rectangle":
        area=dimension1*dimension2 # Rectangle area is: Length*Width
    else:
        print("***Error: Input shape is neither triangle nor rectangle.")
        area=None # If user didn't supply "triangle" or "rectangle" as shape then return None
    return area