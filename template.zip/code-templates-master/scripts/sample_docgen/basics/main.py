""" The main Module makes a function call to the ``area`` module using the functioin calls

- `calculate_area(base,height,"triangle")`
- `calculate_area(length,width,"rectangle")`
- `calculate_area(base,height)`
- `print_pattern(3)`

"""
from area import calculate_area, print_pattern

if __name__ == "__main__":
    print("I am in area.py")
    # ------------------ Shape area exercise ------------------------- #
    # Calculate area of triangle whose base is 10 and height is 5
    base=10
    height=5
    triangle_area=calculate_area(base,height,"triangle")
    print("Area of triangle is:",triangle_area)

    # Calculate area of a rectangle whose length is 20 and width is 30
    length=20
    width=30
    rectangle_area=calculate_area(length,width,"rectangle")
    print("Area of rectangle is:",rectangle_area)

    # Calculate area of a triangle without supplying shape argument in a function call
    triangle_area=calculate_area(base,height) # Here third argument is missing
    print("Area of triangle with no shape supplied: ",triangle_area)

    # -------------------- Pattern exercise ------------------------- #
    print("Print pattern with input=3")
    print_pattern(3)
    print("Print pattern with input=4")
    print_pattern(4)
    print("Print pattern with no input number")
    print_pattern() # Not supplying any input will use default argument which is 5