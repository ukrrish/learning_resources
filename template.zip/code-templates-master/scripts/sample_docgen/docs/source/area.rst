area module
===========

.. automodule:: area
   :members:
   :undoc-members:
   :show-inheritance:
