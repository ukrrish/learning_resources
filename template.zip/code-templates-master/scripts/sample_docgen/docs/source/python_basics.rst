**********************************
Getting started with Python Basics
**********************************

This project Python Code Basics aims at developing simple and easy to understand code in the language of python.
These code snippets will help you to get familiarised with the usual syntax used in the Python language.

Following are the two functions that we have developed in Python

    - Calculate the area of triangle/rectangle
    - Generate visual patterns using number sequence

Calculate the area of triangle/rectangle
========================================

In  this function we take three input parameters that includes the dimension of the shape and the shape type.
The Shape type here can be either ``rectangle`` or ``triangle``

.. code-block:: python  
    :emphasize-lines: 3, 5
    :linenos:
    :caption: Code to calculate the area of triangle or rectangle.

    def calculate_area(dimension1,dimension2,shape="triangle"):

        if shape=="triangle":
            area=1/2*(dimension1*dimension2) # Triangle area is : 1/2(Base*Height)
        elif shape=="rectangle":
            area=dimension1*dimension2 # Rectangle area is: Length*Width
        else:
            print("***Error: Input shape is neither triangle nor rectangle.")
            area=None # If user didn't supply "triangle" or "rectangle" as shape then return None
        return area
    
From the code block we see that this code takes necessary input parameters like dimensions and calculates
the area using simple **mathematical formula**.

Pattern Generation
==================

In this function, we print patterns in the console by taking the number of lines as an input from the user.
The number of lines is to generate patterns till :abbr:`n (number of lines)`.

.. literalinclude:: ../../basics/area.py
    :language: python
    :lines: 1, 25-29
    :caption: Code to generate patterns

From the code, we see that the pattern is generated using `asterisk` symbol. Instated, we can choose to use a differnet symbol
or apply necessary indentation in the pattern to make it look more aesthetically pleasing.