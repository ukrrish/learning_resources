# Imports
import os
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive


def refresh_token(path):
	"""Authenticate and refresh the token."""
	gauth = GoogleAuth()
	gauth.LoadCredentialsFile(path)

	if gauth.credentials is None:
	    # Authenticate if they're not there
	    gauth.LocalWebserverAuth()
	elif gauth.access_token_expired:
	    # Refresh them if expired
	    gauth.Refresh()
	else:
	    # Initialize the saved creds
	    gauth.Authorize()
	# Save the current credentials to a file
	gauth.SaveCredentialsFile(path)

def create_drive_client(path):
	"""Generate the drive client using the token in the path provided."""
	refresh_token(path)
	gauth = GoogleAuth()
	gauth.LoadCredentialsFile(path)
	gauth.Authorize()
	drive = GoogleDrive(gauth)
	return drive

def upload_file(client, local_path, gdrive_file_id, target_file_name=None):
	"""Upload/Update a local file into gdrive.

	Parameters
	----------
	client : pydrive.drive.GoogleDrive
		Authenticated Drive Object Client
	local_path : str
		Location of the file in the local filesystem to be uploaded to gdrive
	gdrive_file_id: str
		Alphanumeric unique file id for the file to be uploaded in the gdrive.

		Generally present in the shared link https://drive.google.com/file/d/<fileid>/view?usp=sharing 
	target_file_name: str
		new name for the file to be updated.
		By default filename of the local file is considered.

	Returns
	-------
		None
	"""
	file = client.CreateFile()
	file['id'] = gdrive_file_id
	if target_file_name:
		file['title'] = target_file_name
	file.SetContentFile(local_path)
	file.Upload()