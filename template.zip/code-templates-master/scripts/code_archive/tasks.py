import os
import os.path as op
import platform
import shutil
import time
from contextlib import contextmanager
from itertools import product

import fsspec
import jinja2

from constants import (
    ADD_ON,
    CONFIG,
    CONFIG_TEMPLATES,
    LOCK,
    NUM_RETRIES,
    OS_KEYS,
    PACKAGE_NAME,
    REMOVE_FILES,
    REMOVE_FILES_SPARK,
    SLEEP_TIME,
    TEMPLATE_PACKS,
    CODE_TEMP_BRANCH,
)
from gdrive_utils import upload_file, create_drive_client

from invoke import Collection, task
from ta_lib.core.utils import create_yml, load_yml

# Some default values
OS = platform.system().lower()
ENV_PREFIX = "ta-lib"
ARCH = platform.architecture()[0][:2]
PLATFORM = f"{OS}-cpu-{ARCH}"
DEV_ENV = "dev"  # one of ['dev', 'run', 'test']

HERE = op.dirname(op.abspath(__file__))
SOURCE_FOLDER = op.join(HERE, PACKAGE_NAME)
DEV_CONDA_PATH = op.join(HERE, "..", "..", "deploy", "conda_envs")
DEV_MASTER_YML = op.join(HERE, DEV_CONDA_PATH, "master.yml")
_TASK_COLLECTIONS = []


def _get_env_name(platform, env):
    # FIXME: do we need platform ?
    return f"{ENV_PREFIX}-{env}"


@contextmanager
def py_env(c, env_name):
    """Activate a python env while the context is active."""
    # FIXME: This works but takes a few seconds. Perhaps find a few to robustly
    # find the python path and just set the PATH variable ?
    if OS == "windows":
        # we assume conda binary is in path
        cmd = f"conda activate {env_name}"
    else:
        cmd = f'eval "$(conda shell.bash hook)" && conda activate {env_name}'
    with c.prefix(cmd):
        yield


def _create_task_collection(name, *tasks):
    """Construct a Collection object."""
    coll = Collection(name)
    for task_ in tasks:
        coll.add_task(task_)
    _TASK_COLLECTIONS.append(coll)
    return coll


def _create_root_task_collection():
    return Collection(*_TASK_COLLECTIONS)


@contextmanager
def tmp_dir():
    import tempfile

    tmp_folder = tempfile.TemporaryDirectory()
    try:
        yield tmp_folder.name
    finally:
        cleaned = False
        for _try in range(NUM_RETRIES):
            try:
                tmp_folder.cleanup()
            except Exception as e:
                time.sleep(SLEEP_TIME)
                print(f"Temp Directory Clean failed :: Retrying .. {e}")
                continue
            cleaned = True
            print("Temp Directory Clean Success")
            break
        if not cleaned:
            print(f"Temp Directory Clean failed after {NUM_RETRIES} tries")


@task(name="create-archive")
def _create_code_archive(c, template="regression-py", force=False):
    """Create template archive.

    Parameters
    ----------
    template: name of the template / usecase.
    force: bool, default False.
        * If True, existing template is overwritten.
        * If False, doesn't override & fails if template exists.

    Returns
    -------
    Archive is generated in ./code-archives/<template>
    """
    if template not in CONFIG_TEMPLATES.keys():
        raise ValueError(
            f"template should be one of: {', '.join(CONFIG_TEMPLATES.keys())}"
        )
    code_path = op.join(HERE, "code-archives", template)
    cleanup = (os.path.exists(code_path)) and force
    if cleanup:
        _clean_rmtree(code_path)
        os.makedirs(code_path)
    else:
        _change_permissions_recursive(code_path, 0o777)
    _clone_code(c, template=template, code_path=code_path, force=force)
    _adjust_layout(c, code_path=code_path, template=template)


@task(name="build-docker")
def _build_docker_image(c, platform=PLATFORM, template="regression-py"):
    docker_file = op.join(HERE, "docker", "Dockerfile")
    if template == "regression-py":
        tag = "ct-reg-py"
    elif template == "classification-py":
        tag = "ct-class-py"
    else:
        raise ValueError(f"Unknown template : {template}")

    build_context = op.join(HERE, "code-archives", template)
    c.run(f"docker build -f {docker_file} -t {tag} {build_context}")


def _change_permissions_recursive(path, mode):
    for root, dirs, files in os.walk(path, topdown=False):
        for _dir in [os.path.join(root, d) for d in dirs]:
            os.chmod(_dir, mode)
        for _file in [os.path.join(root, f) for f in files]:
            os.chmod(_file, mode)


def _clean_rmtree(path):
    for _try in range(NUM_RETRIES):
        try:
            _change_permissions_recursive(path, 0o777)
            shutil.rmtree(path)
        except Exception as e:
            time.sleep(SLEEP_TIME)
            print(f"{path} Remove failed with error {e}:: Retrying ..")
            continue
        print(f"{path} Remove Success")
        break


# ---------
# Dev tasks
# ---------
@task(name="clone")
def _clone_code(c, template="regression-py", code_path=None, force=False):
    if code_path is None:
        code_path = op.join(HERE, "code-archives", "test", "code-templates")

    # FIXME: cleanup the logic and move hardcoded stuff to config
    cleanup = (os.path.exists(code_path)) and force
    if cleanup:
        _clean_rmtree(code_path)
        os.makedirs(code_path)
    else:
        _change_permissions_recursive(code_path, 0o777)
    # clone code-templates repo
    # FIXME: this assume git binary to be avlb. instead use GIT REST API
    c.run(
        f"git clone --single-branch --branch {CODE_TEMP_BRANCH} https://{os.environ['GITHUB_OAUTH_TOKEN']}@github.com/tigerrepository/code-templates {code_path}"
    )

    vendor_repos = CONFIG["vendor_repos"]
    if CONFIG_TEMPLATES[template]["vendor_repos"] is not None:
        vendor_repos = vendor_repos + CONFIG_TEMPLATES[template]["vendor_repos"]

    if "spark" in template:
        vendor_repos = []

    for vendor_repo in vendor_repos:
        with tmp_dir() as tmp_folder:
            c.run(
                f"git clone --single-branch --branch {vendor_repo['branch']} https://{os.environ['GITHUB_OAUTH_TOKEN']}@github.com/{vendor_repo['repo']} {tmp_folder}"
            )
            src_folder = op.join(tmp_folder, vendor_repo["src_folder"])
            tgt_folder = op.join(
                code_path, "src", "ta_lib", "_vendor", vendor_repo["package_name"]
            )
            if op.exists(tgt_folder) and force:
                _clean_rmtree(tgt_folder)
            shutil.copytree(src_folder, tgt_folder)
            with open(op.join(tgt_folder, "__init__.py"), "w") as fp:
                pass
            print(vendor_repo["repo"], " Vendor Clone Done")


def consolidate_configs(cfg):
    cfg_dicts = [i for i in cfg["dependencies"] if type(i) is dict]
    cfg_channnels = list(set(cfg["channels"]))
    result_dict = {}
    for cfg_dict in cfg_dicts:
        key_ = list(cfg_dict.keys())[0]
        value_ = list(cfg_dict.values())[0]
        if key_ in result_dict.keys():
            if value_ not in result_dict.values():
                result_dict[key_] = result_dict[key_] + value_
        else:
            result_dict[key_] = value_
    cfg_non_dicts = [i for i in cfg["dependencies"] if type(i) is not dict]
    cfg["channels"] = cfg_channnels
    cfg["dependencies"] = cfg_non_dicts + ([result_dict] if bool(result_dict) else [])
    return cfg


def get_list(x):
    if type(x) == dict:
        return [x]
    else:
        if x is None:
            return []
        else:
            return x


def merge_dependencies(config_list):
    final_dict = {"channels": [], "dependencies": []}
    for dict_ in config_list:
        if dict_ is not None:
            final_dict.update(
                {"channels": final_dict.get("channels") + get_list(dict_["channels"])}
            )
            final_dict.update(
                {
                    "dependencies": final_dict.get("dependencies")
                    + get_list(dict_["dependencies"])
                }
            )
    final_dict = consolidate_configs(final_dict)
    return final_dict


def generate_lock(c, src_path, OS="windows", platform=PLATFORM, env=DEV_ENV):
    """Generate Lock file from yaml file."""
    env_name = _get_env_name(platform, env)
    yml_file_dir = op.dirname(op.abspath(op.join(src_path)))
    with py_env(c, env_name):
        c.run(f"conda-lock -f {src_path} -p {LOCK[OS]}-64")
        conda_src_path = op.join(HERE, f"conda-{LOCK[OS]}-64.lock")
        conda_tgt_path = op.join(yml_file_dir, f"{OS}-cpu-64-dev.lock")
        shutil.move(conda_src_path, conda_tgt_path)
        # if os.path.exists(conda_src_path):
        #     _clean_rmtree(conda_src_path)


def generate_requirements(src_path, OS="windows", fs=None):
    """Generate pip requirements file."""
    cfg = load_yml(src_path)
    yml_file_dir = op.dirname(op.abspath(op.join(src_path)))
    pip_requirements = [i for i in cfg.get("dependencies") if type(i) == dict]
    fs = fs or fsspec.filesystem("file")
    if len(pip_requirements):
        with fs.open(
            op.join(yml_file_dir, f"requirements-{OS}-cpu-64-dev.txt"), "w"
        ) as req:
            req.write("\n".join(pip_requirements[0].get("pip")))
    else:
        if op.exists(op.join(yml_file_dir, f"requirements-{OS}-cpu-64-dev.txt")):
            os.remove(op.join(yml_file_dir, f"requirements-{OS}-cpu-64-dev.txt"))


@task(name="gen-env-ymls")
def _create_env_yaml_dev(c, path=DEV_CONDA_PATH, template=""):
    """Create separate yamls files from master yaml.

    Yamls created for linux, windows and addons will be overwritten when creating code-archives.

    Parameters
    ----------
    path: str, Default = DEV_CONDA_PATH
        Folder that contains master yml file.
    template: str, Default =  "".
        Name of code-archive to generate yamls.

    """
    master_yml = op.join(path, "master.yml")
    cfg = load_yml(master_yml)

    key_cores = ["core"]

    if template == "":
        template_list = key_cores + TEMPLATE_PACKS + ADD_ON
    else:
        template_list = key_cores + [template]

    windows_yml = []
    linux_yml = []

    # Generate ymls for each of the templates specific to OS
    for temp in template_list:
        if temp in cfg.keys() and cfg.get(temp) is not None:
            for yml in OS_KEYS:
                if yml == "windows":
                    if cfg[temp].get(yml) is not None:
                        windows_yml.append(cfg[temp].get("windows"))
                elif yml == "linux":
                    if cfg[temp].get(yml) is not None:
                        linux_yml.append(cfg[temp].get("linux"))
                elif yml == "common-os":
                    windows_yml.append(cfg[temp].get("common-os"))
                    linux_yml.append(cfg[temp].get("common-os"))

    cfg_windows = merge_dependencies(windows_yml)
    cfg_linux = merge_dependencies(linux_yml)
    win_path = op.join(path, "windows-cpu-64-dev.yml")
    lin_path = op.join(path, "linux-cpu-64-dev.yml")

    create_yml(win_path, cfg_windows)
    generate_lock(c, win_path, "windows")
    generate_requirements(win_path, OS="windows", fs=None)
    create_yml(lin_path, cfg_linux)
    generate_lock(c, lin_path, "linux")
    generate_requirements(lin_path, OS="linux", fs=None)

    # generate ymls for each of add-on packages specific to OS for templates
    if template != "":
        for add_on, os_ in product(ADD_ON, ["windows", "linux"]):
            add_on_dict = []
            if os_ in cfg[add_on].keys():
                add_on_dict.append(cfg[add_on][os_])
            add_on_dict.append(cfg[add_on]["common-os"])
            cfg_addon = merge_dependencies(add_on_dict)
            create_yml(op.join(path, f"{add_on}-{os_}-cpu-64-dev.yml"), cfg_addon)


@task(name="fix-layout")
def _adjust_layout(c, template="regression-py", code_path=""):
    if code_path is None:
        code_path = op.join(HERE, "code-archives", "test", "code-templates")

    CONFIG_TEMPLATE = CONFIG_TEMPLATES[template]
    CONFIG_TEMPLATE.update(CONFIG)
    CONFIG_TEMPLATE.pop("vendor_repos", None)
    for key_, val_ in CONFIG_TEMPLATE.items():
        CONFIG_TEMPLATE[key_] = val_.format(**CONFIG_TEMPLATE)

    if "spark" in template:
        remove_files = REMOVE_FILES_SPARK[:]
    else:
        remove_files = REMOVE_FILES[:]
        remove_files.remove(("scripts", ""))
        remove_files.append((CONFIG_TEMPLATE["docker"], "deploy/docker"))
        remove_files.append(("scripts", ""))
        master_yml = op.join(code_path, "deploy", "conda_envs")
        _create_env_yaml_dev(c, master_yml, template)

    # remove unnecessary files
    remove_files.append((CONFIG_TEMPLATE["notebooks"], "notebooks/reference"))
    remove_files.append((CONFIG_TEMPLATE["production"], "production"))

    # remove tpo for classification and regression
    if template != "tpo-py":
        remove_files.append(("src/ta_lib/tpo", ""))

    # delete source usecases
    usecases = ["regression", "classification", "tpo", "rtm"]
    code_blocks = ["production", "notebooks"]
    for i in code_blocks:
        for j in usecases:
            remove_files.append((i + "/" + j, ""))

    for src_path, tgt_path in remove_files:
        src_path = op.join(code_path, src_path)
        if not op.exists(src_path):
            print(f"Skipped. Path not found : {src_path}")
            continue

        is_folder = not op.isfile(src_path)
        if tgt_path == "":
            # delete the file/folder
            if is_folder:
                _clean_rmtree(src_path)
            else:
                os.remove(src_path)
            print(f"Deleted : {src_path}")
        else:
            tgt_path = op.join(code_path, tgt_path)
            if is_folder:
                with tmp_dir() as tmp_folder:
                    tmp_folder_tgt = os.path.join(tmp_folder, "tgt_path")
                    shutil.copytree(src_path, tmp_folder_tgt)
                    if os.path.exists(tgt_path):
                        _clean_rmtree(tgt_path)
                    shutil.copytree(tmp_folder_tgt, tgt_path)
            else:
                if src_path.endswith(".j2"):
                    with open(src_path) as fp:
                        tmpl = fp.read()
                    out = jinja2.Template(tmpl).render(**CONFIG_TEMPLATE)
                    with open(tgt_path, "w") as fp:
                        fp.write(out)
                else:
                    shutil.copyfile(src_path, tgt_path)

    if "spark" in template:
        with open(op.join(code_path, "src", "ta_lib", "__init__.py"), "w") as fp:
            pass

@task(name="format-shell")
def _format_stuff(c):
    code_path = op.join(HERE, "code-archives", "test", "code-templates")
    py_lib_name = CONFIG["py_lib_name"]
    py_pkg_name = CONFIG["py_lib_name"].replace("_", "-")
    c.run(f'rg -l ta_lib {code_path}/*| xargs sed -i "s/ta_lib/{py_lib_name}/g"')
    c.run(f'rg -l ta-lib {code_path}/*| xargs sed -i "s/ta_lib/{py_pkg_name}/g"')


@task(name="format-py")
def _format_code(c):
    from rope.base.project import Project
    from rope.base import libutils
    from rope.refactor.rename import Rename

    code_path = op.join(HERE, "code-archives", "test", "code-templates")
    proj = Project(code_path)

    # rename pkg
    res = libutils.path_to_resource(proj, op.join(code_path, "ta_lib"))
    changes = Rename(proj, res).get_changes("ta_lib")
    changes.do()


@task(name="zip-archive")
def _create_zip_file(
    c, code_path=None, template="regression-py", archive_name=None, format=zip
):
    """Zip archive files."""
    if code_path is None:
        code_path = op.join(HERE, "code-archives", template)
    else:
        code_path = op.join(code_path + template)

    import shutil

    if archive_name is None:
        archive_name = template

    shutil.make_archive(archive_name, "zip", code_path)


@task(name="format-nb")
def _format_notebook(c):
    # change lib name
    pass


@task(name="upload-archive")
def _upload_code_archive(
    c,
    template="regression-py",
    archive_path=None,
    archive_gdrive_id=None,
    archive_name=None,
    token_fl_path=None,
):
    """Upload the Archive Path into Google Drive.
    """
    if archive_path is None:
        archive_path = template + ".zip"

    if archive_name is None:
        archive_name = template + ".zip"

    if archive_gdrive_id is None:
        archive_gdrive_id = CONFIG_TEMPLATES[template]["gdrive_id"]

    if token_fl_path is None:
        token_fl_path = "token.txt"

    drive = create_drive_client(token_fl_path)
    upload_file(
        client=drive,
        local_path=archive_path,
        gdrive_file_id=archive_gdrive_id,
        new_file_name=archive_name,
    )


_create_task_collection(
    "dev",
    _create_code_archive,
    _adjust_layout,
    _format_code,
    _format_code,
    _format_notebook,
    _format_stuff,
    _create_env_yaml_dev,
    _create_zip_file,
    _build_docker_image,
    _upload_code_archive,
)

# --------------
# Root namespace
# --------------
# override any configuration for the tasks here
# FIXME: refactor defaults (constants) and set them as config after auto-detecting them
ns = _create_root_task_collection()
config = dict(pty=True, echo=True)

if platform == "windows":
    config["pty"] = False

ns.configure(config)
