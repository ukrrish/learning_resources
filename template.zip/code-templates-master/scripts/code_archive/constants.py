import os

PACKAGE_NAME = "ta_lib"
NUM_RETRIES = 10
SLEEP_TIME = 1

CODE_TEMP_BRANCH = 'master'

CONFIG = {
    "py_lib_name": "ta_lib",
    "author": "Tiger Analytics",
    "env": "deploy/conda_envs/",
    "notebooks": "notebooks/{usecase}/{sub_dir}",
    "production": "production/{usecase}/{sub_dir}",
    "docker": "scripts/code_archive/docker",
    "vendor_repos": [
        {"repo": "tigerrepository/TigerML", "branch": "master",  "src_folder": os.path.join("python","tigerml"), "package_name": "tigerml"}
    ],
}

CONFIG_TEMPLATES = {
    "regression-py": {
        "project_name": "Sales price prediction",
        "project_description": "Use regression to predict price of electronic devices",
        "usecase": "regression",
        "sub_dir": "python",
        "vendor_repos": None,
        "gdrive_id":"15hpWCbIiOtnaZ97O1apC6SGZAPiWPxzS"
    },
    "classification-py": {
        "project_name": "Churn prediction",
        "project_description": "Use classification to predict the event of attrition/churn for a customer",
        "usecase": "classification",
        "sub_dir": "python",
        "vendor_repos": None,
        "gdrive_id":"1Rirm-K-U-RZkHldSof26bwylaaCqIl4D"
    },
    "classification-pyspark":{
        "project_name": "Travel Booking Prediction",
        "project_description": "Use classification in pyspark to predict if a customer will book in the next 3 months",
        "usecase": "classification",
        "sub_dir": "pyspark",
        "vendor_repos": None,
        "gdrive_id": "1miNKALQk0jEOwkRzzoQ_DzSrlP3wx5Ib"
    },
    "regression-pyspark":{
        "project_name": "Regression Pyspark",
        "project_description": "Regression Pyspark",
        "usecase": "regression",
        "sub_dir": "pyspark",
        "vendor_repos": None,
        "gdrive_id": "1V95bo9FRX3wfssQXny-PEm1PgCv2UITH"
    },
    "tpo-py": {
        "project_name": "Trade Promo Optimization",
        "project_description": "Use elasticity model and optimization techniques to generate promotional calendar to optimize sales for the next calendar month/ quarter / year",
        "usecase": "tpo",
        "sub_dir": "python",
        "vendor_repos": [
            {
                "repo": "tigerrepository/BayesianLearning", "branch": "master", "src_folder": "BayesFramework", "package_name": "BayesFramework"
            }
        ],
        "gdrive_id":"1jSg-_y5sk9_BPyqvDNY1k0nCQPfmEShh"
    }
    ,
    "rtm-py": {
        "project_name": "Route To Market",
        "project_description": "Use regression to get the contribution of each visits",
        "usecase": "rtm",
        "sub_dir": "python",
        "vendor_repos": None,
        "gdrive_id": "16QPA5BQeAkJbNxpQ2qdNTQlFqEOr-y-5"
    }
}

OS_KEYS = ["common-os", "windows", "linux"]
TEMPLATE_PACKS = ["regression-py", "classification-py", "rtm-py", "tpo-py", "classification-pyspark", "regression-pyspark"]
ADD_ON = [
    "addon-documentation",
    "addon-testing",
    "addon-code_format",
    "addon-jupyter",
    "addon-extras",
]

LOCK = {"windows": "win", "linux": "linux"}

REMOVE_FILES = [
    # delete existing files/folders
    ("README.md", ""),
    ("scripts", ""),
    ("docs", ""),
    ("tests", ""),
    ("tigerml", ""),
    ("deploy/ipython", ""),
    ("deploy/pip", ""),
    (".git", ""),
    (".github", ""),
    (".readthedocs.yml", ""),
    ("notebooks/tests", ""),
    ("src/ta_lib/_vendor/__init__.py", ""),
    ("src/ta_lib/_vendor/tigerml-recipe", ""),
    ("src/ta_lib/_vendor/deploy_conda.sh", ""),
    ("src/ta_lib/_vendor/dev-conda-config.sh", ""),
    ("src/ta_lib/_vendor/dev-env.yml", ""),
    ("src/ta_lib/_vendor/env.yml", ""),
    ("src/ta_lib/_vendor/MANIFEST.in", ""),
    ("src/ta_lib/_vendor/panel-test.yml", ""),
    ("src/ta_lib/_vendor/README.md", ""),
    ("src/ta_lib/_vendor/requirements.txt", ""),
    ("src/ta_lib/_vendor/setup.py", ""),
    ("src/ta_lib/conf", ""),
    # cp any files/folders to new location
    ("deploy/code_gen/README.md.j2", "README.md"),
    # ('ta_lib', CONFIG["py_lib_name"]),
    # delete any old folders after copying
    ("deploy/conda_envs/master.yml", ""),
    ("deploy/conda_envs/linux-cpu-64-ci.yml", ""),
    ("deploy/conda_envs/linux-cpu-64-ci.lock", ""),
    ("deploy/conda_envs/requirements-linux-cpu-64-ci.txt", ""),
    ("deploy/code_gen", ""),
    ("deploy/pyspark", ""),
    ("src/ta_lib/pyspark", ""),
]

REMOVE_FILES_SPARK = [
    # delete existing files/folders
    ("deploy/ipython", ""),
    ("deploy/pip", ""),
    ("deploy/conda_envs", ""),
    ("deploy/code_gen", ""),
    ("README.md", ""),
    ("scripts", ""),
    ("docs", ""),
    ("tests", ""),
    (".git", ""),
    (".github", ""),
    (".readthedocs.yml", ""),
    ("tasks.py", ""),
    ("artifacts", ""),
    ("data",""),
    ("docs",""),
    ("logs",""),
    ("notebooks/tests", ""),
    ("src/ta_lib/classification", ""),
    ("src/ta_lib/conf", ""),
    ("src/ta_lib/core", ""),
    ("src/ta_lib/data_processing", ""),
    ("src/ta_lib/eda", ""),
    ("src/ta_lib/regression", ""),
    ("src/ta_lib/tpo", ""),
    ("src/ta_lib/reports", ""),
    ("src/ta_lib/__init__.py", ""),
    ("src/ta_lib/_ext_lib.py", ""),
    ("deploy/pyspark/README.md", "README.md"),
    ("deploy/pyspark/", "deploy"),
    ("deploy/README.md", ""),
]
