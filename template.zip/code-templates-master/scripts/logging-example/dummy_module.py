import logging

# All the library modules assume that logger had been configured elsewhere
# Logger configurations or specifications are never initialised in individual modules.
# They only inherit the configurations from the entry point scripts
logger = logging.getLogger(__name__)


def dummy_function():
    """Dummy Function to test logging inside a function"""
    logger.info(f"Logging Test - Function Call Object Done")
