# Logging

Logging in general is attained using `logging` package in python.


# Prerequisite
* install package `logging_tree` in the python environment


# Sample Logging Codes

* Basic template of how logging can be done is represented in the `code.py`
* Specifying configurations of logger with dictioneries is shown.
* Modifying a logger config with the help of a function `configure_logger` is also shown
* Running the code will generate a `custom_config.log` file in the working directory with some sample logs.

# More on Logging
* Important Configurations of Logging are as follow
    * In addition to `info()` that is used in `code.py`, logging module provides other functions like `debug()`, `warning()`, `error()` and `critical()`. These help distinguish the types of messages that are to be logged.
    * The level of logger plays an important role in what messages to be logged i.e a logger of `level=WARN` only logs messages that are either of a warning level or above.
    * Formatters - To specify the schema of the logged message. (In `code.py` two formatters i.e `default` and `simple` are shown)
    * Handlers - Specify how to handle the logs i.e `console_handler` helps in showning the logs in console, `file_handler` helps to save the logs into a file. One logger object can have multiple handlers.
    * levels - level of logger. Logs which are either at the level of the logger or higher are only logged.