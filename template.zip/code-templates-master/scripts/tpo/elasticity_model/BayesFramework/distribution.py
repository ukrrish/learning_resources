# import logging
from BayesFramework.logging_utils import get_logger
import sys

LOG = get_logger(__name__)


def create_Normal_dist(loc, scale):
    """
    To Create a string for Joint distribution sequential for Normal distributions

    Parameters
    ----------
    loc : int/float
        loc value for Normal distribution.
    scale : int/float
        scale value for Normal distribution.

    Returns
    -------
    String for normal distribution.

    """

    return "tfd.Normal(loc=" + str(loc) + ", scale=" + str(scale) + ")"


def create_StudentT_dist(loc, scale):
    """
    To Create a string for Joint distribution sequential for Student_T distribution.

    Parameters
    ----------
    loc : int/float
        loc value for Student_T distribution.
    scale : int/float
        scale value for Student_T distribution..

    Returns
    -------
    String for Student_T distribution.

    """

    return "tfd.StudentT(loc=" + str(loc) + ", scale=" + str(scale) + ", df=3)"


def create_HalfCauchy_dist(loc, scale):
    """
    To Create a string for Joint distribution sequential for HalfCauchy distribution.

    Parameters
    ----------
    loc : int/float
        loc value for HalfCauchy distribution.
    scale : int/float
        scale value for HalfCauchy distribution.

    Returns
    -------
    String for HalfCauchy distribution.

    """

    return "tfd.HalfCauchy(loc=" + str(loc) + ", scale=" + str(scale) + ")"


def create_LogNormal_dist(loc, scale):
    """
    To Create a string for Joint distribution sequential for LogNormal distribution.

    Parameters
    ----------
    loc : int/float
        loc value for LogNormal distribution.
    scale : int/float
        loc value for LogNormal distribution.

    Returns
    -------
    String for LogNormal distribution.

    """

    return "tfd.LogNormal(loc=" + str(loc) + ", scale=" + str(scale) + ")"


def create_Gamma_dist(con, rate):
    """
    To Create a string for Joint distribution sequential for Gamma distribution.

    Parameters
    ----------
    con : int/float
        concentration value for Gamma distribution.
    rate : int/float
        rate value for Gamma distribution.

    Returns
    -------
    String for Gamma distribution.

    """
    return "tfd.Gamma(concentration=" + str(con) + ", rate=" + str(rate) + ")"


def select_distribution(dist_type, val1, val2):
    """
    To assign the distribution for Joint distribution sequential given by user

    Parameters
    ----------
    dist_type : string
        distribution.
    val1 : int/float
        prior loc value.
    val2 : int/float
        prior scale value.

    Raises
    ------
    ValueError
        If dist_type is not in the list of allowed distributions.

    Returns
    -------
    string
        A string for the joint distribution sequential with the selected distibution.

    """

    dist_list = ["Normal", "HalfCauchy", "LogNormal", "StudentT", "Gamma"]

    if dist_type not in dist_list:
        LOG.error(
            dist_type,
            "distribution is not allowed. Please use only Normal/ HalfCauchy/ LogNormal/ Gamma distribution.",
        )
        sys.exit(1)
    elif dist_type == "Normal":
        return create_Normal_dist(val1, val2)
    elif dist_type == "HalfCauchy":
        return create_HalfCauchy_dist(val1, val2)
    elif dist_type == "LogNormal":
        return create_LogNormal_dist(val1, val2)
    elif dist_type == "StudentT":
        return create_StudentT_dist(val1, val2)
    elif dist_type == "Gamma":
        return create_Gamma_dist(val1, val2)
