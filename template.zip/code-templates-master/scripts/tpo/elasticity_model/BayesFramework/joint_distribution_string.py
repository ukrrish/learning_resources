import tensorflow as tf
from BayesFramework.distribution import select_distribution, create_HalfCauchy_dist
from BayesFramework.logging_utils import get_logger

LOG = get_logger(__name__)


def global_intercept_param(join_dist_list, dist_param):
    """
    To assign the global intercept to join_dist_list and select distribution for joint distribution sequential

    Parameters
    ----------
    join_dist_list : list
        list of variables name .
    dist_param : dict
        dictionary that contains information about distribution, loc and scale values.

    Returns
    -------
    string
        a string of joint distribution sequential with the selected distibution.

    """
    join_dist_list.append("fixed_slope_global_intercept")
    return [
        select_distribution(
            dist_param["global_intercept"]["fixed_d"],
            dist_param["global_intercept"]["fixed_d_loc"],
            dist_param["global_intercept"]["fixed_d_scale"],
        )
    ]


def random_intercept_param(join_dist_list, dist_param, group_variable, group_count):
    """
    To assign the random intercept to join_dist_list and select distribution for joint distribution sequential

    Parameters
    ----------
    join_dist_list : list
        list of variables name .
    dist_param : dict
        dictionary that contains information about distribution, loc and scale values.
    group_variable : string
        grouping column name.
    group_count : int/float
        number of unique elements in the group.

    Returns
    -------
    string
         a string of joint distribution sequential with the selected distibution with given priors.

    """
    join_dist_list.extend(
        [
            "mu_intercept_" + group_variable,
            "sigma_intercept_" + group_variable,
            "intercept_" + group_variable,
        ]
    )
    return [
        select_distribution(
            dist_param[group_variable]["mu_d"],
            dist_param[group_variable]["mu_d_loc"],
            dist_param[group_variable]["mu_d_scale"],
        ),  # mu_intercept : hyper-prior
        select_distribution(
            dist_param[group_variable]["sigma_d"],
            dist_param[group_variable]["sigma_d_loc"],
            dist_param[group_variable]["sigma_d_scale"],
        ),  # sigma_intercept: hyper-prior
        "lambda {0}, {1}: tfd.MultivariateNormalDiag(loc=affine(tf.ones([{2}]), {3}[..., tf.newaxis]),scale_identity_multiplier={4})".format(
            "sigma_intercept_" + group_variable,
            "mu_intercept_" + group_variable,
            group_count,
            "mu_intercept_" + group_variable,
            "sigma_intercept_" + group_variable,
        ),
    ]


def random_gamma_intercept_param(
    join_dist_list, dist_param, group_variable, group_count
):
    join_dist_list.extend(
        [
            "mu_intercept_" + group_variable,
            "sigma_intercept_" + group_variable,
            "intercept_" + group_variable,
        ]
    )
    return [
        select_distribution(
            dist_param[group_variable]["mu_d"],
            dist_param[group_variable]["mu_d_loc"],
            dist_param[group_variable]["mu_d_scale"],
        ),  # mu_intercept : hyper-prior : TODO update it from user input
        select_distribution(
            dist_param[group_variable]["sigma_d"],
            dist_param[group_variable]["sigma_d_loc"],
            dist_param[group_variable]["sigma_d_scale"],
        ),  # sigma_intercept: hyper-prior : TODO update it from user input
        "lambda {0}, {1}: tfd.Independent(tfd.Gamma(concentration=affine(tf.ones([{2}]), {3}[..., tf.newaxis]),rate=tf.transpose({4}*[{5}])),reinterpreted_batch_ndims=1)".format(
            "sigma_intercept_" + group_variable,
            "mu_intercept_" + group_variable,
            group_count,
            "mu_intercept_" + group_variable,
            group_count,
            "sigma_intercept_" + group_variable,
        ),
    ]


def fixed_slope_param(join_dist_list, dist_param, variable):
    """
    To assign the fixed slope to join_dist_list and select distribution for joint distribution sequential.

    Parameters
    ----------
    join_dist_list : list
        list of variables name .
    dist_param : dict
        dictionary that contains information about distribution, loc and scale values.
    variable : string
        column name of idv.

    Returns
    -------
    string
        a string of joint distribution sequential with the selected distibution with given priors.

    """
    join_dist_list.extend(["fixed_slope_" + variable])
    return [
        select_distribution(
            dist_param[variable]["fixed_d"],
            dist_param[variable]["fixed_d_loc"],
            dist_param[variable]["fixed_d_scale"],
        )
    ]


def random_slope_param(
    join_dist_list, dist_param, variable, group_variable, group_count
):
    """
    To assign the random slope for variables to join_dist_list and select distribution for joint distribution sequential.

    Parameters
    ----------
    join_dist_list : list
        list of variable names .
    dist_param : dict
        dictionary that contains information about distribution, loc and scale values.
    variable : string
        column name of idv.
    group_variable : string
        grouping column name.
    group_count : int/float
        number of unique elements in the group.

    Returns
    -------
    string
        a string of joint distribution sequential with the selected distibution with given priors.

    """
    join_dist_list.extend(
        [
            "mu_slope_" + variable + "_" + group_variable,
            "sigma_slope_" + variable + "_" + group_variable,
            "slope_" + variable + "_" + group_variable,
        ]
    )
    return [
        select_distribution(
            dist_param[variable]["mu_d"],
            dist_param[variable]["mu_d_loc"],
            dist_param[variable]["mu_d_scale"],
        ),  # mu_slope : hyper-prior
        select_distribution(
            dist_param[variable]["sigma_d"],
            dist_param[variable]["sigma_d_loc"],
            dist_param[group_variable]["sigma_d_scale"],
        ),  # sigma_slope: hyper-prior
        "lambda {0},{1}: tfd.MultivariateNormalDiag(loc=affine(tf.ones([{2}]), {3}[..., tf.newaxis]),scale_identity_multiplier={4})".format(
            "sigma_slope_" + variable + "_" + group_variable,
            "mu_slope_" + variable + "_" + group_variable,
            group_count,
            "mu_slope_" + variable + "_" + group_variable,
            "sigma_slope_" + variable + "_" + group_variable,
        ),
    ]


def random_gamma_slope_param(
    join_dist_list, dist_param, variable, group_variable, group_count
):
    join_dist_list.extend(
        [
            "mu_slope_" + variable + "_" + group_variable,
            "sigma_slope_" + variable + "_" + group_variable,
            "slope_" + variable + "_" + group_variable,
        ]
    )
    return [
        select_distribution(
            dist_param[variable]["mu_d"],
            dist_param[variable]["mu_d_loc"],
            dist_param[variable]["mu_d_scale"],
        ),  # mu_slope : hyper-prior : TODO update it from user input
        select_distribution(
            dist_param[variable]["sigma_d"],
            dist_param[variable]["sigma_d_loc"],
            dist_param[group_variable]["sigma_d_scale"],
        ),  # sigma_slope: hyper-prior : TODO update it from user input
        "lambda {0}, {1}: tfd.Independent(tfd.Gamma(concentration=affine(tf.ones([{2}]), {3}[..., tf.newaxis]),rate=tf.transpose({4}*[{5}])),reinterpreted_batch_ndims=1)".format(
            "sigma_slope_" + variable + "_" + group_variable,
            "mu_slope_" + variable + "_" + group_variable,
            group_count,
            "mu_slope_" + variable + "_" + group_variable,
            group_count,
            "sigma_slope_" + variable + "_" + group_variable,
        ),
    ]


def error(join_dist_list):
    """
    To add the error term for target variable.

    Parameters
    ----------
    join_dist_list : list
        list of variable names .

    Returns
    -------
    string
        a string after adding error term to the joint distribution sequential.

    """
    join_dist_list.append("sigma_target")
    return [create_HalfCauchy_dist(0, 5)]  # TODO input from user


def target(args, loc, scale):
    """
    To create a string for the likelihood for target function.

    Parameters
    ----------
    args : list
        list of joint_dist_list terms.
    loc : string
        string of loc for multivariate diag.
    scale : string
        string of scale for multivariate diag.

    Returns
    -------
    string
        a string for the likelihood for target function.

    """
    return [
        "lambda {}:  tfd.MultivariateNormalDiag(loc={},scale_identity_multiplier={})".format(
            args, loc, scale
        )
    ]


def create_joint_dist_seq(model_config_df, data_df, join_dist_list, dist_param):
    """
    To stitch the joint distribution sequential together.

    Parameters
    ----------
    model_config_df : dataframe
        dataframe with dv, idvs and distribution information.
    data_df : dataframe
        data.
    join_dist_list : list
        list of variable names.
    dist_param : dictionary
        dictionary that contains information about distribution, loc and scale values..

    Returns
    -------
    final_list : list
        A string of joint distribution sequential for all terms.

    """
    try:
        final_list = []
        target_likelihood_loc = []
        for _, row in model_config_df.iterrows():
            if "intercept" in row["IDV"]:
                if row["RandomEffect"] == 1:
                    # add random intercept term
                    random_factor = row["RandomFactor"]
                    group_levels = tf.cast(data_df[random_factor].nunique(), tf.int32)
                    if row["mu_d"] == "Gamma" or row["sigma_d"] == "Gamma":
                        final_list.extend(
                            random_gamma_intercept_param(
                                join_dist_list, dist_param, random_factor, group_levels
                            )
                        )
                    else:
                        final_list.extend(
                            random_intercept_param(
                                join_dist_list, dist_param, random_factor, group_levels
                            )
                        )
                    # likelihood loc term
                    target_likelihood_loc.append(
                        "tf.gather({0}, {1}, axis=-1)".format(
                            "intercept_" + random_factor, "{}".format(random_factor)
                        )
                    )
    
                else:
                    # add global/fixed intercept term
                    final_list.extend(global_intercept_param(join_dist_list, dist_param))
                    target_likelihood_loc.append(
                        "affine({0}, {1}[..., tf.newaxis])".format(
                            "{}".format(row["IDV"]), "fixed_slope_{}".format(row["IDV"])
                        )
                    )
    
            else:
                if row["RandomEffect"] == 1:
                    # add random slope term
                    random_factor = row["RandomFactor"]
                    group_levels = tf.cast(data_df[random_factor].nunique(), tf.int32)
                    if row["mu_d"] == "Gamma" or row["sigma_d"] == "Gamma":
                        final_list.extend(
                            random_gamma_slope_param(
                                join_dist_list,
                                dist_param,
                                row["IDV"],
                                random_factor,
                                group_levels,
                            )
                        )
                    else:
                        final_list.extend(
                            random_slope_param(
                                join_dist_list,
                                dist_param,
                                row["IDV"],
                                random_factor,
                                group_levels,
                            )
                        )
                    # likelihood loc term
                    target_likelihood_loc.append(
                        "affine({0}, tf.gather({1}, {2}, axis=-1))".format(
                            "{}".format(row["IDV"]),
                            "slope_" + row["IDV"] + "_" + random_factor,
                            "{}".format(random_factor),
                        )
                    )
                else:
                    # add fixed slope term
                    final_list.extend(
                        fixed_slope_param(join_dist_list, dist_param, row["IDV"])
                    )
                    target_likelihood_loc.append(
                        "affine({0}, {1}[..., tf.newaxis])".format(
                            "{}".format(row["IDV"]), "fixed_slope_{}".format(row["IDV"])
                        )
                    )
    
        # insert error term
        final_list.extend(error(join_dist_list))
    
        # insert target likelihood
        args = ",".join(join_dist_list[::-1])
        loc = "(" + " + ".join(target_likelihood_loc) + ")"
        scale = str(join_dist_list[-1])
    
        final_list.extend(target(args, loc, scale))
    
        # finally add target variable in seq list
        join_dist_list.append(model_config_df["DV"].iloc[0])
    
        return final_list
    
    except Exception as e:
            LOG.warning("Error while creating joint distribution sequential")
            LOG.exception(e)    


def create_joint_dist_seq_func(
    spec_dict, model_config_df, data_df, join_dist_list, dist_param
):
    """
    To create the joint distribution func for model as a  string

    Parameters
    ----------
    spec_dict : dictionary
        dictionary with idvs name.
    model_config_df : dataframe
        dataframe with dv, idvs and distribution information.
    data_df : dataframe
        data.
    join_dist_list : list
        list of variable names.
    dist_param : dictionary
        dictionary that contains information about distribution, loc and scale values.

    Returns
    -------
    func_string : string
        string for joint distribution sequential func is created.

    """
    func_string = "def joint_dist_model({}):\n    return tfd.JointDistributionSequential([{}])".format(
        ",".join(spec_dict["idvs"]),
        ",".join(
            create_joint_dist_seq(model_config_df, data_df, join_dist_list, dist_param)
        ),
    )
    LOG.info(func_string)
    return func_string


def get_resolve_graph_of_JDS():
    """
    To create the function to generate resolve graph.
    
    Returns
    -------
    func_string : string
        string for resolve graph func is created.

    """
    func_string = "print(joint_dist_model.resolve_graph())"
    return func_string


def create_log_prob_func(join_dist_list, spec_dict):
    """
    To create the joint distribution func log prob for model as a  string.

    Parameters
    ----------
    join_dist_list : list
        list of variable names.
    spec_dict : dictionary
        dictionary with idvs name.
        
    Returns
    -------
    func_string : string
         string for joint distribution log prob is created.

    """
    func_string = "@tf.function\ndef joint_dist_model_log_prob({}):\n    return joint_dist_model({}).log_prob([{}])".format(
        ",".join(join_dist_list[:-1]),
        ",".join(spec_dict["idvs"]),
        ",".join(join_dist_list),
    )
    LOG.info(func_string)
    return func_string
