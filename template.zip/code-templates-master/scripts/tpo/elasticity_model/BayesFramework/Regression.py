import os

os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"
import time
import pandas as pd
import tensorflow as tf

tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
import tensorflow_probability as tfp
import collections
import numpy as np
import pdb
import sys
import arviz as az
import pickle
# import mlflow
import copy
import warnings
from BayesFramework.joint_distribution_string import (
    create_joint_dist_seq_func,
    create_log_prob_func,
)
from BayesFramework.utils import (
    rem_specialchar_array,
    get_tensor_var,
    get_tensor_cat,
    tensor_to_dictionary,
    affine,
    check_samples,
    check_values,
)
from BayesFramework.predict import prediction
from BayesFramework.logging_utils import get_logger

LOG = get_logger(__name__)

warnings.filterwarnings("ignore")
os.environ["GIT_PYTHON_REFRESH"] = "quiet"

thismodule = sys.modules[__name__]

tfd = tfp.distributions
tfb = tfp.bijectors


class BayesianEstimation:
    """
    
    This class implements partially pooled heirarchical bayesian model for a given set of random and fixed effects
    ref: 
    
    inputs:
    
    data_df: Pandas DataFrame
    model_config_df:Pandas DataFrame made from config
                    Include_IDV	: 1/0 
                    RandomEffect: Random Effect=1, Fixed Effect=1
                    RandomFactor: Grouping Column
                    mu_d: distribution
                    mu_d_loc_alpha:<int/float>
                    mu_d_scale_beta	:<int/float>
                    sigma_d: distribution
                    sigma_d_loc_alpha: <int/float>
                    sigma_d_scale_beta: <int/float>	
                    mu_bijector	sigma_bijector: Identity/Exp	
                    fixed_d	fixed_d_loc_alpha:<int/float>	
                    fixed_d_scale_beta:<int/float>	
                    fixed_bijector:Identity/Exp
    framework_config_df:Pandas DataFrame made from config
                    objective:regression
                    sampler: hmc/nuts
                    num_chains: <int> number of mcmc chains (passed to hmc.sample_chains())
                    num_results: <int> number of results 
                    num_burnin_steps: <float> parameter to TFP Hmc sampler
                    num_leapfrog_steps: <float> parameter to TFP Hmc sampler
                    hmc_step_size: <float> parameter to TFP Hmc sampler
    experiment_name: name of the experiment in mlflow (default is 'default')
    run_name: name of the run in mlflow (default is 'default')
    output:
    
    Summary: 1) estimates of all random effect params with Rhat values group wise
              2) estimates of all fixed effect paramas with Rhat values on population 
    Traceplots: as per the arguments
    full sample trace: as per the arguments
    """

    def __init__(
        self,
        data_df_original,
        model_config_df_original,
        framework_config_df,
        experiment_name="default",
        run_name="default",
        pickle_file="",
    ):

        data_df = data_df_original.copy()
        model_config_df = model_config_df_original.copy()

        if "global_intercept" not in data_df.columns:
            data_df["global_intercept"] = 1

        self.join_dist_list = []
        t = time.localtime()
        self.dt = time.strftime("%b-%d-%Y_%H%M", t)

        model_config_df = model_config_df[model_config_df["Include_IDV"] == 1].copy()
        model_config_df.drop("Include_IDV", axis=1, inplace=True)
        LOG.info("Removing special characters from dv and idvs.")
        model_config_df.loc[:, "DV"] = rem_specialchar_array(model_config_df["DV"])
        model_config_df.loc[:, "IDV"] = rem_specialchar_array(model_config_df["IDV"])
        model_config_df.loc[:, "RandomFactor"][
            model_config_df["RandomFactor"].isna()
        ] = ""

        model_config_df.loc[:, "RandomFactor"] = rem_specialchar_array(
            model_config_df["RandomFactor"]
        )
        self.model_config_df = model_config_df

        data_df.columns = rem_specialchar_array(data_df.columns)

        mapped_list = []
        for column in [
            s for s in model_config_df["RandomFactor"].unique() if s not in [np.nan, ""]
        ]:
            data_df = data_df[data_df[column].notna()]
            column_name = sorted(data_df[column].unique())
            data_df[column + "_original"] = data_df[column]
            data_df[column] = (
                data_df[column]
                .astype(pd.api.types.CategoricalDtype(categories=column_name))
                .cat.codes
            )
            data_df[column] = data_df[column].astype(int)
            mapped_list.append(column)
            mapped_list.append(column + "_original")
        self.data_df = data_df

        self.ModelParamsTuple = None
        self.SamplesTuple = None
        self.duplicate_data = None
        self.dict_sample = None

        hyperparam_dict = {}
        for _, row in framework_config_df.iterrows():
            if row["TagName"] not in ["objective", "add_globalintercept"]:
                hyperparam_dict[row["TagName"]] = row["Value"]
        spec_dict = {
            "dv": model_config_df["DV"].iloc[0],
            "idvs": [
                item.replace("intercept_", "")
                for item in list(model_config_df["IDV"].drop_duplicates())
            ],
            "group_cols": [
                s
                for s in model_config_df["RandomFactor"].unique()
                if s not in [np.nan, ""]
            ],
            "hyperparams": hyperparam_dict,
        }
        self.spec_dict = spec_dict
        LOG.info("Printing Hyperparams:")
        LOG.info(self.spec_dict["hyperparams"])

        data_df = self.data_df
        self.mapped_df = data_df[mapped_list]
        data_df = data_df[
            list(
                set(
                    [self.spec_dict["dv"]]
                    + self.spec_dict["idvs"]
                    + self.spec_dict["group_cols"]
                )
            )
        ]
        data_df = data_df.dropna()
        self.data_df = data_df

        dist_param = {}
        num_chains = spec_dict["hyperparams"]["num_chains"]
        for _, row in model_config_df.iterrows():
            if row["IDV"] == "global_intercept":
                var = "global_intercept"
                tmp_param = {
                    "fixed_d": row["fixed_d"],
                    "fixed_d_loc": row["fixed_d_loc_alpha"],
                    "fixed_d_scale": row["fixed_d_scale_beta"],
                    "fixed_bijector": row["fixed_bijector"],
                }
                dist_param[var] = tmp_param

            elif "intercept" in row["IDV"]:
                var = row["RandomFactor"]
                tmp_param = {
                    "mu_d": row["mu_d"],
                    "mu_d_loc": row["mu_d_loc_alpha"],
                    "mu_d_scale": row["mu_d_scale_beta"],
                    "sigma_d": row["sigma_d"],
                    "sigma_d_loc": row["sigma_d_loc_alpha"],
                    "sigma_d_scale": row["sigma_d_scale_beta"],
                    "mu_bijector": row["mu_bijector"],
                    "sigma_bijector": row["sigma_bijector"],
                }
                dist_param[var] = tmp_param

            else:
                var = row["IDV"]
                if row["RandomEffect"] == 1:
                    tmp_param = {
                        "mu_d": row["mu_d"],
                        "mu_d_loc": row["mu_d_loc_alpha"],
                        "mu_d_scale": row["mu_d_scale_beta"],
                        "sigma_d": row["sigma_d"],
                        "sigma_d_loc": row["sigma_d_loc_alpha"],
                        "sigma_d_scale": row["sigma_d_scale_beta"],
                        "mu_bijector": row["mu_bijector"],
                        "sigma_bijector": row["sigma_bijector"],
                    }
                else:
                    tmp_param = {
                        "fixed_d": row["fixed_d"],
                        "fixed_d_loc": row["fixed_d_loc_alpha"],
                        "fixed_d_scale": row["fixed_d_scale_beta"],
                        "fixed_bijector": row["fixed_bijector"],
                    }
                dist_param[var] = tmp_param
        dist_bij = copy.deepcopy(dist_param)
        self.dist_bij = dist_bij
        LOG.info("Printing distribution and bijectors:")
        LOG.info(self.dist_bij)

        for key1, value1 in dist_param.items():
            for key2, value2 in value1.items():
                if "bijector" in key2:
                    if value2 == "Identity":
                        dist_param[key1][key2] = tfb.Identity()
                    elif value2 == "Exp":
                        dist_param[key1][key2] = tfb.Exp()
        self.dist_param = dist_param

        random_effect = []
        fixed_effect = []

        for _, row in self.model_config_df.iterrows():
            if row["RandomEffect"] == 0:
                if row["IDV"] != "global_intercept":
                    fixed_effect.append(row["IDV"])
            else:
                check = "intercept_" + row["RandomFactor"]
                l2 = []
                if row["IDV"] != check:
                    l2.append(row["IDV"])
                    l2.append(row["RandomFactor"])
                    random_effect.append(l2)
        self.random_effect = random_effect
        self.fixed_effect = fixed_effect
        
        # mlflow.set_experiment(experiment_name)
        # mlflow.start_run(run_name= run_name + "_"  + self.dt)
        data = {}
        data["idvs"] = self.spec_dict["idvs"]
        data["dv"] = self.spec_dict["dv"]
        data["random_effects"] = self.random_effect
        data["fixed_effects"] = self.fixed_effect
        data["group_column"] = self.spec_dict["group_cols"]

        # mlflow.log_param("Hyperparams", self.spec_dict["hyperparams"])
        # mlflow.log_param("Data", data)
        # mlflow.log_param("distribution_and_bijectors", self.dist_bij)

        if pickle_file:
            LOG.info("Using given pickle file.")
            pickle_off = open(pickle_file, "rb")
            all_data = {}
            all_data = pickle.load(pickle_off)
            samples = all_data["samples"]
            acceptance_probs = all_data["acceptance_probs"]

            self.join_dist_list = all_data["join_dist_list"]
            self.ModelParamsTuple = collections.namedtuple(
                "ModelParams", self.join_dist_list[:-1]
            )
            LOG.info("got model param tuple")
            self.SamplesTuple = self.ModelParamsTuple._make(samples)
            LOG.info("got samples tuple")

            # print("Acceptance Probabilities: ", acceptance_probs.numpy())
            LOG.info("Acceptance Probabilities: ")
            LOG.info(acceptance_probs.numpy())
            try:

                for var in self.join_dist_list[:-1]:
                    if "mu" in var or "sigma" in var:
                        print(
                            "R-hat for ",
                            var,
                            "\t: ",
                            tfp.mcmc.potential_scale_reduction(
                                getattr(self.SamplesTuple, var)
                            ).numpy(),
                        )

            except Exception as e:
                LOG.error("------Error while calculating r-hat-----")
                LOG.exception(e)

    def preprocess(self):
        """
        To Convert spec_dict variables to tensor dv,idv and Categorical data
         
        :raises TypeError:An error occurred while converting dv/idv into tensor.
        :return: columns Converted to Tensors
        :rtype: tensors
        """
        LOG.info("Converting dv and idvs into tensor.")
        for key, value in self.spec_dict.items():
            if key == "dv":
                try:
                    setattr(thismodule, value, get_tensor_var(value, self.data_df))
                except:
                    LOG.exception("An error occurred while converting dv into tensor.")

            elif key == "idvs":
                for idv in value:
                    idv_1 = idv
                    try:
                        if idv_1 not in self.spec_dict["group_cols"]:
                            setattr(
                                thismodule, idv_1, get_tensor_var(idv_1, self.data_df)
                            )
                        else:
                            setattr(
                                thismodule, idv_1, get_tensor_cat(idv_1, self.data_df)
                            )
                    except:
                        LOG.exception(
                            "An error occurred while converting idvs into tensor."
                        )

        pass

    def select_sampling_technique(
        self, condition, initial_state, unconstraining_bijectors, seed
    ):
        """
        To select the sampling technique and assign the initial state
        :param  condition:hmc or nuts
                initial_state: Tensors representing the initial state
                unconstraining_bijectors:Identity or Exp
                seed: random generator 
               
        :type   condition:str
                initial_state:tensor
                unconstraining_bijectors:string
                seed:int/float
              
        :return: kernel for the selected Method 
        :rtype: tf object
        """

        try:
            if condition == "hmc":
                hmc_step_size = self.spec_dict["hyperparams"]["hmc_step_size"]
                num_leapfrog_steps = self.spec_dict["hyperparams"]["num_leapfrog_steps"]

                sampler = tfp.mcmc.HamiltonianMonteCarlo(
                    target_log_prob_fn=joint_dist_model_log_prob,
                    num_leapfrog_steps=num_leapfrog_steps,
                    step_size=hmc_step_size,
                )
                kernel = tfp.mcmc.TransformedTransitionKernel(
                    inner_kernel=sampler, bijector=unconstraining_bijectors
                )
                LOG.info("hmc sampler is selected.")

            else:
                num_chains = self.spec_dict["hyperparams"]["num_chains"]
                hmc_step_size = self.spec_dict["hyperparams"]["hmc_step_size"]
                num_burnin_steps = self.spec_dict["hyperparams"]["num_burnin_steps"]

                target_accept_prob = 0.8
                num_adaptation_steps = int(0.8 * num_burnin_steps)

                step_size = [
                    tf.fill(
                        [num_chains] + [1] * (len(s.shape) - 1),
                        tf.constant(hmc_step_size, np.float32),
                    )
                    for s in initial_state
                ]
                sampler = tfp.mcmc.NoUTurnSampler(
                    joint_dist_model_log_prob, step_size=step_size, seed=seed
                )
                kernel = tfp.mcmc.DualAveragingStepSizeAdaptation(
                    tfp.mcmc.TransformedTransitionKernel(
                        inner_kernel=sampler, bijector=unconstraining_bijectors
                    ),
                    target_accept_prob=target_accept_prob,
                    num_adaptation_steps=num_adaptation_steps,
                    step_size_setter_fn=lambda pkr, new_step_size: pkr._replace(
                        inner_results=pkr.inner_results._replace(
                            step_size=new_step_size
                        )
                    ),
                    step_size_getter_fn=lambda pkr: pkr.inner_results.step_size,
                    log_accept_prob_getter_fn=lambda pkr: pkr.inner_results.log_accept_ratio,
                )
                LOG.info("nuts sampler is selected.")
        except Exception as e:
            LOG.error("---Error occured while getting sampler/kernel.-----")
            LOG.exception(e)
            sys.exit(1)

        return kernel

    def get_ready(self, seed):
        """
        To start the sampling function with all the initial parameter
        :param  
                seed: random generator 
               
        :type   
                seed:int
        :return: sampling_technique, kernel, initial_state, unconstraining_bijectors, num_chains, num_results, num_burnin_steps 
        :rtype: condition:str
                initial_state:tensor
                unconstraining_bijectors:str
                seed:int
                num_chains:tf.int32
                num_results:tf.int32
                num_burnin_steps:tf.int32
        """
        num_chains = tf.cast(self.spec_dict["hyperparams"]["num_chains"], tf.int32)
        num_results = tf.cast(self.spec_dict["hyperparams"]["num_results"], tf.int32)
        num_burnin_steps = tf.cast(
            self.spec_dict["hyperparams"]["num_burnin_steps"], tf.int32
        )

        str_sample = "(joint_dist_model({}).sample(seed=seed)[:-1])".format(
            ",".join(self.spec_dict["idvs"])
        )
        try:
            initial_state_ = eval(str_sample)
            LOG.info("Printing initial_state: ")
            LOG.info(initial_state_)
        except Exception as e:
            LOG.error(
                "Error while generating samples from joint distribution sequential."
            )
            LOG.exception(e)
            sys.exit(1)

        initial_state = []
        unconstraining_bijectors = []
        i = 0
        for element in self.join_dist_list[:-1]:
            element_1 = element
            if element_1 != "sigma_target":
                for repl in ["mu_", "sigma_", "slope_", "fixed_", "intercept_"]:
                    element_1 = element_1.replace(repl, "")
                if "intercept" not in element_1:
                    for repl in ["_" + s for s in self.spec_dict["group_cols"]]:
                        element_1 = element_1.replace(repl, "")
            if element == "sigma_target":
                initial_state.append(
                    tf.ones([num_chains], name="init_" + element) * initial_state_[i]
                )
                i += 1
                unconstraining_bijectors.append(tfb.Exp())
            elif element == "global_intercept":
                initial_state.append(
                    tf.ones([num_chains], name="init_" + element) * initial_state_[i]
                )
                i += 1
                unconstraining_bijectors.append(
                    self.dist_param[element_1]["fixed_bijector"]
                )
            elif "sigma" in element:
                initial_state.append(
                    tf.ones([num_chains], name="init_" + element) * initial_state_[i]
                )
                i += 1
                unconstraining_bijectors.append(
                    self.dist_param[element_1]["sigma_bijector"]
                )
            elif "mu" in element:
                initial_state.append(
                    tf.ones([num_chains], name="init_" + element) * initial_state_[i]
                )
                i += 1
                unconstraining_bijectors.append(
                    self.dist_param[element_1]["mu_bijector"]
                )
            elif "fixed" in element:
                initial_state.append(
                    tf.ones([num_chains], name="init_" + element) * initial_state_[i]
                )
                i += 1
                unconstraining_bijectors.append(
                    self.dist_param[element_1]["fixed_bijector"]
                )
            else:
                group_var_name = [
                    s for s in element.split("_") if s in self.spec_dict["group_cols"]
                ][0]
                group_levels = tf.cast(
                    self.data_df[group_var_name].nunique(), tf.int32
                )  # EDIT
                initial_state.append(
                    tf.ones([num_chains, group_levels], name="init_" + element)
                    * initial_state_[i]
                )
                i += 1
                unconstraining_bijectors.append(
                    tfb.Identity()
                )  # TODO update this to read from config - incomplete

        check_values(initial_state)
        sampling_technique = self.spec_dict["hyperparams"]["sampler"]
        kernel = self.select_sampling_technique(
            sampling_technique, initial_state, unconstraining_bijectors, seed=seed
        )

        return (
            sampling_technique,
            kernel,
            initial_state,
            unconstraining_bijectors,
            num_chains,
            num_results,
            num_burnin_steps,
        )

    @tf.function(experimental_compile=True)
    @tf.autograph.experimental.do_not_convert
    def sample_model(
        self,
        sampling_technique,
        kernel,
        initial_state,
        unconstraining_bijectors,
        num_chains,
        num_results,
        num_burnin_steps,
    ):
        """
                
        To get the Samples from the model.
        :param  
                condition:hmc or nuts
                initial_state: Tensors representing the initial state
                unconstraining_bijectors:Identity or Exp
                seed: random generator
                num_chains:num_chains
                num_results:num_results
                num_burnin_steps:num_burnin_steps
               
        :type   
                condition:str
                initial_state:tensor
                unconstraining_bijectors:str
                seed:int
                num_chains:tf.int32
                num_results:tf.int32
                num_burnin_steps:tf.int32
        :return: samples, acceptance_probs
        :rtype: samples:list of Tensors
                acceptance_probs:list of tensors
        """
        LOG.info("Started Sampling ")
        try:
            samples, kernel_results = tfp.mcmc.sample_chain(
                num_results=num_results,
                num_burnin_steps=num_burnin_steps,
                current_state=initial_state,
                kernel=kernel,
            )
        except Exception as e:
            LOG.error(
                "Error while generating samples. Please try with different priors."
            )
            LOG.exception(e)
            sys.exit(1)

        LOG.info("Calculating acceptance probs")
        try:
            if sampling_technique == "hmc":
                acceptance_probs = tf.reduce_mean(
                    tf.cast(kernel_results.inner_results.is_accepted, tf.float32),
                    axis=0,
                )

            else:
                acceptance_probs = tf.reduce_mean(
                    tf.cast(
                        kernel_results.inner_results.inner_results.is_accepted,
                        tf.float32,
                    ),
                    axis=0,
                )

        except Exception as e:
            LOG.error("----Error while getting acceptance prob.----")
            LOG.exception(e)

        return samples, acceptance_probs

    def train(self, fixed_seed=123):
        """
        To create and Execute the Joint Distribution Sequence and Get the Model Metrics Results after Sampling 
        :param  
                fixed_seed: random generator 
               
        :type   
                fixed_seed:int
        :return: prints model metrics
        """
        start_time = time.time()
        self.preprocess()
        LOG.info("preprocess done")
        try:
            LOG.info("creating joint distribution sequential")
            exec(
                create_joint_dist_seq_func(
                    self.spec_dict,
                    self.model_config_df,
                    self.data_df,
                    self.join_dist_list,
                    self.dist_param,
                ),
                globals(),
            )
        except Exception as e:
            LOG.warning(
                "---error occured while executing create_joint_dist_seq_func----"
            )
            LOG.exception(e)

        try:
            LOG.info("creating joint distribution sequential log prob")
            exec(create_log_prob_func(self.join_dist_list, self.spec_dict), globals())

        except Exception as e:
            LOG.warning("----error occured while executing create_log_prob_func----")
            LOG.exception(e)

        try:
            s = "joint_dist_model({}).resolve_graph()".format(
                ",".join(self.spec_dict["idvs"])
            )

            LOG.info("Printing Resolve Graph function")
            LOG.info(eval(s))

        except Exception as e:
            LOG.warning("----error occured while executing resolve graph----")
            LOG.exception(e)

        (
            sampling_technique,
            kernel,
            initial_state,
            unconstraining_bijectors,
            num_chains,
            num_results,
            num_burnin_steps,
        ) = self.get_ready(seed=fixed_seed)

        samples, acceptance_probs = self.sample_model(
            sampling_technique,
            kernel,
            initial_state,
            unconstraining_bijectors,
            num_chains,
            num_results,
            num_burnin_steps,
        )

        self.ModelParamsTuple = collections.namedtuple(
            "ModelParams", self.join_dist_list[:-1]
        )

        self.SamplesTuple = self.ModelParamsTuple._make(samples)
        LOG.info("Creating samples tuple")
        all_data = {}
        all_data["samples"] = samples
        all_data["acceptance_probs"] = acceptance_probs
        all_data["join_dist_list"] = self.join_dist_list

        # pickling samples
        if not os.path.exists("output/Samples/"):
            os.makedirs("output/Samples/")
        LOG.info("Saving pickle file in output/Samples/.")
        pickling_on = open("output/Samples/Samples" + self.dt + ".pickle", "wb")
        pickle.dump(all_data, pickling_on)

        pickling_on.close()
        # mlflow.log_artifact("output/Samples/Samples" + self.dt + ".pickle")

        dict_sample = tensor_to_dictionary(
            self.join_dist_list, self.SamplesTuple, self.mapped_df
        )
        self.dict_sample = dict_sample

        check_samples(self.dict_sample)

        LOG.info("Acceptance Probabilities: ")
        LOG.info(acceptance_probs.numpy())
        try:

            for var in self.join_dist_list[:-1]:
                if "mu" in var or "sigma" in var:
                    print(
                        "R-hat for ",
                        var,
                        "\t: ",
                        tfp.mcmc.potential_scale_reduction(
                            getattr(self.SamplesTuple, var)
                        ).numpy(),
                    )

        except Exception as e:
            LOG.error("------Error while calculating r-hat-----")
            LOG.exception(e)

        run_time = time.time() - start_time
        # mlflow.log_param("Run_time", run_time)
        pass

    def saving_model_metrics(self):
        """
        To save results and log results in myflow
        :return: saves model results in the directory output/bayesian_model_train_summary/ created in the working folder
        """
        print("=" * 80)
        LOG.info("Saving Model Metrics and traceplots")
        print("=" * 80)

        try:
            LOG.info("Doing nothing")
            # mlflow.log_artifact(
            #     "output/bayesian_model_train_summary/"
            #     + self.dt
            #     + "plot_trace_"
            #     + self.dt
            #     + ".pdf"
            # )
            # mlflow.log_artifact(
            #     "output/bayesian_model_train_summary/" + self.dt + "Group_Summary.xlsx"
            # )
            # mlflow.log_artifact(
            #     "output/bayesian_model_train_summary/"
            #     + "plot_posterior_"
            #     + self.dt
            #     + ".pdf"
            # )
            # mlflow.end_run()
        except Exception as e:
            LOG.error(
                "Error while saving model metrics. Please generate group summary and plots before saving them. "
            )
            LOG.exception(e)
        pass

    def summary(self, output_folder_path="output/bayesian_model_train_summary/"):
        """
        To Save Summary for indivudual groups
        :param  
                output_folder_path: path where the outputs are to be saved (default: "output/bayesian_model_train_summary/")
                   
        :type   
                output_folder_path:str
        :raises: error if object not present for saving
        :return: Saves group summary in the directory mentioned
        """

        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)
        LOG.info("Saving group summary")
        try:
            summary = az.summary(self.dict_sample)
            summary.to_excel(output_folder_path + self.dt + "Group_Summary.xlsx")
        except Exception as e:
            LOG.error("----Error while saving Group Summary.----")
            LOG.exception(e)

    def get_group_summary(self):
        """ Return group summary """
        try:
            summary = az.summary(self.dict_sample)
            return summary
        except Exception as e:
            LOG.error("----Error while returning Group Summary.----")
            LOG.exception(e)

    def predict(self, data_pr, output_folder_path="output/bayesian_model_prediction/"):

        y_pred = prediction(
            data_pr,
            self.join_dist_list,
            self.SamplesTuple,
            self.spec_dict,
            self.mapped_df,
            self.fixed_effect,
            self.dt,
            self.random_effect,
        )
        return y_pred  # , r2_value, RMSE, mape, mae, wmape
