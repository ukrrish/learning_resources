import tensorflow as tf
import numpy as np
import sys
import matplotlib.pyplot as plt
import arviz as az
import os
from matplotlib.backends.backend_pdf import PdfPages

# import logging
from BayesFramework.logging_utils import get_logger
import warnings

warnings.filterwarnings("ignore")

thismodule = sys.modules[__name__]
LOG = get_logger(__name__)


class Plot:
    """
    This class contains functions for traceplot and posterior plot.
    ...
    Attributes
    ----------
    obj
    
    Methods
    -------
    plot_posterior(var_name,var_samples):
        Function to plot posteriors
        
    plot_posterior_allvars(output_folder_path):
        Calls plot_posterior function for every variable.
        
    plot_trace(plot_v,output_folder_path):
        Function for trace plot using arviz
        
   save_all_plots(output_folder_path):
       Calls plot_trace() and plot_posterior_allvars()

        
  
    """

    def __init__(self, obj):

        self.dt = obj.dt
        self.join_dist_list = obj.join_dist_list
        self.SamplesTuple = obj.SamplesTuple
        self.dict_sample = obj.dict_sample

    def plot_posterior(self, var_name, var_samples):
        """
        Function to plot posterior

        Parameters
        ----------
        var_name : string
            Name of the variable to plot.
        var_samples : tensor
            Contains sample.

        Returns
        -------
        fig : posterior plot of variable.

        """
        try:
            if isinstance(var_samples, tf.Tensor):
                var_samples = var_samples.numpy()

            fig = plt.figure(figsize=(10, 3))
            ax = fig.add_subplot(111)
            ax.hist(var_samples.flatten(), bins=40, edgecolor="white")
            sample_mean = var_samples.mean()
            ax.text(
                sample_mean,
                100,
                "mean={:.3f}".format(sample_mean),
                color="white",
                fontsize=12,
            )
            ax.set_xlabel("posterior of " + var_name)
            return fig

        except Exception as e:
            LOG.warning(
                "----Error while plotting posteriors for " + var_name + "----------"
            )
            LOG.exception(e)

    def plot_posterior_allvars(
        self, output_folder_path="output/bayesian_model_train_summary/"
    ):
        """
        Calls plot_posterior function for every variable.

        Parameters
        ----------
        output_folder_path : string, optional
            Path of output folder. The default is 'output/'.

        Returns
        -------
        None.

        """

        var_list = [
            s
            for s in self.join_dist_list[:-1]
            if (("mu" not in s) & ("sigma" not in s))
        ]
        file_post = output_folder_path + "plot_posterior_" + self.dt + ".pdf"
        post = PdfPages(file_post)
        LOG.info("Generating posterior plots.")
        for var in var_list:
            plot_post = self.plot_posterior(var, getattr(self.SamplesTuple, var))
            post.savefig(plot_post)
        post.close()

    def plot_trace(
        self,
        var=[],
        plot_v="trace",
        output_folder_path="output/bayesian_model_train_summary/",
    ):
        """
        Function for trace plot using arviz 

        Parameters
        ----------
        plot_v : string, optional
             The default is 'trace'.
        output_folder_path : string, optional
            Path of output folder. The default is 'output/'.

        Returns
        -------
        None.

        """
        try:
            az_trace = az.from_dict(posterior=self.dict_sample)

            file = (
                output_folder_path + self.dt + "plot_" + plot_v + "_" + self.dt + ".pdf"
            )
            pp = PdfPages(file)

            if var:
                for name in var:
                    if name in self.dict_sample:
                        LOG.info("Generating trace plots for " + name)
                        az.plot_trace(az_trace, var_names=name, figsize=(10, 3))
                    else:
                        LOG.exception("Unable to find any samples/traces for " + name)

            else:
                LOG.info("Generating trace plots.")
                for key, value in self.dict_sample.items():
                    plot_s = (
                        "az.plot_"
                        + plot_v
                        + "(az_trace, var_names=key, figsize=(10,3))"
                    )
                    plot = exec(plot_s)
                    pp.savefig(plot)
                pp.close()
        except Exception as e:
            LOG.warning("----Error while generating trace plots.----")
            LOG.exception(e)

    def save_all_plots(self, output_folder_path="output/bayesian_model_train_summary/"):
        """
        Calls plot_trace() and plot_posterior_allvars()

        Parameters
        ----------
        output_folder_path : string, optional
            path where the outputs are to be saved. The default is "output/bayesian_model_train_summary/".

        Returns
        -------
        None.

        """
        if not os.path.exists(output_folder_path):
            LOG.info("Creating " + output_folder_path + " path")
            os.makedirs(output_folder_path)
        self.plot_trace(output_folder_path=output_folder_path)
        self.plot_posterior_allvars(output_folder_path=output_folder_path)
