import configparser
import pandas as pd
import os
import time
import sys
from BayesFramework.logging_utils import get_logger

LOG = get_logger(__name__)

#%%


class Config:
    """
    A class that deals with config file.

    ...

    Attributes
    ----------
    path : str
        path of .ini file

    Methods
    -------
    check_config(parser):
        Checks the config file
        
    load_config():
        Reads the config file and create a dictionary
        
    create_model_config_data(dictionary):
        Creates a dataframe that contains the information about effect, distribution and bijector of the variables.
        
    create_framework_config_data(dictionary):
        Creates a dataframe that contains the information about objective and sampling.
        
    create_config(config_file_name):
        Calls create_model_config_data(dictionary) and create_framework_config_data(dictionary) methods and creates an excel file that contains information about modelling.
        
    get_config(config_file_name):
        Calls the create_config(config_file_name) method if excel file doesn't exist.

    """

    def __init__(self, path):
        """Inits Config with path."""
        self.path = path

    def check_config(self, parser):
        """
        Checks the config file.

        Parameters
        ----------
        parser : object
            Object of ConfigParser.

        Raises
        ------
        ValueError:
            If some sections or options are missing in config.
            If objective is other than regression or classification.

        Returns
        -------
        None.

        """
        LOG.info("Checking config.ini file")
        for section_n in [
            "Framework",
            "Model",
            "Priors",
            "Bijectors",
            "Specifications",
        ]:
            if not parser.has_section(section_n):
                LOG.error(section_n + " section is missing")
                sys.exit(1)

        for option_n in [
            "data",
            "target",
            "random_effect",
            "fixed_effect",
            "group_column",
        ]:
            if not parser.has_option("Model", option_n):
                LOG.error(option_n + " is missing in model section")
                sys.exit(1)

        if not parser.get("Framework", "objective") in ["regression", "classification"]:
            LOG.error(
                "Please Provide 'regression'/'classification' as the objective only"
            )
            sys.exit(1)

    def load_config(self):
        """
        Reads the config file and creates a dictionary.

        Raises
        ------
        ValueError
            If config file is missing.

        Returns
        -------
        dictionary : dict
            Contains the information present in config file .

        """
        parser = configparser.ConfigParser()
        if not (os.path.exists(self.path)):
            LOG.error(".ini file doesn't exist")
            sys.exit(1)

        parser.read(self.path)
        self.check_config(parser)
        LOG.info("Reading config.ini file")
        dictionary = {}
        for section in parser.sections():
            dictionary[section] = {}
            for option in parser.options(section):
                dictionary[section][option] = parser.get(section, option)
        return dictionary

    def create_model_config_data(self, dictionary):
        """
        Creates a dataframe that contains the information about effect, distribution and bijector of the variables.

        Parameters
        ----------
        dictionary : dict
            dictionary generated on the basis of config file.

        Raises
        ------
        ValueError
            If priors or bijectors are missing for any variable.

        Returns
        -------
        config_model: dataframe
            Contains the information about variables.

        """
        config_model = pd.DataFrame(
            columns=[
                "DV",
                "IDV",
                "Include_IDV",
                "RandomEffect",
                "RandomFactor",
                "mu_d",
                "mu_d_loc_alpha",
                "mu_d_scale_beta",
                "sigma_d",
                "sigma_d_loc_alpha",
                "sigma_d_scale_beta",
                "mu_bijector",
                "sigma_bijector",
                "fixed_d",
                "fixed_d_loc_alpha",
                "fixed_d_scale_beta",
                "fixed_bijector",
            ]
        )

        dv = dictionary["Model"]["target"]
        group_var_list = eval(dictionary["Model"]["group_column"])
        idv_list = [
            x
            for x in eval(dictionary["Model"]["data"])
            if x not in group_var_list + [dictionary["Model"]["target"]]
        ]
        random_effect = eval(dictionary["Model"]["random_effect"])
        fixed_effect = eval(dictionary["Model"]["fixed_effect"])
        intercept_cols = ["intercept_" + s for s in group_var_list]

        if dictionary["Specifications"]["add_globalintercept"] == "True":
            global_intercept = ["global_intercept"]
        else:
            global_intercept = []
        if len(group_var_list) > 0:
            group_var = group_var_list[0]
        else:
            group_var = ""

        config_model["IDV"] = global_intercept + intercept_cols + idv_list
        config_model["Include_IDV"] = 1
        config_model["DV"] = dv
        config_model["RandomEffect"] = 0
        config_model["RandomEffect"][
            config_model["IDV"].isin(random_effect + intercept_cols)
        ] = 1
        config_model["RandomFactor"][
            config_model["IDV"].isin(random_effect + intercept_cols)
        ] = group_var

        try:
            for col in random_effect:
                config_model["mu_d"][config_model["IDV"] == col] = eval(
                    dictionary["Priors"][col.lower()]
                )[0]
                config_model["sigma_d"][config_model["IDV"] == col] = eval(
                    dictionary["Priors"][col.lower()]
                )[1]
                config_model["mu_bijector"][config_model["IDV"] == col] = eval(
                    dictionary["Bijectors"][col.lower()]
                )[0]
                config_model["sigma_bijector"][config_model["IDV"] == col] = eval(
                    dictionary["Bijectors"][col.lower()]
                )[1]
            for col in fixed_effect + global_intercept:
                config_model["fixed_d"][config_model["IDV"] == col] = eval(
                    dictionary["Priors"][col.lower()]
                )[0]
                config_model["fixed_bijector"][config_model["IDV"] == col] = eval(
                    dictionary["Bijectors"][col.lower()]
                )[0]

            for col in group_var_list:
                config_model["mu_d"][config_model["IDV"] == "intercept_" + col] = eval(
                    dictionary["Priors"][col.lower()]
                )[0]
                config_model["sigma_d"][
                    config_model["IDV"] == "intercept_" + col
                ] = eval(dictionary["Priors"][col.lower()])[1]
                config_model["mu_bijector"][
                    config_model["IDV"] == "intercept_" + col
                ] = eval(dictionary["Bijectors"][col.lower()])[0]
                config_model["sigma_bijector"][
                    config_model["IDV"] == "intercept_" + col
                ] = eval(dictionary["Bijectors"][col.lower()])[1]
        except:
            LOG.error("Priors/bijectors are missing for " + col)
            sys.exit(1)

        for base in ["mu_d", "sigma_d", "fixed_d"]:
            config_model[base + "_loc_alpha"][config_model[base] == "Normal"] = 0
            config_model[base + "_scale_beta"][config_model[base] == "Normal"] = 5
            config_model[base + "_loc_alpha"][config_model[base] == "HalfCauchy"] = 0
            config_model[base + "_scale_beta"][config_model[base] == "HalfCauchy"] = 5
            config_model[base + "_loc_alpha"][config_model[base] == "Gamma"] = 50
            config_model[base + "_scale_beta"][config_model[base] == "Gamma"] = 30

        return config_model

    def create_framework_config_data(self, dictionary):
        """
        Creates a dataframe that contains the information about objective and sampling.

        Parameters
        ----------
        dictionary : dict
            dictionary generated by load_config() method.

        Returns
        -------
        framework_data : dataframe
            Contains the information about sampling and objective.

        """
        tagname_list = []
        value_list = []
        for key, value in dictionary["Framework"].items():
            tagname_list.append(key)
            value_list.append(value)
        for key, value in dictionary["Specifications"].items():
            if key != "add_globalintercept":
                tagname_list.append(key)
                if key not in ["add_globalintercept", "sampler"]:
                    if key == "hmc_step_size":
                        value_list.append(float(dictionary["Specifications"][key]))
                    else:
                        value_list.append(int(dictionary["Specifications"][key]))
                else:
                    value_list.append(dictionary["Specifications"][key])
        framework_data = pd.DataFrame(
            list(zip(tagname_list, value_list)), columns=["TagName", "Value"]
        )

        return framework_data

    def create_config(self, config_file_name):
        """
        Calls create_model_config_data(dictionary) and create_framework_config_data(dictionary) methods and creates an excel file that contains information about modelling.

        Parameters
        ----------
        config_file_name : str
            name of the excel file.

        Returns
        -------
        None.

        """
        dictionary = self.load_config()

        model_config_data = self.create_model_config_data(dictionary)
        framework_config_data = self.create_framework_config_data(dictionary)

        writer = pd.ExcelWriter(config_file_name)
        framework_config_data.to_excel(writer, sheet_name="Framework", index=False)
        model_config_data.to_excel(writer, sheet_name="Model", index=False)
        writer.save()
        writer.close()

    def get_config(self, config_file_name):
        """
        Calls the create_config(config_file_name) method if excel file doesn't exist.

        Parameters
        ----------
        config_file_name : str
            name of excel file.

        Returns
        -------
        model_config_df : dataframe
            contains information about variables.
        framework_config_df : dataframe
            contains framework and specification information.

        """
        if os.path.exists(config_file_name):
            LOG.info("Using existing Config excel")

        else:
            LOG.info("Creating new Config excel")
            self.create_config(config_file_name)
        model_config_df = pd.read_excel(config_file_name, sheet_name="Model")
        framework_config_df = pd.read_excel(config_file_name, sheet_name="Framework")

        return model_config_df, framework_config_df
