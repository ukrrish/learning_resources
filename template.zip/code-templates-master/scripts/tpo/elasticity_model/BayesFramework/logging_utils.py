import logging
import time 
import os 

t = time.localtime()
dt = time.strftime("%b-%d-%Y_%H%M", t)
if not os.path.exists("log/"):
    os.makedirs("log/")

def get_logger(name: str) -> logging.Logger:
    """
    Return a logger for the given module name
    Arguments:
        name {string} -- The name of the module
    Returns:
        [logging.logger] -- The logger instance
    """

    formatter = logging.Formatter(
        "[%(asctime)s] | "
        "%(filename)s | "
        "%(funcName)s | "
        "%(levelname)s | "
        "@ line %(lineno)d :"
        "%(message)s"
    )

    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # Output full log
    fh = logging.FileHandler("log/main_"+dt+".log")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    # Output warning log
    fh = logging.FileHandler("log/main_"+dt+".warning.log")
    fh.setLevel(logging.WARNING)
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    # Output error log
    fh = logging.FileHandler("log/main_"+dt+".error.log")
    fh.setLevel(logging.ERROR)
    #formatter = logging.Formatter(log_format)
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    return logger