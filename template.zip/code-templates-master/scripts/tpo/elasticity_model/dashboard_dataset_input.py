#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def Dashboard_dataset_ip_fn(Retailer, Category, File_type):
    """ """
    
    print("Selected File type : {}".format(File_type))
    # TODO - set global variable
    # Model Output Files directory
    processed_op_dir = "/Output Files/"

    if File_type=="General":
        # Input File Path
        # Model Estimates
        model_est_filename =  processed_op_dir + "Model_Est_" + Category + "_" + Retailer + "_all.pkl"
    
        # Cannibal Data
        cannibal_dat_filename = processed_op_dir + "Model_Cannibal_" + Category + "_" + Retailer + "_all.pkl"
        
        # Predictions
        base_dat_filename = processed_op_dir + "Model_Baselines_" + Category + "_" + Retailer + "_all.pkl"
        
        # Raw Data
        raw_dat_filename = processed_op_dir + "CrossBox_Model_EDLP_TPR_" + Category + "_" + Retailer + "_fnl.pkl"
        
        # Mapping_Description
        MappingFile_Description_path =  "RMS_Data_PPG_Mapping_" + Category + "_" + Retailer + ".pkl"
        
        # Filter ppg
        Filtered_PPGs =  processed_op_dir + "Revised_Filtered_PPG_Details_" + Category + "_" + Retailer + "_fnl.csv"
    
        
        # Output File Path
        # Model Estimates- Flat Format- Output File
        model_est_transformed_op_filename = processed_op_dir + "Model_Coefficients_EDLP_TPR_Tranformed_" + Category + "_" + Retailer + ".csv"
        
        # Model Est. for computing cannibalisation in Scenario Planning 
        scenarioplannining_cannibalisation_working_filename = processed_op_dir + "ModelEstForCannibalization_" + Category + "_" + Retailer + ".pkl"
        
        # Competitior Product Names- WB and CB
        comp_prd_dat_filename = processed_op_dir + "Competitor_Products_EDLP_TPR_Transformed_" + Category + "_" + Retailer + ".csv"
        
        # Cannibalisation Flat Report
        cannibal_dat_op_filename = processed_op_dir + "Cannibal_Data_" + Category + "_" + Retailer + ".csv"
        
        # Base Data with Predictions Flat Report
        base_transform_op_filename = processed_op_dir + "Base_Data_Transformed_" + Category + "_" + Retailer + ".csv"
        
        # Base Data with Predictions Flat Report Aggregated to Quarter
        base_transform_op_filename2 = processed_op_dir + "Base_Data_Transformed2_" + Category + "_" + Retailer + ".csv"
        
        # Dashboard UI Input Range
        price_agg_op_filename = processed_op_dir + "price_agg_" + Category + "_" + Retailer + ".csv"                            
        
    elif File_type =="Optimizer":
        # Input File Path    
        #Model Estimates
        model_est_filename = processed_op_dir + "Model_Est_" + Category + "_" + Retailer + "_all.pkl" 
        
        #Cannibal Data
        cannibal_dat_filename = processed_op_dir + "Model_Cannibal_" + Category + "_" + Retailer + "_all_Optimizer.pkl" 
        
        #Predictions
        base_dat_filename = processed_op_dir + "Model_Baselines_" + Category + "_" + Retailer + "_all_Optimizer.pkl" 
        
        #Raw Data
        raw_dat_filename = processed_op_dir + "CrossBox_Model_EDLP_TPR_" + Category + "_" + Retailer + "_fnl_Optimizer_2.pkl" 
        
        #Mapping_Description
        MappingFile_Description_path  =  "RMS_Data_PPG_Mapping_" + Category + "_" + Retailer + ".pkl"
        
        # Filter ppg
        Filtered_PPGs =  processed_op_dir + "Revised_Filtered_PPG_Details_" + Category + "_" + Retailer + "_fnl.csv"
        
        # Output File Path        
        # Model Estimates- Flat Format- Output File
        model_est_transformed_op_filename = processed_op_dir + "Model_Coefficients_EDLP_TPR_Tranformed_" + Category + "_" + Retailer + "_Optimizer.csv" 
        
        # Model Est. for computing cannibalisation in Scenario Planning 
        scenarioplannining_cannibalisation_working_filename = processed_op_dir + "ModelEstForCannibalization_" + Category + "_" + Retailer + ".pkl" 
        
        # Competitior Product Names- WB and CB
        comp_prd_dat_filename = processed_op_dir + "Competitor_Products_EDLP_TPR_Transformed_" + Category + "_" + Retailer + "_Optimizer.csv" 
        
        # Cannibalisation Flat Report
        cannibal_dat_op_filename = processed_op_dir + "Cannibal_Data_" + Category + "_" + Retailer + "_Optimizer.csv" 
        
        # Base Data with Predictions Flat Report
        base_transform_op_filename = processed_op_dir + "Base_Data_Transformed_" + Category + "_" + Retailer + "_Optimizer.csv" 
        
        # Base Data with Predictions Flat Report Aggregated to Quarter
        base_transform_op_filename2 = processed_op_dir + "Base_Data_Transformed2_" + Category + "_" + Retailer + "_Optimizer.csv" 
        
        # Dashboard UI Input Range
        price_agg_op_filename = processed_op_dir + "price_agg_" + Category + "_",Retailer + "_Optimizer.csv"
        print("Optimise ip file names created")
        
    var_list = locals().copy()
    del var_list["Retailer"], var_list["Category"], var_list["File_type"], var_list["processed_op_dir"]
    # print(var_list)
    globals().update(var_list)
