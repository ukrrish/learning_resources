#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

import matplotlib as mpl
mpl.rcParams.update({'figure.max_open_warning': 0})
                     
def get_linear_fit(x, y):
    z = np.polyfit(x, y, 1)
    p = np.poly1d(z)
    return p(x)

def plot_bar_chart(x, y, x_label, y_label, title, pdf):
    """ Generate bar chart"""
        
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    ax1.bar(x, y, color="b")
    ax1.set_xlabel(x_label)
    ax1.set_ylabel(y_label)
    ax1.set_title(title)
    plt.savefig(pdf, format='pdf')
    # plt.show()
    return pdf

def plot_line_chart(x, y, x_label, y_label, title=None, pdf=None, 
                    include_secondary_axis=False, include_linear_fit=False, **kwargs):
    
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    ax1.plot(x, y, 'g-', label=y_label)
    if include_linear_fit:
        ax1.plot(x, get_linear_fit(x, y), 'g-.')
    ax1.set_xlabel(x_label)
    ax1.set_ylabel(y_label)
    if title is not None:
        ax1.set_ylabel(title)
    
    if include_secondary_axis:
        ax2 = ax1.twinx()
        ax2.plot(x, kwargs["sec_axis_value"], 'b-', label=kwargs["sec_axis_label"])
        if include_linear_fit:
            ax2.plot(x, get_linear_fit(x, kwargs["sec_axis_value"]), 'b-.')
        ax2.set_ylabel(kwargs["sec_axis_label"])
        fig.legend(loc="upper center", ncol=2)
    plt.savefig(pdf, format='pdf')
    # plt.show()
    return pdf

def ppg_distribution(merged_ustotal_ppg_ip_filename, Model_Start_Date, Model_End_Date, recent_qtr_count=2, output_path="EDA"):
    """ Generate PPG distribution plots """
    
    input_sales_df_1 = pd.read_pickle(merged_ustotal_ppg_ip_filename)
    input_sales_df_1.rename(columns={"PPG_Item": "PPG_Item_No","PPGName": "PPG_Description","PPG_Category": "PPG_Cat"}, inplace=True)
          
    # ACV Adjustment
    acv_cols = [x for x in input_sales_df_1.columns.to_list() if "ACV" in x] 
    input_sales_df_1.loc[:,acv_cols] = input_sales_df_1.loc[:,acv_cols]/100
                    
    input_sales_df_1["PPG_Item_No"] = input_sales_df_1["PPG_Item_No"] + "_" + input_sales_df_1["PPG_Retailer"]
    input_sales_df_1["Year_Qtr"] = input_sales_df_1["Date"].dt.year.astype(str) + "_" + input_sales_df_1["Date"].dt.quarter.astype(str)
          
    input_sales_df_2 = input_sales_df_1[(input_sales_df_1["Date"]>=Model_Start_Date) & (input_sales_df_1["Date"]<Model_End_Date)]
    input_sales_df_2 = input_sales_df_2[(input_sales_df_2["wk_sold_doll_byppg"]>=0) & 
                                        (~input_sales_df_2["wk_sold_doll_byppg"].isna()) & 
                                        (input_sales_df_2["wk_sold_qty_byppg"]>=0) &
                                        (~input_sales_df_2["wk_sold_qty_byppg"].isna())]
    input_sales_df_2.rename(columns={"wk_avg_price_perunit_byppg": "wk_sold_avg_price_byppg"}, inplace=True)

    df = input_sales_df_2.copy()
    df = df.sort_values(by=["PPG_Cat","PPG_MFG","PPG_Item_No","Date"], ignore_index=True)

    total_datapoints = df["Date"].nunique()
    qtr_list = df["Year_Qtr"].sort_values().unique()
    recent_qtr_list = qtr_list[-recent_qtr_count:]                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
    df["recent_qtr_flag"] = df["Year_Qtr"].apply(lambda x: 1 if x in recent_qtr_list else 0)
    df["wk_sold_doll_byppg_in_recent_qtr"] = df["wk_sold_doll_byppg"]*df["recent_qtr_flag"]
    df_agg = df.groupby(by=["PPG_Item_No"], as_index=False).agg({"wk_sold_doll_byppg": np.nansum,
                                                                 "Date": pd.Series.nunique,
                                                                 "ACV_Selling": np.nansum,
                                                                 "wk_sold_avg_price_byppg": np.nanvar,
                                                                 "Year_Qtr": pd.Series.nunique,
                                                                 "wk_sold_doll_byppg_in_recent_qtr": np.nansum})
    df_agg = df_agg.rename(columns={"wk_sold_doll_byppg": "wk_sold_doll_byppg_sum",
                                    "Date": "Date_cnt",
                                    "ACV_Selling": "ACV_Selling_sum",
                                    "wk_sold_avg_price_byppg": "wk_sold_avg_price_byppg_var",
                                    "Year_Qtr": "Year_Qtr_cnt",
                                    "wk_sold_doll_byppg_in_recent_qtr": "wk_sold_doll_byppg_in_recent_qtr_sum"})
    df_agg["wk_sold_doll_byppg_avg"] = df_agg["wk_sold_doll_byppg_sum"]/df_agg["Year_Qtr_cnt"]
    df_agg["Date_pct"] = df_agg["Date_cnt"]/total_datapoints
    df_agg["ACV_Selling_mean"] = df_agg["ACV_Selling_sum"]/df_agg["Date_cnt"]
    df_agg["wk_sold_doll_byppg_in_recent_qtr_pct"] = df_agg["wk_sold_doll_byppg_in_recent_qtr_sum"]/df_agg["wk_sold_doll_byppg_sum"]

    tmp_plot_df = df_agg.copy()
    pdf = PdfPages(os.path.join(output_path,"ppg_distribution.pdf"))
    
    # PPGs Distribution
    # 1 Dollar Sales per Quarter
    var = "wk_sold_doll_byppg_avg"
    var_name = "Dollar Sales per Quarter"
    var_bin = [0, 2*10**3, 2*10**4, 4*10**4, 6*10**4, np.inf]
    var_bin_name = ["<2k", "2-20k", "20-40k", "40-60k", ">60k"]
    tmp_plot_df["var_bin"] = pd.cut(tmp_plot_df[var], bins=var_bin, labels=var_bin_name)
    ppg_dist = tmp_plot_df.groupby(by=["var_bin"], as_index=True).agg({"PPG_Item_No": len}).rename(columns={"PPG_Item_No": "cnt"})
    ppg_dist["cnt"] = ppg_dist["cnt"].fillna(0)
    ht = ppg_dist.loc[var_bin_name, "cnt"].to_list()
    pdf = plot_bar_chart(var_bin_name, ht, x_label=var_name, y_label="# PPGs", title="PPGs Distribution by " + var_name, pdf=pdf)

    # 2 Average ACV Selling (%)
    var = "Date_pct"
    var_name = "Data Availability (%)"
    var_bin = [0, .50, .70, .90, .95, 1]
    var_bin_name = ["<50%", "50-70%", "70-90%", "90-95%", ">95%"]
    tmp_plot_df["var_bin"] = pd.cut(tmp_plot_df[var], bins=var_bin, labels=var_bin_name)
    ppg_dist = tmp_plot_df.groupby(by=["var_bin"], as_index=True).agg({"PPG_Item_No": len}).rename(columns={"PPG_Item_No": "cnt"})
    ppg_dist["cnt"] = ppg_dist["cnt"].fillna(0)
    ht = ppg_dist.loc[var_bin_name, "cnt"].to_list()
    pdf = plot_bar_chart(var_bin_name, ht, x_label=var_name, y_label="# PPGs", title="PPGs Distribution by " + var_name, pdf=pdf)
    
    # 3 Average ACV Selling (%)
    var = "ACV_Selling_mean"    
    var_name = "Average ACV Selling (%)"
    var_bin = [0, .20, .40, .60, .80, 1]
    var_bin_name = ["<20%", "20-40%", "40-60%", "60-80%", ">80%"]
    tmp_plot_df["var_bin"] = pd.cut(tmp_plot_df[var], bins=var_bin, labels=var_bin_name)
    ppg_dist = tmp_plot_df.groupby(by=["var_bin"], as_index=True).agg({"PPG_Item_No": len}).rename(columns={"PPG_Item_No": "cnt"})
    ppg_dist["cnt"] = ppg_dist["cnt"].fillna(0)
    ht = ppg_dist.loc[var_bin_name, "cnt"].to_list()
    pdf = plot_bar_chart(var_bin_name, ht, x_label=var_name, y_label="# PPGs", title="PPGs Distribution by " + var_name, pdf=pdf)
    
    # 4 Sold Unit Price Variance
    var = "wk_sold_avg_price_byppg_var"    
    var_name = "Sold Unit Price Variance"
    var_bin = [0, 0.01, 0.15, .35, .50, np.inf]
    var_bin_name = ["<0.01", "0.01-0.15", "0.15-0.35", "0.35-0.50", ">0.50"]
    tmp_plot_df["var_bin"] = pd.cut(tmp_plot_df[var], bins=var_bin, labels=var_bin_name)
    ppg_dist = tmp_plot_df.groupby(by=["var_bin"], as_index=True).agg({"PPG_Item_No": len}).rename(columns={"PPG_Item_No": "cnt"})
    ppg_dist["cnt"] = ppg_dist["cnt"].fillna(0)
    ht = ppg_dist.loc[var_bin_name, "cnt"].to_list()
    pdf = plot_bar_chart(var_bin_name, ht, x_label=var_name, y_label="# PPGs", title="PPGs Distribution by " + var_name, pdf=pdf)
    
    # 5 Dollar Sales in Recent Quarters (% Share)
    var = "wk_sold_doll_byppg_in_recent_qtr_pct"    
    var_name = "Dollar Sales in Recent Quarters (% Share)"
    var_bin = [0, 0.10, 0.20, .30, .40, 1]
    var_bin_name = ["<10%", "10-20%", "20-30%", "30-40%", ">40%"]
    tmp_plot_df["var_bin"] = pd.cut(tmp_plot_df[var], bins=var_bin, labels=var_bin_name)
    ppg_dist = tmp_plot_df.groupby(by=["var_bin"], as_index=True).agg({"PPG_Item_No": len}).rename(columns={"PPG_Item_No": "cnt"})
    ppg_dist["cnt"] = ppg_dist["cnt"].fillna(0)
    ht = ppg_dist.loc[var_bin_name, "cnt"].to_list()
    pdf = plot_bar_chart(var_bin_name, ht, x_label=var_name, y_label="# PPGs", title="PPGs Distribution by " + var_name, pdf=pdf)
    
    pdf.close()
    return None

def generate_elasticity_eda_plots(filtered_model_dataset_filename, ActingItem_list, base_dir1, output_path="EDA"):
    """ Generate Price Elasiticity EDA plots """
            
    # Loading the Model Dataset & CMI Acting Item Dataset
    os.chdir(base_dir1)
    Acting_Item = pd.read_pickle(ActingItem_list)    
    os.chdir(os.path.join(base_dir1,"Output Files"))
    model_df_1 = pd.read_pickle(filtered_model_dataset_filename + ".pkl")
    model_df_1["wk_sold_median_base_price_byppg"] = model_df_1["wk_sold_median_base_price_byppg_log"].apply(lambda x: np.exp(x))
    # model_df_1 = pd.read_pickle(filtered_model_dataset_filename + "_Optimizer_1.pkl")

    ppg_list_to_model = model_df_1.loc[model_df_1["PPG_MFG"]=="NPP","PPG_Item_No"].unique()
    if len(ppg_list_to_model)==0:        
        print("No PPGs of selected Manufacturer present")
        return None
        
    PPG = model_df_1.loc[(model_df_1["PPG_MFG"]=="NPP") & (~model_df_1["PPG_Item_No"].str.contains("ROM", regex=False)),"PPG_Item_No"].unique() # model_df_1["PPG_Retailer"]!="ROM"
    
    # # Extracting Acting Items based on CMI list
    # acting_ppg = pd.DataFrame(columns=["PPG_Item_No", "Acting_Items"])   
    # inter_ppg = pd.DataFrame(columns=["PPG_Item_No", "Acting_Items"])
    # for i in ppg_list_to_model:   
    #     ppg = i.replace("_ROM","") if "_ROM" in i else i.replace("_Retailer","")
    #     acting_items = Acting_Item[Acting_Item["Base_Item"].str.contains(ppg, regex=False)]["Acting_Item"].unique()
    #     acting_items = [j+"_Retailer" for j in acting_items] + [j+"_ROM" for j in acting_items]
    #     acting_items = [item for item in acting_items if i not in item]
    #     acting_items = [item for item in acting_items if item in model_df_1["PPG_Item_No"].unique()]       
    #     if len(acting_items)==0:
    #         continue
    #     temp_1 = pd.DataFrame({"PPG_Item_No": [i]*len(acting_items),"Acting_Items": acting_items})
    #     acting_ppg = acting_ppg.append(temp_1, ignore_index=True)
    #     len(acting_ppg)
        
    # if len(acting_ppg)>0:
    #     inter_ppg = acting_ppg[(acting_ppg["PPG_Item_No"].isin(PPG)) & (acting_ppg["Acting_Items"].str.contains("Retailer", regex=False))]
        
    # # Creating Acting item list for UPCs (without PPGs)	
    # ppg_wt_acting_items = acting_ppg["PPG_Item_No"].unique()
    # ppg_wo_acting_items = [ppg for ppg in ppg_list_to_model if ppg not in ppg_wt_acting_items]
    # upc_list = model_df_1.loc[(model_df_1["PPG_Item_No"].isin(ppg_wo_acting_items)) & (model_df_1["PPG_Item_No"]=="ITEM"+model_df_1["PPG_Description"]),"PPG_Item_No"].unique()
    # for i in upc_list:
    #     acting_items = [j+"_Retailer" for j in ppg_list_to_model] + [j+"_ROM" for j in ppg_list_to_model]
    #     acting_items = [item for item in acting_items if i not in item]
    #     acting_items = [item for item in acting_items if item in model_df_1["PPG_Item_No"].unique()]
    #     temp_1 = pd.DataFrame({"PPG_Item_No": [i]*len(acting_items),"Acting_Items": acting_items})
    #     acting_ppg = acting_ppg.append(temp_1, ignore_index=True)
        
    model_df_1 = model_df_1.sort_values(by=["PPG_Cat","PPG_MFG","PPG_Item_No","Date"], ignore_index=True)
        
    
    # EDA
    print("No. of PPGs to model : {}".format(len(ppg_list_to_model)))
    for ppg_no, ppg in enumerate(ppg_list_to_model):
        print("{}. PPG: {}".format(ppg_no, ppg))
        slct_cols_2 = ["PPG_Item_No","Date",
                       "wk_sold_qty_byppg", "wk_sold_median_base_price_byppg",
                       "wk_sold_qty_byppg_log", "wk_sold_median_base_price_byppg_log",
                       "tpr_discount_byppg",  "tpr_discount_byppg_lag1", "tpr_discount_byppg_lag2",
                       "ACV_Selling", "ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp", 
                       "category_trend",  "flag_qtr2", "flag_qtr3", "flag_qtr4",
                       "monthno","Missing_data_flag"]
        ppg_model_df = model_df_1.loc[model_df_1["PPG_Item_No"]==ppg,model_df_1.columns.isin(slct_cols_2)].reset_index(drop=True)        
        ppg_model_df = model_df_1.sort_values(by=["PPG_Item_No","Date"], ignore_index=True)
        pdf = PdfPages(os.path.join(output_path, ppg+".pdf"))

        # Selling Price
        # 1 Unit Sales & EDLP over time
        x = ppg_model_df.index.to_numpy()+1
        y1 = ppg_model_df["wk_sold_qty_byppg"].to_numpy()
        y2 = ppg_model_df["wk_sold_median_base_price_byppg"].to_numpy()
        pdf = plot_line_chart(x, y1, x_label="Week (#)", y_label="Own Unit Sales", pdf=pdf,
                             include_secondary_axis=True, include_linear_fit=False,
                             sec_axis_value=y2, sec_axis_label="EDLP")

        # 2 Unit Sales vs EDLP
        x = ppg_model_df["wk_sold_median_base_price_byppg"].to_numpy()
        y = ppg_model_df["wk_sold_qty_byppg"].to_numpy()
        fig = plt.figure()
        ax1 = fig.add_subplot(111)
        ax1.scatter(x, y, c="b")
        ax1.plot(x, get_linear_fit(x, y), "r-.")     
        ax1.set_xlabel('EDLP')
        ax1.set_ylabel('Own Unit Sales')
        ax1.set_title("Unit Sales vs EDLP")        
        plt.savefig(pdf, format='pdf')      
        
        # 3 Unit Sales vs EDLP (Log Transformation)
        x = ppg_model_df["wk_sold_median_base_price_byppg_log"].to_numpy()
        y = ppg_model_df["wk_sold_qty_byppg_log"].to_numpy()
        fig = plt.figure()
        ax1 = fig.add_subplot(111)
        ax1.scatter(x, y,c="b")
        ax1.plot(x, get_linear_fit(x, y), "r-.")
        ax1.set_xlabel('EDLP (Log Transform)')
        ax1.set_ylabel('Own Unit Sales (Log Transform)')
        ax1.set_title("Unit Sales vs EDLP (Log Transform)")
        plt.savefig(pdf, format='pdf')      

        # 4 Unit Sales & TPR over time
        x = ppg_model_df.index.to_numpy()+1
        y1 = ppg_model_df["wk_sold_qty_byppg"].to_numpy()
        y2 = ppg_model_df["tpr_discount_byppg"].to_numpy()*100
        pdf = plot_line_chart(x, y1, x_label="Week (#)", y_label="Own Unit Sales",
                             pdf=pdf, include_secondary_axis=True, include_linear_fit=False,
                             sec_axis_value=y2, sec_axis_label="TPR Discount (%)")
        

        # ACV , "ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp"
        # 1 Unit Sales & ACV Selling over time
        x = ppg_model_df.index.to_numpy()+1
        y1 = ppg_model_df["wk_sold_qty_byppg"].to_numpy()
        y2 = ppg_model_df["ACV_Selling"].to_numpy()*100
        pdf = plot_line_chart(x, y1, x_label="Week (#)", y_label="Own Unit Sales", pdf=pdf, 
                             include_secondary_axis=True, include_linear_fit=True,
                             sec_axis_value=y2, sec_axis_label="ACV Selling (%)")
        
        # 2 Unit Sales & ACV Feature over time                
        y2 = ppg_model_df["ACV_Feat_Only"].to_numpy()*100
        pdf = plot_line_chart(x, y1, x_label="Week (#)", y_label="Own Unit Sales", pdf=pdf, 
                             include_secondary_axis=True, include_linear_fit=True,
                             sec_axis_value=y2, sec_axis_label="ACV Feature (%)")

        # 3 Unit Sales & ACV Display over time        
        y2 = ppg_model_df["ACV_Disp_Only"].to_numpy()*100
        pdf = plot_line_chart(x, y1, x_label="Week (#)", y_label="Own Unit Sales", pdf=pdf, 
                             include_secondary_axis=True, include_linear_fit=True,
                             sec_axis_value=y2, sec_axis_label="ACV Display (%)")

        # 4 Unit Sales & ACV Feature - Display over time
        y2 = ppg_model_df["ACV_Feat_Disp"].to_numpy()*100
        pdf = plot_line_chart(x, y1, x_label="Week (#)", y_label="Own Unit Sales",pdf=pdf,
                             include_secondary_axis=True, include_linear_fit=True,
                             sec_axis_value=y2, sec_axis_label="ACV Feature & Display (%)")
        

        # Category Trend
        x = ppg_model_df.index.to_numpy()+1
        y1 = ppg_model_df["wk_sold_qty_byppg"].to_numpy()        
        y2 = ppg_model_df["category_trend"].to_numpy()
        pdf = plot_line_chart(x, y1, x_label="Week (#)", y_label="Own Unit Sales", pdf=pdf, 
                             include_secondary_axis=True, include_linear_fit=True,
                             sec_axis_value=y2, sec_axis_label="Category Dollar Sales (Normalized)")
        
        
        # Seasonality
        # 1 Unit Sales by Quarter
        tmp_df = ppg_model_df.copy()
        tmp_df["Quarter"] = ppg_model_df["Date"].dt.quarter
        tmp_agg = tmp_df.groupby(by="Quarter", as_index=False).agg({"wk_sold_qty_byppg": np.nansum})
        tmp_agg = tmp_agg.rename(columns={"wk_sold_qty_byppg": "wk_sold_qty_byppg_sum"})     
        tmp_agg["Quarter"] = tmp_agg["Quarter"].apply(lambda x: "Q"+str(x))
        tmp_agg = tmp_agg.sort_values(by=["Quarter"], axis=0)
        x = tmp_agg["Quarter"].to_numpy()
        y = tmp_agg["wk_sold_qty_byppg_sum"].to_numpy()
        pdf = plot_bar_chart(x, y, x_label="Quarter", y_label="Own Unit Sales", title="Unit Sales by Quarter", pdf=pdf)
        
        # 2 Unit Sales by Month
        tmp_df = ppg_model_df.copy()
        tmp_df["Month"] = ppg_model_df["Date"].dt.month_name().apply(lambda x: x[0:3])
        tmp_df["Month_no"] = ppg_model_df["Date"].dt.month
        tmp_agg = tmp_df.groupby(by=["Month", "Month_no"], as_index=False).agg({"wk_sold_qty_byppg": np.nansum})
        tmp_agg = tmp_agg.rename(columns={"wk_sold_qty_byppg": "wk_sold_qty_byppg_sum"})     
        tmp_agg = tmp_agg.sort_values(by=["Month_no"], axis=0)
        x = tmp_agg["Month"].to_numpy()
        y = tmp_agg["wk_sold_qty_byppg_sum"].to_numpy()
        pdf = plot_bar_chart(x, y, x_label="Month", y_label="Own Unit Sales", title="Unit Sales by Month", pdf=pdf)
        
        # 3 Unit Sales by Week
        x = ppg_model_df.index.to_numpy()+1
        y = ppg_model_df["wk_sold_qty_byppg"].to_numpy()
        pdf = plot_line_chart(x, y, x_label="Week (#)", y_label="Own Unit Sales", pdf=pdf,
                             include_secondary_axis=False, include_linear_fit=True)
        
        # TODO: Competitor EDA plots
        # ppg_acting_items = acting_ppg.loc[acting_ppg["PPG_Item_No"]==ppg, "Acting_Items"].unique()
        # for item in ppg_acting_items:
        #     ai_model_df = model_df.loc[model_df["PPG_Item_No"]==item,slct_cols_2].reset_index(drop=True)        
        #     ai_model_df = ai_model_df.sort_values(by=["PPG_Item_No","Date"], ignore_index=True)
        #     ai_model_df = ai_model_df.rename({"wk_sold_median_base_price_byppg": "comp_wk_sold_median_base_price_byppg",
        #                                       "wk_sold_median_base_price_byppg_log": "comp_wk_sold_median_base_price_byppg_log",
        #                                       "tpr_discount_byppg": "comp_tpr_discount_byppg"})
        #     tmp_ppg_model_df = ppg_model_df.merge(item, how="left", on="Date")
            
        #     # 1 Unit Sales & EDLP over time
        #     x = tmp_ppg_model_df.index.to_numpy()+1
        #     y1 = tmp_ppg_model_df["wk_sold_qty_byppg"].to_numpy()
        #     y2 = tmp_ppg_model_df["comp_wk_sold_median_base_price_byppg"].to_numpy()
        #     pdf = plot_line_chart(x, y1, x_label="Week (#)", y_label="Own Unit Sales", pdf=pdf, title="Competitor: " + item,
        #                          include_secondary_axis=True, include_linear_fit=False,
        #                          sec_axis_value=y2, sec_axis_label="Competitor EDLP")
    
        #     # 2 Unit Sales vs EDLP
        #     x = ppg_model_df["comp_wk_sold_median_base_price_byppg"].to_numpy()
        #     y = ppg_model_df["wk_sold_qty_byppg"].to_numpy()
        #     fig = plt.figure()
        #     ax1 = fig.add_subplot(111)
        #     ax1.scatter(x, y, c="b")
        #     ax1.plot(x, p(x), "r-.")     
        #     ax1.set_xlabel('EDLP')
        #     ax1.set_ylabel('Own Unit Sales')
        #     ax1.set_title("Unit Sales vs Competitor EDLP")        
        #     plt.savefig(pdf, format='pdf')      
            
        #     # 3 Unit Sales vs EDLP (Log Transformation)
        #     x = ppg_model_df["comp_wk_sold_median_base_price_byppg_log"].to_numpy()
        #     y = ppg_model_df["wk_sold_qty_byppg_log"].to_numpy()
        #     fig = plt.figure()
        #     ax1 = fig.add_subplot(111)
        #     ax1.scatter(x, y,c="b")
        #     ax1.plot(x, p(x), "r-.")
        #     ax1.set_xlabel('EDLP (Log Transform)')
        #     ax1.set_ylabel('Own Unit Sales (Log Transform)')
        #     ax1.set_title("Unit Sales vs Competitor EDLP (Log Transform)")
        #     plt.savefig(pdf, format='pdf')      
    
        #     # 4 Unit Sales & TPR over time
        #     x = ppg_model_df.index.to_numpy()+1
        #     y1 = ppg_model_df["wk_sold_qty_byppg"].to_numpy()
        #     y2 = ppg_model_df["comp_tpr_discount_byppg"].to_numpy()*100
        #     pdf = plot_line_chart(x, y1, x_label="Week (#)", y_label="Own Unit Sales",
        #                          pdf=pdf, include_secondary_axis=True, include_linear_fit=False,
        #                          sec_axis_value=y2, sec_axis_label="Competitor TPR Discount (%)")
            
            
        pdf.close()
    return None
        

def generate_post_model_eda_plots(model_est_dat_filename, filtered_ppg_filename, base_dir1, output_path="EDA"):
    """ Generate Price Elasiticity EDA plots """    
        
    os.chdir(os.path.join(base_dir1, "Output Files"))
    model_results_final = pd.read_pickle(model_est_dat_filename+".pkl")
    Filter_PPG_Summary = pd.read_csv(filtered_ppg_filename)
    
    model_metrics = model_results_final[['PPG_Item_No', 'model_RSq', 'TrainMAPE']].drop_duplicates()
    tmp_plot_df = model_metrics.copy()
    pdf = PdfPages(os.path.join(output_path,"post_model_eda.pdf"))
    
    # PPGs Distribution
    # 1 R Squared
    var = "model_RSq"
    var_name = "R Squared (Train data)"
    var_bin = [0, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80, 0.90, 1]
    var_bin_name = ["<30%", "30-40%", "40-50%", "50-60%", "60-70%", "70-80%", "80-90%", ">90%"]
    tmp_plot_df["var_bin"] = pd.cut(tmp_plot_df[var], bins=var_bin, labels=var_bin_name)
    ppg_dist = tmp_plot_df.groupby(by=["var_bin"], as_index=True).agg({"PPG_Item_No": len}).rename(columns={"PPG_Item_No": "cnt"})
    ppg_dist["cnt"] = ppg_dist["cnt"].fillna(0)
    ht = ppg_dist.loc[var_bin_name, "cnt"].to_list()
    pdf = plot_bar_chart(var_bin_name, ht, x_label=var_name, y_label="# PPGs", title="PPGs Distribution by " + var_name, pdf=pdf)
    
    # 2 MAPE
    var = "TrainMAPE"
    var_name = "MAPE (Train data)"
    var_bin = [0, 0.02, 0.04, 0.06, 0.08, np.inf]
    var_bin_name = ["<2%", "2-4%", "4-6%", "6-8%", ">8%"]
    tmp_plot_df["var_bin"] = pd.cut(tmp_plot_df[var], bins=var_bin, labels=var_bin_name)
    ppg_dist = tmp_plot_df.groupby(by=["var_bin"], as_index=True).agg({"PPG_Item_No": len}).rename(columns={"PPG_Item_No": "cnt"})
    ppg_dist["cnt"] = ppg_dist["cnt"].fillna(0)
    ht = ppg_dist.loc[var_bin_name, "cnt"].to_list()
    pdf = plot_bar_chart(var_bin_name, ht, x_label=var_name, y_label="# PPGs", title="PPGs Distribution by " + var_name, pdf=pdf)    

    # 3 EDLP Elasiticity    
    model_elasicity = model_results_final[['PPG_Item_No', 'model_coefficient_name', 'model_coefficient_value']].drop_duplicates()
    temp_model_elasicity = model_elasicity[model_elasicity["model_coefficient_name"].isin(["wk_sold_median_base_price_byppg_log"])]
    tmp_plot_df = temp_model_elasicity.copy()
    
    var = "model_coefficient_value"
    var_name = "EDLP Elasicity"
    var_bin = [-np.inf, -5, -4, -3, -2, -1, 0]
    var_bin_name = ["<-5", "-4 to -5", "-3 to -4", "-2 to -3", "-1 to -2", "0 to -1"]
    tmp_plot_df["var_bin"] = pd.cut(tmp_plot_df[var], bins=var_bin, labels=var_bin_name)
    ppg_dist = tmp_plot_df.groupby(by=["var_bin"], as_index=True).agg({"PPG_Item_No": len}).rename(columns={"PPG_Item_No": "cnt"})
    ppg_dist["cnt"] = ppg_dist["cnt"].fillna(0)
    ht = ppg_dist.loc[var_bin_name[::-1], "cnt"].to_list()
    pdf = plot_bar_chart(var_bin_name[::-1], ht, x_label=var_name, y_label="# PPGs", title="PPGs Distribution by " + var_name, pdf=pdf)    
    
    # 4 TPR Elasiticity    
    model_elasicity = model_results_final[['PPG_Item_No', 'model_coefficient_name', 'model_coefficient_value']].drop_duplicates()
    temp_model_elasicity = model_elasicity[model_elasicity["model_coefficient_name"].isin(["tpr_discount_byppg"])]
    tmp_plot_df = temp_model_elasicity.copy()
    
    var = "model_coefficient_value"
    var_name = "TPR Elasicity"
    var_bin = [0, 1, 2, 3, 4, 5, np.inf]
    var_bin_name = ["0 to 1", "1 to 2", "2 to 3", "3 to 4", "4 to 5", ">5"]
    tmp_plot_df["var_bin"] = pd.cut(tmp_plot_df[var], bins=var_bin, labels=var_bin_name)
    ppg_dist = tmp_plot_df.groupby(by=["var_bin"], as_index=True).agg({"PPG_Item_No": len}).rename(columns={"PPG_Item_No": "cnt"})
    ppg_dist["cnt"] = ppg_dist["cnt"].fillna(0)
    ht = ppg_dist.loc[var_bin_name, "cnt"].to_list()
    pdf = plot_bar_chart(var_bin_name, ht, x_label=var_name, y_label="# PPGs", title="PPGs Distribution by " + var_name, pdf=pdf)

    # 5 ACV Selling
    model_elasicity = model_results_final[['PPG_Item_No', 'model_coefficient_name', 'model_coefficient_value']].drop_duplicates()
    temp_model_elasicity = model_elasicity[model_elasicity["model_coefficient_name"].isin(["ACV_Selling"])]
    tmp_plot_df = temp_model_elasicity.copy()
    
    var = "model_coefficient_value"
    var_name = "ACV Selling Elasicity"
    var_bin = [0, 1, 2, 3, 4, 5, np.inf]
    var_bin_name = ["0 to 1", "1 to 2", "2 to 3", "3 to 4", "4 to 5", ">5"]
    tmp_plot_df["var_bin"] = pd.cut(tmp_plot_df[var], bins=var_bin, labels=var_bin_name)
    ppg_dist = tmp_plot_df.groupby(by=["var_bin"], as_index=True).agg({"PPG_Item_No": len}).rename(columns={"PPG_Item_No": "cnt"})
    ppg_dist["cnt"] = ppg_dist["cnt"].fillna(0)
    ht = ppg_dist.loc[var_bin_name, "cnt"].to_list()
    pdf = plot_bar_chart(var_bin_name, ht, x_label=var_name, y_label="# PPGs", title="PPGs Distribution by " + var_name, pdf=pdf)    
    pdf.close()
    
    # TODO - 
    # Actual Sales vs Predicted Sales
    
    return None
    

# TODO: Set base directory
base_dir = "/home/srinathbala/Documents/NPP/npp-tpo"
code_path = os.path.join(base_dir)
data_path = os.path.join(base_dir,"Data")
os.chdir(code_path)

# 1 PPG Distribution
# TODO: Set filename (Output of data preparation module), Model start & end date and output path
filename = "Data_Prep_OP/Retailer1/Category1/RMS_Data_PPG_Category1_Retailer1.pkl"
date_range = {"start_dt": ["2017-01-01","2017-04-01","2017-07-01","2017-10-01","2018-01-01"],
              "end_dt": ["2019-01-01","2019-04-01","2019-07-01","2019-10-01","2020-01-01"]}
date_range_df = pd.DataFrame(date_range)
Model_Start_Date = date_range_df.iloc[-1,0]
Model_End_Date = date_range_df.iloc[-1,1]
output_path = "/home/srinathbala/Documents/NPP/npp-tpo/EDA"
ppg_distribution(filename, Model_Start_Date, Model_End_Date, recent_qtr_count=2, output_path=output_path)

# 2 Price Elasiticity EDA
# TODO:  Set Acting Items, Filtered data (output of model filtering function), base directory and output path
ActingItem_list="ActingItem_list_Category1_Retailer1.pkl"
filtered_model_dataset_filename="CrossBox_Model_EDLP_TPR_Category1_Retailer1"
base_dir1 = os.path.join(code_path, "Data_Prep_OP/Retailer1/Category1")
output_path = "/home/srinathbala/Documents/NPP/npp-tpo/EDA"
generate_elasticity_eda_plots(filtered_model_dataset_filename, ActingItem_list, base_dir1, output_path)
# model_df = pd.read_pickle("/home/srinathbala/Documents/NPP/npp-tpo/Data_Prep_OP/Retailer1/Category1/Output Files/CrossBox_Model_EDLP_TPR_Category1_Retailer1.pkl")
        
# 3 Post Model EDA    
# TODO:  Set PPG Summary (PPG Summary of model building function), Model estimation (output of model building function), base directory and output path
filtered_ppg_filename = "Revised_Filtered_PPG_Details_Category1_Retailer1_fnl.csv"
model_est_dat_filename = "Model_Est_Category1_Retailer1_Optimizer"
base_dir1 = os.path.join(code_path, "Data_Prep_OP/Retailer1/Category1")
output_path = "/home/srinathbala/Documents/NPP/npp-tpo/EDA"
generate_post_model_eda_plots(model_est_dat_filename, filtered_ppg_filename, base_dir1, output_path)    