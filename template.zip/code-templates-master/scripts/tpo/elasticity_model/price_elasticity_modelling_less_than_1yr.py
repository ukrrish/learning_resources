#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import re
import os
import statsmodels.api as sm
import statsmodels.formula.api as smf
from sklearn import linear_model
from sklearn import preprocessing
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.model_selection import StratifiedKFold
import random
from datetime import datetime
import pdb
import openpyxl
import BayesFramework.model_config_handler as mch
import BayesFramework.Regression as reg

from price_elasticity_modelling_1yr import prepare_optimizer_data
from price_elasticity_modelling_2yr import save_empty_dataframe, RegularPrice_InteractionVariables, TradePromotions_InteractionVariables, model_func, cannibalisation_module, cross_validation
from my_utils import category_format_fn, retailer_format_fn


def generate_bayes_config(dv, re_prior_df=None, fe_prior_df=None, no_iter=500, no_warmup_iter=500, no_chain=4, no_leapfrog_steps=10, hmc_step_size=0.01, filename="test.excel"):
    """ Make changes to configuration excel """
    
    # Initialization
    # Framework Parameter
    framework_dict = {"objective": ["regression"],
                    "sampler": ["nuts"],       
                    "num_chains": [no_chain],
                    "num_results": [no_iter],
                    "num_burnin_steps": [no_warmup_iter],
                    "num_leapfrog_steps": [no_leapfrog_steps],
                    "hmc_step_size": [hmc_step_size]}
    framework_df = pd.DataFrame.from_dict(framework_dict, orient="index").reset_index()
    framework_df = framework_df.rename(columns={"index": "TagName", 0: "Value"})
    
    # Model Parameter
    mdl_params_df = pd.DataFrame(columns=["DV", "IDV", "Include_IDV", "RandomEffect", "RandomFactor",
                                         "mu_d", "mu_d_loc_alpha", "mu_d_scale_beta", 
                                         "sigma_d", "sigma_d_loc_alpha", "sigma_d_scale_beta",	
                                         "mu_bijector", "sigma_bijector", 
                                         "fixed_d", "fixed_d_loc_alpha", "fixed_d_scale_beta", "fixed_bijector"])    
    if re_prior_df is not None:
        re_prior_df = re_prior_df.rename(columns={"model_coefficient_name": "IDV",
                                                  "group_variable" : "RandomFactor",
                                                  "mu_dist": "mu_d",
                                                  "mean_mdl_coef_est": "mu_d_loc_alpha",
                                                  "std_mdl_coef_est": "mu_d_scale_beta",
                                                  "mu_bijector": "mu_bijector",
                                                  "sigma_dist": "sigma_d",
                                                  "mean_mdl_coef_std_err": "sigma_d_loc_alpha",
                                                  "std_mdl_coef_std_err": "sigma_d_scale_beta",
                                                  "sigma_bijector": "sigma_bijector"})
        re_prior_df["DV"] = dv
        re_prior_df["Include_IDV"] = 1
        re_prior_df["RandomEffect"] = 1
        mdl_params_df = mdl_params_df.append(re_prior_df, ignore_index=True)
    if fe_prior_df is not None:
        fe_prior_df = fe_prior_df.rename(columns={"model_coefficient_name": "IDV",
                                                  "distribution": "fixed_d",
                                                  "model_coefficient_value": "fixed_d_loc_alpha",
                                                  "model_coefficient_std": "fixed_d_scale_beta",
                                                  "bijector": "fixed_bijector"})
        fe_prior_df["DV"] = dv
        fe_prior_df["Include_IDV"] = 1
        fe_prior_df["RandomEffect"] = 0
        mdl_params_df = mdl_params_df.append(fe_prior_df, ignore_index=True)

    # Save config excel        
    config_xlsx = pd.ExcelWriter(filename, engine="openpyxl")
    framework_df.to_excel(config_xlsx, "Framework", index=False)
    mdl_params_df.to_excel(config_xlsx, "Model", index=False)
    config_xlsx.save()
    
    
def model_func_less_than_1yr(model_df_1,model_df_2,temp_2,temp_2b,ppg,seed,
                             temp_cols,model_coefficients_final,lwr_bound,upr_bound):
    """ Build Lasso Regularization Model """

    box_matrix = temp_2.drop(columns=["Date","PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description","DV"])
    box_matrix_opt = temp_2b.drop(columns=["Date","PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description","DV"])
    # box_matrix["flag"] = box_matrix["PPG_Item_No"].apply(lambda x: "New" if x==ppg else "Old")
    # box_matrix_opt["flag"] = box_matrix_opt["PPG_Item_No"].apply(lambda x: "New" if x==ppg else "Old")
        
    # Specail Case for seed - 123
    # if seed==123:
    #     lwr_bound = [bound for i,bound in enumerate(lwr_bound) if temp_cols[i] in model_coefficients_final]
    #     upr_bound = [bound for i,bound in enumerate(upr_bound) if temp_cols[i] in model_coefficients_final]
    # temp_colsb = box_matrix.columns.to_list()

    # Missing Value Treatment
    impute_cols = [col for col in box_matrix.columns.to_list() if (("flag" not in col) and 
                                                                   (col!="tpr_discount_byppg") and 
                                                                   ("_PromotedDiscount" not in col) and 
                                                                   (col not in ["tpr_discount_byppg_lag1","tpr_discount_byppg_lag2"])
                                                                   )]    
    if len(impute_cols)>0:
        impute_dict_1 = box_matrix[impute_cols].mean(skipna=True).to_dict()
        box_matrix = box_matrix.fillna(impute_dict_1)  
        impute_dict_2 = box_matrix_opt[impute_cols].mean(skipna=True).to_dict()
        box_matrix_opt = box_matrix_opt.fillna(impute_dict_2)                        
    box_matrix = box_matrix.fillna(0)
    box_matrix[abs(box_matrix)==np.inf] = 0
    box_matrix_opt = box_matrix_opt.fillna(0)
    box_matrix_opt[abs(box_matrix_opt)==np.inf] = 0        
    box_matrix.index = temp_2["Date"]
    box_matrix_opt.index = temp_2b["Date"]
    
    ppg_adj = re.sub("_ROM", "_Retailer", ppg) if "_ROM" in ppg else re.sub("_ROM", "_Retailer", ppg)
    pen_factor = [col!="wk_sold_median_base_price_byppg_log" and  col!="tpr_discount_byppg" and
                  col!="tpr_discount_byppg_lag1" and col!="tpr_discount_byppg_lag2" and
                  col!="wk_sold_median_base_price_byppg_log" and
                  col!= ppg_adj for col in temp_cols]
    # if seed in [71, 123]:
    #     # pdb.set_trace()
    #     print("PPG: {}".format(ppg))
    #     print("Seed: {}".format(seed))
    #     print("NA Cases:")
    #     print(box_matrix.isna().sum().sum())
    #     print(box_matrix.mean(skipna=True))   

            
    # Mixed Effect Model
    # TODO - Include expection handling and consider penalty factor
    # Remove linear dependent columns due to singular error
    temp_box_matrix = box_matrix.to_numpy()
    qr_matrix = np.linalg.qr(temp_box_matrix)
    linear_independent_cols = box_matrix.loc[:,np.abs(np.diag(qr_matrix[1]))>=1e-10].columns  # TODO - check it is dropping important cols
    lwr_bound = [bound for i,bound in enumerate(lwr_bound) if temp_cols[i] in linear_independent_cols]
    upr_bound = [bound for i,bound in enumerate(upr_bound) if temp_cols[i] in linear_independent_cols]

    random.seed(123)
    group_var = "PPG_Item_No"
    mdl_formula = "DV ~ 0 + " + " + ".join([col for col in linear_independent_cols if col!="ACV_Selling"])
    md = smf.mixedlm(mdl_formula, pd.concat([box_matrix, temp_2[["Date", "DV", "PPG_Item_No"]].set_index("Date")], axis="columns"),
                     groups=temp_2[group_var], re_formula="~  ACV_Selling")
    mdf = md.fit()
    fe_params = mdf.fe_params
    re_params = pd.Series([], dtype=np.float64)
    for _, params in mdf.random_effects.items():
        re_params = re_params.append(params)


    # Bayesian Model
    temp_bayes_df = pd.concat([box_matrix, temp_2[["Date", "DV", "PPG_Item_No"]].set_index("Date")], axis="columns")
    
    # Fixed effects prior (mean and std. deviation kept same)
    fe_model_coef_prior = pd.DataFrame({"model_coefficient_name": fe_params.index,
                                      "model_coefficient_value": fe_params.to_numpy()})
    fe_model_coef_prior["model_coefficient_std"] = fe_model_coef_prior["model_coefficient_value"]
    fe_model_coef_prior["distribution"] = "Normal"
    fe_model_coef_prior["bijector"] = "Exp"
    
    # Random effects prior (mu's alpha and beta kept same - sigma's alpha and beta set 0 and 2 resp.)
    re_model_coef_prior = pd.DataFrame({"model_coefficient_name": re_params.index.unique(),
                                      "group_variable": [group_var]*re_params.index.nunique(),
                                      "mean_mdl_coef_est": re_params.groupby(by = re_params.index).mean().to_numpy(),
                                      "std_mdl_coef_est": re_params.groupby(by = re_params.index).std().to_numpy()})
    re_model_coef_prior.loc[re_model_coef_prior["model_coefficient_name"]=="Group", "model_coefficient_name"] = "intercept" + "_" + group_var
    re_model_coef_prior["mu_dist"] = "Normal" 
    re_model_coef_prior["mu_bijector"] = "Exp"
    re_model_coef_prior["mean_mdl_coef_std_err"] = 0
    re_model_coef_prior["std_mdl_coef_std_err"] = 2
    re_model_coef_prior["sigma_dist"] = "HalfCauchy"
    re_model_coef_prior["sigma_bijector"] = "Identity"                
    
    # Reverse sign for columns with negative coefficient estimate (Log-normal/Gamma prior)
    reverse = ['wk_sold_median_base_price_byppg_log','tpr_discount_byppg_lag1','tpr_discount_byppg_lag2']
    flag_qtr = [col for col in box_matrix.columns.to_list() if "flag_qtr" in col]
    unbounded = flag_qtr + ["monthno", "category_trend"]    
    reverse = reverse + fe_model_coef_prior.loc[(fe_model_coef_prior["model_coefficient_name"].isin(unbounded)) &
                                              (fe_model_coef_prior["model_coefficient_value"]<0), "model_coefficient_name"].to_list() 
    reverse = reverse + re_model_coef_prior.loc[(re_model_coef_prior["model_coefficient_name"].isin(unbounded)) &
                                              (re_model_coef_prior["mean_mdl_coef_est"]<0), "model_coefficient_name"].to_list()        
    if temp_bayes_df.columns.isin(reverse).any():
        temp_bayes_df.loc[:,temp_bayes_df.columns.isin(reverse)] = -1*temp_bayes_df.loc[:,temp_bayes_df.columns.isin(reverse)]         
    fe_model_coef_prior["model_coefficient_value"] = fe_model_coef_prior["model_coefficient_value"].abs()
    fe_model_coef_prior["model_coefficient_std"] = fe_model_coef_prior["model_coefficient_std"].abs()
    re_model_coef_prior["mean_mdl_coef_est"] = re_model_coef_prior["mean_mdl_coef_est"].abs()
    re_model_coef_prior["std_mdl_coef_est"] = re_model_coef_prior["std_mdl_coef_est"].abs()
    
    generate_bayes_config(dv = "DV", re_prior_df=re_model_coef_prior, fe_prior_df=fe_model_coef_prior, no_iter=500, no_warmup_iter=500, no_chain=4, filename="bayes_config.xlsx")
    fe_model_coef_prior["model_coefficient_value"] = fe_model_coef_prior.apply(lambda x: (-1)*x["model_coefficient_value"] if x["model_coefficient_name"] in reverse else x["model_coefficient_value"], axis=1)
    re_model_coef_prior["mean_mdl_coef_est"] = re_model_coef_prior.apply(lambda x: (-1)*x["mean_mdl_coef_est"] if x["model_coefficient_name"] in reverse else x["mean_mdl_coef_est"], axis=1)
    config_ini = ""
    config_xlsx = "bayes_config.xlsx"
    get_config_data = mch.Config(config_ini)
    model_config_df, framework_config_df = get_config_data.get_config(config_xlsx)
    model = reg.BayesianEstimation(temp_bayes_df.copy(), model_config_df, framework_config_df)
    start_time = datetime.now()
    model.train()
    end_time = datetime.now()
    run_time = (end_time-start_time).total_seconds()/60
    print("Run Time: {:.2f}".format(run_time))
    return [model, box_matrix[temp_2.set_index("Date")["PPG_Item_No"]==ppg], box_matrix_opt, lwr_bound, upr_bound, fe_model_coef_prior, re_model_coef_prior]

    
def Model_data_filtering_less_than_1yr(Category,merged_ustotal_ppg_ip_filename,min_revenue_threshold,
                                       min_prct_data_points,sd_by_mean_avg_price_threshold,
                                       sd_by_mean_sales_vol_threshold,filtered_model_dataset_filename,
                                       Retailer_ACV_CUTOFF,ROM_ACV_CUTOFF,filtered_ppg_filename,
                                       Retailer,Total_weeks,Model_Start_Date,Model_End_Date, Model_Time_range):
    """ Prepares Modelling data for PPGs with less than 1 year data """
        
    input_sales_df_1 = pd.read_pickle(merged_ustotal_ppg_ip_filename)
    input_sales_df_1.rename(columns={"PPG_Item": "PPG_Item_No","PPGName": "PPG_Description","PPG_Category": "PPG_Cat"}, inplace=True)
          
    filtered_ppgs = pd.read_csv(os.path.join("Output Files",filtered_ppg_filename)) # pd.DataFrame(columns=["PPG_Item_No","Reason"])

    # ACV Adjustment
    acv_cols = [x for x in input_sales_df_1.columns.to_list() if "ACV" in x] 
    input_sales_df_1.loc[:,acv_cols] = input_sales_df_1.loc[:,acv_cols]/100
          
    # Create Qtr Flags
    # qtr_encoding = pd.get_dummies(input_sales_df_1["Date"].dt.quarter, prefix="flag_qtr", prefix_sep="")
    # input_sales_df_1 = pd.concat([input_sales_df_1,qtr_encoding],axis=1)
    input_sales_df_1["flag_qtr2"] = (input_sales_df_1["Date"].dt.quarter==2).astype(int)
    input_sales_df_1["flag_qtr3"] = (input_sales_df_1["Date"].dt.quarter==3).astype(int)
    input_sales_df_1["flag_qtr4"] = (input_sales_df_1["Date"].dt.quarter==4).astype(int)
          
    input_sales_df_1["PPG_Item_No"] = input_sales_df_1["PPG_Item_No"] + "_" + input_sales_df_1["PPG_Retailer"]
    input_sales_df_1["Year_Qtr"] = input_sales_df_1["Date"].dt.year.astype(str) + "_" + input_sales_df_1["Date"].dt.quarter.astype(str)
          
    # TODO - Where do "Model_Time_range" variable comes from?"
    input_sales_df_2 =  input_sales_df_1[(input_sales_df_1["Date"]>=Model_Time_range[0]) & (input_sales_df_1["Date"]<=Model_Time_range[1])]   
    # input_sales_df_2 =  input_sales_df_1[(input_sales_df_1["Year_Qtr"]>=Model_Time_range[0]) & (input_sales_df_1["Year_Qtr"]<Model_Time_range[1])]
    # input_sales_df_2 = input_sales_df_1[(input_sales_df_1["Date"]>=Model_Start_Date) & (input_sales_df_1["Date"]<Model_End_Date)]
    # input_sales_df_2 = input_sales_df_2.drop(columns="Year_Qtr")
    input_sales_df_2 = input_sales_df_2[(input_sales_df_2["wk_sold_doll_byppg"]>=0) & 
                                        (~input_sales_df_2["wk_sold_doll_byppg"].isna()) & 
                                        (input_sales_df_2["wk_sold_qty_byppg"]>=0) &
                                        (~input_sales_df_2["wk_sold_qty_byppg"].isna())]
    print("Filter: Zero sales observation")
    print(len(input_sales_df_2))
    
    # TODO: Move to Model Input module
    data_range_quarters = ((input_sales_df_2["Date"].dt.year).astype(str) + (input_sales_df_2["Date"].dt.quarter).astype(str)).nunique()
    # data_range_quarters = 8
    min_num_quarter_sales = 0.75* data_range_quarters
    min_qtr_sales_share = 0.16*(1/data_range_quarters)
    min_sales_quarters = 0.5*min_num_quarter_sales
    weeks_in_data = input_sales_df_2["Date"].nunique()
    # weeks_in_data = 104
    
    # Modelling data preparation
    input_sales_df_2.rename(columns={"wk_avg_price_perunit_byppg": "wk_sold_avg_price_byppg"}, inplace=True)
    
    # Revenue Cut Off Filter
    temp_1 = input_sales_df_2.groupby(["PPG_Cat","PPG_MFG","PPG_Item_No"], as_index=False).agg({"wk_sold_doll_byppg": np.sum, "wk_sold_qty_byppg": np.sum})
    temp_1["avg_qtrly_sales"] = temp_1["wk_sold_doll_byppg"]/data_range_quarters
    temp_1["avg_qtrly_qty"] = temp_1["wk_sold_qty_byppg"]/data_range_quarters
    temp_1["avg_rough_ppg_price_point"] = temp_1["avg_qtrly_sales"]/temp_1["avg_qtrly_qty"]
    low_revenue_ppgs = temp_1[(temp_1["PPG_Cat"]==Category) & (temp_1["avg_qtrly_sales"]<=min_revenue_threshold)]["PPG_Item_No"].unique()
    input_sales_df_3 = input_sales_df_2[~input_sales_df_2["PPG_Item_No"].isin(low_revenue_ppgs)]
    # if len(low_revenue_ppgs)>0:        
    #     temp_2 = pd.DataFrame({"PPG_Item_No": low_revenue_ppgs,"Reason": ["Low Revenue"]*len(low_revenue_ppgs)})        
    #     filtered_ppgs = filtered_ppgs.append(temp_2, ignore_index=True)
    # del temp_1,temp_2
    
    # Remove PPGs with less than a year data
    # temp_1 = input_sales_df_3.groupby(by=["PPG_Item_No"], as_index=False).agg({"Date": len}).rename(columns={"Date": "week_cnt"})
    # ppgs_lt_yr_data = temp_1.loc[temp_1["week_cnt"]<=51,"PPG_Item_No"]
    # input_sales_df_4 = input_sales_df_3[~input_sales_df_3["PPG_Item_No"].isin(ppgs_lt_yr_data)]
    # del temp_1
    # if len(ppgs_lt_yr_data)>0:        
    #     temp_2 = pd.DataFrame({"PPG_Item_No": ppgs_lt_yr_data,"Reason": ["Low Revenue"]*len(ppgs_lt_yr_data)})        
    #     filtered_ppgs = filtered_ppgs.append(temp_2, ignore_index=True)
    # del temp_1,temp_2
    dummy =  filtered_ppgs[filtered_ppgs["Model_flag"]!=1]
    # dummy = dummy[Reason != "Low Revenue"]
    input_sales_df_4 = input_sales_df_2[input_sales_df_2["PPG_Item_No"].isin(dummy["PPG_Item_No"])]
    # input_sales_data_4 = merge(input_sales_data_2,dummy, by = c("PPG_Item_No"))
    
    # Remove PPGs with zero values over many weeks
    # temp_1 = input_sales_df_4.groupby(by=["PPG_Item_No"], as_index=False).agg({"ACV_Selling": np.count_nonzero}).rename(columns={"ACV_Selling": "week_cnt"})
    # ppgs_wt_zero_acvs = temp_1.loc[temp_1["week_cnt"]<=52,"PPG_Item_No"]
    # input_sales_df_5 = input_sales_df_4[~input_sales_df_4["PPG_Item_No"].isin(ppgs_wt_zero_acvs)]
    # del temp_1
    input_sales_df_5 = input_sales_df_4[input_sales_df_4["ACV_Selling"]>0]

    input_sales_df_7 = input_sales_df_5.copy() 
    print("No. rows in base data:")
    print(len(input_sales_df_7))    
    print("No. rows in raw data:")
    print(len(input_sales_df_1))    
        
    # Add missing date observations for every PPG
    # input_sales_df_8A = input_sales_df_1[input_sales_df_1["PPG_Item_No"].isin(input_sales_df_7["PPG_Item_No"])].copy()
    # input_sales_df_8A["Missing_data_flag"] = 0    
    # input_sales_df_7["Missing_data_flag"] = 0    
    # print("No. rows in raw data: wt PPG filter")
    # print(len(input_sales_df_8A))

    # input_sales_df_8B = input_sales_df_8A[~input_sales_df_8A["Date"].isin(input_sales_df_7["Date"])].copy()  
    # input_sales_df_8B.rename(columns={"wk_avg_price_perunit_byppg": "wk_sold_avg_price_byppg"}, inplace=True)
    # print("No. rows in raw data: wt PPG & Date filter")    
    # print(len(input_sales_df_8B))
       
    # Total_weeks = input_sales_df_8A["Date"].drop_duplicates().reset_index(drop=True)
    # # TODO - Hard Coding
    # if len(Total_weeks)<116:
    #     exit("Low Week Count")	    
    # temp_1 = input_sales_df_8A.groupby("PPG_Item_No", as_index=False).agg({"Date": len}).rename(columns={"Date": "count_of_weeks"})
    # temp_1 = temp_1[temp_1["count_of_weeks"]<len(Total_weeks)]
    
    # temp_2 = input_sales_df_8A[input_sales_df_8A["PPG_Item_No"].isin(temp_1["PPG_Item_No"])][["MarketDescription","PPG_Retailer","PPG_Cat","PPG_MFG","BRAND GROUP(C)","PPG_Description","PPG_Item_No","Missing_data_flag","Date"]].drop_duplicates()
    # temp_3 = input_sales_df_8A[input_sales_df_8A["PPG_Item_No"].isin(temp_1["PPG_Item_No"])][["MarketDescription","PPG_Retailer","PPG_Cat","PPG_MFG","BRAND GROUP(C)","PPG_Description","PPG_Item_No","Missing_data_flag"]].drop_duplicates()
    # if len(temp_3)>0:
    #     temp_3["id"] = 1
    #     temp_4 = temp_3.merge(pd.DataFrame({"Date": Total_weeks, "id": 1}), on="id").drop(columns=["id"])
    #     temp_4["index"] = temp_4.index
    #     temp_5 = temp_4.merge(temp_2, how="inner", on=["MarketDescription","PPG_Retailer","PPG_Cat","PPG_MFG","BRAND GROUP(C)","PPG_Description","PPG_Item_No","Missing_data_flag","Date"])
    #     temp_4 = temp_4[~temp_4.index.isin(temp_5["index"])].drop(columns=["index"])
    #     temp_5 = input_sales_df_8A[0:0].append(temp_4, ignore_index=True)
        
    #     temp_5["Missing_data_flag"] = 1
    #     temp_5["Year_Qtr"] = temp_5["Date"].dt.year.astype(str) + "_" + temp_5["Date"].dt.quarter.astype(str)
    #     # temp_5["flag_qtr1"] = (temp_5["Date"].dt.quarter==1).astype(int)
    #     temp_5["flag_qtr2"] = (temp_5["Date"].dt.quarter==2).astype(int)
    #     temp_5["flag_qtr3"] = (temp_5["Date"].dt.quarter==3).astype(int)
    #     temp_5["flag_qtr4"] = (temp_5["Date"].dt.quarter==4).astype(int)
    #     temp_5[["ACV_Selling","ACV_TPR_Only","ACV_Feat_Only","ACV_Disp_Only","ACV_Feat_Disp"]] = 0
    #     temp_5.rename(columns={"wk_avg_price_perunit_byppg": "wk_sold_avg_price_byppg"}, inplace=True)
    #     print("Unique observations")
    #     print("Base data")
    #     print(len(input_sales_df_7[["PPG_Item_No","PPG_Retailer","Date"]].drop_duplicates()))
    #     input_sales_df_9 = input_sales_df_7.append(temp_5, ignore_index=True)
    #     print("After appending some rows 1")
    #     print(len(input_sales_df_9[["PPG_Item_No","PPG_Retailer","Date"]].drop_duplicates()))
    #     input_sales_df_9 = input_sales_df_9.append(input_sales_df_8B, ignore_index=True)        
    #     print("After appending some rows 2")
    #     print(len(input_sales_df_9[["PPG_Item_No","PPG_Retailer","Date"]].drop_duplicates()))
    # else:
    #     # TODO
    #     input_sales_df_9 = input_sales_df_8B.append(input_sales_df_7, ignore_index=True)
    # del temp_1, temp_2, temp_3, temp_4, temp_5
    
    # EDLP and TPR decompositon of Avg. price per unit
    input_sales_df_9 = input_sales_df_7.copy()
    input_sales_df_9 = input_sales_df_9.sort_values(["PPG_Item_No","Date"])    
    # input_sales_df_9["wk_sold_qty_byppg"] = input_sales_df_9.apply(lambda x: 0 if x["Missing_data_flag"]==1 else x["wk_sold_qty_byppg"], axis=1)
    input_sales_df_9["New_base_price"] = input_sales_df_9[["wk_base_price_perunit_byppg","wk_sold_avg_price_byppg"]].apply(lambda x: np.max(x),axis=1)

    input_sales_df_9["lag_base_price_1"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(1,fill_value=0)
    input_sales_df_9["lag_base_price_2"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(2,fill_value=0)
    input_sales_df_9["lag_base_price_3"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(3,fill_value=0)
    input_sales_df_9["lag_base_price_4"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(4,fill_value=0)
    input_sales_df_9["lag_base_price_5"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(5,fill_value=0)
    input_sales_df_9["lag_base_price_6"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(6,fill_value=0)
    input_sales_df_9["lag_base_price_7"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(7,fill_value=0)
    
    base_price_lag_cols = ["lag_base_price_1","lag_base_price_2","lag_base_price_3","lag_base_price_4","lag_base_price_5","lag_base_price_6","lag_base_price_7"]
    input_sales_df_9["max_base_price_prev"] = input_sales_df_9[base_price_lag_cols].apply(np.max, axis=1)
    for lag_col in base_price_lag_cols:
        input_sales_df_9[lag_col] = input_sales_df_9.apply(lambda x: x[lag_col] if x["max_base_price_prev"]>0 and np.abs((x[lag_col]/x["max_base_price_prev"])-1)<=0.05 else np.nan, axis=1)
    input_sales_df_9["Final_baseprice"] = input_sales_df_9[base_price_lag_cols].apply(np.nanmedian, axis=1)
    
  	# Add Reason column
    input_sales_df_9 = input_sales_df_9.merge(filtered_ppgs[["PPG_Item_No","Reason"]], how="left", on="PPG_Item_No")
  
    # Inputation
    input_sales_df_9["Final_baseprice"] = input_sales_df_9.groupby("PPG_Item_No")["Final_baseprice"].fillna(method="bfill")
    input_sales_df_9["Final_baseprice"] = input_sales_df_9.groupby("PPG_Item_No")["Final_baseprice"].fillna(method="ffill")
    
    # Replacing NA Wk_Avg_price instances with FBP
    input_sales_df_9["wk_sold_avg_price_byppg"] = input_sales_df_9.apply(lambda x: x["Final_baseprice"] if np.isnan(x["wk_sold_avg_price_byppg"]) else x["wk_sold_avg_price_byppg"], axis=1)
    input_sales_df_9["Final_baseprice"] = input_sales_df_9.apply(lambda x: x["New_base_price"] if x["Final_baseprice"]<x["New_base_price"] else x["Final_baseprice"], axis=1)
    
    # Compute medain base price with updated FBP
    input_sales_df_9["lag_price_1"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(1,fill_value=0)
    input_sales_df_9["lag_price_2"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(2,fill_value=0)
    input_sales_df_9["lag_price_3"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(3,fill_value=0)
    input_sales_df_9["lag_price_4"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(4,fill_value=0)
    input_sales_df_9["lag_price_5"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(5,fill_value=0)
    input_sales_df_9["lag_price_6"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(6,fill_value=0)
    input_sales_df_9["lag_price_7"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(7,fill_value=0)
    
    price_lag_cols = ["lag_price_1","lag_price_2","lag_price_3","lag_price_4","lag_price_5","lag_price_6","lag_price_7"]
    input_sales_df_9["max_price_prev"] = input_sales_df_9[price_lag_cols].apply(np.max, axis=1)
    for lag_col in price_lag_cols:
        input_sales_df_9[lag_col] = input_sales_df_9.apply(lambda x: x[lag_col] if x["max_price_prev"]>0 and np.abs((x[lag_col]/x["max_price_prev"])-1)<=0.05 else np.nan, axis=1)
    input_sales_df_9["Estimated_baseprice"] = input_sales_df_9[price_lag_cols].apply(np.nanmedian, axis=1)
    
    input_sales_df_9["median_baseprice"] = input_sales_df_9.apply(lambda x: x["wk_sold_avg_price_byppg"] if (1-x["wk_sold_avg_price_byppg"]/x["Estimated_baseprice"])<=0.05 else x["Estimated_baseprice"], axis=1)
    input_sales_df_9["tpr_discount_byppg"] = input_sales_df_9.apply(lambda x: (1-x["wk_sold_avg_price_byppg"]/x["median_baseprice"]) if (1-x["wk_sold_avg_price_byppg"]/x["median_baseprice"])>0.05 else 0, axis=1)
    # input_sales_df_9["tpr_discount_byppg"] = input_sales_df_9.apply(lambda x: 0 if x["Missing_data_flag"]==1 else x["tpr_discount_byppg"], axis=1)
    input_sales_df_9["median_baseprice"] = input_sales_df_9.apply(lambda x: x["Final_baseprice"] if np.isnan(x["median_baseprice"]) else x["median_baseprice"], axis=1)
    
    
    # Category Trend Variable
    input_sales_df_10 = input_sales_df_9[~input_sales_df_9["median_baseprice"].isna()]
    temp_1 = input_sales_df_10.groupby(["Date"], as_index=False).agg({"wk_sold_doll_byppg": np.sum}).rename(columns={"wk_sold_doll_byppg": "cumsum_wk_sold_doll"})
    temp_1["category_trend"] = temp_1["cumsum_wk_sold_doll"]/temp_1["cumsum_wk_sold_doll"].mean()
    temp_1 = temp_1.drop(columns=["cumsum_wk_sold_doll"])
    input_sales_df_11 = input_sales_df_10.merge(temp_1, how="left", on="Date")
    del temp_1
    
    # ACV Lag  (TPR ACV smoothing) 
    temp_1 = input_sales_df_11[input_sales_df_11["tpr_discount_byppg"]==0].sort_values(["PPG_Item_No","Date"]).copy()
    temp_1["lag_acv_selling_1"] = temp_1.groupby("PPG_Item_No")["ACV_Selling"].shift(1,fill_value=0)
    temp_1["lag_acv_selling_2"] = temp_1.groupby("PPG_Item_No")["ACV_Selling"].shift(2,fill_value=0)
    temp_1["lag_acv_selling_3"] = temp_1.groupby("PPG_Item_No")["ACV_Selling"].shift(3,fill_value=0)
    temp_1["lag_acv_selling_4"] = temp_1.groupby("PPG_Item_No")["ACV_Selling"].shift(4,fill_value=0)
    temp_1["lag_acv_selling_5"] = temp_1.groupby("PPG_Item_No")["ACV_Selling"].shift(5,fill_value=0)
    temp_1["lag_acv_selling_6"] = temp_1.groupby("PPG_Item_No")["ACV_Selling"].shift(6,fill_value=0)
    
    acv_lag_cols = ["lag_acv_selling_1","lag_acv_selling_2","lag_acv_selling_3","lag_acv_selling_4","lag_acv_selling_5","lag_acv_selling_6"]
    temp_1["median_acv_selling"] = temp_1[acv_lag_cols+["ACV_Selling"]].apply(np.nanmedian, axis=1)
    temp_2 = input_sales_df_11.merge(temp_1[["PPG_Item_No","PPG_Retailer", "Date", "median_acv_selling"]], how="left", on=["PPG_Item_No","PPG_Retailer", "Date"])
    # Imputation
    temp_2["median_acv_selling"] = temp_2.groupby("PPG_Item_No")["median_acv_selling"].fillna(method="ffill")
    input_sales_df_12 = temp_2.drop(columns=["median_acv_selling"]).merge(temp_2[["PPG_Item_No","PPG_Retailer", "Date", "median_acv_selling"]], how="left", on=["PPG_Item_No","PPG_Retailer", "Date"])
    del temp_1, temp_2
    
    
    # Model dataset - 1
    model_df_1 = input_sales_df_12.copy()
    model_df_1["wk_sold_qty_byppg_log"] = model_df_1["wk_sold_qty_byppg"].apply(np.log1p)
    model_df_1["wk_sold_avg_price_byppg_log"] = model_df_1["wk_sold_avg_price_byppg"].apply(np.log)
    model_df_1["wk_sold_median_base_price_byppg_log"] = model_df_1["median_baseprice"].apply(np.log)
    model_df_1 = model_df_1.sort_values(["PPG_Cat","PPG_MFG","PPG_Item_No","Date"], ignore_index=True)

    model_df_1["month"] = model_df_1["Date"].dt.month
    model_df_1["year"] = model_df_1["Date"].dt.year
    month_df = model_df_1[["month","year"]].drop_duplicates(ignore_index=True)
    month_df = month_df.sort_values(by=["year","month"])
    month_df["monthno"] = np.arange(len(month_df))+1
    model_df_1 = model_df_1.merge(month_df, how="left", on=["month", "year"])
    model_df_1 = model_df_1.drop(columns=["month","year"])
  
    # Model dataset - 2
    temp_model_df_2 = model_df_1.copy()       
    ppg_list = temp_model_df_2["PPG_Item_No"].unique()
    model_df_2 = pd.DataFrame()
    for ppg in ppg_list:
        ppg_model_df_2 = prepare_optimizer_data(temp_model_df_2[temp_model_df_2["PPG_Item_No"]==ppg])
        model_df_2 = model_df_2.append(ppg_model_df_2, ignore_index=True)
    model_df_2 = model_df_2.sort_values(["PPG_Cat","PPG_MFG","PPG_Item_No","Date"])
  
    # Pantry Loading feature
    model_df_2 = model_df_2.sort_values(["PPG_Item_No","Date"])    
    model_df_1["tpr_discount_byppg_lag1"] = model_df_1.groupby("PPG_Item_No")["tpr_discount_byppg"].shift(1,fill_value=0)
    model_df_1["tpr_discount_byppg_lag2"] = model_df_1.groupby("PPG_Item_No")["tpr_discount_byppg"].shift(2,fill_value=0)
    model_df_2["tpr_discount_byppg_lag1"] = model_df_2.groupby("PPG_Item_No")["tpr_discount_byppg"].shift(1,fill_value=0)
    model_df_2["tpr_discount_byppg_lag2"] = model_df_2.groupby("PPG_Item_No")["tpr_discount_byppg"].shift(2,fill_value=0)
    model_df_2 = model_df_2.drop(columns=["flag"])
    model_df_2["Retailer"] = Retailer
    model_df_2["PPG_Cat"] = model_df_2["PPG_Cat"].apply(category_format_fn)  
  
    if model_df_2.columns.isin(["ACV_Promo"]).any():
       model_df_2 = model_df_2.drop(columns=["ACV_Promo"])            
    model_df_2 = model_df_2[(model_df_2["Date"]>=Model_Time_range[0]) & (model_df_2["Date"]<Model_Time_range[1])]  
    # model_df_2 = model_df_2[(model_df_2["Year_Qtr"]>=Model_Time_range[0]) & (model_df_2["Year_Qtr"]<Model_Time_range[1])]  
    model_df_1 = model_df_1[(model_df_1["Date"]>=Model_Time_range[0]) & (model_df_1["Date"]<Model_Time_range[1])]
    # model_df_1 = model_df_1[(model_df_1["Year_Qtr"]>=Model_Time_range[0]) & (model_df_1["Year_Qtr"]<Model_Time_range[1])]
    # model_df_2_optimizer = model_df_2[["Date","PPG_Item_No","PPG_Cat","PPG_Retailer","Final_baseprice"]] 
  
    # Output files
    # temp_1 = input_sales_df_2.groupby(["PPG_Item_No", "PPG_MFG", "PPG_Retailer","PPG_Description"], as_index=False).agg({"wk_sold_doll_byppg": np.sum}).rename({"wk_sold_doll_byppg": "TotalSales"})
    # PPG_Filter_Summary = temp_1.merge(filtered_ppgs, how="left", on="PPG_Item_No")
    # del temp_1
  
    # model_df_1["Model_flag"] = 2
    # model_df_2["Model_flag"] = 2
    # model_df_2_optimizer["Model_flag"] = 2
    model_df_1["Model_flag"] = model_df_1["Reason"].apply(lambda x: 2 if x=="PPGs Considered for Modelling" else 0)
    model_df_2["Model_flag"] = model_df_2["Reason"].apply(lambda x: 2 if x=="PPGs Considered for Modelling" else 0)
    
    output_path = os.path.join(os.getcwd(),"Output Files")
    if os.path.exists(output_path):
        print("Output directory is present")
    else:
        os.mkdir(output_path)
    os.chdir(output_path)
    model_df_1.to_pickle(filtered_model_dataset_filename + ".pkl")	
    # model_df_1.to_pickle(filtered_model_dataset_filename + "_" + "Optimizer_1.pkl")
    model_df_2.to_pickle(filtered_model_dataset_filename + "_" + "Optimizer_2.pkl")
    # PPG_Filter_Summary.to_csv(filtered_ppg_filename, index=False)
    # model_df_2_optimizer.to_csv("model_data_set_2_optimizer.csv", index=False)
    return True

def Model_building_less_than_1yr(Category,
                             filtered_model_dataset_filename,
                             model_correlation_feature_shortlist,
                             model_correlation_price_trend_cutoff,
                             model_correlation_feature_shortlist_tpr,
                             model_regularization_parameter,
                             cannibalisation_cor_cutoff,
                             cannibal_dat_filename,
                             baselines_dat_filename,
                             model_est_dat_filename,
                             min_interaction_rp_cutoff,
                             max_interaction_rp_cutoff,
                             ActingItem_list,
                             filtered_ppg_filename,	
                             filtered_ppg_filename_revised,Retailer,base_dir1):
    """ Builds Lasso Model - Less than 1 Yr """

    fn_start_time = datetime.now()
    
    # Loading the Model Dataset & CMI Acting Item Dataset
    os.chdir(base_dir1)
    Acting_Item = pd.read_pickle(ActingItem_list)
    os.chdir(os.path.join(base_dir1,"Output Files"))
    model_df_1 = pd.read_pickle(filtered_model_dataset_filename + ".pkl")
    # model_df_1 = pd.read_pickle(filtered_model_dataset_filename + "_Optimizer_1.pkl")
    model_df_2 = pd.read_pickle(filtered_model_dataset_filename + "_Optimizer_2.pkl")    
    Filter_PPG_Summary = pd.read_csv(filtered_ppg_filename)   
    
    ppg_list_to_model = model_df_1.loc[(model_df_1["PPG_MFG"]=="NPP") & 
                           (model_df_1["Model_flag"]==0) &
                           (~model_df_1["PPG_Item_No"].str.contains("ROM", regex=False)) &
                           (model_df_1["Reason"]!="Low Revenue"),"PPG_Item_No"].unique()  # model_df_1["PPG_Retailer"]!="ROM"            
    if len(ppg_list_to_model)==0:
        save_empty_dataframe(filtered_model_dataset_filename, 
                             filtered_ppg_filename, 
                             filtered_ppg_filename_revised,
                             cannibal_dat_filename, 
                             baselines_dat_filename, 
                             model_est_dat_filename)
        return None
        
    PPG = model_df_1.loc[(model_df_1["PPG_MFG"]=="NPP") & 
                         (model_df_1["Model_flag"]==2) &
                         (~model_df_1["PPG_Item_No"].str.contains("ROM", regex=False)),"PPG_Item_No"].unique() # model_df_1["PPG_Retailer"]!="ROM"

    model_df_1 = model_df_1.sort_values(by=["PPG_Cat","PPG_MFG","PPG_Item_No","Date"], ignore_index=True)
    model_df_2 = model_df_2.sort_values(by=["PPG_Cat","PPG_MFG","PPG_Item_No","Date"], ignore_index=True)
    
    # Keep select PPGs for pooled modelling
    model_df_1 = model_df_1[(model_df_1["PPG_MFG"]=="NPP") & 
                            (~model_df_1["PPG_Item_No"].str.contains("ROM", regex=False)) & 
                            (model_df_1["Reason"]!="Low Revenue")]

    # pdb.set_trace()
    # Extract Pack size from PPG description
    # def extract_pack_size(x):
    #     """ Extract pack size from PPG description"""
    #     # TODO - Need double check
    #     lst = re.findall("[\\d.]+OZ|[\\d.]+ LB|[\\d.]+LB|[\\d.]+ OZ", x)
    #     if len(lst)>0:
    #         return lst[0]
    #     else:
    #         temp_lst = re.findall("[\\d.]CT|[\\d.]+ CT", x)
    #         return (temp_lst[0] if len(temp_lst)>0 else np.nan)

    # TODO - Need double check
    # model_df_1["size"] = model_df_1["PPG_Description"].apply(extract_pack_size).astype(str)
    model_df_1["size"] = model_df_1["PPG_Description"].apply(lambda x:  re.findall("[\\d.]+OZ|[\\d.]+ LB|[\\d.]+LB|[\\d.]+ OZ", x)[0] if len(re.findall("[\\d.]+OZ|[\\d.]+ LB|[\\d.]+LB|[\\d.]+ OZ", x))>0 else np.nan)
    model_df_1.loc[model_df_1["size"].isna(), "size"] = model_df_1.loc[model_df_1["size"].isna(), "PPG_Description"].apply(lambda x: re.findall("[\\d.]CT|[\\d.]+ CT", x)[0] if len(re.findall("[\\d.]CT|[\\d.]+ CT", x))>0 else np.nan)
    model_df_1["size"] = model_df_1["size"].astype(str)
    model_df_1["unit"] = model_df_1["size"].apply(lambda x: re.findall("LB|CT|OZ", x)[0] if len(re.findall("LB|CT|OZ", x))>0 else np.nan)
    model_df_1["qty"] = model_df_1["size"].apply(lambda x: re.findall("[\\d.]+", x)[0] if len(re.findall("[\\d.]+", x))>0 else np.nan)
    model_df_1.loc[model_df_1["unit"]=="LB","qty"] = model_df_1.loc[model_df_1["unit"]=="LB","qty"]*16
    model_df_1["size2"] = model_df_1["qty"].astype(np.float64)

    model_df_1 = model_df_1[~model_df_1["tpr_discount_byppg"].isna()]
    # model_df_1 = model_df_1[model_df_1["Missing_data_flag"]==0]
    
    # Data Initialisation
    # Baseline Sales Data
    glbl_model_base_df_1 = pd.DataFrame(columns=[])
    glbl_model_base_df_2 = pd.DataFrame(columns=[])
    # Cannibalisation Data
    glbl_model_cannibal_df_1 = pd.DataFrame(columns=["Cannibal_PPG","Cannibalised_PPG", 
                                                     "Measure", "Date", "Cannibal_Doll"])
    glbl_model_cannibal_df_2 = pd.DataFrame(columns=["Cannibal_PPG","Cannibalised_PPG", 
                                                     "Measure", "Date", "Cannibal_Doll"])  
    # Model Coefficient Estimates and R Sq
    model_results_seed = pd.DataFrame(columns=["PPG", "model_coefficient_name", "model_coefficient_value",
                                               "R_Square", "train_MAPE", "seed", "Model_flag"])
    model_results = pd.DataFrame(columns=["PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description",
                                          "model_RSq","model_CVErrorMean","model_CVErrorSD",
                                          "model_coefficient_name","model_coefficient_value","TrainMAPE", "Model_flag"])
    model_results_final = model_results.copy()
    model_results_cv = pd.DataFrame(columns=["PPG_Cat", "PPG_MFG", "PPG_Item_No","PPG_Description",
                                             "model_RSq", "model_CVErrorMean", "model_CVErrorSD",
                                             "TrainMAPE_edlp", "TrainMAPE_tpr",
                                             "TestMAPE_edlp", "TestMAPE_tpr", 
                                             "TrainMape_overall", "TestMape_overall", 
                                             'no_of_tpr_events_train', "no_of_tpr_events_test","fold", "Model_flag"])
    # glbl_intercept_df = pd.DataFrame()
    
    # List of ppgs without enough features
    ppg_wo_features = []    
    # Seed list to select common features
    seeds = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]
    # List of ppgs with just intercept turning out 
    ppg_wt_intercept = []
  
    print("No. of PPGs to model : {}".format(len(ppg_list_to_model)))
    model_start_time = datetime.now()
    for ppg in ppg_list_to_model:        
        # Data Initialisation
        model_coefficients_check = pd.DataFrame(columns=["model_coefficient_name", "model_coefficient_value"])
        model_coefficients_final = []        
        print(ppg)
        
        # TODO: Decide to check include missing flag variable
        slct_cols_1 = ["PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description","Date","wk_sold_qty_byppg",
               "wk_sold_avg_price_byppg","median_baseprice","Final_baseprice","Estimated_baseprice",
               "tpr_discount_byppg","ACV_Feat_Only","ACV_Disp_Only","ACV_Feat_Disp",
               "ACV_Selling","median_acv_selling","flag_qtr2","flag_qtr3","flag_qtr4",
               "category_trend","tpr_discount_byppg_lag1","tpr_discount_byppg_lag2",
               "monthno","Missing_data_flag"][0:-1]
        model_base_df_1 = model_df_1.loc[model_df_1["PPG_Item_No"]==ppg,slct_cols_1].reset_index(drop=True)
        model_base_df_2 = model_df_2.loc[model_df_2["PPG_Item_No"]==ppg,slct_cols_1].reset_index(drop=True)
        slct_cols_2 = ["PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description","Date","wk_sold_qty_byppg_log",
                        "wk_sold_median_base_price_byppg_log","tpr_discount_byppg","ACV_Feat_Only",
                        "ACV_Disp_Only","ACV_Feat_Disp","ACV_Selling","flag_qtr2","flag_qtr3","flag_qtr4",
                        "category_trend","tpr_discount_byppg_lag1","tpr_discount_byppg_lag2",
                        "monthno","Missing_data_flag"][0:-1]
        model_ppg_1 = model_df_1.loc[model_df_1["PPG_Item_No"]==ppg,slct_cols_2].reset_index(drop=True)
        model_ppg_1.rename(columns={"wk_sold_qty_byppg_log":"DV"}, inplace=True)
        model_ppg_2 = model_df_2.loc[model_df_2["PPG_Item_No"]==ppg,slct_cols_2].reset_index(drop=True)
        model_ppg_2.rename(columns={"wk_sold_qty_byppg_log":"DV"}, inplace=True)
        
        # Add similar PPGs' datapoints to selected PPG for modelling
        ppg_datapoints = len(model_df_1[model_df_1["PPG_Item_No"]==ppg])
        ppg_brand = model_df_1.loc[model_df_1["PPG_Item_No"]==ppg,"BRAND GROUP(C)"].unique()
        ppg_brand_list = model_df_1.loc[(model_df_1["BRAND GROUP(C)"].isin(ppg_brand)) & 
                                        (model_df_1["PPG_Item_No"].isin(PPG) | model_df_1["PPG_Item_No"]==ppg),
                                        "PPG_Item_No"].unique()
 
        ppg_pack_size = model_df_1.loc[model_df_1["PPG_Item_No"]==ppg,"size2"].mean()
        ppg_pack_size_list = model_df_1.loc[(model_df_1["size2"]<(1.1*ppg_pack_size)) & 
                                            (model_df_1["size2"]>(0.9*ppg_pack_size)) &
                                            (model_df_1["PPG_Item_No"].isin(PPG) | model_df_1["PPG_Item_No"]==ppg),
                                            "PPG_Item_No"].unique()   
        ppg_pack_size_list_in_brand = [i for i in ppg_pack_size_list if i in ppg_brand_list]

        ppg_mean_price = model_df_1.loc[model_df_1["PPG_Item_No"]==ppg, "wk_sold_avg_price_byppg"].mean()
        ppg_sd_price = model_df_1.loc[model_df_1["PPG_Item_No"]==ppg, "wk_sold_avg_price_byppg"].std()
        temp_1 = model_df_1[(model_df_1["PPG_Item_No"].isin(PPG)) | (model_df_1["PPG_Item_No"]==ppg)]
        temp_2 = temp_1.groupby(by=["PPG_Item_No", "BRAND GROUP(C)"], as_index=False).agg({"wk_sold_avg_price_byppg": np.mean})
        temp_2 = temp_2.rename(columns={"wk_sold_avg_price_byppg": "mean_price"})
        temp_2["z_val"] = (temp_2["mean_price"] - ppg_mean_price)/ppg_sd_price
        ppg_price_list_1_sigma = temp_2.loc[(temp_2["z_val"]>(-1)) & (temp_2["z_val"]<1), "PPG_Item_No"].unique()
        ppg_price_list_1_sigma_in_brand =  temp_2.loc[(temp_2["z_val"]>(-1)) & (temp_2["z_val"]<1) & 
                                                      (temp_2["BRAND GROUP(C)"].isin(ppg_brand)), "PPG_Item_No"].unique()
        del temp_1, temp_2        
        
        if (len(ppg_price_list_1_sigma_in_brand) + len(ppg_pack_size_list_in_brand))>2:
            model_ppg_1 = model_df_1.loc[(model_df_1["PPG_Item_No"].isin(ppg_price_list_1_sigma_in_brand)) | 
                                        (model_df_1["PPG_Item_No"].isin(ppg_pack_size_list_in_brand)), slct_cols_2].reset_index(drop=True)
        elif len(ppg_brand_list)>1:
            model_ppg_1 = model_df_1.loc[model_df_1["PPG_Item_No"].isin(ppg_brand_list), slct_cols_2].reset_index(drop=True)
        elif len(ppg_pack_size_list)>1:
            model_ppg_1 = model_df_1.loc[model_df_1["PPG_Item_No"].isin(ppg_pack_size_list), slct_cols_2].reset_index(drop=True)
        elif len(ppg_price_list_1_sigma)>1:
            model_ppg_1 = model_df_1.loc[model_df_1["PPG_Item_No"].isin(ppg_price_list_1_sigma), slct_cols_2].reset_index(drop=True)
        elif model_df_1.loc[(model_df_1["PPG_Item_No"].isin(PPG)) | (model_df_1["PPG_Item_No"]==ppg), "PPG_Item_No"].nunique()<20:
            model_ppg_1 = model_df_1.loc[(model_df_1["PPG_Item_No"].isin(PPG)) | (model_df_1["PPG_Item_No"]==ppg), slct_cols_2].reset_index(drop=True)
        else:
            continue
        model_ppg_1.rename(columns={"wk_sold_qty_byppg_log":"DV"}, inplace=True)
                
        
        # ACV Smoothening
        # TPR ACV smoothing - Model df 1      
        min_date = model_base_df_1["Date"].min()
        model_base_df_1["ACV_Selling"] = model_base_df_1.apply(lambda x: min(x["ACV_Selling"],x["median_acv_selling"]) if x["tpr_discount_byppg"]!=0 and x["Date"]!=min_date else x["ACV_Selling"], axis=1)
        model_base_df_1["lead_acv_selling_1"] = model_base_df_1.groupby(by=["PPG_Item_No"])["ACV_Selling"].shift(-1)
        model_base_df_1["ACV_Selling"] = model_base_df_1.apply(lambda x: x["lead_acv_selling_1"] if x["tpr_discount_byppg"]!=0 and x["Date"]==min_date else x["ACV_Selling"], axis=1)
        model_base_df_1["ACV_Selling"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].fillna(method="bfill")
        model_base_df_1 = model_base_df_1.drop(columns=["median_acv_selling","lead_acv_selling_1"])
        
        # TPR ACV smoothing - Model df 2        
        min_date = model_base_df_2["Date"].min()
        model_base_df_2["ACV_Selling"] = model_base_df_2.apply(lambda x: min(x["ACV_Selling"],x["median_acv_selling"]) if x["tpr_discount_byppg"]!=0 and x["Date"]!=min_date else x["ACV_Selling"], axis=1)
        model_base_df_2["lead_acv_selling_1"] = model_base_df_2.groupby(by=["PPG_Item_No"])["ACV_Selling"].shift(-1)
        model_base_df_2["ACV_Selling"] = model_base_df_2.apply(lambda x: x["lead_acv_selling_1"] if x["tpr_discount_byppg"]!=0 and x["Date"]==min_date else x["ACV_Selling"], axis=1)
        model_base_df_2["ACV_Selling"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].fillna(method="bfill")
        model_base_df_2 = model_base_df_2.drop(columns=["median_acv_selling","lead_acv_selling_1"])
        
        # EDLP ACV smoothing - Model df 1
        model_base_df_1["lag_acv_selling_1"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(1, fill_value=None)
        model_base_df_1["lag_acv_selling_2"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(2, fill_value=None)
        model_base_df_1["lag_acv_selling_3"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(3, fill_value=None)
        model_base_df_1["lag_acv_selling_4"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(4, fill_value=None)
        model_base_df_1["lag_acv_selling_5"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(5, fill_value=None)
        model_base_df_1["lag_acv_selling_6"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(6, fill_value=None)
        model_base_df_1["lag_acv_selling_7"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(7, fill_value=None)        
        acv_lag_cols = ["lag_acv_selling_1","lag_acv_selling_2","lag_acv_selling_3","lag_acv_selling_4","lag_acv_selling_5","lag_acv_selling_6","lag_acv_selling_7"]
        model_base_df_1["median_acv_selling"] = model_base_df_1[acv_lag_cols].apply(np.nanmedian, axis=1)
        model_base_df_1["median_acv_selling"] = model_base_df_1.groupby("PPG_Item_No")["median_acv_selling"].fillna(method="ffill")                
        
        model_base_df_1["Promotion"] = 1-(model_base_df_1["wk_sold_avg_price_byppg"]/model_base_df_1["Final_baseprice"])
        temp_fil = model_base_df_1["Promotion"]>0.04
        model_base_df_1.loc[temp_fil,"ACV_Selling"] = model_base_df_1.loc[temp_fil,["ACV_Selling","median_acv_selling"]].min(axis=1)
        model_base_df_1 = model_base_df_1.drop(columns=["Promotion"])
        model_base_df_1["ACV_Selling"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].fillna(method="bfill")
        model_base_df_1 = model_base_df_1.drop(columns=acv_lag_cols+["median_acv_selling"])
        del acv_lag_cols, temp_fil
        
        # EDLP ACV smoothing - Model df 2
        model_base_df_2["lag_acv_selling_1"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(1, fill_value=None)
        model_base_df_2["lag_acv_selling_2"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(2, fill_value=None)
        model_base_df_2["lag_acv_selling_3"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(3, fill_value=None)
        model_base_df_2["lag_acv_selling_4"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(4, fill_value=None)
        model_base_df_2["lag_acv_selling_5"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(5, fill_value=None)
        model_base_df_2["lag_acv_selling_6"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(6, fill_value=None)
        model_base_df_2["lag_acv_selling_7"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(7, fill_value=None)        
        acv_lag_cols = ["lag_acv_selling_1","lag_acv_selling_2","lag_acv_selling_3","lag_acv_selling_4","lag_acv_selling_5","lag_acv_selling_6","lag_acv_selling_7"]
        model_base_df_2["median_acv_selling"] = model_base_df_2[acv_lag_cols].apply(np.nanmedian, axis=1)
        model_base_df_2["median_acv_selling"] = model_base_df_2.groupby("PPG_Item_No")["median_acv_selling"].fillna(method="ffill")                
        
        model_base_df_2["Promotion"] = 1-(model_base_df_2["wk_sold_avg_price_byppg"]/model_base_df_2["Final_baseprice"])
        temp_fil = model_base_df_2["Promotion"]>0.04
        model_base_df_2.loc[temp_fil,"ACV_Selling"] = model_base_df_2.loc[temp_fil,["ACV_Selling","median_acv_selling"]].min(axis=1)
        model_base_df_2 = model_base_df_2.drop(columns=["Promotion"])
        model_base_df_2["ACV_Selling"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].fillna(method="bfill")
        model_base_df_2 = model_base_df_2.drop(columns=acv_lag_cols+["median_acv_selling"])
        del acv_lag_cols, temp_fil
        
        # Extracting Acting Items from CMI Data 
        temp_2 = model_ppg_1.copy()
        temp_2b = model_ppg_2.copy()
                
        # Model Data Preparation
        temporary_df = temp_2[["Date","DV","tpr_discount_byppg"]].rename(columns={"tpr_discount_byppg": "tpr_temp"})
        temporary_df = temporary_df.set_index("Date")        
        
        # Remove initial weeks where ACV is zero
        acv_min_date = temp_2.loc[temp_2["ACV_Selling"]>0,"Date"].min()
        temp_2 = temp_2[~((temp_2["ACV_Selling"]==0) & (temp_2["Date"]<acv_min_date))]
        temp_2b = temp_2b[~((temp_2b["ACV_Selling"]==0) & (temp_2b["Date"]<acv_min_date))]
        
        # temp_2 = temp_2[temp_2["Missing_data_flag"]!=1]
        # temp_2b = temp_2b[temp_2b["Missing_data_flag"]!=1]
        # temp_2 = temp_2.drop(columns=["Missing_data_flag"])
        # temp_2b = temp_2b.drop(columns=["Missing_data_flag"])
        # model_ppg_1 = model_ppg_1.drop(columns=["Missing_data_flag"])
        # model_ppg_2 = model_ppg_2.drop(columns=["Missing_data_flag"])
        # model_base_df_1 = model_base_df_1.drop(columns=["Missing_data_flag"])
        # model_base_df_2 = model_base_df_2.drop(columns=["Missing_data_flag"])
        
        # Set median price wt low variance to 0 
        if model_base_df_1.loc[model_base_df_1["tpr_discount_byppg"]==0,"wk_sold_avg_price_byppg"].var()<0.001:
            temp_2["wk_sold_median_base_price_byppg_log"] = 0
        if model_base_df_2.loc[model_base_df_1["tpr_discount_byppg"]==0,"wk_sold_avg_price_byppg"].var()<0.001:
            temp_2b["wk_sold_median_base_price_byppg_log"] = 0
        
        # Set ACV selling wt low variance to 0
        if temp_2["ACV_Selling"].var()<0.001:
            temp_2["ACV_Selling"] = 0
        if temp_2b["ACV_Selling"].var()<0.001:
            temp_2b["ACV_Selling"] = 0
        # print("QC: ACV Selling")
            
        # Fix Low and High limits for the model variables        
        temp_cols = temp_2.drop(columns=["Date","PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description","DV"]).columns.to_list()
        rp_col_cnt = temp_2.columns.str.contains("_RegularPrice").sum()
        tpr_col_cnt = temp_2.columns.str.contains("_PromotedDiscount").sum()        
        lwr_bound = [-np.inf] + [0]*5 + [-np.inf]*4 + [-np.inf]*2 + [-np.inf] + [0]*rp_col_cnt + [-np.inf]*tpr_col_cnt
        upr_bound = [0] + [np.inf]*5 + [np.inf]*4 + [0]*2 + [np.inf] + [np.inf]*rp_col_cnt + [0]*tpr_col_cnt
        # wk_sold_median_base_price_byppg_log   < -Inf to 0                  
        # tpr_discount_byppg,ACV_Metrics        <    0 to Inf       
        # flag_qtrs & "category_trend"          < -Inf to Inf
        # tpr_discount_byppg_lag1 & lag2        < -Inf to 0
        # monthno                               < -Inf to Inf
        
        
        os.chdir(os.path.join(base_dir1))
        seed=123
        mdl_lst = model_func_less_than_1yr(model_df_1, model_df_2, temp_2, temp_2b, ppg, seed,
                                            temp_cols, model_coefficients_final, lwr_bound, upr_bound)
        
        os.chdir(os.path.join(base_dir1,"Output Files"))            
        model = mdl_lst[0]
        fe_model_coef_prior = mdl_lst[5][["model_coefficient_name", "model_coefficient_value"]]
        re_model_coef_prior = mdl_lst[6].rename(columns={"mean_mdl_coef_est": "model_coefficient_value"})        
        model_coef_prior = fe_model_coef_prior.append(re_model_coef_prior[["model_coefficient_name", "model_coefficient_value"]], ignore_index=True)              
        
        # Get model coefficents
        tmp_model_coef = model.get_group_summary().reset_index()
        tmp_model_coef = tmp_model_coef.rename(columns={"index": "model_coefficient_name_adj", "mean": "model_coefficient_value"})
        tmp_model_coef = tmp_model_coef[~((tmp_model_coef["model_coefficient_name_adj"].str.contains("PPGItemNo", regex=False)) & 
                                         (~tmp_model_coef["model_coefficient_name_adj"].str.contains(ppg, regex=False)))]
        tmp_model_coef["model_coefficient_name_adj"] = tmp_model_coef["model_coefficient_name_adj"].apply(lambda x: re.sub("_PPGItemNo\\[\\'" + ppg + "\\'\\]", "", x))        
        tmp_model_coef["model_coefficient_name_adj"] = tmp_model_coef["model_coefficient_name_adj"].apply(lambda x: re.sub("fixed_slope_|slope_","",x))
        model_coef_prior["model_coefficient_name_adj"] = model_coef_prior["model_coefficient_name"].apply(lambda x: x if x=="intercept" else re.sub("_","",x))
        tmp_model_coef = tmp_model_coef.merge(model_coef_prior[["model_coefficient_name", "model_coefficient_name_adj"]], how="left", on="model_coefficient_name_adj")
        tmp_model_coef.loc[tmp_model_coef["model_coefficient_name_adj"]=="intercept","model_coefficient_name"] = "(Intercept)"
        model_coefficients = tmp_model_coef[["model_coefficient_name", "model_coefficient_value"]]

        reverse = ['wk_sold_median_base_price_byppg_log','tpr_discount_byppg_lag1','tpr_discount_byppg_lag2']
        reverse = reverse + [var for var in model_coefficients["model_coefficient_name"] if ("_PromotedDiscount" in var) and (re.search(".*PromotedDiscount.*PromotedDiscount",var) is None)]
        interactions = [var for var in model_coefficients["model_coefficient_name"] if re.search("ITEM.*ITEM.*",var) is not None]
        flag_qtr = [var for var in model_coefficients["model_coefficient_name"] if "flag_qtr" in var]
        unbounded = interactions + flag_qtr + ["monthno","category_trend"]
        reverse = reverse + model_coef_prior.loc[(model_coef_prior["model_coefficient_name"].isin(unbounded)) & 
                                                 (model_coef_prior["model_coefficient_value"]<0), "model_coefficient_name"].to_list()
        model_coefficients.loc[model_coefficients["model_coefficient_name"].isin(reverse), "model_coefficient_value"] = -1*model_coefficients.loc[model_coefficients["model_coefficient_name"].isin(reverse), "model_coefficient_value"]
        
        box_matrix = mdl_lst[1]
        box_matrix["PPG_Item_No"] = ppg
        box_matrix.loc[:,box_matrix.columns.isin(reverse)] = -1*box_matrix.loc[:,box_matrix.columns.isin(reverse)]
        train_set_prediction = pd.DataFrame({"PPG_Item_No": [ppg]*len(box_matrix),
                                             "Date": temp_2.loc[temp_2["PPG_Item_No"]==ppg, "Date"],
                                             "Prediction": np.exp(model.predict(box_matrix))})        
        train_set_rsq = r2_score((temp_2["DV"]),np.log(train_set_prediction["Prediction"])) # r2_score(np.exp(temp_2["DV"]),train_set_prediction["Prediction"])
        train_set_MAPE = mean_absolute_error(np.array([1]*len(temp_2["DV"])),train_set_prediction["Prediction"]/np.exp(temp_2["DV"]))
        cv_mse_mean = 0 # model.mse_path_[np.where(model.alphas_==model.alpha_)[0]].mean()
        cv_mse_sd = 0 # model.mse_path_[np.where(model.alphas_==model.alpha_)[0]].std()
        
        box_matrix_opt = mdl_lst[2]
        box_matrix["PPG_Item_No"] = ppg        
        box_matrix_opt.loc[:,box_matrix_opt.columns.isin(reverse)] = -1*box_matrix_opt.loc[:,box_matrix_opt.columns.isin(reverse)]            
        model_base_df_1 = model_base_df_1[model_base_df_1["Date"].isin(temp_2["Date"])]
        model_base_df_1["pred_vol"] = np.exp(model.predict(box_matrix))
        model_base_df_1["base_vol"] = np.exp(model.predict(box_matrix))  
        model_base_df_2 = model_base_df_2[model_base_df_2["Date"].isin(temp_2b["Date"])]
        model_base_df_2["pred_vol"] = np.exp(model.predict(box_matrix_opt))
        model_base_df_2["base_vol"] = np.exp(model.predict(box_matrix_opt))
        
        
        # Compute Baseline Volume for Retailer PPGs
        if "_ROM" not in ppg:
            temp_box_matrix = box_matrix.copy().reset_index()
            
            # Set values
            if "wk_sold_median_base_price_byppg_log" in temp_box_matrix.columns:
                temp_box_matrix = temp_box_matrix.merge(model_base_df_1[["Date","Final_baseprice"]].drop_duplicates(), how="left", on="Date")
                # temp_box_matrix = temp_box_matrix.rename(columns={"Final_baseprice_y": "Final_baseprice"}).drop(columns=["Final_baseprice_x"])
                temp_box_matrix["Final_baseprice"] = temp_box_matrix["Final_baseprice"].astype(np.float64)
                temp_box_matrix["wk_sold_median_base_price_byppg_log"] = -1*np.log(temp_box_matrix["Final_baseprice"])
                temp_box_matrix = temp_box_matrix.drop(columns=["Final_baseprice"])
            if "tpr_discount_byppg" in temp_box_matrix.columns:
                temp_box_matrix["tpr_discount_byppg"] = 0
            if temp_box_matrix.columns.str.contains(".*PromotedDiscount.*PromotedDiscount", regex=True).any():
                temp_box_matrix.loc[:,temp_box_matrix.columns.str.contains(".*PromotedDiscount.*PromotedDiscount", regex=True)] = 0
            if temp_box_matrix.columns.str.contains(".*RegularPrice.*RegularPrice", regex=True).any():
                rp_interaction_cols = [col for col in temp_box_matrix.columns if re.search(".*RegularPrice.*RegularPrice", col) is not None]
                for col in rp_interaction_cols:
                    col_adj = re.sub(ppg, "", col)
                    col_adj = re.sub("_RegularPrice_", "", col_adj)
                    col_adj = re.sub("_RegularPrice", "", col_adj)
                    temp_box_matrix = temp_box_matrix.merge(model_base_df_1.loc[model_base_df_1["PPG_Item_No"]==ppg,["Date","Final_baseprice"]], how="left", on="Date")
                    temp = model_df_1.loc[model_df_1["PPG_Item_No"]==col_adj,["Date","wk_sold_median_base_price_byppg_log"]]
                    temp = temp.rename(columns={"wk_sold_median_base_price_byppg_log": "wk_price_log"})
                    temp_box_matrix = temp_box_matrix.merge(temp[["Date","wk_price_log"]], how="left", on="Date")
                    if (model_coef_prior.loc[model_coef_prior["model_coefficient_name"]==col,"model_coefficient_value"]<0).any():
                        temp_box_matrix[col] = -1*np.log(temp_box_matrix["Final_baseprice"])*temp_box_matrix["wk_price_log"]
                    else:
                        temp_box_matrix[col] = np.log(temp_box_matrix["Final_baseprice"])*temp_box_matrix["wk_price_log"]
                    temp_box_matrix = temp_box_matrix.drop(columns=["Final_baseprice","wk_price_log"])
            if temp_box_matrix.columns.isin(["ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp"]).any():
                temp_box_matrix[[col for col in temp_box_matrix.columns if col in ["ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp"]]] = 0            
                # temp_box_matrix.loc[:,temp_box_matrix.columns.isin(["ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp"])] = 0            
            if "ACV_Selling" in temp_box_matrix.columns:
                temp_box_matrix = temp_box_matrix.merge(model_base_df_1[["Date","ACV_Selling"]].drop_duplicates(), how="left", on="Date")
                temp_box_matrix = temp_box_matrix.rename(columns={"ACV_Selling_y": "ACV_Selling"}).drop(columns=["ACV_Selling_x"])
                
            temp_box_matrix = temp_box_matrix.drop(columns=["Date"])
            base_volume =  pd.DataFrame(np.exp(model.predict(temp_box_matrix)),columns=["Prediction"])   
            model_base_df_1["base_vol"] = base_volume["Prediction"].to_list()
                   
        # Compute Baseline Volume for Retailer PPGs - Optimizer Data
        if "_ROM" not in ppg:
            temp_box_matrix_opt = box_matrix_opt.copy().reset_index()
            
            # Set values
            if "wk_sold_median_base_price_byppg_log" in temp_box_matrix_opt.columns:
                temp_box_matrix_opt = temp_box_matrix_opt.merge(model_base_df_2[["Date","Final_baseprice"]].drop_duplicates(), how="left", on="Date")
                # temp_box_matrix_opt = temp_box_matrix_opt.rename(columns={"Final_baseprice_y": "Final_baseprice"}).drop(columns=["Final_baseprice_x"])
                temp_box_matrix_opt["Final_baseprice"] = temp_box_matrix_opt["Final_baseprice"].astype(np.float64)
                temp_box_matrix_opt["wk_sold_median_base_price_byppg_log"] = -1*np.log(temp_box_matrix_opt["Final_baseprice"])
                temp_box_matrix_opt = temp_box_matrix_opt.drop(columns=["Final_baseprice"])
            if "tpr_discount_byppg" in temp_box_matrix_opt.columns:
                temp_box_matrix_opt["tpr_discount_byppg"] = 0
            if temp_box_matrix_opt.columns.str.contains(".*PromotedDiscount.*PromotedDiscount", regex=True).any():
                temp_box_matrix_opt.loc[:,temp_box_matrix_opt.columns.str.contains(".*PromotedDiscount.*PromotedDiscount", regex=True)] = 0
            if temp_box_matrix_opt.columns.str.contains(".*RegularPrice.*RegularPrice", regex=True).any():
                rp_interaction_cols = [col for col in temp_box_matrix_opt.columns if re.search(".*RegularPrice.*RegularPrice", col) is not None]
                for col in rp_interaction_cols:
                    col_adj = re.sub(ppg, "", col)
                    col_adj = re.sub("_RegularPrice_", "", col_adj)
                    col_adj = re.sub("_RegularPrice", "", col_adj)
                    temp_box_matrix_opt = temp_box_matrix_opt.merge(model_base_df_2.loc[model_base_df_2["PPG_Item_No"]==ppg,["Date","Final_baseprice"]], how="left", on="Date")
                    temp = model_df_2.loc[model_df_2["PPG_Item_No"]==col_adj,["Date","wk_sold_median_base_price_byppg_log"]]
                    temp = temp.rename(columns={"wk_sold_median_base_price_byppg_log": "wk_price_log"})
                    temp_box_matrix_opt = temp_box_matrix_opt.merge(temp[["Date","wk_price_log"]], how="left", on="Date")
                    if (model_coef_prior.loc[model_coef_prior["model_coefficient_name"]==col,"model_coefficient_value"]<0).any():
                        temp_box_matrix_opt[col] = -1*np.log(temp_box_matrix_opt["Final_baseprice"])*temp_box_matrix_opt["wk_price_log"]
                    else:
                        temp_box_matrix_opt[col] = np.log(temp_box_matrix_opt["Final_baseprice"])*temp_box_matrix_opt["wk_price_log"]
                    temp_box_matrix_opt = temp_box_matrix_opt.drop(columns=["Final_baseprice","wk_price_log"])                                
            if temp_box_matrix_opt.columns.isin(["ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp"]).any():
                 temp_box_matrix_opt[[col for col in temp_box_matrix_opt.columns if col in ["ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp"]]] = 0            
            if "ACV_Selling" in temp_box_matrix_opt.columns:
                temp_box_matrix_opt = temp_box_matrix_opt.merge(model_base_df_2[["Date","ACV_Selling"]].drop_duplicates(), how="left", on="Date")
                temp_box_matrix_opt = temp_box_matrix_opt.rename(columns={"ACV_Selling_y": "ACV_Selling"}).drop(columns=["ACV_Selling_x"])
                
            temp_box_matrix_opt = temp_box_matrix_opt.drop(columns=["Date"])
            base_volume =  pd.DataFrame(np.exp(model.predict(temp_box_matrix_opt)),columns=["Prediction"])   
            model_base_df_2["base_vol"] = base_volume["Prediction"]

            
        # Compute Cannibalisation Doll. Effects to exclude from gross lift computed
        model_cannibal_df_1 = pd.DataFrame(columns=["Cannibal_PPG","Cannibalised_PPG", "Measure", "Date", "Cannibal_Doll"])
        model_cannibal_df_2 = pd.DataFrame(columns=["Cannibal_PPG","Cannibalised_PPG", "Measure", "Date", "Cannibal_Doll"])
        # if train_set_rsq>cannibalisation_cor_cutoff:
        cannibal_ppg = model_coefficients[model_coefficients["model_coefficient_name"].str.contains("^(ITEM([0-9]|[a-z]|[A-Z])+)|([0-9]+)\\_Retailer")]["model_coefficient_name"]
        cannibal_ppg = cannibal_ppg[~cannibal_ppg.str.contains("\\_ROM")].to_list() 
        cannibal_ppg = [col for col in cannibal_ppg if re.sub("(\\_RegularPrice)|(\\_PromotedDiscount)","",col) in ppg_list_to_model]
        
        model_coefficients_check_pantry = model_coefficients[(model_coefficients["model_coefficient_name"].isin(["tpr_discount_byppg_lag1","tpr_discount_byppg_lag2"])) & (model_coefficients["model_coefficient_value"]<0)]
        model_cannibal_df_1 = cannibalisation_module(ppg, model, box_matrix, model_df_1, 
                                                     cannibal_ppg, model_coefficients_check_pantry)
        model_cannibal_df_2 = cannibalisation_module(ppg, model, box_matrix_opt, model_df_2, 
                                                     cannibal_ppg, model_coefficients_check_pantry)
                
        # Cannibalisation Data Set
        model_cannibal_df_1 = model_cannibal_df_1[model_cannibal_df_1["Cannibal_Doll"]>0]
        if len(model_cannibal_df_1)>0:
            glbl_model_cannibal_df_1 = glbl_model_cannibal_df_1.append(model_cannibal_df_1, ignore_index=True)
        model_cannibal_df_2 = model_cannibal_df_2[model_cannibal_df_2["Cannibal_Doll"]>0]
        if len(model_cannibal_df_2)>0:
            glbl_model_cannibal_df_2 = glbl_model_cannibal_df_2.append(model_cannibal_df_2, ignore_index=True)
            
        # Model Baseline Data Set
        glbl_model_base_df_1 = glbl_model_base_df_1.append(model_base_df_1, ignore_index=True)
        glbl_model_base_df_2 = glbl_model_base_df_2.append(model_base_df_2, ignore_index=True)
        
        # TODO - Not so clear
        # model_coefficients = model_coefficients.append(pd.DataFrame({"model_coefficient_name": "(Intercept)","model_coefficient_value":1}))
        model_coefficients["dummy"] = 1
        temp_4 = temp_2[["PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description"]].drop_duplicates().reset_index(drop=True)
        temp_4["model_RSq"] = train_set_rsq
        temp_4["TrainMAPE"] = train_set_MAPE
        temp_4["model_CVErrorMean"] = cv_mse_mean
        temp_4["model_CVErrorSD"] = cv_mse_sd

        temp_4["dummy"] = 1
        temp_5 = temp_4.merge(model_coefficients, how="left", on="dummy")
        temp_5 = temp_5.drop(columns="dummy")
        model_results_final = model_results_final.append(temp_5, ignore_index=True)
        # print(ppg)
        # print(temp_4[["model_RSq","TrainMAPE","model_CVErrorMean","model_CVErrorSD"]])
        # print(temp_5.iloc[:,[-2,-1]])
        # print(model_base_df_1.mean())
        # print(model_base_df_2.mean())
        # print(model_cannibal_df_1.mean())
        # print(model_cannibal_df_2.mean())        
        # pdb.set_trace()
        # continue
        
        # Cross-Validation        
        cv_lwr_bound = mdl_lst[3]	
        cv_upr_bound = mdl_lst[4]	
        # model_results_cv1 = cross_validation(ppg, box_matrix, temp_2, temporary_df, cv_lwr_bound, cv_upr_bound)
        # model_results_cv = model_results_cv.append(model_results_cv1, ignore_index=True)

    model_end_time = datetime.now()

    # Filter_PPG_Summary.loc[Filter_PPG_Summary["Reason"].isna(),"Reason"] = "PPGs Considered for Modelling"
    # Revised_Filtered_PPG = Filter_PPG_Summary.merge(model_results_final[["PPG_MFG","PPG_Item_No","model_RSq","TrainMAPE"]].drop_duplicates(),
    #                                                 how="left", on=["PPG_Item_No","PPG_MFG"])
    glbl_model_base_df_1["Model_flag"] = 0
    glbl_model_base_df_2["Model_flag"] = 0
    glbl_model_cannibal_df_1["Model_flag"] = 0 
    glbl_model_cannibal_df_2["Model_flag"] = 0
    model_results_final["Model_flag"] = 0
    # model_results_seed["Model_flag"] = 0
    # model_results_cv["Model_flag"] = 0
    # TODO - DC
    Filter_PPG_Summary["Model_flag"] = Filter_PPG_Summary.apply(lambda x: 0 if x["PPG_Item_No"] in ppg_list_to_model else x["Model_flag"], axis=1)

    model_results_final.to_pickle(model_est_dat_filename+".pkl")
    model_results_final["Retailer"] = Retailer
    model_results_final["Market"] = model_results_final["PPG_Item_No"].apply(lambda x: "Retailer" if ("Retailer" in x) else "ROM")
    model_results_final.to_pickle(model_est_dat_filename+"_Optimizer.pkl")
    model_results_final.to_csv(model_est_dat_filename+"_final.csv", index=False)
    # TODO - Remove them - Not required    
    # model_results_seed.to_csv(model_est_dat_filename+"_seeds.csv", index=False)
    # model_results_cv.to_csv(model_est_dat_filename+"_cross_validation.csv", index=False)
    Filter_PPG_Summary.to_csv(filtered_ppg_filename_revised, index=False)

    glbl_model_base_df_1.to_pickle(baselines_dat_filename+".pkl")
    glbl_model_base_df_2.to_pickle(baselines_dat_filename+"_Optimizer.pkl")
    glbl_model_cannibal_df_1.to_pickle(cannibal_dat_filename+".pkl")
    glbl_model_cannibal_df_2.to_pickle(cannibal_dat_filename+"_Optimizer.pkl")

    fn_end_time = datetime.now()
    total_model_time = (model_end_time-model_start_time).total_seconds()
    total_fn_time = (fn_end_time-fn_start_time).total_seconds()
    print("{} PPGs taken {:02d}:{:02d}:{:02d} to build models".format(len(ppg_list_to_model),int(total_model_time//3600), int((total_model_time%3600)//60), int(total_model_time%60)))
    print("Overall time taken:  {:02d}:{:02d}:{:02d}".format(int(total_fn_time//3600), int((total_fn_time%3600)//60), int(total_fn_time%60)))