#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import pdb
from my_utils import category_format_fn, retailer_format_fn

def get_acting_item(x):
    """ Extract acting item from the model variable name """
    
    extracted_str = re.findall("(ITEM([0-9]|[a-z]|[A-Z]|\\.)+\\_)|(^[0-9]+\\_)",x["model_coefficient_name"])
    if len(extracted_str)==0:
        return ""
    elif len(extracted_str)==1:
        return extracted_str[0][0]
    elif len(extracted_str)==2:
        temp = [extracted_str[0][0], extracted_str[1][0]]
        temp = [i for i in temp if x["Modelled_PPG_Item_No"] not in i]
        return temp[0]
                
    
def identify_variable_type(x):
    """ Categorise acting item model variable """
    
    if "_RegularPrice_" in x:
        return "Interaction Regular Price"
    elif "_RegularPrice" in x or "wk_sold_median_base_price_byppg_log" in x:
        return "Regular Price"
    elif "_PromotedDiscount_" in x:
        return "Interaction Promoted Discount"
    elif "_PromotedDiscount" in x or "tpr_discount_byppg"==x:
        return "Promoted Discount"
    elif "flag_promotion_spend_yes" in x:
        return "Promotion Spend"
    elif "flag_promotion_spend_no" in x:
        return "No Promotion Spend"    
    elif "tpr_discount_byppg_lag" in x:
        return ("Pantry Loading" + re.sub("tpr_discount_byppg_lag"," ",x))
    else:
        return x

def model_coeff_transform_fn(model_est_filename,
        model_est_transformed_op_filename,
        MappingFile_Description_path,
        comp_prd_dat_filename,
        scenarioplannining_cannibalisation_working_filename,
        Retailer,
        Category,
        base_dir1):
    """ """
    
    model_coef_1 = pd.read_pickle(base_dir1+model_est_filename)
    model_coef_1["model_box"] = model_coef_1["PPG_Item_No"].apply(lambda x: "ROM" if "_ROM" in x else "Retailer")
    model_coef_1["Modelled_PPG_Item_No"] = model_coef_1["PPG_Item_No"].apply(lambda x: re.sub("(\\_ROM)|\\_Retailer","",x))
    model_coef_1["acting_box"] = model_coef_1["model_box"]
    model_coef_1.loc[model_coef_1["model_coefficient_name"].str.contains("_ROM", regex=False),"acting_box"] = "ROM"
    model_coef_1.loc[model_coef_1["model_coefficient_name"].str.contains("_Retailer", regex=False),"acting_box"] = "Retailer"
    model_coef_1["Acting_PPG_Item_No"] = model_coef_1.apply(get_acting_item, axis=1)
    model_coef_1["Acting_PPG_Item_No"] = model_coef_1["Acting_PPG_Item_No"].apply(lambda x: re.sub("\\_","",x))
    model_coef_1["Acting_PPG_Item_No"] = model_coef_1.apply(lambda x:  x["Modelled_PPG_Item_No"] if x["Acting_PPG_Item_No"]=="" else x["Acting_PPG_Item_No"], axis=1)
    model_coef_1["Variable"] =  model_coef_1["model_coefficient_name"].apply(identify_variable_type)    
    # Split Intercept and Other model variables
    model_intercept = model_coef_1[model_coef_1["Variable"]=="(Intercept)"]
    model_coef_1 = model_coef_1[model_coef_1["Variable"]!="(Intercept)"]
    
    # Assign key number to each acting item
    model_coef_2 = pd.DataFrame()
    for ppg in model_coef_1["PPG_Item_No"].unique():        
        model_coef_temp = model_coef_1[model_coef_1["PPG_Item_No"]==ppg]
        model_coef_temp.loc[:,"CompKey"] = model_coef_temp["Variable"]
                
        var_type = ["Regular Price", "Promoted Discount", "Interaction Regular Price", "Interaction Promoted Discount", "Regular Price", "Promoted Discount"]
        col_name = ["CompKey_WB", "CompKey_WB_TPR", "CompKey_WB_Interaction_RP", "CompKey_WB_Interaction_TPR", "CompKey_CB", "CompKey_CB_TPR"]
        col_type = ["WB_Comp_RP", "WB_Comp_TPR", "WB_Comp_Interaction_RP", "WB_Comp_Interaction_TPR", "CB_Comp_RP", "CB_Comp_TPR"]                
        for var, name, typ in zip(var_type[0:4], col_name[0:4], col_type[0:4]):
            temp_index = ((model_coef_temp["Acting_PPG_Item_No"]!=model_coef_temp["Modelled_PPG_Item_No"]) &
                          (model_coef_temp["model_box"]==model_coef_temp["acting_box"]) & 
                          (model_coef_temp["Variable"]==var))
            if temp_index.sum()>0:
                acting_item = model_coef_temp.loc[temp_index, "Acting_PPG_Item_No"].unique()
                model_coef_temp.loc[:,name] = model_coef_temp["Acting_PPG_Item_No"].apply(lambda x: np.where(acting_item==x)[0][0] + 1 if x in acting_item else np.nan)
                model_coef_temp.loc[temp_index, "CompKey"] = typ + "_" + model_coef_temp.loc[temp_index, name].astype(int).astype(str)        
        for var, name, typ in zip(var_type[4:], col_name[4:], col_type[4:]):
            temp_index = ((model_coef_temp["model_box"]!=model_coef_temp["acting_box"]) & 
                          (model_coef_temp["Variable"]==var))
            acting_item = model_coef_temp.loc[temp_index, "Acting_PPG_Item_No"].unique()
            model_coef_temp.loc[:,name] = model_coef_temp["Acting_PPG_Item_No"].apply(lambda x: np.where(acting_item==x)[0][0] + 1 if x in acting_item else np.nan)
            model_coef_temp.loc[temp_index, "CompKey"] = typ + "_" + model_coef_temp.loc[temp_index, name].astype(int).astype(str)                                        
        model_coef_2 = model_coef_2.append(model_coef_temp, ignore_index=True)
        
    # # Interaction Key
    # InteractionCompKey = model_coef_2
    # InteractionCompKey = InteractionCompKey[InteractionCompKey["Variable"].isin(["Interaction Promoted Discount", "Interaction Regular Price"])]
    # InteractionCompKey["InteractionVariable"] = InteractionCompKey["model_coefficient_name"].apply(lambda x: re.sub("_RegularPrice|_PromotedDiscount","", x))
    # InteractionCompKey["InteractionVariable"] = InteractionCompKey.apply(lambda x: re.sub("_"+x["PPG_Item_No"]+"|"+x["PPG_Item_No"]+"_", "", x["InteractionVariable"]), axis=1)
    # InteractionCompKey["InteractionVariable"] = InteractionCompKey["InteractionVariable"].apply(lambda x: re.sub("_Retailer","",x))
    # InteractionCompKey = InteractionCompKey[["InteractionVariable","CompKey","Variable","model_box","acting_box","Modelled_PPG_Item_No"]]
    # InteractionCompKey = InteractionCompKey.rename(columns={"InteractionVariable": "Acting_PPG_Item_No"})
    # InteractionCompKey["Variable"] = InteractionCompKey["Variable"].apply(lambda x: re.sub("Interaction ","",x))
    
    # # RegularPrice_Interaction Key
    # RegularPrice_InteractionItem = model_coef_2
    # RegularPrice_InteractionItem = RegularPrice_InteractionItem[RegularPrice_InteractionItem["Variable"].isin(["Regular Price"])]
    # RegularPrice_InteractionItem = RegularPrice_InteractionItem[["CompKey","Variable","model_box","acting_box","Modelled_PPG_Item_No","Acting_PPG_Item_No"]]
    # RegularPrice_InteractionItem = RegularPrice_InteractionItem.rename(columns={"CompKey": "ActingCompKey_RP"})
    
    # # TPR_Interaction Key
    # TPR_InteractionItem = model_coef_2
    # TPR_InteractionItem = TPR_InteractionItem[TPR_InteractionItem["Variable"].isin(["Promoted Discount"])]
    # TPR_InteractionItem = TPR_InteractionItem[["CompKey","Variable","model_box","acting_box","Modelled_PPG_Item_No","Acting_PPG_Item_No"]]
    # TPR_InteractionItem = TPR_InteractionItem.rename(columns={"CompKey": "ActingCompKey_TPR"})


    # Model Coefficients in Wide format
    model_coef_melt = model_coef_2.copy()
    model_coef_melt["Modelled_PPG_Item_No"] = model_coef_melt["Modelled_PPG_Item_No"]+"_"+model_coef_melt["model_box"]
    model_coef_melt["CompKey"] = model_coef_melt["CompKey"].apply(lambda x: re.sub("\\s+", "_",x))
    model_coef_melt = model_coef_melt[["Modelled_PPG_Item_No","PPG_Description","CompKey","model_coefficient_value"]]
    model_coef_melt = model_coef_melt.pivot_table(index=["Modelled_PPG_Item_No","PPG_Description"], columns="CompKey", values = "model_coefficient_value").reset_index()
    
    wb_comp_rp_cols = sorted([col for col in model_coef_melt.columns if "WB_Comp_RP_" in col]) 
    wb_comp_tpr_cols = sorted([col for col in model_coef_melt.columns if "WB_Comp_TPR_" in col])
    wb_comp_interaction_rp_cols = sorted([col for col in model_coef_melt.columns if "WB_Comp_Interaction_RP_" in col])
    wb_comp_interaction_tpr_cols = sorted([col for col in model_coef_melt.columns if "WB_Comp_Interaction_TPR_" in col])
    cb_comp_rp_cols = sorted([col for col in model_coef_melt.columns if "CB_Comp_RP_" in col])
    cb_comp_tpr_cols = sorted([col for col in model_coef_melt.columns if "CB_Comp_TPR_" in col])    
    model_cols = ["Regular_Price", "Promoted_Discount","Pantry_Loading_1", "Pantry_Loading_2",
                  "ACV_Selling", "ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp","Promotion_Spend", 
                  "category_trend", "flag_qtr2", "flag_qtr3", "flag_qtr4", "monthno"]
    model_cols = [col for col in model_cols if col in model_coef_melt.columns]
    model_coef_melt = model_coef_melt[["Modelled_PPG_Item_No","PPG_Description"] +
                                      model_cols + wb_comp_rp_cols + wb_comp_tpr_cols +
                                      cb_comp_rp_cols + cb_comp_tpr_cols +
                                      wb_comp_interaction_rp_cols + wb_comp_interaction_tpr_cols]  
    
    model_coef_melt["Modelled_PPG_Item_No"] = model_coef_melt["Modelled_PPG_Item_No"].apply(lambda x: re.sub("\\_ROM","_ROM",x))  
    model_intercept_temp = model_intercept[["PPG_Item_No","PPG_Description","model_coefficient_value"]].drop_duplicates()
    model_intercept_temp = model_intercept_temp.rename(columns={"PPG_Item_No" : "Modelled_PPG_Item_No", "model_coefficient_value": "Intercept"})  
    model_coef_melt = model_coef_melt.merge(model_intercept_temp, how="left", on=["Modelled_PPG_Item_No","PPG_Description"])  
    model_coef_melt = model_coef_melt.fillna(value=0)
    if len(model_coef_melt)!=0:     
        model_coef_melt["Retailer"] = Retailer
        model_coef_melt["Retailer"] = model_coef_melt["Retailer"].apply(retailer_format_fn)
        model_coef_melt["PPG_Cat"] = Category
        model_coef_melt["PPG_Cat"] = model_coef_melt["PPG_Cat"].apply(category_format_fn)
        model_coef_melt["Market"] = model_coef_melt["PPG_Cat"].apply(lambda x: "Retailer" if "Retailer" in x else "ROM")
        model_coef_melt.to_csv(base_dir1+model_est_transformed_op_filename, index=False)
        # print("Model_Coefficients_EDLP_TPR_Tranformed file created")


    # Acting item with full name for Scenario planning - computing cannibalisation
    RMS_Data_PPG_Mapping_2 = pd.read_pickle(MappingFile_Description_path)
    RMS_Data_PPG_Mapping_2 = RMS_Data_PPG_Mapping_2.drop(columns=["PPG_Description"])
    RMS_Data_PPG_Mapping_2 = RMS_Data_PPG_Mapping_2.rename(columns={"PPGName": "PPG_Description"})    
    # Add Intercept only PPG
    model_coef_2 = model_coef_2.append(model_intercept[~model_intercept["PPG_Item_No"].isin(model_coef_2["PPG_Item_No"])], ignore_index=True)
    model_coef_2 = model_coef_2.rename(columns={"PPG_Description": "Modelled_PPG_Description"})    
    model_coef_2 = model_coef_2.merge(RMS_Data_PPG_Mapping_2[["PPG_Description","PPG_Item"]], how="left", left_on="Acting_PPG_Item_No", right_on="PPG_Item")
    model_coef_2 = model_coef_2.rename(columns={"PPG_Description": "Acting_PPG_Item"})    
    model_coef_2["Market"] = model_coef_2["PPG_Item_No"].apply(lambda x: "Retailer" if "Retailer" in x else "ROM")
    model_coef_2["Retailer"] = Retailer
    model_coef_2["Retailer"] = model_coef_2["Retailer"].apply(retailer_format_fn)
    model_coef_2["PPG_Cat"] = Category
    model_coef_2["PPG_Cat"] = model_coef_2["PPG_Cat"].apply(category_format_fn)
    model_coef_2.to_pickle(base_dir1+scenarioplannining_cannibalisation_working_filename)
    # print("ModelEstForCannibalization file created")
    
    
    # Competitor Product Information
    if len(model_coef_2[model_coef_2["CompKey"].str.contains("Comp")])>0:                
        model_coef_2["Modelled_PPG_Item_No"] = model_coef_2["Modelled_PPG_Item_No"]+"_"+model_coef_2["model_box"]
        ppg_wt_comp_prod = model_coef_2.loc[model_coef_2["CompKey"].str.contains("Comp"),["Modelled_PPG_Item_No","Modelled_PPG_Description","CompKey","Acting_PPG_Item"]]                
        ppg_wt_comp_prod = ppg_wt_comp_prod.pivot_table(index=["Modelled_PPG_Item_No","Modelled_PPG_Description"], columns="CompKey", values="Acting_PPG_Item", aggfunc="first").reset_index()
    
        wb_comp_rp_cols = sorted([col for col in model_coef_melt.columns if "WB_Comp_RP_" in col]) 
        wb_comp_tpr_cols = sorted([col for col in model_coef_melt.columns if "WB_Comp_TPR_" in col])
        wb_comp_interaction_rp_cols = sorted([col for col in model_coef_melt.columns if "WB_Comp_Interaction_RP_" in col])
        wb_comp_interaction_tpr_cols = sorted([col for col in model_coef_melt.columns if "WB_Comp_Interaction_TPR_" in col])
        cb_comp_rp_cols = sorted([col for col in model_coef_melt.columns if "CB_Comp_RP_" in col])
        cb_comp_tpr_cols = sorted([col for col in model_coef_melt.columns if "CB_Comp_TPR_" in col])
        ppg_wt_comp_prod = ppg_wt_comp_prod[["Modelled_PPG_Item_No"] +
                                            wb_comp_rp_cols + wb_comp_tpr_cols +
                                            cb_comp_rp_cols + cb_comp_tpr_cols +
                                            wb_comp_interaction_rp_cols + wb_comp_interaction_tpr_cols]  
        ppg_wt_comp_prod = ppg_wt_comp_prod.fillna(value="Not Applicable")
        
        ppg_wo_comp_prod = model_coef_2.loc[~model_coef_2["Modelled_PPG_Item_No"].isin(ppg_wt_comp_prod["Modelled_PPG_Item_No"].to_list()),"Modelled_PPG_Item_No"].drop_duplicates()
        if len(ppg_wo_comp_prod)>0:
            col_type = ["WB_Comp_RP", "WB_Comp_TPR", "CB_Comp_RP", "CB_Comp_TPR", "WB_Comp_Interaction_RP", "WB_Comp_Interaction_TPR"]
            for col in col_type:
                temp_len = ppg_wt_comp_prod.columns.str.contains(col, regex=False).sum()
                if temp_len>0:
                    temp_col = [col + "_" + str(i+1) for i in np.arange(temp_len)]
                    ppg_wo_comp_prod = pd.concat((ppg_wo_comp_prod, pd.DataFrame(columns=temp_col)), axis=1)
                    ppg_wo_comp_prod[temp_col] = "Not Applicable"
            comp_prod = ppg_wt_comp_prod.append(ppg_wo_comp_prod, ignore_index=False)          
        comp_prod.to_csv(base_dir1+comp_prd_dat_filename, index=False)
        # print("Competitor_Products_EDLP_TPR_Transformed file created")  
    
    

def cannibal_report(cannibal_dat_filename, MappingFile_Description_path,
                    glbl_model_pred_transformed_df, cannibal_dat_op_filename,
                    Retailer, Category, base_dir1):
    """ Cannibalisation flat reporting """
    
    # Load PPG descriptions 
    RMS_Data_PPG_Mapping_2 = pd.read_pickle(MappingFile_Description_path)
    RMS_Data_PPG_Mapping_2 = RMS_Data_PPG_Mapping_2.drop(columns=["PPG_Description"])
    RMS_Data_PPG_Mapping_2 = RMS_Data_PPG_Mapping_2.rename(columns={"PPGName": "PPG_Description"})  

    cannibal_df = pd.read_pickle(base_dir1 + cannibal_dat_filename)

    if len(cannibal_df)> 0:        
        cannibal_df["Cannibal_Doll"] = cannibal_df["Cannibal_Doll"].astype(np.float64)        
        cannibal_df = cannibal_df[cannibal_df["Cannibal_Doll"]>0]
        cannibal_df["box"] = cannibal_df["Cannibalised_PPG"].apply(lambda x:  "Cross" if re.search("\\_ROM",x) is not None else "Within")      

        cannibal_df[["Cannibalised_PPG","Cannibal_PPG"]] = cannibal_df[["Cannibalised_PPG","Cannibal_PPG"]].astype(str)        
        cannibal_df.loc[cannibal_df["Cannibalised_PPG"]==cannibal_df["Cannibal_PPG"], "Cannibalised_PPG"] = "Pantry Loading"
        cannibal_df["Cannibalised_PPG"] = cannibal_df["Cannibalised_PPG"].apply(lambda x: re.sub("(\\_ROM)|\\_Retailer", "", x))
        cannibal_df = cannibal_df.groupby(["Cannibal_PPG", "Cannibalised_PPG", "box", "Date", "Model_flag"], as_index=False).agg({"Cannibal_Doll": np.sum})      
        cannibal_df = cannibal_df.merge(RMS_Data_PPG_Mapping_2[["PPG_Description","PPG_Item"]].rename(columns={"PPG_Item": "Cannibalised_PPG"}), how="left", on="Cannibalised_PPG")
        cannibal_df.loc[~cannibal_df["Cannibalised_PPG"].str.contains("Pantry Loading"), "Cannibalised_PPG"] = cannibal_df["PPG_Description"]
        cannibal_df = cannibal_df.drop(columns=["PPG_Description"])

        cannibal_df_agg = cannibal_df.groupby(["Cannibal_PPG", "box" ,"Date"], as_index=False).agg({"Cannibal_Doll": np.sum})
        cannibal_df_agg = cannibal_df_agg.rename(columns={"Cannibal_Doll": "tot_box_bycannibalppg"})
        cannibal_df = cannibal_df.merge(cannibal_df_agg, how="left", on=["Cannibal_PPG", "box" ,"Date"])
        cannibal_df["pct_box_bycannibalppg"] = cannibal_df["Cannibal_Doll"]/cannibal_df["tot_box_bycannibalppg"]        
        box_cannibal_df = cannibal_df[["Cannibal_PPG", "Date", "box", "tot_box_bycannibalppg"]].drop_duplicates()
        box_cannibal_df = box_cannibal_df.pivot_table(index=["Cannibal_PPG", "Date"], values="tot_box_bycannibalppg", columns="box", aggfunc="first", fill_value=0, dropna=False).reset_index()
        # box_cannibal_df["Date"] = box_cannibal_df["Date"].astype(str) # TODO - Check if it is required
        
        glbl_model_pred_transformed_df = glbl_model_pred_transformed_df.merge(box_cannibal_df.rename(columns={"Cannibal_PPG": "PPG_Item_No"}), how="left", on=["PPG_Item_No","Date"])
        glbl_model_pred_transformed_df[["Within", "Cross"]] = glbl_model_pred_transformed_df[["Within", "Cross"]].fillna(value=0)        
        glbl_model_pred_transformed_df["true_lift_doll"] = (glbl_model_pred_transformed_df["lift_doll"] -
                                                            glbl_model_pred_transformed_df["Within"]-
                                                            glbl_model_pred_transformed_df["Cross"])
        glbl_model_pred_transformed_df.loc[glbl_model_pred_transformed_df["true_lift_doll"]<0, "true_lift_doll"] = 0 
        glbl_model_pred_transformed_df["Within_pct"] = glbl_model_pred_transformed_df["Within"].div((glbl_model_pred_transformed_df["Within"] + glbl_model_pred_transformed_df["Cross"]))
        glbl_model_pred_transformed_df["Cross_pct"] = glbl_model_pred_transformed_df["Cross"].div((glbl_model_pred_transformed_df["Within"] + glbl_model_pred_transformed_df["Cross"]))
        # glbl_model_pred_transformed_df[["Within_pct", "Cross_pct"]] = glbl_model_pred_transformed_df[["Within_pct", "Cross_pct"]].fillna(value=0)
        glbl_model_pred_transformed_df["Within"] = glbl_model_pred_transformed_df.apply(lambda x: 
                                                                                         x["Within_pct"] * x["lift_doll"]
                                                                                         if x["true_lift_doll"]==0
                                                                                         else x["Within"],
                                                                                         axis=1)
        glbl_model_pred_transformed_df["Cross"] = glbl_model_pred_transformed_df.apply(lambda x: 
                                                                                         x["Cross_pct"] * x["lift_doll"]
                                                                                         if x["true_lift_doll"]==0 
                                                                                         else x["Cross"],
                                                                                         axis=1)
        glbl_model_pred_transformed_df = glbl_model_pred_transformed_df.drop(columns=["Within_pct", "Cross_pct"])
                
        box_cannibal_df = glbl_model_pred_transformed_df[["PPG_Item_No","Date","Within","Cross"]].drop_duplicates()
        box_cannibal_df = box_cannibal_df.melt(id_vars=["PPG_Item_No","Date"], value_vars=["Within","Cross"], var_name="box", value_name="Cannibal_Doll_New")
        # cannibal_df["Date"] = cannibal_df["Date"].astype(str)  # TODO - Check if it is required
        cannibal_df = cannibal_df.merge(box_cannibal_df.rename(columns={"PPG_Item_No": "Cannibal_PPG"}), how="left", on=["Cannibal_PPG","Date","box"])      
        cannibal_df["Cannibal_Doll"] = cannibal_df["pct_box_bycannibalppg"] * cannibal_df["Cannibal_Doll_New"]
        cannibal_df = cannibal_df.drop(columns=["Cannibal_Doll_New", "pct_box_bycannibalppg", "tot_box_bycannibalppg"])
        cannibal_df = cannibal_df[~cannibal_df["Cannibal_PPG"].str.contains("\\_ROM\\_Retailer")]      
        cannibal_df = cannibal_df[(~cannibal_df["Cannibal_Doll"].isna()) & (cannibal_df["Cannibal_Doll"]>0)]
        
        if len(cannibal_df)>0:          
            cannibal_df["Cannibal_PPG_temp"] = cannibal_df["Cannibal_PPG"].apply(lambda x: re.sub("(\\_ROM)|\\_Retailer","",x))
            cannibal_df = cannibal_df.merge((RMS_Data_PPG_Mapping_2[["PPG_Description","PPG_Item"]]).rename(columns={"PPG_Item": "Cannibal_PPG_temp"}), how="left", on="Cannibal_PPG_temp")
            cannibal_df = cannibal_df.rename(columns={"PPG_Description": "Cannibal_PPG_Description"})
            cannibal_df = cannibal_df.drop(columns=["Cannibal_PPG_temp"])
            cannibal_df["PPG_Cat"] = Category
            cannibal_df["PPG_Cat"] = cannibal_df["PPG_Cat"].apply(category_format_fn)
            cannibal_df["Retailer"] = Retailer
            cannibal_df["Retailer"] = cannibal_df["Retailer"].apply(retailer_format_fn)   
            cannibal_df.to_csv(base_dir1+cannibal_dat_op_filename, index=False)
            # print("Cannibal file created")
    else:
      glbl_model_pred_transformed_df["Cross"] = 0
      glbl_model_pred_transformed_df["Within"] = 0
      glbl_model_pred_transformed_df["true_lift_doll"] = glbl_model_pred_transformed_df["lift_doll"]          
    return glbl_model_pred_transformed_df
    
 
def base_transform_fn(base_dat_filename, raw_dat_filename, MappingFile_Description_path,
                      cannibal_dat_filename, scenarioplannining_cannibalisation_working_filename,
                      cannibal_dat_op_filename, base_transform_op_filename, base_transform_op_filename2, 
                      Filtered_PPGs, price_agg_op_filename, 
                      Retailer, Category,base_dir1,file_type):
    """ Base data flat reporting """
      
    # Load data
    model_pred_df = pd.read_pickle(base_dir1+base_dat_filename)    
    new_model_coef = pd.read_pickle(base_dir1+scenarioplannining_cannibalisation_working_filename)
    base_df = pd.read_pickle(base_dir1+raw_dat_filename)
    
    Metrics_check = new_model_coef.loc[(new_model_coef["model_coefficient_name"].str.contains("ACV") |
                                        new_model_coef["model_coefficient_name"].isin(["wk_sold_median_base_price_byppg_log", "tpr_discount_byppg"])),
                                       ["PPG_Item_No","model_coefficient_name"]]    
    Metrics_check["RP_Elastic"] = Metrics_check["model_coefficient_name"].apply(lambda x: 1 if "wk_sold_median_base_price_byppg_log" in x else 0)
    Metrics_check["TPR_Elastic"] = Metrics_check["model_coefficient_name"].apply(lambda x: 1 if "tpr_discount_byppg" in x else 0)
    Metrics_check["ACV_Selling_Impact"] = Metrics_check["model_coefficient_name"].apply(lambda x: 1 if "ACV_Selling" in x else 0)
    Metrics_check["ACV_TPR_Impact"] = Metrics_check["model_coefficient_name"].apply(lambda x: 1 if "tpr_discount_byppg" in x else 0)
    Metrics_check["ACV_FT_Impact"] = Metrics_check["model_coefficient_name"].apply(lambda x: 1 if "ACV_Feat_Only" in x else 0)
    Metrics_check["ACV_DP_Impact"] = Metrics_check["model_coefficient_name"].apply(lambda x: 1 if "ACV_Disp_Only" in x else 0)
    Metrics_check["ACV_FT_DP_Impact"] = Metrics_check["model_coefficient_name"].apply(lambda x: 1 if "ACV_Feat_Disp" in x else 0)    
    Metrics_check = Metrics_check.drop(columns=["model_coefficient_name"])
    Final_Metrics = Metrics_check.groupby(by=["PPG_Item_No"], as_index=False).agg(np.max)
    
    # Generating Flat reports for each PPG with relevant acting items pricing in the week
    glbl_model_pred_transformed_df = pd.DataFrame()
    col_type = ["WB_Comp_RP", "WB_Comp_TPR", "WB_Comp_Interaction_RP", "WB_Comp_Interaction_TPR", "CB_Comp_RP", "CB_Comp_TPR"]                
    val_type = ["median_baseprice", "tpr_discount_byppg", "median_baseprice", "tpr_discount_byppg", "median_baseprice", "tpr_discount_byppg"]
    for ppg in new_model_coef["PPG_Item_No"].unique():       
        # TODO - Handle no acting items in any of the models
        temp_model_pred_df = model_pred_df[model_pred_df["PPG_Item_No"]==ppg]               
        for val, col in zip(val_type, col_type):            
            temp_model_coef = new_model_coef[(new_model_coef["PPG_Item_No"]==ppg) & new_model_coef["CompKey"].str.contains(col)]                
            temp_model_coef["Acting_PPG_Item_No"] = temp_model_coef.apply(lambda x: x["Acting_PPG_Item_No"]+"_Retailer"
                                                                          if x["acting_box"]=="Retailer"
                                                                          else x["Acting_PPG_Item_No"]+"_ROM",
                                                                          axis=1)
            temp_comp_prod_df = base_df.loc[base_df["PPG_Item_No"].isin(temp_model_coef["Acting_PPG_Item_No"]),["PPG_Item_No","Date", val]]
            temp_comp_prod_df = temp_comp_prod_df.merge(temp_model_coef[["Acting_PPG_Item_No", "CompKey"]].rename(columns={"Acting_PPG_Item_No": "PPG_Item_No"}),
                                                        how="left", on="PPG_Item_No")
            temp_comp_prod_df["CompKey"] = temp_comp_prod_df["CompKey"].fillna(value="")
            temp_comp_prod_df = temp_comp_prod_df.drop(columns=["PPG_Item_No"])
            
            ppg_comp_keys_cnt = temp_comp_prod_df.loc[temp_comp_prod_df["CompKey"].str.contains(col), "CompKey"].nunique()
            tot_comp_keys_cnt = new_model_coef.loc[new_model_coef["CompKey"].str.contains(col), "CompKey"].nunique()            
            if len(temp_comp_prod_df)>0:
                temp_comp_prod_df = temp_comp_prod_df[["Date","CompKey",val]]
                temp_comp_prod_df = temp_comp_prod_df.pivot_table(values=val, index="Date", columns="CompKey").reset_index()                                
            else:
                temp_comp_prod_df = temp_model_pred_df[["Date"]].reset_index(drop=True)                
            if ppg_comp_keys_cnt < tot_comp_keys_cnt:
                temp = pd.DataFrame()                
                temp = temp.append(pd.DataFrame([[np.nan]*(tot_comp_keys_cnt - ppg_comp_keys_cnt)],
                                                                columns=[col + "_" + str(i+1) for i in np.arange(ppg_comp_keys_cnt, tot_comp_keys_cnt)]),
                                                   ignore_index=True)
                temp_comp_prod_df = pd.concat((temp_comp_prod_df, temp), ignore_index=False, axis=1)                
                # col_order = temp_comp_prod_df.columns[temp_comp_prod_df.columns.str.contains(col)].sort_values().to_list()   
                # temp_comp_prod_df = temp_comp_prod_df[["Date"] + col_order] 
            if len(temp_comp_prod_df.columns)>1:
                temp_comp_prod_df["Date"] = temp_comp_prod_df["Date"].astype(str)
                temp_model_pred_df = temp_model_pred_df.merge(temp_comp_prod_df, how="left", on="Date")
        glbl_model_pred_transformed_df = glbl_model_pred_transformed_df.append(temp_model_pred_df, ignore_index=False)                        
    # TODO - check if it is required
    if glbl_model_pred_transformed_df.columns.str.contains("Comp").sum() > 0:
        comp_prod_cols = [col for col in glbl_model_pred_transformed_df.columns if "Comp" in col]
        glbl_model_pred_transformed_df[comp_prod_cols] = glbl_model_pred_transformed_df[comp_prod_cols].astype(np.float64)

    glbl_model_pred_transformed_df = glbl_model_pred_transformed_df.fillna(value=np.nan)
    glbl_model_pred_transformed_df[["base_vol", "pred_vol", "wk_sold_avg_price_byppg", "Final_baseprice"]] = glbl_model_pred_transformed_df[["base_vol", "pred_vol", "wk_sold_avg_price_byppg", "Final_baseprice"]].astype(np.float64)    
    glbl_model_pred_transformed_df["lift_vol"] = glbl_model_pred_transformed_df["pred_vol"] - glbl_model_pred_transformed_df["base_vol"]    
    # TODO - To get the cross-platform results same
    glbl_model_pred_transformed_df.loc[(glbl_model_pred_transformed_df["lift_vol"]>0) & 
                                       (glbl_model_pred_transformed_df["lift_vol"]<(3e-13)),"lift_vol"] = 0
    glbl_model_pred_transformed_df["base_vol"] = glbl_model_pred_transformed_df.apply(lambda x: x["pred_vol"] if x["lift_vol"]<=0 else x["base_vol"], axis=1)
    glbl_model_pred_transformed_df["lift_vol"] = glbl_model_pred_transformed_df["lift_vol"].apply(lambda x: 0 if x<0 else x)     
    glbl_model_pred_transformed_df["base_doll"] = glbl_model_pred_transformed_df["base_vol"] * glbl_model_pred_transformed_df["Final_baseprice"]    
    glbl_model_pred_transformed_df["wk_sold_doll_byppg"] = glbl_model_pred_transformed_df["pred_vol"]*glbl_model_pred_transformed_df["wk_sold_avg_price_byppg"]
    glbl_model_pred_transformed_df["lift_doll"] = glbl_model_pred_transformed_df["wk_sold_doll_byppg"] - glbl_model_pred_transformed_df["base_doll"]
    glbl_model_pred_transformed_df["lift_doll"] = glbl_model_pred_transformed_df["lift_doll"].apply(lambda x: 0 if x<0 else x)
    glbl_model_pred_transformed_df["base_doll"] = glbl_model_pred_transformed_df.apply(lambda x: x["wk_sold_doll_byppg"] if x["lift_doll"]<=0 else x["base_doll"], axis=1)        

    glbl_model_pred_transformed_df = cannibal_report(cannibal_dat_filename,
                                                     MappingFile_Description_path,
                                                     glbl_model_pred_transformed_df,
                                                     cannibal_dat_op_filename,
                                                     Retailer,Category, base_dir1)
    # glbl_model_pred_transformed_df = glbl_model_pred_transformed_df.fillna(value="")    
    if file_type=="General":
        glbl_model_pred_transformed_df["Spend"] = (glbl_model_pred_transformed_df["wk_sold_qty_byppg"].astype(float) * 
                                                   (glbl_model_pred_transformed_df["Final_baseprice"].astype(float) - 
                                                    glbl_model_pred_transformed_df["wk_sold_avg_price_byppg"].astype(float)))
    elif file_type=="Optimizer":
        glbl_model_pred_transformed_df["Spend"] = (glbl_model_pred_transformed_df["pred_vol"].astype(float)  * 
                                                   (glbl_model_pred_transformed_df["Final_baseprice"].astype(float) -
                                                    glbl_model_pred_transformed_df["wk_sold_avg_price_byppg"].astype(float)))
    glbl_model_pred_transformed_df["Retailer"] = Retailer
    glbl_model_pred_transformed_df["Market"] = glbl_model_pred_transformed_df["PPG_Item_No"].apply(lambda x: "Retailer" if "Retailer" in x else "ROM")

    # Append missing weeks to base df
    Output_Data_Hist = glbl_model_pred_transformed_df
    Output_Data_Hist = Output_Data_Hist.loc[:,~Output_Data_Hist.columns.str.contains("_Comp_")]
    Output_Data_Hist["Retailer"] = Output_Data_Hist["Retailer"].apply(retailer_format_fn)
    Output_Data_Hist["PPG_Cat"] = Output_Data_Hist["PPG_Cat"].apply(category_format_fn)
    ppg_week_cnt = Output_Data_Hist.groupby(by=["PPG_Item_No"], as_index=False).agg({"Date": len}).rename(columns={"Date": "no_of_weeks"})
    base_cols =  Output_Data_Hist.columns
    base_cols = base_cols[~base_cols.isin(["PPG_Item_No","Date","PPG_Cat","PPG_MFG",
                                           "PPG_Description","Retailer","Market",
                                           "wk_sold_avg_price_byppg","median_baseprice",
                                           "Final_baseprice","Estimated_baseprice"])]    
    ppg_with_max_weeks = ppg_week_cnt[ppg_week_cnt["no_of_weeks"]==ppg_week_cnt["no_of_weeks"].max()]["PPG_Item_No"][0]
    date_range = Output_Data_Hist.loc[Output_Data_Hist["PPG_Item_No"]==ppg_with_max_weeks, "Date"].unique() 
    overall_min_date = date_range.min()
    
    df_rbind = pd.DataFrame()  # for all ppg value one data frame
    count_dates = 0  # for checking the number of dates to be imputed     
    for ppg in Output_Data_Hist["PPG_Item_No"].unique():
        ppg_model_pred_df = Output_Data_Hist[Output_Data_Hist["PPG_Item_No"]==ppg].copy()
        ppg_model_pred_df["Date"] = ppg_model_pred_df["Date"]
        date_var = ppg_model_pred_df["Date"].unique()        
        current_min_date = date_var.min()
        date_values = [dt for dt in date_range if dt not in date_var]
        count_dates = count_dates + len(date_values)
        nrows_to_be_imputed = len(date_values)
        
        if nrows_to_be_imputed>0:        
            temp = pd.DataFrame() 
            temp = temp.append([ppg_model_pred_df.iloc[0,:].to_list()]*nrows_to_be_imputed, ignore_index=True)
            temp.columns = ppg_model_pred_df.columns            
            temp["Date"] = date_values            
            cols_1 = ["wk_sold_qty_byppg","tpr_discount_byppg",
                      "ACV_Feat_Only","ACV_Disp_Only","ACV_Feat_Disp","ACV_Selling",
                      "flag_qtr2","flag_qtr3","flag_qtr4",
                      "category_trend","tpr_discount_byppg_lag1","tpr_discount_byppg_lag2",
                      "monthno","pred_vol","base_vol","lift_vol","base_doll","wk_sold_doll_byppg","lift_doll",              
                       "Cross","Within","true_lift_doll","Spend"]
            cols_2 = ["wk_sold_avg_price_byppg","median_baseprice","Final_baseprice","Estimated_baseprice"]
            temp[cols_1] = 0          
            temp[cols_2] = np.nan            
            ppg_model_pred_df = ppg_model_pred_df.append(temp, ignore_index=True)
            ppg_model_pred_df = ppg_model_pred_df.sort_values(by=["Date"], ignore_index=True)
            
            # Set price points to 0 if starting weeks is not available
            if current_min_date != overall_min_date:            
                Starting_missing_weeks = [dt for dt in date_range if datetime.strptime(dt,"%Y-%m-%d") < datetime.strptime(current_min_date, "%Y-%m-%d")]
                ppg_model_pred_df.loc[ppg_model_pred_df["Date"].isin(Starting_missing_weeks), "wk_sold_avg_price_byppg"] = 0
                ppg_model_pred_df.loc[ppg_model_pred_df["Date"].isin(Starting_missing_weeks), "median_baseprice"] = 0
                ppg_model_pred_df.loc[ppg_model_pred_df["Date"].isin(Starting_missing_weeks), "Final_baseprice"] = 0
                ppg_model_pred_df.loc[ppg_model_pred_df["Date"].isin(Starting_missing_weeks), "Estimated_baseprice"] = 0                    
                
            # Impute price points wt preceding weeks data
            ppg_model_pred_df["Final_baseprice"] = ppg_model_pred_df.groupby("PPG_Item_No")["Final_baseprice"].fillna(method="ffill")
            ppg_model_pred_df["wk_sold_avg_price_byppg"] = ppg_model_pred_df.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].fillna(method="ffill")
            ppg_model_pred_df["median_baseprice"] = ppg_model_pred_df.groupby("PPG_Item_No")["median_baseprice"].fillna(method="ffill")
            ppg_model_pred_df["Estimated_baseprice"] = ppg_model_pred_df.groupby("PPG_Item_No")["Estimated_baseprice"].fillna(method="ffill")                
        df_rbind = df_rbind.append(ppg_model_pred_df, ignore_index=True)        
    Output_Data_Hist = df_rbind.copy()
    Output_Data_Hist.to_csv(base_dir1 + base_transform_op_filename, index=False)   
    # print("Base data transformed file created")
    
    
    glbl_model_pred_transformed_df["median_baseprice_byppg"] = glbl_model_pred_transformed_df["median_baseprice"]
    glbl_model_pred_transformed_df = glbl_model_pred_transformed_df.drop(columns=["wk_sold_qty_byppg",
                                                                                  "wk_sold_avg_price_byppg",
                                                                                  "wk_sold_doll_byppg",
                                                                                  "median_baseprice"])
    numeric_cols = [col for col in glbl_model_pred_transformed_df.columns 
                    if col not in ["PPG_Item_No", "PPG_Cat", "PPG_MFG","Date","PPG_Description","Retailer","Market"]]
    # print(glbl_model_pred_transformed_df.iloc[0,:])
    # glbl_model_pred_transformed_df[numeric_cols] = glbl_model_pred_transformed_df[numeric_cols].astype(np.float64)
    
    
    retailer_price_df = glbl_model_pred_transformed_df.merge(base_df[["PPG_Item_No","Date","ACV_TPR_Only"]], how="left", on=["PPG_Item_No","Date"])
    retailer_price_df.loc[retailer_price_df["tpr_discount_byppg"]==0,"tpr_discount_byppg"] = np.nan
    # Multiplying tpr and acv with 100 for price agg file
    acv_cols = retailer_price_df.columns[retailer_price_df.columns.str.contains("ACV")]
    retailer_price_df[acv_cols] = retailer_price_df[acv_cols]*100
    retailer_price_df["tpr_discount_byppg"] = retailer_price_df["tpr_discount_byppg"]*100
    retailer_price_agg = retailer_price_df.groupby(by=["PPG_Item_No", "PPG_Cat", "PPG_MFG","PPG_Description"], 
                                                   as_index=False).agg({
                                                                        "Final_baseprice": (np.nanmax, np.nanmax, np.nanmax), # TODO - Why all of them mean?
                                                                        "tpr_discount_byppg": (np.nanmax, np.nanmin, np.nanmean),
                                                                        "median_baseprice_byppg": (np.nanmax, np.nanmin, np.nanmean),
                                                                        "ACV_TPR_Only": (np.nanmax, np.nanmin),
                                                                        "ACV_Feat_Only": (np.nanmax, np.nanmin),
                                                                        "ACV_Disp_Only": (np.nanmax, np.nanmin),
                                                                        "ACV_Feat_Disp": (np.nanmax, np.nanmin),
                                                                        })    
    retailer_price_agg.columns = [i + (("_" + j) if j!="" else j) for i, j in retailer_price_agg.columns] 
    # Preseve existing output df column names
    retailer_price_agg.columns = ["PPG_Item_No", "PPG_Cat", "PPG_MFG","PPG_Description",
                                  "median_baseprice","min.baseprice","max.baseprice",
                                  "max.TPR","min.TPR","mean.TPR","max.RP","min.RP","mean.RP",
                                  "ACV_TPR_Max","ACV_TPR_Min","ACV_FT_Max","ACV_FT_Min",
                                  "ACV_DP_Max","ACV_DP_Min","ACV_FT_DP_Max","ACV_FT_DP_Min"]
    
    retailer_price_df["Date"] = pd.to_datetime(retailer_price_df["Date"])
    maxweek = retailer_price_df["Date"].max()

    # Impute mean ACV Selling for PPGs , which dont have ACV selling for last 7weeks, we will be taking last ACV selling is present  
    acv_agg = retailer_price_df[retailer_price_df["Date"] > (maxweek - timedelta(days=49))].groupby(
        by=["PPG_Item_No"], as_index=False).agg({
            "ACV_Selling": np.nanmax}).rename(columns={"ACV_Selling": "ACV_Selling_Mean"})   
    ppgs_in_recent_weeks = retailer_price_df.loc[retailer_price_df["Date"] > (maxweek - timedelta(days=49)), "PPG_Item_No"].unique()
    acv_df = retailer_price_df.loc[~retailer_price_df["PPG_Item_No"].isin(ppgs_in_recent_weeks),
                                                       ["PPG_Item_No","Date","ACV_Selling"]]
    acv_df = acv_df[~acv_df["ACV_Selling"].isna()]
    max_week_acv_df  = acv_df.groupby(by=["PPG_Item_No"]).apply(lambda x: x[x["Date"] == x["Date"].max()])
    max_week_acv_df = max_week_acv_df.drop(columns=["Date"]).rename(columns={"ACV_Selling": "ACV_Selling_Mean"})
    acv_agg = acv_agg.append(max_week_acv_df, ignore_index=True)
    
    # Adjusting the Price ranges
    retailer_price_agg["min.baseprice"] = (retailer_price_agg["min.baseprice"] - (retailer_price_agg["median_baseprice"] / 10)).apply(np.floor)
    retailer_price_agg["max.baseprice"] = (retailer_price_agg["max.baseprice"] + (retailer_price_agg["median_baseprice"] / 10)).apply(np.ceil)
    retailer_price_agg["median_baseprice"] = retailer_price_agg["median_baseprice"].apply(lambda x: np.round(x,1))
    retailer_price_agg["min.TPR"] = 0
    retailer_price_agg["max.TPR"] = (retailer_price_agg["max.TPR"] + (retailer_price_agg["mean.TPR"] / 10)).apply(np.ceil)
    retailer_price_agg["min.RP"] = (retailer_price_agg["min.RP"] - (retailer_price_agg["mean.RP"] / 10)).apply(np.floor)
    retailer_price_agg["max.RP"] = (retailer_price_agg["max.RP"] + (retailer_price_agg["mean.RP"] / 10)).apply(np.ceil)
    retailer_price_agg["mean.RP"] = retailer_price_agg.apply(lambda x: x["median_baseprice"] if (x["mean.RP"] > x["median_baseprice"]) else x["mean.RP"], axis=1)
    retailer_price_agg["max.RP"] = retailer_price_agg.apply(lambda x: x["max.baseprice"] if (x["max.RP"] > x["max.baseprice"]) else x["max.RP"], axis=1)
    retailer_price_agg = retailer_price_agg.merge(acv_agg, how="left", on="PPG_Item_No")
    retailer_price_agg = retailer_price_agg.merge(Final_Metrics, how="left", on="PPG_Item_No")

    if (retailer_price_agg[Final_Metrics.columns.to_list()].isna().sum()>0).any():    
        retailer_price_agg_wo_na = retailer_price_agg[~retailer_price_agg["RP_Elastic"].isna()]
        retailer_price_agg_wt_na = retailer_price_agg[retailer_price_agg["RP_Elastic"].isna()]
        retailer_price_agg_wt_na[Final_Metrics.columns.to_list()[1:]] = 0
        retailer_price_agg = retailer_price_agg_wo_na.append(retailer_price_agg_wt_na, ignore_index=False)
        
    # TODO - NaN imputation - check if it can happen
    retailer_price_agg.loc[retailer_price_agg["mean.TPR"].isna(),"mean.TPR"] = 0
    retailer_price_agg.loc[retailer_price_agg["max.TPR"].isna(),"max.TPR"] = 0
    retailer_price_agg["Retailer"] = Retailer
    retailer_price_agg["Market"] = retailer_price_agg["PPG_Item_No"].apply(lambda x: "Retailer" if "Retailer" in x else "ROM")
    retailer_price_agg = retailer_price_agg.rename(columns={"PPG_Description":"PPG_Item"})
    retailer_price_agg["Retailer"] = retailer_price_agg["Retailer"].apply(retailer_format_fn)
    retailer_price_agg["PPG_Cat"] = retailer_price_agg["PPG_Cat"].apply(category_format_fn)        

    # Add
    Filter_ppg_file = pd.read_csv(base_dir1+Filtered_PPGs)
    Filter_ppg_file = Filter_ppg_file.drop(columns=["TotalSales", "Reason", "PPG_Retailer"])
    retailer_price_agg = retailer_price_agg.merge(Filter_ppg_file.rename(columns={"PPG_Description": "PPG_Item"}),
                                                  how="left",
                                                  on=["PPG_Item_No","PPG_MFG","PPG_Item"])    
    # Add TPR events count
    tpr_event = Output_Data_Hist[["PPG_Item_No","PPG_MFG","tpr_discount_byppg"]]
    tpr_event["TPR_Flag"] = tpr_event["tpr_discount_byppg"].apply(lambda x: 1 if x>0 else 0)
    # tpr_event = tpr_event[tpr_event["TPR_Flag"==1]
    tpr_event_agg = tpr_event.groupby(by=["PPG_Item_No", "PPG_MFG"]).agg({"TPR_Flag": np.count_nonzero})
    tpr_event_agg = tpr_event_agg.rename(columns={"TPR_Flag": "TPR_Events"})    
    retailer_price_agg = retailer_price_agg.merge(tpr_event_agg, how="left", on=["PPG_Item_No","PPG_MFG"])
    retailer_price_agg["TPR_Events"] = retailer_price_agg["TPR_Events"].fillna(0)
    retailer_price_agg.to_csv(base_dir1+price_agg_op_filename, index=False)    
    # print("Price agg file created")
    
    
    glbl_model_pred_transformed_df = glbl_model_pred_transformed_df.groupby(by=["PPG_Item_No", "PPG_Description", 
                                                                                "PPG_Cat", "PPG_MFG",
                                                                                "flag_qtr2", "flag_qtr3", "flag_qtr4",
                                                                                "Market", "Retailer"], 
                                                                            as_index=False).agg(np.mean)
    glbl_model_pred_transformed_df["qtr"] = 1
    glbl_model_pred_transformed_df.loc[glbl_model_pred_transformed_df["flag_qtr2"]==1, "qtr"] = 2
    glbl_model_pred_transformed_df.loc[glbl_model_pred_transformed_df["flag_qtr3"]==1, "qtr"] = 3
    glbl_model_pred_transformed_df.loc[glbl_model_pred_transformed_df["flag_qtr4"]==1,"qtr"] = 4    
    glbl_model_pred_transformed_df["Retailer"] = glbl_model_pred_transformed_df["Retailer"].apply(retailer_format_fn)
    glbl_model_pred_transformed_df["PPG_Cat"] = glbl_model_pred_transformed_df["PPG_Cat"].apply(category_format_fn)
    glbl_model_pred_transformed_df.to_csv(base_dir1 + base_transform_op_filename2, index=False)
    # print("Base data transformed 2 is created")