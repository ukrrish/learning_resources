#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import string
import numpy as np
import pandas as pd
from itertools import chain 

def preprocess_sample_data(data_path="Data", filename="FAREWAY_data_2019.xlsx"):
    """ Pre-processs sample data and generate support files """
    
    df = pd.read_excel(os.path.join(data_path, filename), sheet_name="Sheet1", na_valuess=[""," ","NA"])
    # df = pd.read_pickle(os.path.join(data_path, filename+".xlsx"))
    df.shape
    
    # QC
    # df.apply(lambda x: np.sum(pd.isnull(x)), axis=0)
    
    # Rename PPG
    ppg_list = df.loc[df["PPGName"].notna(),"PPGName"].drop_duplicates().reset_index(drop=True).sort_values()
    ppg_new_id = []
    for i in list(string.ascii_uppercase)[0:]:
        tmp = [i + j for j in string.ascii_uppercase]
        ppg_new_id.append(tmp)
    ppg_new_id = list(chain.from_iterable(ppg_new_id))
    ppg_mapping = pd.DataFrame(ppg_list)
    ppg_mapping["PPGName_NEW"] = ppg_new_id[0:len(ppg_list)]
    ppg_mapping["PPGName_NEW"] = "Product" + " " + ppg_mapping["PPGName_NEW"]
    ppg_mapping.head()
    
    len(df)
    df_new = df.merge(ppg_mapping, how="left",on = ["PPGName"])
    len(df_new)
    df_new["PPGName"] = df_new["PPGName_NEW"]
    df_new.drop(columns=["PPGName_NEW"], inplace=True)
    
    # Choose Vendor based on Sales
    ppg_summary_1 = pd.pivot_table(df_new, index=["PPGName"], columns=["VENDOR(C)"], aggfunc={"Units": np.sum}, fill_value=0, dropna=False)
    ppg_summary_1["Vendor_MaxSales"] = ppg_summary_1.apply(lambda x: x.idxmax(), axis=1)
    # print(ppg_summary_1["Vendor_MaxSales"].value_counts())
    # df_new.groupby("VENDOR(C)").agg({"Dollars": np.sum, "Units": np.sum})
    
    vendor_lst = df_new["VENDOR(C)"].drop_duplicates().sort_values().to_list()
    slct_vendor = vendor_lst[3]
    df_new["VENDOR(C)"] = df["VENDOR(C)"].apply(lambda x: "NPPC" if x==slct_vendor else x)
    data_pull_from_server = df_new.copy()
    
    # Create Support Data Files
    retailer_desc = ["Retailer1 Total TA"]
    retailer_name = ["Retailer1"]
    rom_desc = ["Retailer1 Total RM Food"]
    rom_name = ["Retailer1"]
    process_flg = [1]
    
    excluded_mkt_desc = ["TEMP"]
    
    category_lst = ["Food Category1"]
    subcategory_lst = ["Food Sub-Category1"]
    ppg_category_lst = ["Category1"]
    
    ip_retailer_mapping = pd.DataFrame({"MarketDescription": retailer_desc, "Retailer.Name": retailer_name, "Process_flag": process_flg})    
    ip_ROM_mapping = pd.DataFrame({"MarketDescription": rom_desc, "ROM.Name": rom_name,"Process_flag": process_flg})
    ip_Excluded_Market_Descriptions = pd.DataFrame({"MarketDescription": excluded_mkt_desc})
    ip_category_mapping = pd.DataFrame({"category": category_lst, "subcategory": subcategory_lst, "PPG_Category": ppg_category_lst, "Process_flag": process_flg})
    
    ppg_mapping_temp = ppg_mapping.drop("PPGName", axis=1)
    ppg_mapping_temp["id"] = 1
    Acting_Item_ppg = ppg_mapping_temp.merge(ppg_mapping_temp,on = "id")
    Acting_Item_ppg.rename(columns={"PPGName_NEW_x": "Base_PPG","PPGName_NEW_y": "Acting_PPG"}, inplace=True)
    Acting_Item_ppg = Acting_Item_ppg[Acting_Item_ppg["Base_PPG"]!=Acting_Item_ppg["Acting_PPG"]]
    Acting_Item_ppg.drop(columns="id", inplace=True)
    Acting_Item_ppg["Category"] = ppg_category_lst[0]

    return data_pull_from_server, Acting_Item_ppg, ip_retailer_mapping, ip_ROM_mapping, ip_Excluded_Market_Descriptions, ip_category_mapping
