#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import re
import os
import statsmodels.api as sm
from sklearn import linear_model
from sklearn import preprocessing
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.model_selection import StratifiedKFold
import random
from datetime import datetime
import pdb
from price_elasticity_modelling_2yr import save_empty_dataframe, RegularPrice_InteractionVariables, TradePromotions_InteractionVariables, model_func, cannibalisation_module, cross_validation
from my_utils import category_format_fn, retailer_format_fn, MyLassoCV


def prepare_optimizer_data(model_df_2):
    
    """" Prepares Optimizer Data - 1 Yr Modelling"""
    max_qtr = model_df_2.loc[model_df_2["wk_sold_qty_byppg"]>0, "Year_Qtr"].sort_values(ascending=False)[0:1]
    last_qtr_sales = model_df_2.loc[(model_df_2["Year_Qtr"].isin(max_qtr.to_list())) & 
                                    (model_df_2["wk_sold_qty_byppg"]>0), ["PPG_Item_No", "PPG_Retailer","PPG_MFG", "Estimated_baseprice","ACV_Selling"]]
    last_qtr_sales_agg = last_qtr_sales.groupby(by=["PPG_Item_No", "PPG_Retailer","PPG_MFG"], as_index=False).agg({"Estimated_baseprice": np.nanmedian, "ACV_Selling": np.nanmedian})
    last_qtr_sales_agg.rename(columns={"Estimated_baseprice": "median_ebp", "ACV_Selling": "ACV_median"}, inplace=True)
    
    model_df_2["percent_diff_med_bp"] = 1-(model_df_2["median_baseprice"]/model_df_2["Estimated_baseprice"])
    model_df_2 = model_df_2.merge(last_qtr_sales_agg, how="left", on=["PPG_Item_No", "PPG_Retailer","PPG_MFG"])
    model_df_2["ACV_Selling"] = model_df_2["ACV_median"]
    model_df_2 = model_df_2.drop(columns=["ACV_median"])
    model_df_2["median_baseprice_1"] = model_df_2.apply(lambda x: x["median_ebp"] if x["percent_diff_med_bp"]<0 else x["median_ebp"]*(1-x["percent_diff_med_bp"]), axis=1)
    # print(model_df_2[["ACV_Selling", "wk_sold_avg_price_byppg", "Final_baseprice", "Estimated_baseprice", "median_baseprice", "wk_sold_avg_price_byppg_log", "wk_sold_median_base_price_byppg_log"]].mean())

    model_df_2_edlp = model_df_2[model_df_2["tpr_discount_byppg"]==0].copy()    
    model_df_2_edlp["percent_diff_avg_price"] = 1 - (model_df_2_edlp["wk_sold_avg_price_byppg"]/model_df_2_edlp["Estimated_baseprice"])
    model_df_2_edlp["wk_sold_avg_price_byppg_1"] = model_df_2_edlp.apply(lambda x: x["median_ebp"] if x["percent_diff_avg_price"]<0 else x["median_ebp"]*(1-x["percent_diff_avg_price"]), axis=1)
    model_df_2 = model_df_2.merge(model_df_2_edlp[["PPG_Item_No","PPG_Retailer", "PPG_MFG", "Date", "wk_sold_avg_price_byppg_1"]], how="left", on=["PPG_Item_No","PPG_Retailer", "PPG_MFG", "Date"])
    model_df_2["wk_sold_avg_price_byppg"] = model_df_2.apply(lambda x: x["wk_sold_avg_price_byppg_1"] if x["tpr_discount_byppg"]==0 else x["wk_sold_avg_price_byppg"], axis=1)  
    model_df_2["median_baseprice"] = model_df_2["median_baseprice_1"]
    model_df_2["Estimated_baseprice"] = model_df_2["median_ebp"]
    model_df_2["Final_baseprice"] = model_df_2["median_ebp"]
    model_df_2 = model_df_2.drop(columns=["wk_sold_avg_price_byppg_1"])
    # print(model_df_2[["ACV_Selling", "wk_sold_avg_price_byppg", "Final_baseprice", "Estimated_baseprice", "median_baseprice", "wk_sold_avg_price_byppg_log", "wk_sold_median_base_price_byppg_log"]].mean())
       
    model_df_2_tpr = model_df_2[model_df_2["tpr_discount_byppg"]!=0].copy()
    model_df_2_tpr["wk_sold_avg_price_byppg_1"] = model_df_2_tpr["Estimated_baseprice"]*(1-model_df_2_tpr["tpr_discount_byppg"])
    model_df_2 = model_df_2.merge(model_df_2_tpr[["PPG_Item_No","PPG_Retailer", "PPG_MFG", "Date", "wk_sold_avg_price_byppg_1"]], how="left", on=["PPG_Item_No","PPG_Retailer", "PPG_MFG", "Date"])
    model_df_2["wk_sold_avg_price_byppg"] = model_df_2.apply(lambda x:  x["wk_sold_avg_price_byppg_1"] if x["tpr_discount_byppg"]!=0 else x["wk_sold_avg_price_byppg"], axis=1)
    model_df_2 = model_df_2.drop(columns=["wk_sold_avg_price_byppg_1","median_baseprice_1", "percent_diff_med_bp", "median_ebp"])  
    model_df_2[["ACV_Feat_Only","ACV_TPR_Only", "ACV_Disp_Only", "ACV_Feat_Disp"]] = 0  
    model_df_2["flag"] = model_df_2.apply(lambda x: 1 if x["PPG_Retailer"]=="ROM" or x["PPG_MFG"]=="Non-NPP" else 0, axis=1)  
    model_df_2.loc[model_df_2["flag"]==1, "wk_sold_avg_price_byppg"] = model_df_2.loc[model_df_2["flag"]==1,"Final_baseprice"]
    model_df_2.loc[model_df_2["flag"]==1, "median_baseprice"] = model_df_2.loc[model_df_2["flag"]==1,"Final_baseprice"]
    model_df_2.loc[model_df_2["flag"]==1, "tpr_discount_byppg"] = 0
    model_df_2["wk_sold_avg_price_byppg_log"] = model_df_2["wk_sold_avg_price_byppg"].apply(np.log)
    model_df_2["wk_sold_median_base_price_byppg_log"] = model_df_2["median_baseprice"].apply(np.log)    
    # print(model_df_2[["ACV_Selling", "wk_sold_avg_price_byppg", "Final_baseprice", "Estimated_baseprice", "median_baseprice", "wk_sold_avg_price_byppg_log", "wk_sold_median_base_price_byppg_log"]].mean())
    return model_df_2
    
def acting_item_filter_edlp_module_1yr(model_df,ppg,action_items,
                                   model_correlation_feature_shortlist,
                                   model_correlation_price_trend_cutoff):
    """ EDLP Acting Item selection """
    
    corr_acting_items = []
    for i in action_items:
        ppg_vol = model_df.loc[model_df["PPG_Item_No"]==ppg,["wk_sold_qty_byppg_log", "Date"]].set_index("Date")
        ppg_base_price = model_df.loc[model_df["PPG_Item_No"]==ppg,["wk_sold_median_base_price_byppg_log", "Date"]].set_index("Date")
        action_vol = model_df.loc[model_df["PPG_Item_No"]==i, ["wk_sold_qty_byppg_log", "Date"]].set_index("Date")
        action_base_price = model_df.loc[model_df["PPG_Item_No"]==i, ["wk_sold_median_base_price_byppg_log", "Date"]].set_index("Date")
        common_index = ppg_vol.index.intersection(action_base_price.index)        
        ppg_vol = ppg_vol[ppg_vol.index.isin(common_index)]
        action_base_price = action_base_price[action_base_price.index.isin(common_index)]

        # TODO - Expection Handling
        # ppg_vol_decomposed = sm.tsa.seasonal_decompose(ppg_vol["wk_sold_qty_byppg_log"]) 
        # TODO - Expection Handling
        # action_base_price_decomposed = sm.tsa.seasonal_decompose(action_base_price["wk_sold_median_base_price_byppg_log"])
        action_corr = ppg_vol["wk_sold_qty_byppg_log"].corr(action_base_price["wk_sold_median_base_price_byppg_log"])
        # trend_corr = ppg_vol_decomposed.trend.corr(action_base_price_decomposed.trend)
        price_corr =  ppg_vol["wk_sold_qty_byppg_log"].corr(ppg_base_price["wk_sold_median_base_price_byppg_log"])
        price_corr =  0.5 if np.isnan(price_corr) else price_corr        
        if(~np.isnan(action_corr) and ((abs(action_corr)<abs(price_corr)) or abs(action_corr)<model_correlation_price_trend_cutoff)):
            corr_acting_items.append(action_corr)
        else:
            corr_acting_items.append(np.nan)
            
    ppg_adj = re.sub("_ROM", "_Retailer", ppg) if "_ROM" in ppg else re.sub("_ROM", "_Retailer", ppg)
    slct_action_items = [item for ptr,item in enumerate(action_items) if ((~np.isnan(corr_acting_items[ptr]) and corr_acting_items[ptr]>=model_correlation_feature_shortlist) or 
                                                   ((item==ppg_adj) & ~np.isnan(corr_acting_items[ptr])))]        
    slct_action_items_df = model_df.loc[model_df["PPG_Item_No"].isin(slct_action_items),["PPG_Item_No","Date","wk_sold_median_base_price_byppg_log"]]   
    if len(slct_action_items_df)>0:
        final_df = slct_action_items_df.pivot_table(values="wk_sold_median_base_price_byppg_log",index="Date",columns="PPG_Item_No")
        final_df.columns = [i+"_RegularPrice" for i in final_df.columns.to_list()]
        final_df.reset_index(inplace=True)
        return final_df
    else:
        return None


# TODO - Remove the module - Same as in 2Yr model 
def acting_item_filter_tpr_module_1yr(model_df,ppg,action_items,
                                    model_correlation_feature_shortlist_tpr):
    """ TPR Acting Item selection - 1 Yr """
    
    corr_acting_items = []
    for i in action_items:
        ppg_vol = model_df.loc[model_df["PPG_Item_No"]==ppg,["wk_sold_qty_byppg_log", "Date"]].set_index("Date")
        action_tpr = model_df.loc[model_df["PPG_Item_No"]==i,["tpr_discount_byppg", "Date"]].set_index("Date")
        common_index = ppg_vol.index.intersection(action_tpr.index)        
        ppg_vol = ppg_vol[ppg_vol.index.isin(common_index)]
        action_tpr = action_tpr[action_tpr.index.isin(common_index)]
        
        action_corr = ppg_vol["wk_sold_qty_byppg_log"].corr(action_tpr["tpr_discount_byppg"])
        corr_acting_items.append(action_corr)
            
    ppg_adj = re.sub("_ROM", "_Retailer", ppg) if "_ROM" in ppg else re.sub("_ROM", "_Retailer", ppg)
    slct_action_items = [item for ptr,item in enumerate(action_items) if ((~np.isnan(corr_acting_items[ptr]) and corr_acting_items[ptr]<=model_correlation_feature_shortlist_tpr) or 
                                                        ((item==ppg_adj) and ~np.isnan(corr_acting_items[ptr])))]        
    slct_action_items_df = model_df.loc[model_df["PPG_Item_No"].isin(slct_action_items),["PPG_Item_No","Date","tpr_discount_byppg"]]
    if len(slct_action_items_df)>0:
        final_df = slct_action_items_df.pivot_table(values="tpr_discount_byppg",index="Date",columns="PPG_Item_No")
        final_df.columns = [i+"_PromotedDiscount" for i in final_df.columns.to_list()]
        final_df.reset_index(inplace=True)
        return final_df
    else:
        return None


def Model_data_filtering_1yr(Category,merged_ustotal_ppg_ip_filename,min_revenue_threshold,
                             min_prct_data_points,sd_by_mean_avg_price_threshold,
                             sd_by_mean_sales_vol_threshold,filtered_model_dataset_filename,
                             Retailer_ACV_CUTOFF,ROM_ACV_CUTOFF,filtered_ppg_filename,
                             Retailer,Total_weeks,Model_Start_Date,Model_End_Date, Model_Time_range):
    """ Prepares 1Yr Modelling data """
        
    input_sales_df_1 = pd.read_pickle(merged_ustotal_ppg_ip_filename)
    input_sales_df_1.rename(columns={"PPG_Item": "PPG_Item_No","PPGName": "PPG_Description","PPG_Category": "PPG_Cat"}, inplace=True)
          
    filtered_ppgs = pd.read_csv(os.path.join("Output Files",filtered_ppg_filename)) # pd.DataFrame(columns=["PPG_Item_No","Reason"])

    # ACV Adjustment
    acv_cols = [x for x in input_sales_df_1.columns.to_list() if "ACV" in x] 
    input_sales_df_1.loc[:,acv_cols] = input_sales_df_1.loc[:,acv_cols]/100
          
    # Create Qtr Flags
    input_sales_df_1["flag_qtr2"] = (input_sales_df_1["Date"].dt.quarter==2).astype(int)
    input_sales_df_1["flag_qtr3"] = (input_sales_df_1["Date"].dt.quarter==3).astype(int)
    input_sales_df_1["flag_qtr4"] = (input_sales_df_1["Date"].dt.quarter==4).astype(int)
          
    input_sales_df_1["PPG_Item_No"] = input_sales_df_1["PPG_Item_No"] + "_" + input_sales_df_1["PPG_Retailer"]
    input_sales_df_1["Year_Qtr"] = input_sales_df_1["Date"].dt.year.astype(str) + "_" + input_sales_df_1["Date"].dt.quarter.astype(str)
          
    input_sales_df_2 =  input_sales_df_1[(input_sales_df_1["Year_Qtr"]>=Model_Time_range[0]) & (input_sales_df_1["Year_Qtr"]<=Model_Time_range[1])]
    # input_sales_df_2 = input_sales_df_1[(input_sales_df_1["Date"]>=Model_Start_Date) & (input_sales_df_1["Date"]<Model_End_Date)]
    # input_sales_df_2 = input_sales_df_2.drop(columns="Year_Qtr")
    input_sales_df_2 = input_sales_df_2[(input_sales_df_2["wk_sold_doll_byppg"]>=0) & 
                                        (~input_sales_df_2["wk_sold_doll_byppg"].isna()) & 
                                        (input_sales_df_2["wk_sold_qty_byppg"]>=0) &
                                        (~input_sales_df_2["wk_sold_qty_byppg"].isna())]
    # print("Filter: Zero sales observation")
    # print(len(input_sales_df_2))
    
    # TODO: Move to Model Input module
    data_range_quarters = ((input_sales_df_2["Date"].dt.year).astype(str) + (input_sales_df_2["Date"].dt.quarter).astype(str)).nunique()  # data_range_quarters = 8
    min_num_quarter_sales = 0.75* data_range_quarters
    min_qtr_sales_share = 0.16*(1/data_range_quarters)
    min_sales_quarters = 0.5*min_num_quarter_sales
    weeks_in_data = input_sales_df_2["Date"].nunique()  # weeks_in_data = 104
    
    # Modelling data preparation
    input_sales_df_2.rename(columns={"wk_avg_price_perunit_byppg": "wk_sold_avg_price_byppg"}, inplace=True)
    
    # Revenue Cut Off Filter
    temp_1 = input_sales_df_2.groupby(["PPG_Cat","PPG_MFG","PPG_Item_No"], as_index=False).agg({"wk_sold_doll_byppg": np.sum, "wk_sold_qty_byppg": np.sum})
    temp_1["avg_qtrly_sales"] = temp_1["wk_sold_doll_byppg"]/data_range_quarters
    temp_1["avg_qtrly_qty"] = temp_1["wk_sold_qty_byppg"]/data_range_quarters
    temp_1["avg_rough_ppg_price_point"] = temp_1["avg_qtrly_sales"]/temp_1["avg_qtrly_qty"]
    low_revenue_ppgs = temp_1[(temp_1["PPG_Cat"]==Category) & (temp_1["avg_qtrly_sales"]<=min_revenue_threshold)]["PPG_Item_No"].unique()
    input_sales_df_3 = input_sales_df_2[~input_sales_df_2["PPG_Item_No"].isin(low_revenue_ppgs)]
    del temp_1
    
    # Remove PPGs with less than a year data
    temp_1 = input_sales_df_3.groupby(by=["PPG_Item_No"], as_index=False).agg({"Date": len}).rename(columns={"Date": "week_cnt"})
    ppgs_lt_yr_data = temp_1.loc[temp_1["week_cnt"]<=51,"PPG_Item_No"].unique()
    input_sales_df_4 = input_sales_df_3[~input_sales_df_3["PPG_Item_No"].isin(ppgs_lt_yr_data)]
    del temp_1 
    
    # Remove PPGs with zero values over many weeks
    temp_1 = input_sales_df_4.groupby(by=["PPG_Item_No"], as_index=False).agg({"ACV_Selling": np.count_nonzero}).rename(columns={"ACV_Selling": "week_cnt"})
    ppgs_wt_zero_acvs = temp_1.loc[temp_1["week_cnt"]<=52,"PPG_Item_No"].unique()
    input_sales_df_5 = input_sales_df_4[~input_sales_df_4["PPG_Item_No"].isin(ppgs_wt_zero_acvs)]
    del temp_1

    input_sales_df_7 = input_sales_df_5.copy() 
    # print("No. rows in base data:")
    # print(len(input_sales_df_7))    
    # print("No. rows in raw data:")
    # print(len(input_sales_df_1))    
        
    # Add missing date observations for every PPG
    input_sales_df_8A = input_sales_df_1[input_sales_df_1["PPG_Item_No"].isin(input_sales_df_7["PPG_Item_No"])].copy()
    input_sales_df_8A["Missing_data_flag"] = 0    
    input_sales_df_7["Missing_data_flag"] = 0    
    # print("No. rows in raw data: wt PPG filter")
    # print(len(input_sales_df_8A))

    input_sales_df_8B = input_sales_df_8A[~input_sales_df_8A["Date"].isin(input_sales_df_7["Date"])].copy()  
    input_sales_df_8B.rename(columns={"wk_avg_price_perunit_byppg": "wk_sold_avg_price_byppg"}, inplace=True)
    # print("No. rows in raw data: wt PPG & Date filter")    
    # print(len(input_sales_df_8B))
       
    Total_weeks = input_sales_df_8A["Date"].drop_duplicates().reset_index(drop=True)
    # TODO - Hard Coding
    if len(Total_weeks)<116:
        exit("Low Week Count")	    
    temp_1 = input_sales_df_8A.groupby("PPG_Item_No", as_index=False).agg({"Date": len}).rename(columns={"Date": "count_of_weeks"})
    temp_1 = temp_1[temp_1["count_of_weeks"]<len(Total_weeks)]
    
    temp_2 = input_sales_df_8A[input_sales_df_8A["PPG_Item_No"].isin(temp_1["PPG_Item_No"])][["MarketDescription","PPG_Retailer","PPG_Cat","PPG_MFG","BRAND GROUP(C)","PPG_Description","PPG_Item_No","Missing_data_flag","Date"]].drop_duplicates()
    temp_3 = input_sales_df_8A[input_sales_df_8A["PPG_Item_No"].isin(temp_1["PPG_Item_No"])][["MarketDescription","PPG_Retailer","PPG_Cat","PPG_MFG","BRAND GROUP(C)","PPG_Description","PPG_Item_No","Missing_data_flag"]].drop_duplicates()
    if len(temp_3)>0:
        temp_3["id"] = 1
        temp_4 = temp_3.merge(pd.DataFrame({"Date": Total_weeks, "id": 1}), on="id").drop(columns=["id"])
        temp_4["index"] = temp_4.index
        temp_5 = temp_4.merge(temp_2, how="inner", on=["MarketDescription","PPG_Retailer","PPG_Cat","PPG_MFG","BRAND GROUP(C)","PPG_Description","PPG_Item_No","Missing_data_flag","Date"])
        temp_4 = temp_4[~temp_4.index.isin(temp_5["index"])].drop(columns=["index"])
        temp_5 = input_sales_df_8A[0:0].append(temp_4, ignore_index=True)
        
        temp_5["Missing_data_flag"] = 1
        temp_5["Year_Qtr"] = temp_5["Date"].dt.year.astype(str) + "_" + temp_5["Date"].dt.quarter.astype(str)
        # temp_5["flag_qtr1"] = (temp_5["Date"].dt.quarter==1).astype(int)
        temp_5["flag_qtr2"] = (temp_5["Date"].dt.quarter==2).astype(int)
        temp_5["flag_qtr3"] = (temp_5["Date"].dt.quarter==3).astype(int)
        temp_5["flag_qtr4"] = (temp_5["Date"].dt.quarter==4).astype(int)
        temp_5[["ACV_Selling","ACV_TPR_Only","ACV_Feat_Only","ACV_Disp_Only","ACV_Feat_Disp"]] = 0
        temp_5.rename(columns={"wk_avg_price_perunit_byppg": "wk_sold_avg_price_byppg"}, inplace=True)
        # print("Unique observations")
        # print("Base data")
        # print(len(input_sales_df_7[["PPG_Item_No","PPG_Retailer","Date"]].drop_duplicates()))
        input_sales_df_9 = input_sales_df_7.append(temp_5, ignore_index=True)
        # print("After appending some rows 1")
        # print(len(input_sales_df_9[["PPG_Item_No","PPG_Retailer","Date"]].drop_duplicates()))
        input_sales_df_9 = input_sales_df_9.append(input_sales_df_8B, ignore_index=True)        
        # print("After appending some rows 2")
        # print(len(input_sales_df_9[["PPG_Item_No","PPG_Retailer","Date"]].drop_duplicates()))
    else:
        # TODO
        input_sales_df_9 = input_sales_df_8B.append(input_sales_df_7, ignore_index=True)
    del temp_1, temp_2, temp_3, temp_4, temp_5
    
    # EDLP and TPR decompositon of Avg. price per unit
    input_sales_df_9 = input_sales_df_9.sort_values(["PPG_Item_No","Date"])    
    input_sales_df_9["wk_sold_qty_byppg"] = input_sales_df_9.apply(lambda x: 0 if x["Missing_data_flag"]==1 else x["wk_sold_qty_byppg"], axis=1)
    input_sales_df_9["New_base_price"] = input_sales_df_9[["wk_base_price_perunit_byppg","wk_sold_avg_price_byppg"]].apply(lambda x: np.max(x),axis=1)

    input_sales_df_9["lag_base_price_1"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(1, fill_value=None)
    input_sales_df_9["lag_base_price_2"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(2, fill_value=None)
    input_sales_df_9["lag_base_price_3"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(3, fill_value=None)
    input_sales_df_9["lag_base_price_4"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(4, fill_value=None)
    input_sales_df_9["lag_base_price_5"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(5, fill_value=None)
    input_sales_df_9["lag_base_price_6"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(6, fill_value=None)
    input_sales_df_9["lag_base_price_7"] = input_sales_df_9.groupby("PPG_Item_No")["New_base_price"].shift(7, fill_value=None)
    
    base_price_lag_cols = ["lag_base_price_1","lag_base_price_2","lag_base_price_3","lag_base_price_4","lag_base_price_5","lag_base_price_6","lag_base_price_7"]
    input_sales_df_9["max_base_price_prev"] = input_sales_df_9[base_price_lag_cols].apply(np.nanmax, axis=1)
    for lag_col in base_price_lag_cols:
        input_sales_df_9[lag_col] = input_sales_df_9.apply(lambda x: x[lag_col] if x["max_base_price_prev"]>0 and np.abs((x[lag_col]/x["max_base_price_prev"])-1)<=0.05 else np.nan, axis=1)
    input_sales_df_9["Final_baseprice"] = input_sales_df_9[base_price_lag_cols].apply(np.nanmedian, axis=1)
    
  	# Add Reason column
    input_sales_df_9 = input_sales_df_9.merge(filtered_ppgs[["PPG_Item_No","Reason"]], how="left", on="PPG_Item_No")

    # Inputation
    input_sales_df_9["Final_baseprice"] = input_sales_df_9.groupby("PPG_Item_No")["Final_baseprice"].fillna(method="ffill")
    input_sales_df_9["Final_baseprice"] = input_sales_df_9.groupby("PPG_Item_No")["Final_baseprice"].fillna(method="bfill")
    
    # Replacing NA Wk_Avg_price instances with FBP
    input_sales_df_9["wk_sold_avg_price_byppg"] = input_sales_df_9.apply(lambda x: x["Final_baseprice"] if np.isnan(x["wk_sold_avg_price_byppg"]) else x["wk_sold_avg_price_byppg"], axis=1)
    input_sales_df_9["Final_baseprice"] = input_sales_df_9.apply(lambda x: x["New_base_price"] if x["Final_baseprice"]<x["New_base_price"] else x["Final_baseprice"], axis=1)
    
    # Compute medain base price with updated FBP
    input_sales_df_9["lag_price_1"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(1, fill_value=None)
    input_sales_df_9["lag_price_2"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(2, fill_value=None)
    input_sales_df_9["lag_price_3"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(3, fill_value=None)
    input_sales_df_9["lag_price_4"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(4, fill_value=None)
    input_sales_df_9["lag_price_5"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(5, fill_value=None)
    input_sales_df_9["lag_price_6"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(6, fill_value=None)
    input_sales_df_9["lag_price_7"] = input_sales_df_9.groupby("PPG_Item_No")["wk_sold_avg_price_byppg"].shift(7, fill_value=None)
    
    price_lag_cols = ["lag_price_1","lag_price_2","lag_price_3","lag_price_4","lag_price_5","lag_price_6","lag_price_7"]
    input_sales_df_9["max_price_prev"] = input_sales_df_9[price_lag_cols].apply(np.nanmax, axis=1)
    for lag_col in price_lag_cols:
        input_sales_df_9[lag_col] = input_sales_df_9.apply(lambda x: x[lag_col] if x["max_price_prev"]>0 and np.abs((x[lag_col]/x["max_price_prev"])-1)<=0.05 else np.nan, axis=1)
    input_sales_df_9["Estimated_baseprice"] = input_sales_df_9[price_lag_cols].apply(np.nanmedian, axis=1)
    
    input_sales_df_9["median_baseprice"] = input_sales_df_9.apply(lambda x: x["wk_sold_avg_price_byppg"] if (1-x["wk_sold_avg_price_byppg"]/x["Estimated_baseprice"])<=0.05 else x["Estimated_baseprice"], axis=1)
    input_sales_df_9["tpr_discount_byppg"] = input_sales_df_9.apply(lambda x: (1-x["wk_sold_avg_price_byppg"]/x["median_baseprice"]) if (1-x["wk_sold_avg_price_byppg"]/x["median_baseprice"])>0.05 else 0, axis=1)
    input_sales_df_9["tpr_discount_byppg"] = input_sales_df_9.apply(lambda x: 0 if x["Missing_data_flag"]==1 else x["tpr_discount_byppg"], axis=1)
    input_sales_df_9["median_baseprice"] = input_sales_df_9.apply(lambda x: x["Final_baseprice"] if np.isnan(x["median_baseprice"]) else x["median_baseprice"], axis=1)
    
    # Category Trend Variable
    input_sales_df_10 = input_sales_df_9[~input_sales_df_9["median_baseprice"].isna()]
    temp_1 = input_sales_df_10.groupby(["Date"], as_index=False).agg({"wk_sold_doll_byppg": np.sum}).rename(columns={"wk_sold_doll_byppg": "cumsum_wk_sold_doll"})
    temp_1["category_trend"] = temp_1["cumsum_wk_sold_doll"]/temp_1["cumsum_wk_sold_doll"].mean()
    temp_1 = temp_1.drop(columns=["cumsum_wk_sold_doll"])
    input_sales_df_11 = input_sales_df_10.merge(temp_1, how="left", on="Date")
    del temp_1
    
    # ACV Lag  (TPR ACV smoothing) 
    temp_1 = input_sales_df_11[input_sales_df_11["tpr_discount_byppg"]==0].sort_values(["PPG_Item_No","Date"]).copy()
    temp_1["lag_acv_selling_1"] = temp_1.groupby("PPG_Item_No")["ACV_Selling"].shift(1, fill_value=None)
    temp_1["lag_acv_selling_2"] = temp_1.groupby("PPG_Item_No")["ACV_Selling"].shift(2, fill_value=None)
    temp_1["lag_acv_selling_3"] = temp_1.groupby("PPG_Item_No")["ACV_Selling"].shift(3, fill_value=None)
    temp_1["lag_acv_selling_4"] = temp_1.groupby("PPG_Item_No")["ACV_Selling"].shift(4, fill_value=None)
    temp_1["lag_acv_selling_5"] = temp_1.groupby("PPG_Item_No")["ACV_Selling"].shift(5, fill_value=None)
    temp_1["lag_acv_selling_6"] = temp_1.groupby("PPG_Item_No")["ACV_Selling"].shift(6, fill_value=None)
    
    acv_lag_cols = ["lag_acv_selling_1","lag_acv_selling_2","lag_acv_selling_3","lag_acv_selling_4","lag_acv_selling_5","lag_acv_selling_6"]
    temp_1["median_acv_selling"] = temp_1[acv_lag_cols+["ACV_Selling"]].apply(np.nanmedian, axis=1)
    temp_2 = input_sales_df_11.merge(temp_1[["PPG_Item_No","PPG_Retailer", "Date", "median_acv_selling"]], how="left", on=["PPG_Item_No","PPG_Retailer", "Date"])
    # Imputation
    temp_2["median_acv_selling"] = temp_2.groupby("PPG_Item_No")["median_acv_selling"].fillna(method="ffill")
    input_sales_df_12 = temp_2.drop(columns=["median_acv_selling"]).merge(temp_2[["PPG_Item_No","PPG_Retailer", "Date", "median_acv_selling"]], how="left", on=["PPG_Item_No","PPG_Retailer", "Date"])
    del temp_1, temp_2
    
    
    # Model dataset - 1
    model_df_1 = input_sales_df_12.copy()
    model_df_1["wk_sold_qty_byppg_log"] = model_df_1["wk_sold_qty_byppg"].apply(np.log1p)
    model_df_1["wk_sold_avg_price_byppg_log"] = model_df_1["wk_sold_avg_price_byppg"].apply(np.log)
    model_df_1["wk_sold_median_base_price_byppg_log"] = model_df_1["median_baseprice"].apply(np.log)
    model_df_1 = model_df_1.sort_values(["PPG_Cat","PPG_MFG","PPG_Item_No","Date"], ignore_index=True)

    model_df_1["month"] = model_df_1["Date"].dt.month
    model_df_1["year"] = model_df_1["Date"].dt.year
    month_df = model_df_1[["month","year"]].drop_duplicates(ignore_index=True)
    month_df = month_df.sort_values(by=["year","month"])
    month_df["monthno"] = np.arange(len(month_df))+1
    model_df_1 = model_df_1.merge(month_df, how="left", on=["month", "year"])
    model_df_1 = model_df_1.drop(columns=["month","year"])

    # Model dataset - 2
    temp_model_df_2 = model_df_1.copy()       
    ppg_list = temp_model_df_2["PPG_Item_No"].unique()
    model_df_2 = pd.DataFrame()
    for ppg in ppg_list:
        ppg_model_df_2 = prepare_optimizer_data(temp_model_df_2[temp_model_df_2["PPG_Item_No"]==ppg])
        model_df_2 = model_df_2.append(ppg_model_df_2, ignore_index=True)
    model_df_2 = model_df_2.sort_values(["PPG_Cat","PPG_MFG","PPG_Item_No","Date"])

    # Pantry Loading feature
    model_df_2 = model_df_2.sort_values(["PPG_Item_No","Date"])    
    model_df_1["tpr_discount_byppg_lag1"] = model_df_1.groupby("PPG_Item_No")["tpr_discount_byppg"].shift(1,fill_value=0)
    model_df_1["tpr_discount_byppg_lag2"] = model_df_1.groupby("PPG_Item_No")["tpr_discount_byppg"].shift(2,fill_value=0)
    model_df_2["tpr_discount_byppg_lag1"] = model_df_2.groupby("PPG_Item_No")["tpr_discount_byppg"].shift(1,fill_value=0)
    model_df_2["tpr_discount_byppg_lag2"] = model_df_2.groupby("PPG_Item_No")["tpr_discount_byppg"].shift(2,fill_value=0)
    model_df_2 = model_df_2.drop(columns=["flag"])
    model_df_2["Retailer"] = Retailer
    model_df_2["PPG_Cat"] = model_df_2["PPG_Cat"].apply(category_format_fn)  
  
    if model_df_2.columns.isin(["ACV_Promo"]).any():
       model_df_2 = model_df_2.drop(columns=["ACV_Promo"])            
    # model_df_2 = model_df_2[(model_df_2["Date"]>=Model_Start_Date) & (model_df_2["Date"]<Model_End_Date)]  
    model_df_2 = model_df_2[(model_df_2["Year_Qtr"]>=Model_Time_range[0]) & (model_df_2["Year_Qtr"]<=Model_Time_range[1])]  
    # model_df_1 = model_df_1[(model_df_1["Date"]>=Model_Start_Date) & (model_df_1["Date"]<Model_End_Date)]
    model_df_1 = model_df_1[(model_df_1["Year_Qtr"]>=Model_Time_range[0]) & (model_df_1["Year_Qtr"]<=Model_Time_range[1])]
    # model_df_2_optimizer = model_df_2[["Date","PPG_Item_No","PPG_Cat","PPG_Retailer","Final_baseprice"]] 
  
    # Output files
    # temp_1 = input_sales_df_2.groupby(["PPG_Item_No", "PPG_MFG", "PPG_Retailer","PPG_Description"], as_index=False).agg({"wk_sold_doll_byppg": np.sum}).rename({"wk_sold_doll_byppg": "TotalSales"})
    # PPG_Filter_Summary = temp_1.merge(filtered_ppgs, how="left", on="PPG_Item_No")
    # del temp_1
  
    # model_df_1["Model_flag"] = 2
    # model_df_2["Model_flag"] = 2
    # model_df_2_optimizer["Model_flag"] = 2
    model_df_1["Model_flag"] = model_df_1["Reason"].apply(lambda x: 2 if x=="PPGs Considered for Modelling" else 1)
    model_df_2["Model_flag"] = model_df_2["Reason"].apply(lambda x: 2 if x=="PPGs Considered for Modelling" else 1)
    
    output_path = os.path.join(os.getcwd(),"Output Files")
    if os.path.exists(output_path):
        print("Output directory is present")
    else:
        os.mkdir(output_path)
    os.chdir(output_path)
    model_df_1.to_pickle(filtered_model_dataset_filename + ".pkl")	
    # model_df_1.to_pickle(filtered_model_dataset_filename + "_" + "Optimizer_1.pkl")
    model_df_2.to_pickle(filtered_model_dataset_filename + "_" + "Optimizer_2.pkl")
    # PPG_Filter_Summary.to_csv(filtered_ppg_filename, index=False)
    # model_df_2_optimizer.to_csv("model_data_set_2_optimizer.csv", index=False)
    return True
    
    
def Model_building_1yr(Category,
                        filtered_model_dataset_filename,
                        model_correlation_feature_shortlist,
                        model_correlation_price_trend_cutoff,
                        model_correlation_feature_shortlist_tpr,
                        model_regularization_parameter,
                        cannibalisation_cor_cutoff,
                        cannibal_dat_filename,
                        baselines_dat_filename,
                        model_est_dat_filename,
                        min_interaction_rp_cutoff,
                        max_interaction_rp_cutoff,
                        ActingItem_list,
                        filtered_ppg_filename,	
                        filtered_ppg_filename_revised,Retailer,base_dir1):
    """ Builds Lasso Model - 1 Yr """
    
    fn_start_time = datetime.now()
    
    # Loading the Model Dataset & CMI Acting Item Dataset
    os.chdir(base_dir1)
    Acting_Item = pd.read_pickle(ActingItem_list)
    os.chdir(os.path.join(base_dir1,"Output Files"))
    model_df_1 = pd.read_pickle(filtered_model_dataset_filename + ".pkl")
    # model_df_1 = pd.read_pickle(filtered_model_dataset_filename + "_Optimizer_1.pkl")
    model_df_2 = pd.read_pickle(filtered_model_dataset_filename + "_Optimizer_2.pkl")    
    Filter_PPG_Summary = pd.read_csv(filtered_ppg_filename)   
    
    ppg_list_to_model = model_df_1.loc[(model_df_1["PPG_MFG"]=="NPP") & (model_df_1["Reason"]!="PPGs Considered for Modelling"),"PPG_Item_No"].unique()
    if len(ppg_list_to_model)==0:
        save_empty_dataframe(filtered_model_dataset_filename,
                             filtered_ppg_filename,
                             filtered_ppg_filename_revised,
                             cannibal_dat_filename,
                             baselines_dat_filename,
                             model_est_dat_filename,
                             flag_2yr_model = False)
        return None
        
    PPG = model_df_1.loc[(model_df_1["PPG_MFG"]=="NPP") & 
                         (model_df_1["Reason"]!="PPGs Considered for Modelling") & 
                         (~model_df_1["PPG_Item_No"].str.contains("ROM", regex=False)),"PPG_Item_No"].unique() # model_df_1["PPG_Retailer"]!="ROM"
    
    # Extracting Acting Items based on CMI list
    acting_ppg = pd.DataFrame(columns=["PPG_Item_No", "Acting_Items"])   
    inter_ppg = pd.DataFrame(columns=["PPG_Item_No", "Acting_Items"])
    for i in ppg_list_to_model:   
        ppg = i.replace("_ROM","") if "_ROM" in i else i.replace("_Retailer","")
        acting_items = Acting_Item[Acting_Item["Base_Item"].str.contains(ppg, regex=False)]["Acting_Item"].unique()
        acting_items = [j+"_Retailer" for j in acting_items] + [j+"_ROM" for j in acting_items]
        acting_items = [item for item in acting_items if i not in item]
        acting_items = [item for item in acting_items if item in model_df_1.loc[model_df_1["Reason"]=="PPGs Considered for Modelling","PPG_Item_No"].unique()]       
        if len(acting_items)==0:
            continue
        temp_1 = pd.DataFrame({"PPG_Item_No": [i]*len(acting_items),"Acting_Items": acting_items})
        acting_ppg = acting_ppg.append(temp_1, ignore_index=True)
        len(acting_ppg)
        
    if len(acting_ppg)>0:
        inter_ppg = acting_ppg[(acting_ppg["PPG_Item_No"].isin(PPG)) & (acting_ppg["Acting_Items"].str.contains("Retailer", regex=False))]
        
    # Creating Acting item list for UPCs (without PPGs)	
    ppg_wt_acting_items = acting_ppg["PPG_Item_No"].unique()
    ppg_wo_acting_items = [ppg for ppg in ppg_list_to_model if ppg not in ppg_wt_acting_items]
    upc_list = model_df_1.loc[(model_df_1["PPG_Item_No"].isin(ppg_wo_acting_items)) & (model_df_1["PPG_Item_No"]=="ITEM"+model_df_1["PPG_Description"]),"PPG_Item_No"].unique()
    for i in upc_list:
        acting_items = [j+"_Retailer" for j in ppg_list_to_model] + [j+"_ROM" for j in ppg_list_to_model]
        acting_items = [item for item in acting_items if i not in item]
        acting_items = [item for item in acting_items if item in model_df_1.loc[model_df_1["Reason"]=="PPGs Considered for Modelling","PPG_Item_No"].unique()]   
        temp_1 = pd.DataFrame({"PPG_Item_No": [i]*len(acting_items),"Acting_Items": acting_items})
        acting_ppg = acting_ppg.append(temp_1, ignore_index=True)
        
    model_df_1 = model_df_1.sort_values(by=["PPG_Cat","PPG_MFG","PPG_Item_No","Date"], ignore_index=True)
    model_df_2 = model_df_2.sort_values(by=["PPG_Cat","PPG_MFG","PPG_Item_No","Date"], ignore_index=True)
    
    # RP & TPR Interactions calculation
    InteractionVars_RP = pd.DataFrame(columns=['BasePPG','InteractionPPG'])
    InteractionVars_TPR = pd.DataFrame(columns=['BasePPG','InteractionPPG'])
    if (len(PPG)>1 and len(inter_ppg)>0):
        InteractionVars_RP = RegularPrice_InteractionVariables(model_df_1,PPG,min_interaction_rp_cutoff,
                                                              max_interaction_rp_cutoff,inter_ppg)
        if any(model_df_1.loc[(model_df_1["PPG_Retailer"]=="Retailer") & (model_df_1["PPG_MFG"]=="NPP"),"tpr_discount_byppg"]!=0):
            InteractionVars_TPR = TradePromotions_InteractionVariables(model_df_1,PPG,inter_ppg)

    # Model data set creation 
    # Exclude 2yr Modelled PPGs
    model_df_1.loc[model_df_1["Reason"]!="PPGs Considered for Modelling",["flag_qtr2","flag_qtr3","flag_qtr4"]] = 0
    model_df_2.loc[model_df_2["Reason"]!="PPGs Considered for Modelling",["flag_qtr2","flag_qtr3","flag_qtr4"]] = 0
    
    # Data Initialisation
    # Baseline Sales Data
    glbl_model_base_df_1 = pd.DataFrame(columns=[])
    glbl_model_base_df_2 = pd.DataFrame(columns=[])
    # Cannibalisation Data
    glbl_model_cannibal_df_1 = pd.DataFrame(columns=["Cannibal_PPG","Cannibalised_PPG", 
                                                     "Measure", "Date", "Cannibal_Doll"])
    glbl_model_cannibal_df_2 = pd.DataFrame(columns=["Cannibal_PPG","Cannibalised_PPG", 
                                                     "Measure", "Date", "Cannibal_Doll"])  
    # Model Coefficient Estimates and R Sq
    model_results_seed = pd.DataFrame(columns=["PPG", "model_coefficient_name", "model_coefficient_value",
                                               "R_Square", "train_MAPE", "seed", "Model_flag"])
    model_results = pd.DataFrame(columns=["PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description",
                                          "model_RSq","model_CVErrorMean","model_CVErrorSD",
                                          "model_coefficient_name","model_coefficient_value", "TrainMAPE", "Model_flag"])
    model_results_final = model_results.copy()
    model_results_cv = pd.DataFrame(columns=["PPG_Cat", "PPG_MFG", "PPG_Item_No","PPG_Description",
                                             "model_RSq", "model_CVErrorMean", "model_CVErrorSD",
                                             "TrainMAPE_edlp", "TrainMAPE_tpr",
                                             "TestMAPE_edlp", "TestMAPE_tpr", 
                                             "TrainMape_overall", "TestMape_overall", 
                                             'no_of_tpr_events_train', "no_of_tpr_events_test","fold", "Model_flag"])

    # List of ppgs without enough features
    # ppg_wo_features = []    
    # Seed list to select common features
    seeds = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]
    # List of ppgs with just intercept turning out 
    # ppg_wt_intercept = []
  
    print("No. of PPGs to model : {}".format(len(ppg_list_to_model)))
    model_start_time = datetime.now()
    for ppg in ppg_list_to_model:
        # Data Initialisation
        model_coefficients_check = pd.DataFrame(columns=["model_coefficient_name", "model_coefficient_value"])
        model_coefficients_final = []

        slct_cols_1 = ["PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description","Date","wk_sold_qty_byppg",
                       "wk_sold_avg_price_byppg","median_baseprice","Final_baseprice","Estimated_baseprice",
                       "tpr_discount_byppg","ACV_Feat_Only","ACV_Disp_Only","ACV_Feat_Disp",
                       "ACV_Selling","median_acv_selling","flag_qtr2","flag_qtr3","flag_qtr4",
                       "category_trend","tpr_discount_byppg_lag1","tpr_discount_byppg_lag2",
                       "monthno","Missing_data_flag"]
        model_base_df_1 = model_df_1.loc[model_df_1["PPG_Item_No"]==ppg,slct_cols_1].reset_index(drop=True)
        model_base_df_2 = model_df_2.loc[model_df_1["PPG_Item_No"]==ppg,slct_cols_1].reset_index(drop=True)
        slct_cols_2 = ["PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description","Date","wk_sold_qty_byppg_log",
                       "wk_sold_median_base_price_byppg_log","tpr_discount_byppg","ACV_Feat_Only",
                       "ACV_Disp_Only","ACV_Feat_Disp","ACV_Selling","flag_qtr2","flag_qtr3","flag_qtr4",
                       "category_trend","tpr_discount_byppg_lag1","tpr_discount_byppg_lag2",
                       "monthno","Missing_data_flag"]
        model_ppg_1 = model_df_1.loc[model_df_1["PPG_Item_No"]==ppg,slct_cols_2].reset_index(drop=True)
        model_ppg_1.rename(columns={"wk_sold_qty_byppg_log":"DV"}, inplace=True)
        model_ppg_2 = model_df_2.loc[model_df_1["PPG_Item_No"]==ppg,slct_cols_2].reset_index(drop=True)
        model_ppg_2.rename(columns={"wk_sold_qty_byppg_log":"DV"}, inplace=True)
        
        
        # ACV Smoothening
        # TPR ACV smoothing - Model df 1      
        min_date = model_base_df_1["Date"].min()
        model_base_df_1["ACV_Selling"] = model_base_df_1.apply(lambda x: min(x["ACV_Selling"],x["median_acv_selling"]) if x["tpr_discount_byppg"]!=0 and x["Date"]!=min_date else x["ACV_Selling"], axis=1)
        model_base_df_1["lead_acv_selling_1"] = model_base_df_1.groupby(by=["PPG_Item_No"])["ACV_Selling"].shift(-1)
        model_base_df_1["ACV_Selling"] = model_base_df_1.apply(lambda x: x["lead_acv_selling_1"] if x["tpr_discount_byppg"]!=0 and x["Date"]==min_date else x["ACV_Selling"], axis=1)
        model_base_df_1["ACV_Selling"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].fillna(method="bfill")
        model_base_df_1 = model_base_df_1.drop(columns=["median_acv_selling","lead_acv_selling_1"])
        
        # TPR ACV smoothing - Model df 2        
        # min_date = model_base_df_2["Date"].min()
        # model_base_df_2["ACV_Selling"] = model_base_df_2.apply(lambda x: min(x["ACV_Selling"],x["median_acv_selling"]) if x["tpr_discount_byppg"]!=0 and x["Date"]!=min_date else x["ACV_Selling"], axis=1)
        # model_base_df_2["lead_acv_selling_1"] = model_base_df_2.groupby(by=["PPG_Item_No"])["ACV_Selling"].shift(-1)
        # model_base_df_2["ACV_Selling"] = model_base_df_2.apply(lambda x: x["lead_acv_selling_1"] if x["tpr_discount_byppg"]!=0 and x["Date"]==min_date else x["ACV_Selling"], axis=1)
        # model_base_df_2["ACV_Selling"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].fillna(method="bfill")
        # model_base_df_2 = model_base_df_2.drop(columns=["median_acv_selling","lead_acv_selling_1"])

        # EDLP ACV smoothing - Model df 1
        model_base_df_1["lag_acv_selling_1"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(1, fill_value=None)
        model_base_df_1["lag_acv_selling_2"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(2, fill_value=None)
        model_base_df_1["lag_acv_selling_3"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(3, fill_value=None)
        model_base_df_1["lag_acv_selling_4"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(4, fill_value=None)
        model_base_df_1["lag_acv_selling_5"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(5, fill_value=None)
        model_base_df_1["lag_acv_selling_6"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(6, fill_value=None)
        model_base_df_1["lag_acv_selling_7"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].shift(7, fill_value=None)        
        acv_lag_cols = ["lag_acv_selling_1","lag_acv_selling_2","lag_acv_selling_3","lag_acv_selling_4","lag_acv_selling_5","lag_acv_selling_6","lag_acv_selling_7"]
        model_base_df_1["median_acv_selling"] = model_base_df_1[acv_lag_cols].apply(np.nanmedian, axis=1)
        model_base_df_1["median_acv_selling"] = model_base_df_1.groupby("PPG_Item_No")["median_acv_selling"].fillna(method="ffill")                
        
        model_base_df_1["Promotion"] = 1-(model_base_df_1["wk_sold_avg_price_byppg"]/model_base_df_1["Final_baseprice"])
        temp_fil = model_base_df_1["Promotion"]>0.04
        model_base_df_1.loc[temp_fil,"ACV_Selling"] = model_base_df_1.loc[temp_fil,["ACV_Selling","median_acv_selling"]].min(axis=1)
        model_base_df_1 = model_base_df_1.drop(columns=["Promotion"])
        model_base_df_1["ACV_Selling"] = model_base_df_1.groupby("PPG_Item_No")["ACV_Selling"].fillna(method="bfill")
        model_base_df_1 = model_base_df_1.drop(columns=acv_lag_cols+["median_acv_selling"])
        del acv_lag_cols, temp_fil

        # EDLP ACV smoothing - Model df 2
        # model_base_df_2["lag_acv_selling_1"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(1, fill_value=None)
        # model_base_df_2["lag_acv_selling_2"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(2, fill_value=None)
        # model_base_df_2["lag_acv_selling_3"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(3, fill_value=None)
        # model_base_df_2["lag_acv_selling_4"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(4, fill_value=None)
        # model_base_df_2["lag_acv_selling_5"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(5, fill_value=None)
        # model_base_df_2["lag_acv_selling_6"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(6, fill_value=None)
        # model_base_df_2["lag_acv_selling_7"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].shift(7, fill_value=None)       
        # acv_lag_cols = ["lag_acv_selling_1","lag_acv_selling_2","lag_acv_selling_3","lag_acv_selling_4","lag_acv_selling_5","lag_acv_selling_6","lag_acv_selling_7"]
        # model_base_df_2["median_acv_selling"] = model_base_df_2[acv_lag_cols].apply(np.nanmedian, axis=1)
        # model_base_df_2["median_acv_selling"] = model_base_df_2.groupby("PPG_Item_No")["median_acv_selling"].fillna(method="ffill")                
        
        # model_base_df_2["Promotion"] = 1-(model_base_df_2["wk_sold_avg_price_byppg"]/model_base_df_2["Final_baseprice"])
        # temp_fil = model_base_df_2["Promotion"]>0.04
        # model_base_df_2.loc[temp_fil,"ACV_Selling"] = model_base_df_2.loc[temp_fil,["ACV_Selling","median_acv_selling"]].min(axis=1)
        # model_base_df_2 = model_base_df_2.drop(columns=["Promotion"])
        # model_base_df_2["ACV_Selling"] = model_base_df_2.groupby("PPG_Item_No")["ACV_Selling"].fillna(method="bfill")
        # model_base_df_2 = model_base_df_2.drop(columns=acv_lag_cols+["median_acv_selling"])
        # del acv_lag_cols, temp_fil
        # TODO - Check this!
        # model_base_df_2 = model_base_df_2.drop(columns="median_acv_selling")
        
        # Extracting Acting Items from CMI Data 
        temp_2 = model_ppg_1.copy()
        temp_2b = model_ppg_2.copy()              
        slct_acting_ppgs = acting_ppg[acting_ppg["PPG_Item_No"]==ppg]["Acting_Items"]
        if len(slct_acting_ppgs)>0:
            edlp_action_item_df = acting_item_filter_edlp_module_1yr(model_df_1,ppg,slct_acting_ppgs,
                                                                     model_correlation_feature_shortlist,
                                                                     model_correlation_price_trend_cutoff)
            if edlp_action_item_df is not None:
                temp_2 = model_ppg_1.merge(edlp_action_item_df, how="left", on="Date")
                edlp_action_items = edlp_action_item_df.columns.to_list()[1:]
                edlp_action_items = [re.sub("_RegularPrice","",k) for k in edlp_action_items]
                pt = model_df_2.loc[model_df_2["PPG_Item_No"].isin(edlp_action_items), ["PPG_Item_No", "Date", "wk_sold_median_base_price_byppg_log"]]
                pt = pt.pivot_table(values="wk_sold_median_base_price_byppg_log", index="Date", columns="PPG_Item_No",fill_value=0, dropna=False)
                pt.columns = [k+"_RegularPrice" for k in pt.columns]
                pt.reset_index(inplace=True)
                temp_2b = model_ppg_2.merge(pt, how="left", on="Date")
            else:
                temp_2 = model_ppg_1.copy()
                temp_2b = model_ppg_2.copy()                
        else:
            temp_2 = model_ppg_1.copy()
            temp_2b = model_ppg_2.copy()


        # Extracting TPR Impacting Acting Items from CMI Data
        if len(slct_acting_ppgs)>0:
            tpr_action_item_df = acting_item_filter_tpr_module_1yr(model_df_1,ppg,slct_acting_ppgs,
                                                                   model_correlation_feature_shortlist)
            if tpr_action_item_df is not None:
                temp_2 = temp_2.merge(tpr_action_item_df, how="left", on="Date")                
                tpr_action_items = tpr_action_item_df.columns.to_list()[1:]
                tpr_action_items = [re.sub("_PromotedDiscount","",k) for k in tpr_action_items]
                pt = model_df_2.loc[model_df_2["PPG_Item_No"].isin(tpr_action_items), ["PPG_Item_No", "Date", "tpr_discount_byppg"]]
                pt = pt.pivot_table(values="tpr_discount_byppg", index="Date", columns="PPG_Item_No",fill_value=0, dropna=False)
                pt.columns = [k+"_PromotedDiscount" for k in pt.columns]
                pt.reset_index(inplace=True)
                temp_2b = temp_2b.merge(pt, how="left", on="Date")
                

        # Extracting the EDLP & TPR Interactions
        RP_Interaction = InteractionVars_RP.loc[InteractionVars_RP["BasePPG"]==ppg,"InteractionPPG"]
        RP_Interaction = RP_Interaction.to_list()
        TPR_Interaction = InteractionVars_TPR.loc[InteractionVars_TPR["BasePPG"]==ppg,"InteractionPPG"]
        TPR_Interaction = TPR_Interaction.to_list()
        TotalInteraction = [var + "_RegularPrice" for var in RP_Interaction] + [var + "_PromotedDiscount" for var in TPR_Interaction]        
        # TotalInteraction = [] TotalInteraction[regexpr("_",TotalInteraction)>1]
        
        # Model Data Preparation
        temporary_df = temp_2[["Date","DV","tpr_discount_byppg"]].rename(columns={"tpr_discount_byppg": "tpr_temp"})
        temporary_df = temporary_df.set_index("Date")        
        # Remove initial weeks where ACV is zero
        acv_min_date = temp_2.loc[temp_2["ACV_Selling"]>0,"Date"].min()
        temp_2 = temp_2[~((temp_2["ACV_Selling"]==0) & (temp_2["Date"]<acv_min_date))]
        temp_2b = temp_2b[~((temp_2b["ACV_Selling"]==0) & (temp_2b["Date"]<acv_min_date))]
        
        temp_2 = temp_2[temp_2["Missing_data_flag"]!=1]
        temp_2b = temp_2b[temp_2b["Missing_data_flag"]!=1]
        temp_2 = temp_2.drop(columns=["Missing_data_flag"])
        temp_2b = temp_2b.drop(columns=["Missing_data_flag"])
        model_ppg_1 = model_ppg_1.drop(columns=["Missing_data_flag"])
        model_ppg_2 = model_ppg_2.drop(columns=["Missing_data_flag"])
        model_base_df_1 = model_base_df_1.drop(columns=["Missing_data_flag"])
        model_base_df_2 = model_base_df_2.drop(columns=["Missing_data_flag"])
        
        # TODO - Why this is combined into single piece?
        # Set median price wt low variance to 0 
        if model_base_df_1.loc[model_base_df_1["tpr_discount_byppg"]==0,"wk_sold_avg_price_byppg"].var()<0.001:
            temp_2["wk_sold_median_base_price_byppg_log"] = 0
        # if model_base_df_2.loc[model_base_df_1["tpr_discount_byppg"]==0,"wk_sold_avg_price_byppg"].var()<0.001:
            temp_2b["wk_sold_median_base_price_byppg_log"] = 0
        
        # Set ACV selling wt low variance to 0
        if temp_2["ACV_Selling"].var()<0.001:
            temp_2["ACV_Selling"] = 0
        # if temp_2b["ACV_Selling"].var()<0.001:
            temp_2["ACV_Selling"] = 0
            
        # Fix Low and High limits for the model variables        
        temp_cols = temp_2.drop(columns=["Date","PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description","DV"]).columns.to_list()
        rp_col_cnt = temp_2.columns.str.contains("_RegularPrice").sum()
        tpr_col_cnt = temp_2.columns.str.contains("_PromotedDiscount").sum()        
        lwr_bound = [-np.inf] + [0]*5 + [-np.inf]*4 + [-np.inf]*2 + [-np.inf] + [0]*rp_col_cnt + [-np.inf]*tpr_col_cnt
        upr_bound = [0] + [np.inf]*5 + [np.inf]*4 + [0]*2 + [np.inf] + [np.inf]*rp_col_cnt + [0]*tpr_col_cnt
        # wk_sold_median_base_price_byppg_log   < -Inf to 0                  
        # tpr_discount_byppg,ACV_Metrics        <    0 to Inf       
        # flag_qtrs & "category_trend"          < -Inf to Inf
        # tpr_discount_byppg_lag1 & lag2        < -Inf to 0
        # monthno                               < -Inf to Inf
    
        # Model Function call
        for seed in seeds:
            mdl_lst =  model_func(model_df_1,model_df_2,temp_2,temp_2b,ppg,seed,
                                   RP_Interaction,TPR_Interaction,TotalInteraction,
                                   temp_cols,model_coefficients_final,lwr_bound,upr_bound)
            model = mdl_lst[0]
            box_matrix = mdl_lst[1]
    
            # TODO - Choose alphas within 1 Std error 
            # model_lambda = model.alpha_
            model_coefficients = pd.DataFrame({"model_coefficient_name": box_matrix.columns.to_list(),
                                               "model_coefficient_value": model.coef_})
            model_coefficients = model_coefficients.append({"model_coefficient_name": "(Intercept)","model_coefficient_value": model.intercept_}, ignore_index=True)    
            model_coefficients = model_coefficients[model_coefficients["model_coefficient_value"].abs()>0]
            model_coefficients_check = model_coefficients_check.append(model_coefficients, ignore_index=True)
            train_set_prediction = pd.DataFrame({"PPG_Item_No": [ppg]*len(box_matrix),
                                                 "Date": temp_2["Date"],
                                                 "Prediction": np.exp(model.predict(box_matrix))})
            train_set_rsq = r2_score(np.exp(temp_2["DV"]),train_set_prediction["Prediction"])
            train_set_MAPE = mean_absolute_error(np.array([1]*len(temp_2["DV"])),train_set_prediction["Prediction"]/np.exp(temp_2["DV"]))
            model_results = model_coefficients.copy()
            model_results["PPG"] = ppg
            model_results["R_Square"] = train_set_rsq
            model_results["train_MAPE"] = train_set_MAPE
            model_results["seed"] = seed            
            # Append the results
            model_results_seed = model_results_seed.append(model_results, ignore_index=True)
            
        # Extract features which turned out >15 times out of 20 Seeds
        model_coefficients_Acting = model_coefficients_check.groupby(by=["model_coefficient_name"], as_index=False).agg({"model_coefficient_value": len}).rename(columns={"model_coefficient_value": "cnt"})
        model_coefficients_final = model_coefficients_Acting[(model_coefficients_Acting["cnt"]>15) & (model_coefficients_Acting["model_coefficient_name"]!="(Intercept)")]["model_coefficient_name"].to_list()
        
        # if len(model_coefficients_final)<2:
        #    ppg_wo_features.append(ppg)
            
        actionppg = [col for col in model_coefficients_final if ppg not in col]
        
        # Create dataset for the final model with consistent features
        own_effects_cols = ["Date","PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description","DV",
                            "wk_sold_median_base_price_byppg_log",                     
                            "tpr_discount_byppg","ACV_Feat_Only","ACV_Disp_Only",                                           
                            "ACV_Feat_Disp","ACV_Selling","flag_qtr2","flag_qtr3",                                               
                            "flag_qtr4","category_trend","tpr_discount_byppg_lag1",                                 
                            "tpr_discount_byppg_lag2","monthno"]
        own_effects_coeff = ["wk_sold_median_base_price_byppg_log",                     
                             "tpr_discount_byppg","ACV_Feat_Only","ACV_Disp_Only",                                           
                             "ACV_Feat_Disp","ACV_Selling","flag_qtr2","flag_qtr3",                                               
                             "flag_qtr4","category_trend","tpr_discount_byppg_lag1",                                 
                             "tpr_discount_byppg_lag2","monthno"]
        
        if len(model_coefficients_final)<2 or model_coefficients_final is None:
            temp_2 = temp_2[own_effects_cols]
            temp_2b = temp_2b[own_effects_cols]
            RP_Interaction = []
            TPR_Interaction = []
            TotalInteraction = []
        else:
            actionppg = [col for col in actionppg if col not in own_effects_cols]
            temp_2 = temp_2[own_effects_cols+[col for col in temp_2.columns.to_list() if col in actionppg]]
            temp_2b = temp_2b[own_effects_cols+[col for col in temp_2b.columns.to_list() if col in actionppg]]
        
        seed = 123
        model_coefficients_final = own_effects_coeff+[col for col in model_coefficients_final if col not in own_effects_coeff]
        mdl_lst =  model_func(model_df_1,model_df_2,temp_2,temp_2b,ppg,seed,
                               RP_Interaction,TPR_Interaction,TotalInteraction,
                               temp_cols,model_coefficients_final,lwr_bound,upr_bound)
        
        model = mdl_lst[0]
        box_matrix = mdl_lst[1]    
        box_matrix_opt = mdl_lst[2]          
        # TODO - Choose alphas within 1 Std error 
        # model_lambda = model.alpha_
        model_coefficients = pd.DataFrame({"model_coefficient_name": box_matrix.columns.to_list(),
                                           "model_coefficient_value": model.coef_})
        model_coefficients = model_coefficients.append({"model_coefficient_name": "(Intercept)","model_coefficient_value": model.intercept_}, ignore_index=True)    
        model_coefficients = model_coefficients[model_coefficients["model_coefficient_value"].abs()>0]
        # if len(model_coefficients)<2:
        #    ppg_wt_intercept.append(ppg)
            
        train_set_prediction = pd.DataFrame({"PPG_Item_No": [ppg]*len(box_matrix),
                                             "Date": temp_2["Date"],
                                             "Prediction": np.exp(model.predict(box_matrix))})
        train_set_rsq = r2_score((temp_2["DV"]),np.log(train_set_prediction["Prediction"])) # r2_score(np.exp(temp_2["DV"]),train_set_prediction["Prediction"])
        train_set_MAPE = mean_absolute_error(np.array([1]*len(temp_2["DV"])),train_set_prediction["Prediction"]/np.exp(temp_2["DV"]))
        cv_mse_mean = model.mse_path_[np.where(model.alphas_==model.alpha_)[0]].mean()
        cv_mse_sd = model.mse_path_[np.where(model.alphas_==model.alpha_)[0]].std()
        # cv_mse_mean, cv_mse_sd = model.get_cv_metrics()
        
        box_matrix_opt = mdl_lst[2]          
        model_base_df_1 = model_base_df_1[model_base_df_1["Date"].isin(temp_2["Date"])]
        model_base_df_1["pred_vol"] = np.exp(model.predict(box_matrix))
        model_base_df_1["base_vol"] = np.exp(model.predict(box_matrix))  
        model_base_df_2 = model_base_df_2[model_base_df_2["Date"].isin(temp_2b["Date"])]
        model_base_df_2["pred_vol"] = np.exp(model.predict(box_matrix_opt))
        model_base_df_2["base_vol"] = np.exp(model.predict(box_matrix_opt))
        
        
        # Compute Baseline Volume for Retailer PPGs
        if "_ROM" not in ppg:
            temp_box_matrix = box_matrix.copy().reset_index()
            
            # Set values
            if "wk_sold_median_base_price_byppg_log" in temp_box_matrix.columns:
                temp_box_matrix = temp_box_matrix.merge(model_base_df_1[["Date","Final_baseprice"]].drop_duplicates(), how="left", on="Date")
                # temp_box_matrix = temp_box_matrix.rename(columns={"Final_baseprice_y": "Final_baseprice"}).drop(columns=["Final_baseprice_x"])
                temp_box_matrix["Final_baseprice"] = temp_box_matrix["Final_baseprice"].astype(np.float64)
                temp_box_matrix["wk_sold_median_base_price_byppg_log"] = np.log(temp_box_matrix["Final_baseprice"])
                temp_box_matrix = temp_box_matrix.drop(columns=["Final_baseprice"])
            if "tpr_discount_byppg" in temp_box_matrix.columns:
                temp_box_matrix["tpr_discount_byppg"] = 0
            if temp_box_matrix.columns.str.contains(".*PromotedDiscount.*PromotedDiscount", regex=True).any():
                temp_box_matrix.loc[:,temp_box_matrix.columns.str.contains(".*PromotedDiscount.*PromotedDiscount", regex=True)] = 0                
            if temp_box_matrix.columns.str.contains(".*RegularPrice.*RegularPrice", regex=True).any():
                rp_interaction_cols = [col for col in temp_box_matrix.columns if re.search(".*RegularPrice.*RegularPrice", col) is not None]
                for col in rp_interaction_cols:
                    col_adj = re.sub(ppg, "", col)
                    col_adj = re.sub("_RegularPrice_", "", col_adj)
                    col_adj = re.sub("_RegularPrice", "", col_adj)
                    temp_box_matrix = temp_box_matrix.merge(model_base_df_1.loc[model_base_df_1["PPG_Item_No"]==ppg,["Date","Final_baseprice"]], how="left", on="Date")
                    temp = model_df_1.loc[model_df_1["PPG_Item_No"]==col_adj,["Date","wk_sold_median_base_price_byppg_log"]]
                    temp = temp.rename(columns={"wk_sold_median_base_price_byppg_log": "wk_price_log"})
                    temp_box_matrix = temp_box_matrix.merge(temp[["Date","wk_price_log"]], how="left", on="Date")
                    # if model_coef_prior.loc[model_coef_prior["model_coefficient_name"]==col,"model_coefficient_value"]<0:
                    #    temp_box_matrix[col] = -1*np.log(temp_box_matrix["Final_baseprice"])*temp_box_matrix["wk_price_log"]
                    # else:
                    #    temp_box_matrix[col] = np.log(temp_box_matrix["Final_baseprice"])*temp_box_matrix["wk_price_log"]
                    temp_box_matrix[col] = np.log(temp_box_matrix["Final_baseprice"])*temp_box_matrix["wk_price_log"]
                    temp_box_matrix = temp_box_matrix.drop(columns=["Final_baseprice","wk_price_log"])                        
            if temp_box_matrix.columns.isin(["ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp"]).any():
                 temp_box_matrix[[col for col in temp_box_matrix.columns if col in ["ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp"]]] = 0            
            if "ACV_Selling" in temp_box_matrix.columns:
                temp_box_matrix = temp_box_matrix.merge(model_base_df_1[["Date","ACV_Selling"]].drop_duplicates(), how="left", on="Date")
                temp_box_matrix = temp_box_matrix.rename(columns={"ACV_Selling_y": "ACV_Selling"}).drop(columns=["ACV_Selling_x"])
                
            temp_box_matrix = temp_box_matrix.drop(columns=["Date"])
            base_volume =  pd.DataFrame(np.exp(model.predict(temp_box_matrix[box_matrix.columns])),columns=["Prediction"])   
            model_base_df_1["base_vol"] = base_volume["Prediction"]
                   
        # Compute Baseline Volume for Retailer PPGs - Optimizer Data
        if "_ROM" not in ppg:
            temp_box_matrix_opt = box_matrix_opt.copy().reset_index()
            
            # Set values
            if "wk_sold_median_base_price_byppg_log" in temp_box_matrix_opt.columns:
                temp_box_matrix_opt = temp_box_matrix_opt.merge(model_base_df_2[["Date","Final_baseprice"]].drop_duplicates(), how="left", on="Date")
                # temp_box_matrix_opt = temp_box_matrix_opt.rename(columns={"Final_baseprice_y": "Final_baseprice"}).drop(columns=["Final_baseprice_x"])
                temp_box_matrix_opt["Final_baseprice"] = temp_box_matrix_opt["Final_baseprice"].astype(np.float64)
                temp_box_matrix_opt["wk_sold_median_base_price_byppg_log"] = np.log(temp_box_matrix_opt["Final_baseprice"])
                temp_box_matrix_opt = temp_box_matrix_opt.drop(columns=["Final_baseprice"])
            if "tpr_discount_byppg" in temp_box_matrix_opt.columns:
                temp_box_matrix_opt["tpr_discount_byppg"] = 0
            if temp_box_matrix_opt.columns.str.contains(".*PromotedDiscount.*PromotedDiscount", regex=True).any():
                temp_box_matrix_opt.loc[:,temp_box_matrix_opt.columns.str.contains(".*PromotedDiscount.*PromotedDiscount", regex=True)] = 0                
            if temp_box_matrix_opt.columns.str.contains(".*RegularPrice.*RegularPrice", regex=True).any():
                rp_interaction_cols = [col for col in temp_box_matrix_opt.columns if re.search(".*RegularPrice.*RegularPrice", col) is not None]
                for col in rp_interaction_cols:
                    col_adj = re.sub(ppg, "", col)
                    col_adj = re.sub("_RegularPrice_", "", col_adj)
                    col_adj = re.sub("_RegularPrice", "", col_adj)
                    temp_box_matrix_opt = temp_box_matrix_opt.merge(model_base_df_2.loc[model_base_df_2["PPG_Item_No"]==ppg,["Date","Final_baseprice"]], how="left", on="Date")
                    temp = model_df_2.loc[model_df_2["PPG_Item_No"]==col_adj,["Date","wk_sold_median_base_price_byppg_log"]]
                    temp = temp.rename(columns={"wk_sold_median_base_price_byppg_log": "wk_price_log"})
                    temp_box_matrix_opt = temp_box_matrix_opt.merge(temp[["Date","wk_price_log"]], how="left", on="Date")
                    # if model_coef_prior.loc[model_coef_prior["model_coefficient_name"]==col,"model_coefficient_value"]<0:
                    #    temp_box_matrix_opt[col] = -1*np.log(temp_box_matrix_opt["Final_baseprice"])*temp_box_matrix_opt["wk_price_log"]
                    # else:
                    #    temp_box_matrix_opt[col] = np.log(temp_box_matrix_opt["Final_baseprice"])*temp_box_matrix_opt["wk_price_log"]
                    temp_box_matrix_opt[col] = np.log(temp_box_matrix_opt["Final_baseprice"])*temp_box_matrix_opt["wk_price_log"]
                    temp_box_matrix_opt = temp_box_matrix_opt.drop(columns=["Final_baseprice","wk_price_log"])                                        
            if temp_box_matrix_opt.columns.isin(["ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp"]).any():
                 temp_box_matrix_opt[[col for col in temp_box_matrix_opt.columns if col in ["ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp"]]] = 0            
            if "ACV_Selling" in temp_box_matrix_opt.columns:
                temp_box_matrix_opt = temp_box_matrix_opt.merge(model_base_df_2[["Date","ACV_Selling"]].drop_duplicates(), how="left", on="Date")
                temp_box_matrix_opt = temp_box_matrix_opt.rename(columns={"ACV_Selling_y": "ACV_Selling"}).drop(columns=["ACV_Selling_x"])
                
            temp_box_matrix_opt = temp_box_matrix_opt.drop(columns=["Date"])
            base_volume =  pd.DataFrame(np.exp(model.predict(temp_box_matrix_opt[box_matrix_opt.columns])),columns=["Prediction"])   
            model_base_df_2["base_vol"] = base_volume["Prediction"]

            
        # Compute Cannibalisation Doll. Effects to exclude from gross lift computed
        model_cannibal_df_1 = pd.DataFrame(columns=["Cannibal_PPG","Cannibalised_PPG", "Measure", "Date", "Cannibal_Doll"])
        model_cannibal_df_2 = pd.DataFrame(columns=["Cannibal_PPG","Cannibalised_PPG", "Measure", "Date", "Cannibal_Doll"])
        # if train_set_rsq>cannibalisation_cor_cutoff:
        cannibal_ppg = model_coefficients[model_coefficients["model_coefficient_name"].str.contains("^(ITEM([0-9]|[a-z]|[A-Z])+)|([0-9]+)\\_Retailer")]["model_coefficient_name"]
        cannibal_ppg = cannibal_ppg[~cannibal_ppg.str.contains("\\_ROM")].to_list() 
        cannibal_ppg = [col for col in cannibal_ppg if re.sub("(\\_RegularPrice)|(\\_PromotedDiscount)","",col) in ppg_list_to_model]
        
        model_coefficients_check_pantry = model_coefficients[(model_coefficients["model_coefficient_name"].isin(["tpr_discount_byppg_lag1","tpr_discount_byppg_lag2"])) & (model_coefficients["model_coefficient_value"]<0)]
        model_cannibal_df_1 = cannibalisation_module(ppg, model, box_matrix, model_df_1, 
                                                     cannibal_ppg, model_coefficients_check_pantry)
        model_cannibal_df_2 = cannibalisation_module(ppg, model, box_matrix_opt, model_df_2, 
                                                     cannibal_ppg, model_coefficients_check_pantry)
                
        # Cannibalisation Data Set
        model_cannibal_df_1 = model_cannibal_df_1[model_cannibal_df_1["Cannibal_Doll"]>0]
        if len(model_cannibal_df_1)>0:
            glbl_model_cannibal_df_1 = glbl_model_cannibal_df_1.append(model_cannibal_df_1, ignore_index=True)
        model_cannibal_df_2 = model_cannibal_df_2[model_cannibal_df_2["Cannibal_Doll"]>0]
        if len(model_cannibal_df_2)>0:
            glbl_model_cannibal_df_2 = glbl_model_cannibal_df_2.append(model_cannibal_df_2, ignore_index=True)
            
        # Model Baseline Data Set
        glbl_model_base_df_1 = glbl_model_base_df_1.append(model_base_df_1, ignore_index=True)
        glbl_model_base_df_2 = glbl_model_base_df_2.append(model_base_df_2, ignore_index=True)
        
        # TODO - Not so clear
        # model_coefficients = model_coefficients.append(pd.DataFrame({"model_coefficient_name": "(Intercept)","model_coefficient_value":1}))
        model_coefficients["dummy"] = 1
        temp_4 = temp_2[["PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description"]].drop_duplicates().reset_index(drop=True)
        temp_4["model_RSq"] = train_set_rsq
        temp_4["TrainMAPE"] = train_set_MAPE
        temp_4["model_CVErrorMean"] = cv_mse_mean
        temp_4["model_CVErrorSD"] = cv_mse_sd
        
        temp_4["dummy"] = 1
        temp_5 = temp_4.merge(model_coefficients, how="left", on="dummy")
        temp_5 = temp_5.drop(columns="dummy")
        model_results_final = model_results_final.append(temp_5, ignore_index=True)        
        # print(ppg)
        # print(temp_4[["model_RSq","TrainMAPE","model_CVErrorMean","model_CVErrorSD"]])
        # print(temp_5.iloc[:,[-2,-1]])
        # print(model_base_df_1.mean())
        # print(model_base_df_2.mean())
        # print(model_cannibal_df_1.mean())
        # print(model_cannibal_df_2.mean())        
        # pdb.set_trace()
        # continue

        Filter_PPG_Summary["model_RSq"] = Filter_PPG_Summary.apply(lambda x: train_set_rsq if x["PPG_Item_No"]==ppg else x["model_RSq"], axis=1)
        Filter_PPG_Summary["TrainMAPE"] = Filter_PPG_Summary.apply(lambda x: train_set_MAPE if x["PPG_Item_No"]==ppg else x["TrainMAPE"], axis=1)
    
        # Cross-Validation        
        cv_lwr_bound = mdl_lst[3]	
        cv_upr_bound = mdl_lst[4]	
        model_results_cv1 = cross_validation(ppg, box_matrix, temp_2, temporary_df, cv_lwr_bound, cv_upr_bound)
        model_results_cv = model_results_cv.append(model_results_cv1, ignore_index=True)
                
    model_end_time = datetime.now()
    # model_results_final = model_results.copy()
      
    # Filter_PPG_Summary.loc[Filter_PPG_Summary["Reason"].isna(),"Reason"] = "PPGs Considered for Modelling"
    # Revised_Filtered_PPG = Filter_PPG_Summary.merge(model_results_final[["PPG_MFG","PPG_Item_No","model_RSq","TrainMAPE"]].drop_duplicates(),
    #                                                 how="left", on=["PPG_Item_No","PPG_MFG"])
    glbl_model_base_df_1["Model_flag"] = 1
    glbl_model_base_df_2["Model_flag"] = 1
    glbl_model_cannibal_df_1["Model_flag"] = 1 
    glbl_model_cannibal_df_2["Model_flag"] = 1
    model_results_final["Model_flag"] = 1
    model_results_seed["Model_flag"] = 1
    model_results_cv["Model_flag"] = 1
    Filter_PPG_Summary["Model_flag"] = Filter_PPG_Summary.apply(lambda x: 1 if (x["PPG_Item_No"] in model_df_1["PPG_Item_No"]) and (x["Reason"]!="PPGs Considered for Modelling") else x["Model_flag"], axis=1)

    model_results_final.to_pickle(model_est_dat_filename+".pkl")
    model_results_final["Retailer"] = Retailer
    model_results_final["Market"] = model_results_final["PPG_Item_No"].apply(lambda x: "Retailer" if ("Retailer" in x) else "ROM")
    model_results_final.to_pickle(model_est_dat_filename+"_Optimizer.pkl")
    model_results_final.to_csv(model_est_dat_filename+"_final.csv", index=False)
    model_results_seed.to_csv(model_est_dat_filename+"_seeds.csv", index=False)
    model_results_cv.to_csv(model_est_dat_filename+"_cross_validation.csv", index=False)
    Filter_PPG_Summary.to_csv(filtered_ppg_filename_revised, index=False)

    glbl_model_base_df_1.to_pickle(baselines_dat_filename+".pkl")
    glbl_model_base_df_2.to_pickle(baselines_dat_filename+"_Optimizer.pkl")
    glbl_model_cannibal_df_1.to_pickle(cannibal_dat_filename+".pkl")
    glbl_model_cannibal_df_2.to_pickle(cannibal_dat_filename+"_Optimizer.pkl")

    fn_end_time = datetime.now()
    total_model_time = (model_end_time-model_start_time).total_seconds()
    total_fn_time = (fn_end_time-fn_start_time).total_seconds()
    print("{} PPGs taken {:02d}:{:02d}:{:02d} to build models".format(len(ppg_list_to_model),int(total_model_time//3600), int((total_model_time%3600)//60), int(total_model_time%60)))
    print("Overall time taken:  {:02d}:{:02d}:{:02d}".format(int(total_fn_time//3600), int((total_fn_time%3600)//60), int(total_fn_time%60)))
    return True