#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import numpy as np
import pandas as pd
pd.options.mode.chained_assignment = None  

base_dir = "/home/srinathbala/Documents/NPP/npp-tpo"
code_path = os.path.join(base_dir)
data_path = os.path.join(base_dir,"Data")
os.chdir(code_path)

from data_preparation import prepare_data
from price_elasticity_input import Price_Elasticity_ip_fn
from price_elasticity_modelling_2yr import Model_data_filtering_2yr, Model_building_2yr_Lasso, Model_building_2yr_Bayesian
from price_elasticity_modelling_1yr import Model_data_filtering_1yr, Model_building_1yr
# from price_elasticity_modelling_less_than_1yr import Model_data_filtering_less_than_1yr, Model_building_less_than_1yr
from dashboard_dataset_input import Dashboard_dataset_ip_fn
from dashboard_dataset_creation import model_coeff_transform_fn, base_transform_fn
from my_utils import binding_op_files
from support_files_creation import preprocess_sample_data

# TODO - Some issue in setting variables global with import function - temporary fix 
exec(open("price_elasticity_input.py").read())
exec(open("dashboard_dataset_input.py").read())

# TODO: Load input files
input_lst = preprocess_sample_data()
data_pull_from_server = input_lst[0]
Acting_Item_ppg = input_lst[1]
ip_retailer_mapping = input_lst[2]
ip_ROM_mapping = input_lst[3]
ip_Excluded_Market_Descriptions = input_lst[4]
ip_category_mapping = input_lst[5]

# Create set of retailers & categories for modelling
# Retailer
ip_retailer_mapping = ip_retailer_mapping[ip_retailer_mapping["Process_flag"]==1]
ip_retailer_mapping = ip_retailer_mapping.drop(columns = ["Process_flag"])
ip_ROM_mapping = ip_ROM_mapping[ip_ROM_mapping["Process_flag"]==1]
ip_ROM_mapping = ip_ROM_mapping.drop(columns = ["Process_flag"])
slct_mkt_desc = ip_retailer_mapping.merge(ip_ROM_mapping.rename(columns={"ROM.Name": "Retailer.Name"}), how = "inner", on ="Retailer.Name")
slct_mkt_desc = slct_mkt_desc[["Retailer.Name", "MarketDescription_x", "MarketDescription_y"]]
slct_mkt_desc = slct_mkt_desc.rename(columns = {"Retailer.Name": "Retailer_Name","MarketDescription_x": "Retailer", "MarketDescription_y": "ROM"})

# Category
ip_category_mapping = ip_category_mapping[ip_category_mapping["Process_flag"]==1]
ip_category_mapping = ip_category_mapping.drop(columns = ["Process_flag"])
slct_category = ip_category_mapping[["PPG_Category"]].drop_duplicates()
# TODO - Check it is needed becaused it is just printed
# slct_category["Sub_category"] = ""

# TODO: Set date range
date_range = {"start_dt": ["2017-01-01","2017-04-01","2017-07-01","2017-10-01","2018-01-01"],
              "end_dt": ["2019-01-01","2019-04-01","2019-07-01","2019-10-01","2020-01-01"]}
date_range_df = pd.DataFrame(date_range)
Start_date = "2016-10-01"
End_date = "2019-12-31"

retailer_list = slct_mkt_desc["Retailer_Name"].to_list()
features_count = 3

os.chdir(code_path)
output_path_1 = os.path.join(code_path,"Data_Prep_OP")
for retailer in retailer_list:    
    if not os.path.exists(output_path_1):
        os.mkdir(output_path_1)        
        
    output_path_2 = os.path.join(output_path_1,retailer)
    if not os.path.exists(output_path_2):
        os.mkdir(output_path_2)
    os.chdir(output_path_2)
    
    retailer_mkt_desc = slct_mkt_desc.loc[slct_mkt_desc["Retailer_Name"]==retailer, "Retailer"].to_list()[0]   
    ROM_mkt_desc = slct_mkt_desc.loc[slct_mkt_desc["Retailer_Name"]==retailer, "ROM"].to_list()[0]    
    category_list = ["Category1"]  # ["LITTER","CAT_TREATS","DOG_TREATS","WET_CAT","WET_DOG","DRY_CAT","DRY_DOG"]
    for cat in category_list:  
        output_path_3 = os.path.join(output_path_2,cat)
        if not os.path.exists(output_path_3):
            os.mkdir(output_path_3)
        os.chdir(output_path_3)
    
        # Function call 1 : DB Data Fetching & Cleaning
        prepare_data(retailer_mkt_desc, ROM_mkt_desc, cat, Acting_Item_ppg, ip_retailer_mapping, ip_ROM_mapping, ip_Excluded_Market_Descriptions, ip_category_mapping, data_path)
        print("Data Preparation is done")
                
        Model_Year_Flag = 2
        model_name_flag = "L"
        model_name = "Lasso Model"
        for k in np.arange(0,5):
            Model_Start_Date = date_range_df.iloc[k,0]
            Model_End_Date = date_range_df.iloc[k,1]
            print("Start dt: {}, End dt: {}".format(Model_Start_Date, Model_End_Date))
    
            # Function call 2: Inputs for 2 yr PPG Model
            Price_Elasticity_ip_fn(retailer, cat, Model_Year_Flag, model_name_flag, model_name, Model_Start_Date, Model_End_Date)
            print("Inputs are defined for 2year model")

            Total_weeks = pd.DataFrame(pd.date_range("2016-10-01","2019-12-31",freq="7D",name="Date"))
            
            # Function call 3 : Data filtering for 2 yr PPG Model
            os.chdir(output_path_3)
            Model_data_filtering_2yr(cat,
                                      merged_ustotal_ppg_ip_filename,
                                      min_revenue_threshold,
                                      min_prct_data_points,
                                      sd_by_mean_avg_price_threshold,
                                      sd_by_mean_sales_vol_threshold,
                                      filtered_model_dataset_filename,
                                      Retailer_ACV_CUTOFF,
                                      ROM_ACV_CUTOFF,
                                      filtered_ppg_filename,retailer,Total_weeks,Model_Start_Date,Model_End_Date)
            print("Model data filtering for 2 yr PPGs are done")

            
            # Function call 4 : 2 yr PPG Lasso Model building
            model_results = Model_building_2yr_Lasso(cat,
                                                      filtered_model_dataset_filename,
                                                      model_correlation_feature_shortlist,
                                                      model_correlation_price_trend_cutoff,
                                                      model_correlation_feature_shortlist_tpr,
                                                      model_regularization_parameter,
                                                      cannibalisation_cor_cutoff,
                                                      cannibal_dat_filename,
                                                      baselines_dat_filename,
                                                      model_est_dat_filename,
                                                      min_interaction_rp_cutoff,
                                                      max_interaction_rp_cutoff,
                                                      ActingItem_list,
                                                      filtered_ppg_filename,
                                                      filtered_ppg_filename_revised,retailer,
                                                      output_path_3)
            print("Model building for 2 yr PPGs are done")

                        

        Model_Year_Flag = 2
        model_name_flag = "B"
        model_name = "Bayesian"                
        Model_Start_Date = date_range_df.iloc[4,0]
        Model_End_Date = date_range_df.iloc[4,1]                
        Price_Elasticity_ip_fn(retailer, cat, Model_Year_Flag, model_name_flag, model_name)
        print("Inputs are defined for 2year model")
    
        os.chdir(output_path_3)
        Total_weeks = pd.DataFrame(pd.date_range(Start_date, End_date, freq="7D", name="Date"))
        # Function call 5: Data filtering for 2 yr PPG Model Bayesian####
        Model_data_filtering_2yr(cat,
                                  merged_ustotal_ppg_ip_filename,
                                  min_revenue_threshold,
                                  min_prct_data_points,
                                  sd_by_mean_avg_price_threshold,
                                  sd_by_mean_sales_vol_threshold,
                                  filtered_model_dataset_filename,
                                  Retailer_ACV_CUTOFF,
                                  ROM_ACV_CUTOFF,
                                  filtered_ppg_filename,retailer,Total_weeks,Model_Start_Date,Model_End_Date)
        print("Bayesian model data filtering for 2 yr PPGs are done")        

        # Function call 6 : 2 yr PPG Lasso Model building Bayesian ####
        model_results = Model_building_2yr_Bayesian(cat,
                                                      filtered_model_dataset_filename,
                                                      model_correlation_feature_shortlist,
                                                      model_correlation_price_trend_cutoff,
                                                      model_correlation_feature_shortlist_tpr,
                                                      model_regularization_parameter,
                                                      cannibalisation_cor_cutoff,
                                                      cannibal_dat_filename,
                                                      baselines_dat_filename,
                                                      model_est_dat_filename,
                                                      min_interaction_rp_cutoff,
                                                      max_interaction_rp_cutoff,
                                                      ActingItem_list,
                                                      filtered_ppg_filename,
                                                      filtered_ppg_filename_revised,retailer,output_path_3,date_range_df,
                                                      features_count, Model_Start_Date, Model_End_Date)
        print("Bayesian model building for 2 yr PPGs are done")

            
        # Function call 7 : Inputs for 1 yr PPG Model ####
        Model_Year_Flag = 1
        Price_Elasticity_ip_fn(retailer, cat, Model_Year_Flag, model_name_flag, model_name)
        print("Inputs are defined for 1 year model")
    
    
        # Function call 8 : Data filtering for 1 yr PPG Model ####
        os.chdir(output_path_3)
        Model_Time_range = ["2018_1","2019_4"]
        Total_weeks = pd.DataFrame(pd.date_range(Start_date, End_date, freq="7D", name="Date"))
        Model_data_filtering_1yr(cat,
                                  merged_ustotal_ppg_ip_filename,
                                  min_revenue_threshold,
                                  min_prct_data_points,
                                  sd_by_mean_avg_price_threshold,
                                  sd_by_mean_sales_vol_threshold,
                                  filtered_model_dataset_filename,
                                  Retailer_ACV_CUTOFF,
                                  ROM_ACV_CUTOFF,
                                  filtered_ppg_filename,retailer,Total_weeks,Model_Start_Date,Model_End_Date, Model_Time_range)    
        print("Model data filtering for 1 yr is done")
        
        
        # Function call 9 : 1 yr PPG Model building ####
        model_results = Model_building_1yr(cat,
                                            filtered_model_dataset_filename,
                                            model_correlation_feature_shortlist,
                                            model_correlation_price_trend_cutoff,
                                            model_correlation_feature_shortlist_tpr,
                                            model_regularization_parameter,
                                            cannibalisation_cor_cutoff,
                                            cannibal_dat_filename,baselines_dat_filename,
                                            model_est_dat_filename,
                                            min_interaction_rp_cutoff,max_interaction_rp_cutoff,
                                            ActingItem_list,filtered_ppg_filename,
                                            filtered_ppg_filename_revised,retailer,output_path_3)        
        print("Model building for 1 yr PPGs are done")
        
        # Function call 10 : Inputs for less than 1 yr PPG Model ####
        Model_Year_Flag = 0
        # Price_Elasticity_ip_fn(retailer, cat, Model_Year_Flag, model_name_flag, model_name)
        print("Inputs are defined for less than 1 year model")
    
    
        # Function call 11 : Data filtering for less than 1 yr PPG Model ####
        os.chdir(output_path_3)
        Model_Time_range = ["2018-01-01", "2019-12-31"]     
        Total_weeks = pd.DataFrame(pd.date_range(Start_date, End_date, freq="7D", name="Date"))
        # Model_data_filtering_less_than_1yr(cat,
        #                           merged_ustotal_ppg_ip_filename,
        #                           min_revenue_threshold,
        #                           min_prct_data_points,
        #                           sd_by_mean_avg_price_threshold,
        #                           sd_by_mean_sales_vol_threshold,
        #                           filtered_model_dataset_filename,
        #                           Retailer_ACV_CUTOFF,
        #                           ROM_ACV_CUTOFF,
        #                           filtered_ppg_filename,retailer,Total_weeks,Model_Start_Date,Model_End_Date, Model_Time_range)
        print("Model data filtering for less than 1 yr is done")
        
        # Function call 12 : Less than 1 yr PPG Model building ####
        # model_results = Model_building_less_than_1yr(cat,
        #                                     filtered_model_dataset_filename,
        #                                     model_correlation_feature_shortlist,
        #                                     model_correlation_price_trend_cutoff,
        #                                     model_correlation_feature_shortlist_tpr,
        #                                     model_regularization_parameter,
        #                                     cannibalisation_cor_cutoff,
        #                                     cannibal_dat_filename,baselines_dat_filename,
        #                                     model_est_dat_filename,
        #                                     min_interaction_rp_cutoff,max_interaction_rp_cutoff,
        #                                     ActingItem_list,filtered_ppg_filename,
        #                                     filtered_ppg_filename_revised,retailer,output_path_3)
        print("Model building for less than 1 yr PPGs are done")
        
        # Function call 13 : Combine Output Files
        Price_Elasticity_ip_fn(retailer, cat, Model_Year_Flag=-1, model_name_flag="", model_name="")
        binding_op_files(cannibal_dat_filename, baselines_dat_filename, model_est_dat_filename,
                         cannibal_dat_filename_all, baselines_dat_filename_all, model_est_dat_filename_all,
                         base_dir1, include_2yr_flag=True, include_1yr_flag=True, include_less_than_1yr_flag=False)
        
        # Function call 14 : Inputs for Dashboard dataset preparation
        os.chdir(output_path_3)
        File_type = "General"
        Dashboard_dataset_ip_fn(retailer,cat,File_type)
        print("Input files are defined for Dashboard dataset preparation")
        
    
        # Function call 15 : Model Coeff transform
        os.chdir(output_path_3)
        model_coeff_transform_fn(model_est_filename,
                                 model_est_transformed_op_filename,
                                 MappingFile_Description_path,
                                 comp_prd_dat_filename,
                                 scenarioplannining_cannibalisation_working_filename,
                                 retailer, cat, output_path_3)
        print("Model coeff transform files created")
        
        
        # Function call 16 : Base transform fn #####
        base_transform_fn(base_dat_filename,raw_dat_filename,
                          MappingFile_Description_path, cannibal_dat_filename,
                          scenarioplannining_cannibalisation_working_filename,
                          cannibal_dat_op_filename, 
                          base_transform_op_filename, base_transform_op_filename2,
                          Filtered_PPGs, price_agg_op_filename,
                          retailer,cat,output_path_3,File_type)   
        print("Base transform files created")
        
        
        # Function call 17 : Optimizer Input for Dashboard dataset preparation ####
        File_type = "Optimizer"
        Dashboard_dataset_ip_fn(retailer,cat,File_type)
        print("Optimizer Input files are defined for Dashboard dataset preparation")
        
        
        # Function call 18 : Optimizer Model Coeff transform ####
        os.chdir(output_path_3)
        model_coeff_transform_fn(model_est_filename,
                                 model_est_transformed_op_filename,
                                 MappingFile_Description_path,
                                 comp_prd_dat_filename,
                                 scenarioplannining_cannibalisation_working_filename,
                                 retailer, cat, output_path_3)
        print("Optimizer Model coeff transform files created")
        
        
        # Function call 19 : Optimizer Base transform fn #####
        os.chdir(output_path_3)
        base_transform_fn(base_dat_filename, raw_dat_filename,
                          MappingFile_Description_path, cannibal_dat_filename,
                          scenarioplannining_cannibalisation_working_filename,
                          cannibal_dat_op_filename, 
                          base_transform_op_filename, base_transform_op_filename2,
                          Filtered_PPGs, price_agg_op_filename,
                          retailer, cat,output_path_3,File_type)    
        print("Optimizer Base transform files created")
        
        
        # TODO - Yet to add optimizer module
        # Function call 20 : Min max spend & Solver Ip file creation ####
        processed_op_dir = output_path_3 + "/" + "Output Files/"
        year = "2019"
        # Min_Max_Spend_N_Solver_ip_creation(Retailer,Category,processed_op_dir,year)
        # print(paste0("Output files created for ",Retailer,"-",Category," in : ",hms_span(Category_time,Sys.time())))       