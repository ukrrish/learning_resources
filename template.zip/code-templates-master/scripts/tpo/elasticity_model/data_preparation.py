#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re
import sys
import pandas as pd
import numpy as np
import datetime 
import calendar
import pdb
from support_files_creation import preprocess_sample_data

def get_quarter_start_dt(quarter, year):
    """Get first saturday of the quarter"""

    temp = datetime.datetime(year,(quarter-1)*3+1,1)    
    while temp.weekday() != 5:
        temp = temp + datetime.timedelta(days=1)
        
    return(temp.strftime("%Y-%m-%d"))
    
    
def get_quarter_end_dt(quarter, year):
    """Get last saturday of the quarter"""

    last_dt = calendar.monthrange(year,quarter*3)[1]
    temp = datetime.datetime(year,quarter*3,last_dt)    
    while temp.weekday() != 5:
        temp = temp + datetime.timedelta(days=-1)
        
    return(temp.strftime("%Y-%m-%d"))
        

def select_date_range(df,qtrs_cnt):
    """dfdf
    """
    
    min_dt = pd.DatetimeIndex(df["WeekEndDt"]).min()
    min_qtr = min_dt.quarter
    min_yr = min_dt.year    
    first_saturday =  get_quarter_end_dt(min_qtr, min_yr)
    if first_saturday == min_dt:
        start_dt = min_dt
    elif min_qtr == 4:
        start_dt = get_quarter_end_dt(1, min_yr+1)
    else:
        start_dt = get_quarter_end_dt(min_qtr+1, min_yr)
    print("Actual End Date: {}".format(start_dt))
    
    max_dt = pd.DatetimeIndex(df["WeekEndDt"]).max()
    max_qtr = max_dt.quarter
    max_yr = max_dt.year    
    last_saturday =  get_quarter_end_dt(max_qtr, max_yr)
    if last_saturday == max_dt:
        end_dt = max_dt
    elif max_qtr == 1:
        end_dt = get_quarter_end_dt(4, max_yr-1)
    else:
        end_dt = get_quarter_end_dt(max_qtr-1, max_yr)
    print("Actual End Date: {}".format(end_dt))
  
    df["Date"] = pd.DatetimeIndex(df["WeekEndDt"])
    df = df.sort_values(by=["Date"])
    df = df[df.Date>=start_dt & df.Date<=end_dt]
    df["Quarter"] =  df["Date"].quarter
    df["Year"] = df["Date"].year
    df["Rank"] = df[["Year","Quarter"]].rank(method="dense")
    df = df[df.Rank > (max(df.Rank)-qtrs_cnt)]  
    
    # TODO: Set Start and End Date as Global Variable      
    start_dt = df["Date"].min()
    end_dt = df["Date"].max()
    print("Updated Start Date: {}".format(start_dt))
    print("Updated Dnd Date: {}".format(end_dt))

    
def validate_data(df, ip_retailer_mapping, ip_ROM_mapping, ip_Excluded_Market_Descriptions, ip_category_mapping):
    """Checks for new Retailers-ROM/Categories in data"""
    
    # TODO: Set Global Variables
    tmp_df = df[~df["MarketDescription"].isin(ip_retailer_mapping["MarketDescription"])]
    tmp_df = tmp_df[~tmp_df["MarketDescription"].isin(ip_ROM_mapping["MarketDescription"])]
    tmp_df = tmp_df[~tmp_df["MarketDescription"].isin(ip_Excluded_Market_Descriptions["Excluded.MarketDescription"])] 
    if tmp_df.shape[0] != 0:
        sys.exit("New Market descriptions are found, Update Input file list to proceed further")
        
    df["Key"] = df["CATEGORY"] + df["SUBCATEGORY"]
    ip_category_mapping["Key"] = ip_category_mapping["category"] + ip_category_mapping["subcategory"]
    tmp_df = df[~df["Key"].isin(ip_category_mapping["Key"])]
    if tmp_df.shape[0]!=0:
        sys.exit("New Category & Subcategory records are found, Update Input file list to proceed further")
    ip_category_mapping.drop(columns=["Key"])
    
    
def prepare_data(Retailer, ROM, Category_list, Acting_Item_ppg, ip_retailer_mapping, ip_ROM_mapping, ip_Excluded_Market_Descriptions, ip_category_mapping, data_path=""):
    """ Converting UPC level data into PPG level data"""
    
    # TODO: Get Data from Server
    # df = pd.read_excel("/home/srinathbala/Documents/NPP/Data/FAREWAY_data_2019.xlsx")
    df = preprocess_sample_data(data_path)[0]
    df.fillna(value={"BRAND GROUP(C)": "A/O Brand"})
    
    # Keep PPGs present in the mapping table
    ip_category_mapping.rename(columns={"PPG_Category": "PPG_CATEGORY"}, inplace=True)
    df = df.merge(ip_category_mapping, left_on=["CATEGORY","SUBCATEGORY"], right_on=["category","subcategory"])
    df = df.dropna(subset = ["PPG_CATEGORY"])
    df = df[df["PPG_CATEGORY"]!="NA"]    
    df["PPG_Category"] = df["PPG_CATEGORY"]
    df = df.drop(columns=["PPG_CATEGORY"])
    
    df["Product_UPC"] = df["Product_UPC"].astype("int64")
    df_wt_na = df[df["PPGName"].isna()]
    df_wo_na = df[df["PPGName"].notna()]
    
    upc_df = df[["ITEM","PPGName"]].drop_duplicates()
    upc_df = upc_df.dropna(subset = ["PPGName"])
    upc_df.rename(columns={"PPGName": "PPGName_NEW"}, inplace=True)
    df_wt_na = df_wt_na.merge(upc_df, how="left", on=["ITEM"])
    df_wt_na["PPGName"] = df_wt_na["PPGName_NEW"]
    df_wt_na = df_wt_na.drop(columns=["PPGName_NEW"])
    df_imputed = pd.concat([df_wo_na,df_wt_na], ignore_index=True)

    # Retailer & ROM Data Consolidatio
    df_retailer = df_imputed[df_imputed["MarketDescription"].isin([Retailer])]
    if df_retailer.shape[0]==0:
        sys.exit("No records available for the selected retailer")
    df_retailer_agg = df_retailer.groupby(by = ["Product_UPC"], as_index=False).agg({"Dollars": np.sum, "Units":np.sum})    
    df_retailer_agg = df_retailer_agg[df_retailer_agg["Dollars"]>0]
    df_retailer_wt_sales = df_retailer[df_retailer["Product_UPC"].isin(df_retailer_agg["Product_UPC"].to_list())]
    df_retailer_wt_sales["PPG_Retailer"] = "Retailer"
    
    df_ROM = df_imputed[df_imputed["MarketDescription"].isin([ROM])]
    if df_ROM.shape[0]==0:
        sys.exit("No records available for the selected ROM")
    df_ROM_agg = df_ROM.groupby(by = ["Product_UPC"], as_index=False).agg({"Dollars": np.sum, "Units":np.sum})    
    df_ROM_agg = df_ROM_agg[df_ROM_agg["Units"]>0]
    df_ROM_wt_sales = df_ROM[df_ROM["Product_UPC"].isin(df_ROM_agg["Product_UPC"])]
    df_ROM_wt_sales["PPG_Retailer"] = "ROM"
    
    df_RMS = pd.concat([df_retailer_wt_sales,df_ROM_wt_sales])
    df_RMS.rename(columns={"Product_UPC": "Item Number"}, inplace=True)
    print("RMS Data - Part 1 Created")
    
    # PPG Mapping File Creation
    ppg_mapping = df_imputed[["PPGName","PPG_Category"]].drop_duplicates().sort_values(by=["PPGName"])
    ppg_mapping = ppg_mapping[ppg_mapping["PPGName"].notna() & ppg_mapping["PPG_Category"].notna()]
    if ppg_mapping.shape[0]>0:
        ppg_mapping["PPG_ID"] = (np.arange(len(ppg_mapping))+1)
        print("Mapping File Created")    

        ppg_mapping["PPG_Description"] = "ITEM" + ppg_mapping["PPG_ID"].astype(str) + ppg_mapping["PPGName"]
        ppg_mapping["temp_name"] = ppg_mapping["PPGName"].str.split(pat="[0-9]+",expand=True).iloc[:,0]
        ppg_mapping["temp_name"] = ppg_mapping["temp_name"].str.replace("&", "N", regex=False)
        
        # Handle SPL cases 
        # 1 PPGs starting with numeric char Ex. "9Lives"
        def handle_spl_case_1(name, fmt_name):
            if fmt_name=="" and name[0].isnumeric():
                return(re.split("\\s+",name)[0])
            else:
                return(fmt_name)                                                         
        ppg_mapping["temp_name"] = ppg_mapping.apply(lambda row: handle_spl_case_1(row["PPGName"],row["temp_name"]), axis=1)
        # 2 CAT type Ex. "CT 9Lives"
        def handle_spl_case_2(name, fmt_name):
            if fmt_name=="CT " and name[3].isnumeric():
                return(re.split("\\s+",name)[1])
            else:
                return(fmt_name)                                                         
        ppg_mapping["temp_name"] = ppg_mapping.apply(lambda row: handle_spl_case_2(row["PPGName"],row["temp_name"]), axis=1)             
        if ppg_mapping[ppg_mapping["temp_name"]==""].shape[0]>0:
            sys.exit("Empty PPG names found; Recheck temp_name column")                  
        # 3 Remove all spl chars            
        ppg_mapping["PPG_Item"] = "ITEM" + ppg_mapping["PPG_ID"].astype(str) + ppg_mapping["temp_name"]
        ppg_mapping["PPG_Item"] = ppg_mapping["PPG_Item"].apply(lambda x: re.sub("[^[:alnum:]]","",re.sub("-|_","",re.sub(" ","",x)))) 

        df_RMS_wt_PPG = df_RMS.merge(ppg_mapping[["PPGName","PPG_Description","PPG_Item"]], on="PPGName", how="left")
        df_RMS_wt_PPG["PPG_Description"] = df_RMS_wt_PPG.apply(lambda x: "ITEM"+str(x["Item Number"]) if pd.isnull(x["PPG_Description"]) else x["PPG_Description"], axis=1)
        df_RMS_wt_PPG["PPG_Item"] = df_RMS_wt_PPG.apply(lambda x: "ITEM"+str(x["Item Number"]) if pd.isnull(x["PPG_Item"]) else x["PPG_Item"], axis=1)
        df_RMS_wt_PPG["PPGName"] = df_RMS_wt_PPG.apply(lambda x: x["ITEM"] if pd.isnull(x["PPGName"]) else x["PPGName"], axis=1)        
    else:
        df_RMS_wt_PPG = df_RMS
        df_RMS_wt_PPG["PPG_Description"] = "ITEM" + df_RMS_wt_PPG["Item Number"].astype(str)
        df_RMS_wt_PPG["PPG_Item"] = "ITEM" + df_RMS_wt_PPG["Item Number"].astype(str)
        df_RMS_wt_PPG["PPGName"] = "ITEM" + df_RMS_wt_PPG["ITEM"]
        
    df_RMS_wt_PPG["PPG_MFG"] = df_RMS_wt_PPG.apply(lambda x: "NPP" if x["VENDOR(C)"]=="NPPC" else "Non-NPP", axis=1)
    df_RMS_wt_PPG["PPG_MFG"] = df_RMS_wt_PPG.apply(lambda x: "Non-NPP" if pd.isnull(x["VENDOR(C)"]) else x["PPG_MFG"], axis=1)
    
    # Assign MFG (NPP/Non-NPP) based on sales
    ppg_summary_1 = pd.pivot_table(df_RMS_wt_PPG, values="Dollars", index=["PPG_Item"],columns=["PPG_MFG"], aggfunc=np.sum, fill_value=0, dropna = False).reset_index()
    ppg_summary_1["PPG_MFG_2"] = ppg_summary_1.apply(lambda x: "NPP" if x["NPP"]>=x["Non-NPP"] else "Non-NPP", axis=1)
    df_RMS_wt_PPG = df_RMS_wt_PPG.merge(ppg_summary_1[["PPG_Item","PPG_MFG_2"]], how="left", on="PPG_Item")
    df_RMS_wt_PPG["PPG_MFG"] = df_RMS_wt_PPG["PPG_MFG_2"]
    df_RMS_wt_PPG = df_RMS_wt_PPG.drop(columns=["PPG_MFG_2"])
    df_RMS_wt_PPG.rename(columns={"WeekEndDt": "Date"}, inplace=True)
    
    # Assign Brand based on sales
    ppg_summary_2 = pd.pivot_table(df_RMS_wt_PPG, values="Dollars", index=["PPG_Item"],columns=["BRAND GROUP(C)"], aggfunc=np.sum, fill_value=0, dropna = False).reset_index()
    ppg_summary_2["Fnl_Brand"] = ppg_summary_2.drop(columns="PPG_Item").apply(lambda x: x.idxmax(), axis=1)
    df_RMS_wt_PPG = df_RMS_wt_PPG.merge(ppg_summary_2[["PPG_Item","Fnl_Brand"]], how="left", on="PPG_Item")
    df_RMS_wt_PPG["BRAND GROUP(C)"] = df_RMS_wt_PPG["Fnl_Brand"]
    df_RMS_wt_PPG = df_RMS_wt_PPG.drop(columns=["Fnl_Brand"])    
    
    # PPG Aggegration   
    groupby_cols = ["MarketDescription","PPG_Retailer","PPG_Category","BRAND GROUP(C)","PPG_MFG","PPGName","PPG_Item","Date"]
    df_RMS_wt_PPG_agg = df_RMS_wt_PPG.groupby(by=groupby_cols, as_index=False).agg({"Dollars": np.sum,
                                                                  "Units": np.sum,
                                                                  "BaseDollars": np.sum,
                                                                  "BaseUnits": np.sum,
                                                                  "PCTACV": np.max,
                                                                  "PriceDecrOnlyPctACV": np.max,
                                                                  "FeatwoDispPctACV": np.max,
                                                                  "DispwoFeatPctACV": np.max,
                                                                  "FeatandDispPctACV": np.max})
    df_RMS_wt_PPG_agg.rename(columns= {"Dollars": "wk_sold_doll_byppg",
                                       "Units": "wk_sold_qty_byppg",
                                       "BaseDollars": "wk_sold_doll_base_byppg",
                                       "BaseUnits": "wk_sold_qty_base_byppg",
                                       "PCTACV": "ACV_Selling",
                                       "PriceDecrOnlyPctACV": "ACV_TPR_Only",
                                       "FeatwoDispPctACV": "ACV_Feat_Only",
                                       "DispwoFeatPctACV": "ACV_Disp_Only",
                                       "FeatandDispPctACV": "ACV_Feat_Disp"}, inplace=True)
    
    df_RMS_wt_PPG_agg["wk_sold_doll_byppg"] = df_RMS_wt_PPG_agg["wk_sold_doll_byppg"].apply(lambda x: 0 if x<0 else x)
    df_RMS_wt_PPG_agg["wk_sold_qty_byppg"] = df_RMS_wt_PPG_agg["wk_sold_qty_byppg"].apply(lambda x: 0 if x<0 else x)
    df_RMS_wt_PPG_agg["wk_sold_doll_base_byppg"] = df_RMS_wt_PPG_agg["wk_sold_doll_base_byppg"].apply(lambda x: 0 if x<0 else x)
    df_RMS_wt_PPG_agg["wk_sold_qty_base_byppg"] = df_RMS_wt_PPG_agg["wk_sold_qty_base_byppg"].apply(lambda x: 0 if x<0 else x)
  
    # Calculate Unit Price
    df_RMS_wt_PPG_agg["wk_avg_price_perunit_byppg"] = df_RMS_wt_PPG_agg["wk_sold_doll_byppg"]/df_RMS_wt_PPG_agg["wk_sold_qty_byppg"]
    df_RMS_wt_PPG_agg["wk_avg_price_perunit_byppg"] = df_RMS_wt_PPG_agg["wk_avg_price_perunit_byppg"].apply(lambda x:  np.nan if (x<0 | np.isnan(x) | ~np.isfinite(x)) else x)
    df_RMS_wt_PPG_agg["wk_base_price_perunit_byppg"] = df_RMS_wt_PPG_agg["wk_sold_doll_base_byppg"]/df_RMS_wt_PPG_agg["wk_sold_qty_base_byppg"]
    df_RMS_wt_PPG_agg["wk_base_price_perunit_byppg"] = df_RMS_wt_PPG_agg["wk_base_price_perunit_byppg"].apply(lambda x:  np.nan if (x<0 | np.isnan(x) | ~np.isfinite(x)) else x)
  
    selected_retailer = ip_retailer_mapping[ip_retailer_mapping["MarketDescription"]==Retailer][0:1]
    df_RMS_wt_PPG_agg.to_pickle("RMS_Data_PPG_" + df_RMS_wt_PPG_agg["PPG_Category"][0] + "_" + selected_retailer["Retailer.Name"][0] + ".pkl")
    print("RMS Data part 2 created")
  
    # UPC data
    UPC_file = df_RMS_wt_PPG[["PPG_Item","PPGName","PPG_Category","Item Number","ITEM"]].drop_duplicates()
    UPC_file["Retailer"] = selected_retailer["Retailer.Name"][0]
    UPC_file = UPC_file.merge(df_RMS_wt_PPG_agg[["PPG_Item","BRAND GROUP(C)"]].drop_duplicates(), how="inner", on="PPG_Item")
    UPC_file.to_csv("UPC_file_" + df_RMS_wt_PPG_agg["PPG_Category"][0] + "_" + selected_retailer["Retailer.Name"][0] + ".csv", index=False)

    # RMS Mapping File
    RMS_ppg_mapping = df_RMS_wt_PPG[["PPG_Item","PPG_Description","PPGName","PPG_Category"]].drop_duplicates()
    RMS_ppg_mapping["Retailer"] = ip_retailer_mapping[ip_retailer_mapping["MarketDescription"]==Retailer][0:1]["Retailer.Name"][0]
    RMS_ppg_mapping.to_pickle("RMS_Data_PPG_Mapping_" + RMS_ppg_mapping["PPG_Category"][0] + "_" + selected_retailer["Retailer.Name"][0] + ".pkl")
    print("RMS Mapping file created")
      
    # Acting Item List Creation
    acting_item_ppg = Acting_Item_ppg[Acting_Item_ppg["Category"].isin(RMS_ppg_mapping["PPG_Category"].drop_duplicates())]
    acting_item_ppg = acting_item_ppg.drop_duplicates()
    if acting_item_ppg.shape[0]==0:
        sys.exit("No Acting items found in the selected category recheck the Marysmatrix file")    
  
    RMS_ppg_mapping_tmp = RMS_ppg_mapping.drop_duplicates(subset=["PPG_Item","PPGName","PPG_Category"])
    RMS_ppg_mapping_tmp["PPGName"] = RMS_ppg_mapping_tmp.apply(lambda x: x["PPGName"][2:].strip() if ((x["PPG_Category"] in ["CAT_SNACKS","CAT_TREATS"]) & (x["PPGName"][0:3]=="CT ")) else x["PPGName"], axis=1)      
    acting_item_ppg = acting_item_ppg.merge(RMS_ppg_mapping_tmp[["PPG_Item","PPGName","PPG_Category"]], how="inner", left_on=["Base_PPG","Category"], right_on=["PPGName","PPG_Category"])
    acting_item_ppg.rename(columns = {"PPG_Item": "Base_Item"}, inplace=True)
    acting_item_ppg = acting_item_ppg.merge(RMS_ppg_mapping_tmp[["PPG_Item","PPGName","PPG_Category"]], how="inner", left_on=["Acting_PPG","Category"], right_on=["PPGName","PPG_Category"])
    acting_item_ppg.rename(columns = {"PPG_Item": "Acting_Item"}, inplace=True)

    acting_item_ppg = acting_item_ppg[["Base_Item","Acting_Item"]]
    acting_item_ppg.to_pickle("ActingItem_list_" + RMS_ppg_mapping["PPG_Category"][0] + "_" + selected_retailer["Retailer.Name"][0] + ".pkl")
    print("Acting Item Created")