#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import random
import numpy as np
import pandas as pd
from sklearn import linear_model
import pymc3 as pm

# import rpy2.robjects as ro
# from rpy2.robjects.packages import importr
# from rpy2.robjects import pandas2ri
# import rpy2.robjects.numpy2ri
# rpy2.robjects.numpy2ri.activate()

  
def category_format_fn(category):
    """Format category column"""

    category = re.sub("CAT_LITTER", "Litter", category)
    category = re.sub("SNACKS", "TREATS", category)
    # TODO - Search Python equivalent function of "stri_trans_general"
    category = re.sub("_", " ", category)
    return category

def retailer_format_fn(retailer):
    """Format retailer column"""

    # retailer =  stri_trans_general(gsub("_", " ", retailer), id = "Title")
    retailer = re.sub("_", " ", retailer)
    return retailer

def binding_op_files(cannibal_dat_filename, 
                     baselines_dat_filename,
                     model_est_dat_filename,                     
                     cannibal_dat_filename_all, 
                     baselines_dat_filename_all,
                     model_est_dat_filename_all,
                     base_dir1, 
                     include_2yr_flag=True,
                     include_1yr_flag=True,
                     include_less_than_1yr_flag=False):
    """ Combine 1yr and 2Yr output files """
    
    os.chdir(os.path.join(base_dir1,"Output Files"))
    
    # Data Initialization
    glbl_model_cannibal_df_1 = pd.DataFrame(columns=["Cannibal_PPG","Cannibalised_PPG", 
                                                     "Measure", "Date", "Cannibal_Doll"])
    glbl_model_cannibal_df_2 = pd.DataFrame(columns=["Cannibal_PPG","Cannibalised_PPG", 
                                                     "Measure", "Date", "Cannibal_Doll"])    
    
    # Model Base Data
    glbl_model_base_df_1 = pd.DataFrame(columns=["PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description", 
                                                 "Date", "wk_sold_qty_byppg", "wk_sold_avg_price_byppg", 
                                                 "median_baseprice", "Final_baseprice", "Estimated_baseprice", "tpr_discount_byppg", 
                                                 "ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp", "ACV_Selling",
                                                 "flag_qtr2", "flag_qtr3", "flag_qtr4",
                                                 "category_trend", "tpr_discount_byppg_lag1", "tpr_discount_byppg_lag2", 
                                                 "monthno", "pred_vol", "base_vol", "Model_flag"])
    glbl_model_base_df_2 = pd.DataFrame(columns=["PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description", "Cannibal_Doll",
                                                 "Date", "wk_sold_qty_byppg", "wk_sold_avg_price_byppg", 
                                                 "median_baseprice", "Final_baseprice", "Estimated_baseprice", "tpr_discount_byppg", 
                                                 "ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp", "ACV_Selling",
                                                 "flag_qtr2", "flag_qtr3", "flag_qtr4",
                                                 "category_trend", "tpr_discount_byppg_lag1", "tpr_discount_byppg_lag2", 
                                                 "monthno", "pred_vol", "base_vol", "Model_flag"])    
    # Cannibalisation Data
    glbl_model_cannibal_df_1 = pd.DataFrame(columns=["Cannibal_PPG","Cannibalised_PPG", "Measure", 
                                                     "Date", "Cannibal_Doll", "Model_flag"])
    glbl_model_cannibal_df_2 = pd.DataFrame(columns=["Cannibal_PPG","Cannibalised_PPG", "Measure", 
                                                     "Date", "Cannibal_Doll", "Model_flag"])    
    # Model Results    
    model_results_final_1 = pd.DataFrame(columns=["PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description",
                                                  "model_RSq","model_CVErrorMean","model_CVErrorSD",
                                                  "model_coefficient_name","model_coefficient_value",
                                                  "TrainMAPE", "Model_flag"])
    model_results_final_2 = pd.DataFrame(columns=["PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description",
                                                  "model_RSq","model_CVErrorMean","model_CVErrorSD",
                                                  "model_coefficient_name","model_coefficient_value",
                                                  "TrainMAPE", "Model_flag", "Retailer", "Market"])

    file_format =  ["", "_1yr", "_less_than_1yr"]
    input_list = np.array([include_2yr_flag, include_1yr_flag, include_less_than_1yr_flag])
    slct_file_format = [val for ind, val in enumerate(file_format) if  input_list[ind]]
    for val in slct_file_format:
        file_subscript = val
        tmp_glbl_model_cannibal_df_1 = pd.read_pickle(cannibal_dat_filename + file_subscript + ".pkl")
        tmp_glbl_model_base_df_1 = pd.read_pickle(baselines_dat_filename + file_subscript + ".pkl")
        tmp_model_results_final_1 = pd.read_pickle(model_est_dat_filename + file_subscript + ".pkl")
        tmp_glbl_model_cannibal_df_2 = pd.read_pickle(cannibal_dat_filename + file_subscript + "_Optimizer.pkl")
        tmp_glbl_model_base_df_2 = pd.read_pickle(baselines_dat_filename + file_subscript + "_Optimizer.pkl")
        tmp_model_results_final_2 = pd.read_pickle(model_est_dat_filename + file_subscript + "_Optimizer.pkl")

        glbl_model_cannibal_df_1 = glbl_model_cannibal_df_1.append(tmp_glbl_model_cannibal_df_1, ignore_index=False)  
        glbl_model_base_df_1 = glbl_model_base_df_1.append(tmp_glbl_model_base_df_1, ignore_index=False)
        model_results_final_1 = model_results_final_1.append(tmp_model_results_final_1, ignore_index=False)
        glbl_model_cannibal_df_2 = glbl_model_cannibal_df_2.append(tmp_glbl_model_cannibal_df_2, ignore_index=False)
        glbl_model_base_df_2 = glbl_model_base_df_2.append(tmp_glbl_model_base_df_2, ignore_index=False)
        model_results_final_2 = model_results_final_2.append(tmp_model_results_final_2, ignore_index=False)
        
    glbl_model_cannibal_df_1.to_pickle(cannibal_dat_filename_all + ".pkl")
    glbl_model_base_df_1.to_pickle(baselines_dat_filename_all + ".pkl")
    model_results_final_1.to_pickle(model_est_dat_filename_all + ".pkl") 
    glbl_model_cannibal_df_2.to_pickle(cannibal_dat_filename_all + "_Optimizer.pkl")
    glbl_model_base_df_2.to_pickle(baselines_dat_filename_all + "_Optimizer.pkl")    
    model_results_final_2.to_pickle(model_est_dat_filename_all + "_Optimizer.pkl")
    
    
class MyLassoCV():
    """ Modified class for LassoCV from scikit-learn package
    
    Example
    ------
    random.seed(19)
    X = pd.DataFrame({"X1": np.random.normal(0, 0.25, 500), "X2": np.random.normal(0, 0.25, 500)})
    y = -1*X["X1"] + 1*X["X2"] + 1
    lwr_bound = [-np.Inf, 0]
    upr_bound = [0, np.Inf]
    model = MyLassoCV(max_iter = 10**5, cv=10, random_state=123, selection="random", positive_flag=True)
    model.fit(X, y, lwr_bound, upr_bound)
    print(model.coef_)
    print(model.intercept_)
    y_pred = model.predict(X)
    print(np.mean(np.abs(1-(y_pred/y.to_numpy()))*100))
    print(model.get_cv_metrics())
    """
    
    def __init__(self, max_iter = 10**3, cv=None, positive_flag=False, random_state=None, selection="cyclic"):
        self.positive_flag = positive_flag
        self.model = linear_model.LassoCV(max_iter = max_iter, cv=cv, positive=positive_flag, random_state=random_state, selection=selection)
    
    def fit(self, X_train, y_train, lwr_bound, upr_bound):        
        # TODO: Add exception handling block
        self.X = X_train.copy()
        self.y = y_train.copy()
        self.nobs = len(self.X)
        self.idv_cols = self.X.columns.to_list()
        if self.positive_flag==True:
            self.idv_reverse_flag = [self.is_reverse(lwr_bound[i], upr_bound[i]) for i in np.arange(len(self.idv_cols))]
            self.X.loc[:, self.idv_reverse_flag] = -1*self.X.loc[:, self.idv_reverse_flag]
        else:
            self.idv_reverse_flag = [False for i in np.arange(len(self.idv_cols))]
        
        self.model.fit(self.X, self.y)
        self.mdl_lambda = self.model.alpha_
        self.coef_, self.intercept_ = self.get_coef()
        
    def is_reverse(self, lwr, upr):
        if lwr<0 and upr==0:
            return True
        elif lwr==0 and upr>0:
            return False
        elif lwr<0 and upr>0:
            return False
        else:
            # Handle rest of the combinations
            # lwr>0 and upr==0 | lwr==0 and upr<0 | lwr==0 and upr==0 | lwr<0 and upr<0 | lwr>0 and upr>0
            return False
            
    def get_coef(self):
        coef_ = self.model.coef_.copy()
        coef_[self.idv_reverse_flag] = -1*coef_[self.idv_reverse_flag]
        return coef_ , self.model.intercept_
        
    def predict(self, X_test):
        self.X_test = X_test[self.idv_cols].copy()
        self.X_test.loc[:, self.idv_reverse_flag] = -1*self.X_test.loc[:, self.idv_reverse_flag]
        return self.model.predict(self.X_test)
        
    def get_cv_metrics(self):
        mse_mean = self.model.mse_path_[np.where(self.model.alphas_==self.mdl_lambda)[0]].mean()
        mse_sd = self.model.mse_path_[np.where(self.model.alphas_==self.mdl_lambda)[0]].std()
        return mse_mean, mse_sd
    
    
class MyPyMC3():
    """ Modified class for PyMC3
    
    Example
    -------
    random.seed(19)
    train_df = pd.DataFrame({"X1": np.random.normal(0, 0.25, 500), "X2": np.random.normal(0, 0.25, 500)})
    train_df["y"] = -1*train_df["X1"] + 1*train_df["X2"] + 1
    prior_df = pd.DataFrame({"model_coefficient_name" : ["X1", "X2"],
                             "model_coefficient_value": [-1, 1],
                             "model_coefficient_std": [0.05, 0.05]})
    model = MyPyMC3(train_df, prior_df, dv_col="y")        
    model.train()
    coef = model.get_group_summary()
    print(coef)
    y_pred = model.predict(model_df)
    print(np.mean(np.abs(1-(y_pred/model_df["DV"].to_numpy())))*100)
    """
    
    def __init__(self, train_df, prior_df, dv_col="DV"):
        self.train_df = train_df.copy()
        self.prior_df = prior_df.copy()

        self.nobs = len(self.train_df)
        self.dv_col = dv_col
        self.idv_cols = self.train_df.drop(columns=[self.dv_col]).columns.to_list()
        self.model = pm.Model()

    def train(self, no_iter=500, no_warmup_iter=500, no_chain=4, seed=123):
        with self.model:
            self.priors = {"Intercept": pm.StudentT.dist(nu=3, mu=np.median(self.train_df[self.dv_col]), sigma=2.5)}
            for index, row in self.prior_df.iterrows():
                self.priors.update({row["model_coefficient_name"]: pm.Gamma.dist(mu=abs(row["model_coefficient_value"]), sigma=row["model_coefficient_std"])})
            
            # Reverse variable sign for log-normal/gamma prior
            # self.reverse_cols = self.prior_df.loc[self.prior_df["model_coefficient_value"]<0,"model_coefficient_name"].to_list()
            # self.train_df.loc[:,self.reverse_cols] = -1*self.train_df.loc[:,self.reverse_cols]

            self.formula = self.dv_col + "~" + "+".join(self.idv_cols)
            pm.glm.GLM.from_formula(self.formula, self.train_df, self.priors)
            self.trace = pm.sample(model=self.model, draws=no_iter, init="adapt_diag", 
                                   tune=no_warmup_iter, chains=no_chain, cores=4,
                                   random_seed=seed, target_accept = 0.995, max_treedepth = 15)
            
        self.coef_ = self.get_group_summary()
        
    def get_group_summary(self):
        trace_df = pm.trace_to_dataframe(self.trace)
        coef = trace_df.drop(columns="sd").mean()
        
        # Reverse variable sign for log-normal/gamma prior
        # coef[coef.index.isin(self.reverse_cols)] = -1*coef[coef.index.isin(self.reverse_cols)]
        return coef

    def predict(self, test_df):
        self.test_df = test_df[self.idv_cols].copy()
        # Gets prediction by matrix multiplication (Not sign reversal required as it is done in model coef)
        y_pred = self.coef_["Intercept"] + self.test_df.dot(self.coef_[~self.coef_.index.isin(["Intercept"])])
        return y_pred.to_numpy()
    
# class r_glmnet:
#     """ Python class for R cv.glmnet function from glmnet library
    
#     Example
#     -------    
#     random.seed(19)
#     X = pd.DataFrame({"X1": np.random.normal(2, 0.25, 500), "X2": np.random.normal(2, 0.25, 500)})
#     y = pd.DataFrame({"y": np.random.normal(2, 0.25, 500)}, dtype=float)
#     lwr_bound = [-np.Inf, -np.Inf]
#     upr_bound = [np.Inf, np.Inf]
#     penalty_factor = [False, True]
#     glm = r_glmnet()
#     glm.fit(X, y, 1, lwr_bound, upr_bound, penalty_factor)
#     coef = glm.get_coef()
#     print(coef)
#     y_pred = glm.predict(X)
#     mse_mean, mse_sd = glm.get_cv_metrics()
#     """
    
#     def __init__(self):
#         self.glmnet = importr("glmnet")        
    
#     def fit(self, X_train, y_train, reg_param, lwr_bound, upr_bound, penalty_factor):
#         # TODO: Add exception handling block
#         self.nobs = len(X_train)
#         self.idv_cols = X_train.columns.to_list()
#         self.X = X_train.to_numpy()
#         self.y = y_train.to_numpy()
#         self.cv_glm = self.glmnet.cv_glmnet(ro.r.matrix(self.X, nrow=self.nobs , ncol=len(self.idv_cols)), 
#                                             ro.vectors.FloatVector(self.y), 
#                                             alpha=reg_param, 
#                                             lower_limits=ro.vectors.FloatVector(lwr_bound),
#                                             upper_limits=ro.vectors.FloatVector(upr_bound),
#                                             maxit=1000000,
#                                             penalty_factor = ro.vectors.IntVector(penalty_factor))
#         self.mdl_lambda = self.cv_glm.rx2("lambda.1se")
#         self.coef_ = self.get_coef()[1:]
#         self.intercept_ = self.get_coef()[0]
        
#     def get_coef(self):
#         coef = ro.r.matrix(ro.r.predict(self.cv_glm, s=self.mdl_lambda, type="coefficients"))
#         py_coef = pandas2ri.ri2py(coef)
#         return py_coef[:,0]
    
#     def predict(self, X_test):
#         self.X_test = X_test[self.idv_cols].to_numpy()
#         self.y_pred = pandas2ri.ri2py(ro.r.predict(self.cv_glm, self.X_test,s = self.mdl_lambda))
#         return self.y_pred[:,0]
        
#     def get_cv_metrics(self):
#         mse_mean = self.cv_glm.rx2("cvm")[self.cv_glm.rx2("lambda")==self.mdl_lambda]
#         mse_sd = self.cv_glm.rx2("cvsd")[self.cv_glm.rx2("lambda")==self.mdl_lambda]
#         return mse_mean, mse_sd


# class r_glinternet:
#     """ Python class for R glinternet.cv function glinternet library
    
#     Example
#     -------  
#     random.seed(19)
#     X = pd.DataFrame({"X1": np.random.normal(2, 0.25, 500), "X2": np.random.normal(2, 0.25, 500)})
#     y = pd.DataFrame({"y": np.random.normal(2, 0.25, 500)}, dtype=float)
#     glinternet = r_glinternet()
#     glinternet.fit(X, y)
#     interaction_df = glinternet.get_interaction_var()
#     print(interaction_df)
#     """
    
#     def __init__(self):
#         self.base = importr('base')
#         self.stats = importr('stats')
#         self.glinternet = importr("glinternet")
        
#     def fit(self, X_train, y_train):
#         self.nobs = len(X_train)
#         self.idv_cols = X_train.columns.to_list()         
#         self.X = X_train.to_numpy()
#         self.y = y_train.to_numpy()
#         self.num_levels = [1]*X_train.shape[1]
#         self.interaction_candidates = [1]*X_train.shape[1]
#         self.mdl = self.glinternet.glinternet_cv(ro.r.matrix(self.X, nrow=self.nobs , ncol=len(self.idv_cols)), 
#                                                  ro.vectors.FloatVector(self.y), 
#                                                  numLevels=ro.vectors.IntVector(self.num_levels),
#                                                  interactionCandidates=ro.vectors.IntVector(self.interaction_candidates))
        
#     def get_interaction_var(self):
        
#         self.results = self.stats.coef(self.mdl).rx2("interactions").rx2("contcont")
#         if self.base.is_null(self.results)[0]==True:
#             return pd.DataFrame([], columns=["X1", "X2"])
#         else:
#             self.pd_results = pandas2ri.ri2py(self.results)
#             # Convert column indices to python's zero-based format
#             self.pd_results[:,1] = self.pd_results[:,1]-1
#             return pd.DataFrame(self.pd_results, columns=["X1", "X2"])