#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def Price_Elasticity_ip_fn(Retailer, Category, Model_Year_Flag, model_name_flag, model_name, Model_Start_Date="", Model_End_Date=""):
    """Set input parameters """
  
    # Model Parameters  
    # Specify Model Regularization Parameter
    model_regularization_parameter = 1
      
    # Cut Off/ Thresholds for Data Filtering- PPGs to exclude from model set consideration
    # Min. Quarterly Doll Sales Threshold ($100 per week)
    min_revenue_threshold = 1250 
      
    # Minimum Data Present
    min_prct_data_points = 0.9
      
    # Low Variance Cutoff
    # Qty. Sold
    sd_by_mean_sales_vol_threshold = 0.01      
    # Avg. price
    sd_by_mean_avg_price_threshold = 0.01
      
    # Price Minimum Correlation Cut Off
    model_correlation_feature_shortlist = 0.05
      
    # TPR Minimum Correlation Cut Off
    model_correlation_feature_shortlist_tpr = (-0.05)
      
    # Price Trend Acting Item Correlation Cut Off
    model_correlation_price_trend_cutoff = 0.5
      
    # R Square Threshold to account vol. contri into cannibalisation
    cannibalisation_cor_cutoff = -0.5
      
    # ACV Cutoff
    Retailer_ACV_CUTOFF = 0.15
    ROM_ACV_CUTOFF = 0.15
      
    # Interactions cutoff
    min_interaction_rp_cutoff = 0.1
    max_interaction_rp_cutoff = 0.9

    # Quarter cutoff for feature seelction in bayesian 
    features_count = 3
    if Model_Year_Flag == 2:
        if model_name_flag=="B":
            # Retailer and LTA Pos: US Total X PPG X Week data merged with TMT Weekly Data
            merged_ustotal_ppg_ip_filename = "RMS_Data_PPG_"+Category+"_"+Retailer+".pkl"
            
            ActingItem_list = "ActingItem_list_"+Category+"_"+Retailer+ ".pkl"
            
            # Output Files              
            # Output Model Filename
            filtered_model_dataset_filename = "CrossBox_Model_EDLP_TPR_"+Category+"_"+Retailer
  
            # Output Filter PPGs
            filtered_ppg_filename = "Filtered_PPG_Details_"+Category+"_"+Retailer+".csv"
              
            # Revised Filter PPGs Summary
            filtered_ppg_filename_revised = "Revised_Filtered_PPG_Details_"+Category+"_"+Retailer+".csv"
              
            # Output Cannibalisation Filename
            cannibal_dat_filename = "Model_Cannibal_"+Category+"_"+Retailer+ ""
              
            # Output Baselines Filename
            baselines_dat_filename = "Model_Baselines_"+Category+"_"+Retailer+ ""
              
            # Output Model Estimates Filename
            model_est_dat_filename = "Model_Est_"+Category+"_"+Retailer+ ""
            
        elif model_name_flag=="L":
            merged_ustotal_ppg_ip_filename="RMS_Data_PPG_"+Category+"_"+Retailer+".pkl"
  
            ActingItem_list = "ActingItem_list_"+Category+"_"+Retailer+ ".pkl"  
              
            # Output Files       
            # Output Model Filename
            filtered_model_dataset_filename = "CrossBox_Model_EDLP_TPR_"+Category+"_"+Retailer+" "+Model_Start_Date+" to "+Model_End_Date
          
            # Output Filter PPGs
            filtered_ppg_filename = "Filtered_PPG_Details_"+" "+Model_Start_Date+" to "+Model_End_Date+".csv"
          
            # Revised Filter PPGs Summary
            filtered_ppg_filename_revised = "Revised_Filtered_PPG_Details_"+Category+"_"+Retailer+" "+Model_Start_Date+" to "+Model_End_Date+".csv"
          
            # Output Cannibalisation Filename
            cannibal_dat_filename = "Model_Cannibal_"+Category+"_"+Retailer+" "+model_name+" "+Model_Start_Date+" to "+Model_End_Date
          
            # Output Baselines Filename
            baselines_dat_filename = "Model_Baselines_"+Category+"_"+Retailer+" "+model_name+" "+Model_Start_Date+" to "+Model_End_Date
          
            # Output Model Estimates Filename
            model_est_dat_filename = "Model_Est_"+Category+"_"+Retailer+" "+model_name+" "+Model_Start_Date+" to "+Model_End_Date
            
    elif Model_Year_Flag==1:
        # Input Files    
        # Retailer and LTA Pos: US Total X PPG X Week data merged with TMT Weekly Data
        merged_ustotal_ppg_ip_filename = "RMS_Data_PPG_"+Category+"_"+Retailer+".pkl"
        
        ActingItem_list = "ActingItem_list_"+Category+"_"+Retailer+ ".pkl"
        
        # Filter PPGs
        filtered_ppg_filename = "Revised_Filtered_PPG_Details_"+Category+"_"+Retailer+".csv"

        # Output Files    
        # Output Model Filename
        filtered_model_dataset_filename = "CrossBox_Model_EDLP_TPR_"+Category+"_"+Retailer+ "_fnl"
        
        # Output Filter PPGs
        # filtered_ppg_filename_1yr  =  "Filtered_PPG_Details_"+Category+"_"+Retailer+"_1yr.csv"
        
        # Revised Filter PPGs Summary
        filtered_ppg_filename_revised = "Revised_Filtered_PPG_Details_"+Category+"_"+Retailer+"_fnl.csv"
        
        # Output Cannibalisation Filename
        cannibal_dat_filename = "Model_Cannibal_"+Category+"_"+Retailer+ "_1yr"
        
        # Output Baselines Filename
        baselines_dat_filename = "Model_Baselines_"+Category+"_"+Retailer+ "_1yr"
        
        # Output Model Estimates Filename
        model_est_dat_filename = "Model_Est_"+Category+"_"+Retailer+ "_1yr"    

    elif Model_Year_Flag==0:
        
        # Alpha parameter for Gamma Distribution
        alpha = 1.0

        # Input Files    
        # Retailer and LTA Pos: US Total X PPG X Week data merged with TMT Weekly Data
        merged_ustotal_ppg_ip_filename = "RMS_Data_PPG_"+Category+"_"+Retailer+".pkl"
        
        ActingItem_list = "ActingItem_list_" + Category+"_"+Retailer+ ".pkl"
        

        # Output Files    
        # Output Model Filename
        filtered_model_dataset_filename = "CrossBox_Model_EDLP_TPR_"+Category+"_"+Retailer + "_less_than_1yr"
        
        # Filter PPGs
        filtered_ppg_filename = "Revised_Filtered_PPG_Details_"+Category+"_"+Retailer+"_fnl.csv"
        # output_filtered_ppg_filename  =  "Filtered_PPG_Details_"+Category+"_"+Retailer+".csv"
        
        # Revised Filter PPGs Summary
        filtered_ppg_filename_revised = "Revised_Filtered_PPG_Details_"+Category+"_"+Retailer+"_fnl.csv"
        
        # Output Cannibalisation Filename
        cannibal_dat_filename = "Model_Cannibal_"+Category+"_"+Retailer + "_less_than_1yr"
        
        # Output Baselines Filename
        baselines_dat_filename = "Model_Baselines_"+Category+"_"+Retailer + "_less_than_1yr"
        
        # Output Model Estimates Filename
        model_est_dat_filename = "Model_Est_"+Category+"_"+Retailer + "_less_than_1yr"

    elif Model_Year_Flag==-1:
        # Output Files to combine
        # Output Cannibalisation Filename
        cannibal_dat_filename = "Model_Cannibal_"+Category+"_"+Retailer
        
        # Output Baselines Filename
        baselines_dat_filename = "Model_Baselines_"+Category+"_"+Retailer
        
        # Output Model Estimates Filename
        model_est_dat_filename = "Model_Est_"+Category+"_"+Retailer
        
        # Final Files
        # Output Cannibalisation Filename
        cannibal_dat_filename_all = "Model_Cannibal_"+Category+"_"+Retailer+ "_all"
        
        # Output Baselines Filename
        baselines_dat_filename_all = "Model_Baselines_"+Category+"_"+Retailer+ "_all"
        
        # Output Model Estimates Filename
        model_est_dat_filename_all = "Model_Est_"+Category+"_"+Retailer+ "_all"
        
                
    var_list = locals().copy()
    del var_list["Retailer"], var_list["Category"], var_list["Model_Year_Flag"], var_list["features_count"], var_list["model_name_flag"], var_list["model_name"], var_list["Model_Start_Date"], var_list["Model_End_Date"]
    # print(var_list)
    globals().update(var_list)
    
