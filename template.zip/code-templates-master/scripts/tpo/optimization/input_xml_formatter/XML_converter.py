import xmltodict
import pprint
import json

with open('input.xml') as fd:
    doc = xmltodict.parse(fd.read())

pp = pprint.PrettyPrinter(indent=4)

input_dict_str = json.dumps(doc)

head = doc['data']

ret_cat = head['ret_cat_combo']

pp.pprint(ret_cat[0])