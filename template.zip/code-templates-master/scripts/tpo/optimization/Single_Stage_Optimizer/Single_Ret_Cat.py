################################### Load the Required Packages #################################

from __future__ import division

import itertools as it
import random
import re
import time
from functools import reduce

import numpy as np
import pandas as pd

import pyomo.environ as pyo
from Data_class import Data_Return_Formatter
from pyomo.environ import *

################################################################################################


def Multiple_Ret_Cat(Retailer, Category, timeout):

    """Single shot optimizer function for a specific combo"""

    ######################### Load the Required data for Retailer Category Combination #############
    Ret = Retailer
    Cat = Category

    def Load_Ret_Cat_Data(Ret, Cat):
        """Function to load required historical data and coefficient values"""

        annual_df = pd.read_csv("Data/FinalSpendsData.csv")
        annual_df = annual_df[
            (annual_df.Retailer == "Retailer" + str(Ret))
            & (annual_df.Category == "Category" + str(Cat))
        ].reset_index(drop=True)
        coef_df = pd.read_csv(
            "Data/Coeff Matrix/Coeff_Matrix_Category"
            + str(Cat)
            + "_Retailer"
            + str(Ret)
            + ".csv"
        )
        quarter_df = pd.read_csv("Data/FinalBasePrice.csv")
        quarter_df = quarter_df[
            (quarter_df.Retailer == "Retailer" + str(Ret))
            & (quarter_df.Category == "Category" + str(Cat))
        ].reset_index(drop=True)

        return annual_df, coef_df, quarter_df

    try:
        annual_df, coef_df, quarter_df = Load_Ret_Cat_Data(Ret, Cat)
    except:
        return Data_Return_Formatter()  # return a null object indicating error

    ######################## Required Variables from the Inputs ##############################

    Tot_Prod = coef_df["Product"].nunique()
    Tot_Week = coef_df["wk"].nunique()
    EDLP_Events = list(annual_df["RP_Events"])
    Event_Buffer = 4
    Min_EDLP_Events = [
        i - Event_Buffer if i - Event_Buffer >= 0 else 0 for i in EDLP_Events
    ]
    Max_EDLP_Events = [
        i + Event_Buffer if i + Event_Buffer < Tot_Week + 1 else Tot_Week
        for i in EDLP_Events
    ]
    TPR_Events = list(annual_df["TPR_Events"])
    Min_TPR_Events = [
        i - Event_Buffer if i - Event_Buffer >= 0 else 0 for i in TPR_Events
    ]
    Max_TPR_Events = [
        i + Event_Buffer if i + Event_Buffer < Tot_Week + 1 else Tot_Week
        for i in TPR_Events
    ]
    Target_EDLP_Spend = [i for i in annual_df["PPG_RP_Spend"]]
    Target_TPR_Spend = [i for i in annual_df["PPG_TPR_Spend"]]
    Target_Trade_Spend = [i for i in annual_df["PPG_Total_Spend"]]
    Mapping = {}
    Prod_Ind = coef_df["Product"][0:Tot_Prod]

    for i, j in zip(Prod_Ind.index, Prod_Ind.values):

        Mapping[j] = i

    Mapping_reverse = {i: j for j, i in Mapping.items()}
    Base_Price = [[i] * Tot_Week for i in quarter_df["Final_baseprice"]]
    con = [i for i in coef_df["constant"]]
    Intercepts = [con[j : j + Tot_Prod] for j in range(0, len(con), Tot_Prod)]
    EDLP_Coef = np.array(
        coef_df[[i for i in coef_df.columns if i.count("Retailer_Regular") == 1]]
    )
    TPR_Coef = np.array(
        coef_df[[i for i in coef_df.columns if i.count("Retailer_Promoted") == 1]]
    )

    ################################# Available EDLP Interactions pairs ##############################

    EDLP = [
        re.findall(r"[0-9]+", i)
        for i in coef_df.columns
        if i.count("Retailer_Regular") > 1
    ]
    EDLP_Interactions = []

    for i in EDLP:
        temp = []
        for j in i:
            temp.append(int(j))

        EDLP_Interactions.append(temp)

    ####################################### Available TPR Interactions pairs #########################

    TPR = [
        re.findall(r"[0-9]+", i)
        for i in coef_df.columns
        if i.count("Retailer_Promoted") > 1
    ]
    TPR_Interactions = []

    for i in TPR:
        temp = []
        for j in i:
            temp.append(int(j))

        TPR_Interactions.append(temp)

    ####################################### EDLP_Interaction_Coef_Values ############################

    EDLP_Int_Coef_Values = {}

    for col in coef_df.columns:
        if col.count("Retailer_Regular") > 1:
            Pair_name = "_".join([str(int(i)) for i in re.findall(r"[0-9]+", col)])

            EDLP_Int_Coef_Values[Pair_name] = list(coef_df[col])

    ####################################### TPR_Interaction_Coef_Values #############################

    TPR_Int_Coef_Values = {}

    for col in coef_df.columns:
        if col.count("Retailer_Promoted") > 1:
            Pair_name = "_".join([str(int(i)) for i in re.findall(r"[0-9]+", col)])
            TPR_Int_Coef_Values[Pair_name] = list(coef_df[col])

    ###################################### Loading Pantry Loading Coefficients #######################

    Pantry_1 = list(coef_df["Pantry_Loading_1"])
    Pantry_1 = [Pantry_1[j : j + Tot_Prod] for j in range(0, len(Pantry_1), Tot_Prod)]
    Pantry_2 = list(coef_df["Pantry_Loading_2"])
    Pantry_2 = [Pantry_2[j : j + Tot_Prod] for j in range(0, len(Pantry_2), Tot_Prod)]

    ############################### Setting Up The Limits ####################################

    def Buffer_Limit(
        EDLP_Perc_Limit=20,
        TPR_Perc_Limit=20,
        Ov_Perc_Limit=10,
        Total_EDLP_Perc_Limit=0,
        Total_TPR_Perc_Limit=0,
    ):

        return (
            EDLP_Perc_Limit,
            TPR_Perc_Limit,
            Ov_Perc_Limit,
            Total_EDLP_Perc_Limit,
            Total_TPR_Perc_Limit,
        )

    (
        EDLP_Perc_Limit,
        TPR_Perc_Limit,
        Ov_Perc_Limit,
        Total_EDLP_Perc_Limit,
        Total_TPR_Perc_Limit,
    ) = Buffer_Limit()

    def Bound_Limits(EDLP_LB=0.95, EDLP_UB=1, TPR_LB=0.05, TPR_UB=0.5):

        return EDLP_LB, EDLP_UB, TPR_LB, TPR_UB

    EDLP_LB, EDLP_UB, TPR_LB, TPR_UB = Bound_Limits()

    ######################################## Retailer_Unit_Sales ###############################

    def Retailer_Unit_Sales_Fn(Model, P, W):

        Self = exp(
            (log(Model.EDLP[P, W] * Base_Price[P][W]) * EDLP_Coef[P][P])
            * Model.FLAG[P, W]
            + (
                log(Base_Price[P][W]) * EDLP_Coef[P][P]
                + Model.TPR[P, W] * TPR_Coef[P][P]
            )
            * (1 - Model.FLAG[P, W])
            + Intercepts[W][P]
        )

        Comp = Competitor_Unit_Effect_Fn(Model, P, W)
        EDLP_Inter_Val = EDLP_Interaction_Unit_Effect_Fn(Model, P, W)
        TPR_Inter_Val = TPR_Interaction_Unit_Effect_Fn(Model, P, W)
        Pantry_Loading_Val = Pantry_Loading_Unit_Effect_Fn(Model, P, W)
        Unit_Sales = Self * Comp * EDLP_Inter_Val * TPR_Inter_Val * Pantry_Loading_Val

        return Unit_Sales

    ######################### Competitor_Unit_Effect #####################

    def Competitor_Unit_Effect_Fn(Model, Cur_Ret, Wk):

        Comp_Retailers_Unit_Sales = [
            exp(
                (log(Model.EDLP[i, Wk] * Base_Price[i][Wk]) * EDLP_Coef[Cur_Ret][i])
                * Model.FLAG[i, Wk]
                + (
                    log(Base_Price[i][Wk]) * EDLP_Coef[Cur_Ret][i]
                    + Model.TPR[i, Wk] * TPR_Coef[Cur_Ret][i]
                )
                * (1 - Model.FLAG[i, Wk])
            )
            for i in Model.PPG_index
            if i != Cur_Ret
        ]

        return reduce(lambda x, y: x * y, Comp_Retailers_Unit_Sales, 1)

    ########################################################################

    ####################### EDLP Interactions ##############################

    def EDLP_Interaction_Unit_Effect_Fn(Model, P, Wk):

        EDLP_Interaction_Unit_Effect = [1]
        P1 = int("".join(re.findall(r"[0-9]+", Mapping_reverse[P])))

        for Inter in EDLP_Interactions:
            if P1 in Inter:
                Pr_ind1, Pr_ind2 = Inter
                Comb = str(Pr_ind1) + "_" + str(Pr_ind2)
                Pr_ind1 = Mapping["Product" + str(Pr_ind1) + "_Retailer"]
                Pr_ind2 = Mapping["Product" + str(Pr_ind2) + "_Retailer"]

                Val1 = Base_Price[Pr_ind1][Wk] * (1 - Model.FLAG[Pr_ind1, Wk]) + (
                    Model.EDLP[Pr_ind1, Wk] * Base_Price[Pr_ind1][Wk]
                ) * (Model.FLAG[Pr_ind1, Wk])

                Val2 = Base_Price[Pr_ind2][Wk] * (1 - Model.FLAG[Pr_ind2, Wk]) + (
                    Model.EDLP[Pr_ind2, Wk] * Base_Price[Pr_ind2][Wk]
                ) * (Model.FLAG[Pr_ind2, Wk])

                Val = exp(log(Val1) * log(Val2) * EDLP_Int_Coef_Values[Comb][P])

                EDLP_Interaction_Unit_Effect.append(Val)

        return reduce(lambda x, y: x * y, EDLP_Interaction_Unit_Effect)

    ########################################################################

    ####################### TPR Interactions ###############################

    def TPR_Interaction_Unit_Effect_Fn(Model, P, Wk):

        TPR_Interaction_Unit_Effect = [1]
        P1 = int("".join(re.findall(r"[0-9]+", Mapping_reverse[P])))

        for Inter in TPR_Interactions:

            if P1 in Inter:

                Pr_ind1, Pr_ind2 = Inter
                Comb = str(Pr_ind1) + "_" + str(Pr_ind2)
                Pr_ind1 = Mapping["Product" + str(Pr_ind1) + "_Retailer"]
                Pr_ind2 = Mapping["Product" + str(Pr_ind2) + "_Retailer"]
                Val = exp(
                    (
                        Model.TPR[Pr_ind1, Wk]
                        * Model.TPR[Pr_ind2, Wk]
                        * TPR_Int_Coef_Values[Comb][P]
                        * (1 - Model.FLAG[Pr_ind1, Wk])
                        * (1 - Model.FLAG[Pr_ind2, Wk])
                    )
                )

                TPR_Interaction_Unit_Effect.append(Val)

        return reduce(lambda x, y: x * y, TPR_Interaction_Unit_Effect)

    ########################################################################

    ######################## Pantry Loading ################################

    def Pantry_Loading_Unit_Effect_Fn(Model, P, Wk):

        Pantry_1_Effect = Pantry_2_effect = 1
        PL_Coef1 = Pantry_1[Wk][P]
        PL_Coef2 = Pantry_2[Wk][P]

        if Wk > 0:
            Pantry_1_Effect = exp(
                Model.TPR[P, Wk - 1] * PL_Coef1 * (1 - Model.FLAG[P, Wk - 1])
            )

        if Wk > 1:
            Pantry_2_effect = exp(
                Model.TPR[P, Wk - 2] * PL_Coef2 * (1 - Model.FLAG[P, Wk - 2])
            )

        Pantry_Loading_Unit_Effect = Pantry_1_Effect * Pantry_2_effect

        return Pantry_Loading_Unit_Effect

    ###############################################################################

    ################################## Retailer_Price #############################

    def Retailer_Price_Fn(Model, P, W):

        Price = (Base_Price[P][W] * (1 - Model.TPR[P, W]) * (1 - Model.FLAG[P, W])) + (
            Model.EDLP[P, W] * Base_Price[P][W] * Model.FLAG[P, W]
        )

        return Price

    #################################################################################

    ################################ Dollar Sales ###################################

    def Dollar_Sales_Fn(Model):

        return sum(
            [
                Retailer_Unit_Sales_Fn(Model, P, W) * Retailer_Price_Fn(Model, P, W)
                for W in Model.Wk_index
                for P in Model.PPG_index
            ]
        )

    #################################################################################

    ############################### CONSTRAINTS AS FUNCTIONS ########################

    ############################### FLAG UTILIZATION ################################

    def FLAG_Util_Fn(Model, Cur_Ret):

        return (
            sum(
                [
                    Model.FLAG[Cur_Ret, Wk] * (1 - Model.FLAG[Cur_Ret, Wk])
                    for Wk in range(Tot_Week)
                ]
            )
            == 0
        )

    #################################################################################

    ############################### EDLP Events #####################################

    def EDLP_Event_Fn(Model, P):

        return pyo.inequality(
            Min_EDLP_Events[P],
            sum([Model.FLAG[P, W] for W in Model.Wk_index]),
            Max_EDLP_Events[P],
        )

    #################################################################################

    ############################### TPR Events ######################################

    def TPR_Event_Fn(Model, P):

        return pyo.inequality(
            Min_TPR_Events[P],
            Tot_Week - sum([Model.FLAG[P, W] for W in Model.Wk_index]),
            Max_TPR_Events[P],
        )

    #################################################################################

    ############################ Total Trade Spend Events ###########################

    def Total_Trade_Spent_Bnd_Fn(Model, Cur_Ret):

        Val = sum(
            [
                (Base_Price[Cur_Ret][Wk] - Retailer_Price_Fn(Model, Cur_Ret, Wk))
                * Retailer_Unit_Sales_Fn(Model, Cur_Ret, Wk)
                for Wk in Model.Wk_index
            ]
        )

        return pyo.inequality(
            Target_Trade_Spend[Cur_Ret] * (1 - Ov_Perc_Limit / 100),
            Val,
            Target_Trade_Spend[Cur_Ret] * (1 + Ov_Perc_Limit / 100),
        )

    ##################################################################################

    ############################ EDLP Trade Spend Events #############################

    def EDLP_Trade_Spent_Bnd_Fn(Model, Cur_Ret):

        Val = sum(
            [
                (Base_Price[Cur_Ret][Wk] - Retailer_Price_Fn(Model, Cur_Ret, Wk))
                * Retailer_Unit_Sales_Fn(Model, Cur_Ret, Wk)
                * (Model.FLAG[Cur_Ret, Wk])
                for Wk in Model.Wk_index
            ]
        )

        return pyo.inequality(
            Target_EDLP_Spend[Cur_Ret] * (1 - EDLP_Perc_Limit / 100),
            Val,
            Target_EDLP_Spend[Cur_Ret] * (1 + EDLP_Perc_Limit / 100),
        )

    ###################################################################################

    ############################ TPR Trade Spend Events ##############################

    def TPR_Trade_Spent_Bnd_Fn(Model, Cur_Ret):

        Val = sum(
            [
                (Base_Price[Cur_Ret][Wk] - Retailer_Price_Fn(Model, Cur_Ret, Wk))
                * Retailer_Unit_Sales_Fn(Model, Cur_Ret, Wk)
                * (1 - Model.FLAG[Cur_Ret, Wk])
                for Wk in range(Tot_Week)
            ]
        )

        return pyo.inequality(
            Target_TPR_Spend[Cur_Ret] * (1 - TPR_Perc_Limit / 100),
            Val,
            Target_TPR_Spend[Cur_Ret] * (1 + TPR_Perc_Limit / 100),
        )

    ###################################################################################

    ####################### Overall Total Trade Spent #################################

    def Overall_Total_Trade_Spent_Fn(Model):

        return sum(
            [
                sum(
                    [
                        (
                            Base_Price[Cur_Ret][Wk]
                            - Retailer_Price_Fn(Model, Cur_Ret, Wk)
                        )
                        * Retailer_Unit_Sales_Fn(Model, Cur_Ret, Wk)
                        for Wk in range(Tot_Week)
                    ]
                )
                for Cur_Ret in range(Tot_Prod)
            ]
        ) == sum(Target_Trade_Spend)

    ####################################################################################

    ########################### Creating Pyomo Model ###################################

    def Create_Model(Flag_Init):
        """Function for creating a Pyomo model. Model consists of 
		1. Functions to properly initialize EDLP and TPR values from previous operations
		2. Variables to optimize
		3. Objective function
		4. Constraints"""

        def Flag_Initialize(Model, *Index):

            return Flag_Init[Index]

        Model = ConcreteModel(name="Spend_Optim")

        Model.Weeks = Param(initialize=Tot_Week, domain=PositiveIntegers)

        Model.PPGs = Param(initialize=Tot_Prod, domain=PositiveIntegers)

        Model.Wk_index = RangeSet(0, Model.Weeks - 1)

        Model.PPG_index = RangeSet(0, Model.PPGs - 1)

        Model.EDLP = Var(
            Model.PPG_index,
            Model.Wk_index,
            initialize=EDLP_LB,
            domain=NonNegativeReals,
            bounds=(EDLP_LB, EDLP_UB),
        )

        Model.TPR = Var(
            Model.PPG_index,
            Model.Wk_index,
            initialize=TPR_LB,
            domain=NonNegativeReals,
            bounds=(TPR_LB, TPR_UB),
        )

        Model.FLAG = Var(
            Model.PPG_index, Model.Wk_index, initialize=Flag_Initialize, domain=Binary
        )

        Model.Obj = Objective(rule=Dollar_Sales_Fn, sense=maximize)

        Model.Tot_Spent_Bnd = Constraint(Model.PPG_index, rule=Total_Trade_Spent_Bnd_Fn)

        Model.EDLP_Bnd = Constraint(Model.PPG_index, rule=EDLP_Trade_Spent_Bnd_Fn)

        Model.TPR_Bnd = Constraint(Model.PPG_index, rule=TPR_Trade_Spent_Bnd_Fn)

        Model.FLAG_Util_c = Constraint(Model.PPG_index, rule=FLAG_Util_Fn)

        Model.TPR_Event = Constraint(Model.PPG_index, rule=TPR_Event_Fn)

        Model.EDLP_Event = Constraint(Model.PPG_index, rule=EDLP_Event_Fn)

        Model.Overall = Constraint(rule=Overall_Total_Trade_Spent_Fn)

        return Model

    ####################################################################################

    ########################### Solver Calling With Pyomo Model ########################

    def call_solver(Flag_Init, PPGs, Wks, name="bonmin", obj=1):

        """Main solver area used for generating and then calling a pyomo model. 
    	The function generates a generic model which can be ran across solvers
    	which are supported in the Pyomo framework and can solve MINLP problems
    	ex-Bonmin, Baron. Results are loaded into the data formatter class which 
		includes nature of convergence and error if any"""

        from pyomo.util.infeasible import (
            log_infeasible_constraints,
            log_infeasible_bounds,
        )

        Model = Create_Model(Flag_Init)

        Opt = SolverFactory(name)

        # opt.options['tol'] = 1e-4
        Opt.options["max_cpu_time"] = timeout
        # opt.options['max_iter']= 50000
        # Opt.options['bonmin.time_limit'] = 1800
        Opt.options["bonmin.algorithm"] = "B-Hyb"

        start_time = time.time()

        Result = Opt.solve(Model, tee=False)

        end_time = time.time()

        EDLP_Val = np.array(
            [pyo.value(Model.EDLP[i, j]) for i in range(PPGs) for j in range(Wks)]
        ).reshape(PPGs, Wks)

        TPR_Val = np.array(
            [pyo.value(Model.TPR[i, j]) for i in range(PPGs) for j in range(Wks)]
        ).reshape(PPGs, Wks)

        FLAG_Val = np.array(
            [pyo.value(Model.FLAG[i, j]) for i in range(PPGs) for j in range(Wks)]
        ).reshape(PPGs, Wks)

        el_time = end_time - start_time

        btime = Result["Solver"][0]["Time"]

        if (
            str(Result["Solver"][0]["Status"]) == "ok"
            and pyomo.environ.value(Model.Obj) > obj
        ):

            call_solver.Obj_Val = pyomo.environ.value(Model.Obj)

            push_obj = Data_Return_Formatter(
                error=False,
                model=Model,
                feasible=True,
                message=Result["Solver"][0]["Message"],
                termi_cond=Result["Solver"][0]["Termination condition"],
                status=Result["Solver"][0]["Status"],
                objective=pyomo.environ.value(Model.Obj),
                total_time=el_time,
                bonmin_time=btime,
                EDLP_VAL=EDLP_Val,
                TPR_VAL=TPR_Val,
                FLAG_VAL=FLAG_Val,
            )

            return push_obj

        else:

            call_solver.Obj_Val = obj
            push_obj = Data_Return_Formatter(
                error=False,
                model=Model,
                feasible=False,
                message=Result["Solver"][0]["Message"],
                termi_cond=Result["Solver"][0]["Termination condition"],
                status=Result["Solver"][0]["Status"],
                objective=pyomo.environ.value(Model.Obj),
                total_time=el_time,
                bonmin_time=btime,
                EDLP_VAL=EDLP_Val,
                TPR_VAL=TPR_Val,
                FLAG_VAL=FLAG_Val,
            )

            return push_obj

    ####################################################################################

    ########################### Multiple Iteration With Flags ##########################

    Value = 1

    historical_df = pd.read_csv("Data/HistoricalEvents.csv")

    historical_df = historical_df[
        (historical_df.Retailer == "Retailer" + str(Ret))
        & (historical_df.Category == "Category" + str(Cat))
    ].reset_index(drop=True)

    flag_init = historical_df.Event.tolist()

    flag_init = [(1 - x) for x in flag_init]

    flag_init = np.array(flag_init).reshape(Tot_Prod, Tot_Week)

    try:
        net_result = call_solver(
            flag_init, PPGs=Tot_Prod, Wks=Tot_Week, name="bonmin", obj=Value
        )
        return net_result
    except:
        return Data_Return_Formatter()

    ####################################################################################################################
