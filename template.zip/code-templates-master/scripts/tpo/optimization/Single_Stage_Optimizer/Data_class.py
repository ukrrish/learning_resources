class Data_Return_Formatter:
    """Concrete class for single stage data.
	Usage Data_Return_Formatter() while returning an error and 
	Data_Return_Formatter(arguments=values) while loading values"""

    def __init__(self, **kwargs):

        self.error = kwargs.get("error", True)
        self.Model = kwargs.get("model", None)
        self.feasible = kwargs.get("feasible", None)
        self.message = kwargs.get("message", None)
        self.termination_condition = kwargs.get("termi_cond", None)
        self.status = kwargs.get("status", None)
        self.Objective = kwargs.get("objective", None)
        self.total_time = kwargs.get("total_time", None)
        self.bonmin_time = kwargs.get("bonmin_time", None)
        self.EDLP_VAL = kwargs.get("EDLP_VAL", None)
        self.TPR_VAL = kwargs.get("TPR_VAL", None)
        self.FLAG_VAL = kwargs.get("FLAG_VAL", None)
