import numpy as np
import pandas as pd

from Single_Ret_Cat import *

# Retailer_Category_Combo = [ (13,7) ]


def single_stage_fire(Retailer, Category, timeout):

    net_status = Multiple_Ret_Cat(Retailer, Category, timeout)

    return net_status
