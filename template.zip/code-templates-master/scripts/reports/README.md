# Introduction

Generate reports with raw and processed data.


# Pre-requisites

* Ensure you have `raw` and `processed` data in the data folder. If not, please run either notebooks or production scripts

# Getting started

* Activate `ta-lib-dev` and Switch to `scripts/reports` directory and run the following to get all reports related to regression:
```
(ta-lib-dev):~/scripts/reports$ python gen_reports.py regression 
```
The reports corresponding to regression will be present in `scripts/regression` directory

In case of classification:
```
(ta-lib-dev):~/scripts/reports$ python gen_reports.py classification 
```
The reports for classification will be present in `scripts/classification`
