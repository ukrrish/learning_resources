import sys
import os
import os.path as op
import pandas as pd
import numpy as np
from ta_lib.core.api import (
    create_context, get_dataframe, get_feature_names_from_column_transformer, string_cleaning, 
    get_package_path, display_as_tabs, save_data, save_pipeline, load_dataframe, load_pipeline, DEFAULT_ARTIFACTS_PATH, DEFAULT_DATA_BASE_PATH 
)
from tigerml.model_eval.plotters.evaluation.regression import create_scatter
import ta_lib.core.api as dataset
import ta_lib.eda.api as eda
from ta_lib.reports.api import create_report
import ta_lib.reports.api as health
from xgboost import XGBRegressor
from dateutil.relativedelta import relativedelta
from sklearn.base import BaseEstimator, TransformerMixin
from ta_lib.regression.api import SKLStatsmodelOLS
from ta_lib.regression.api import RegressionComparison, RegressionReport
from sklearn.ensemble import RandomForestClassifier
from ta_lib.classification.api import ClassificationComparison, ClassificationReport, confusion_matrix_by_feature, SKLStatsmodelLogit
from ta_lib.data_processing.api import WoeBinningTransformer
import ta_lib.reports.api as reports
from ta_lib.data_processing.api import Outlier
from sklearn.pipeline import Pipeline
from sklearn.feature_selection import SelectFromModel
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import FunctionTransformer
from sklearn.compose import ColumnTransformer
from scripts import CustomFeatureGeneration
from category_encoders import OneHotEncoder

# impute missing values
from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.impute import KNNImputer, IterativeImputer, SimpleImputer
from sklearn.tree import DecisionTreeRegressor
from category_encoders import TargetEncoder


HERE = op.dirname(op.abspath(__file__))

def columns_to_drop(corr_table, features_to_be_dropped=[], corr_threshold=0.6):
    """List the features to be dropped based on correlation coefficient threshold
    """
    corr_table = corr_table.sort_values('Variable 1')
    for index, row in corr_table.iterrows():
        if row['Abs Coer Coef'] > corr_threshold:
            if row['Variable 1'] not in features_to_be_dropped:
                features_to_be_dropped.append(row['Variable 2'])
    return(features_to_be_dropped)


def add_features(df, context, ref_date):
    data = (
        df.add_features_primary_sales(context, ref_date) \
          .add_features_seconday_sales(context, ref_date) \
          .add_features_no_objection_data(context, ref_date)\
          .add_features_order_alloc_data(context, ref_date)\
          .add_features_coverage_data(context, ref_date)\
          .add_features_order_alloc_reason(context, ref_date)\
          .add_features_profit_data(context, ref_date)\
          .add_features_retail_program_data(context, ref_date)\
          .add_features_business_data(context, ref_date)\
          .add_features_ordered_withapp_data(context, ref_date)\
          .add_features_ordered_withoutapp_data(context, ref_date)\
          .add_features_retail_invoices_data(context, ref_date)\
          .add_days_in_business_feature(context, ref_date)
    )
    return(data)


def _custom_data_transform(df, cols2keep=None):
    """Transformation to drop some columns in the data
    
    Parameters
    ----------
        df - pd.DataFrame
        cols2keep - columns to keep in the dataframe
    """
    cols2keep = cols2keep or []
    if len(cols2keep):
        return (df
                .select_columns(cols2keep))
    else:
        return df

def adjusted_r2(y, yhat, idv):
    from sklearn.metrics import r2_score
    r2 = r2_score(y, yhat)
    adjusted_r_squared = 1 - (1 - r2) * (len(y) - 1) / (len(y) - idv - 1)
    return adjusted_r_squared


def gen_regression_reports():
    reports_path = op.join(HERE, 'regression')
    config_path = op.join(get_package_path(), '..', 'production', 'regression', 'python','conf', 'config.yml')
    context = create_context(config_path)
    orders_df = dataset.load_dataset(context, 'raw/orders')
    prod_df = dataset.load_dataset(context, 'raw/product')
    ## health reports
    health.summary_report(orders_df, f'{reports_path}/orders.html')
    health.summary_report(prod_df, f'{reports_path}/prod.html')

    orders_df = dataset.load_dataset(context, 'raw/orders')
    prod_df = dataset.load_dataset(context, 'raw/product')

    train_X = dataset.load_dataset(context, 'train/sales/features')
    train_y = dataset.load_dataset(context, 'train/sales/target')

    test_X = dataset.load_dataset(context, 'test/sales/features')
    test_y = dataset.load_dataset(context, 'test/sales/target')

    cat_columns = train_X.select_dtypes('object').columns
    num_columns = train_X.select_dtypes('number').columns

    outlier_transformer = Outlier(method='mean')
    train_X = outlier_transformer.fit_transform(train_X)

    tgt_enc_simple_impt = Pipeline([
    ('target_encoding', TargetEncoder(return_df=False)),
    ('simple_impute', SimpleImputer(strategy='most_frequent')),
    ])


    # NOTE: the list of transformations here are not sequential but weighted 
    # (if multiple transforms are specified for a particular column)
    # for sequential transforms use a pipeline as shown above.
    features_transformer = ColumnTransformer([
        
        ## categorical columns
        ('tgt_enc', TargetEncoder(return_df=False),
         list(set(cat_columns) - set(['technology', 'functional_status', 'platforms']))),
        
        # NOTE: if the same column gets repeated, then they are weighed in the final output
        # If we want a sequence of operations, then we use a pipeline but that doesen't YET support
        # get_feature_names. 
        ('tgt_enc_sim_impt', tgt_enc_simple_impt, ['technology', 'functional_status', 'platforms']),
            
        ## numeric columns
        ('med_enc', SimpleImputer(strategy='median'), num_columns),
        
    ])
    train_X = get_dataframe(
    features_transformer.fit_transform(train_X, train_y), 
    get_feature_names_from_column_transformer(features_transformer)
    )

    out = eda.get_density_plots(train_X, cols=['brand', 'condition'])
    reports.create_report({'univariate': out}, path=reports_path ,name='feature_analysis_univariate')

    reports.feature_analysis(train_X,f'{reports_path}/feature_analysis_report.html')

    curated_columns = list(
    set(train_X.columns.to_list()) 
    - set(['manufacturer', 'inventory_id', 'ext_grade', 'source_channel',
           'tgt_enc_iter_impt_platforms', 'ext_model_family',
           'order_no', 'line', 'inventory_id',
           'gp', 'selling_price', 'selling_cost','invoice_no','customername'])
    )

    train_X = train_X[curated_columns]
    cols = train_X.columns.to_list()
    all_plots = {}
    for ii, col1 in enumerate(cols): 
        for jj in range(ii+1, len(cols)):
            col2 = cols[jj]
            out = eda.get_bivariate_plots(train_X, x_cols=[col1], y_cols=[col2])
            all_plots.update({f'{col2} vs {col1}': out})

    reports.create_report(all_plots, path=reports_path, name='feature_analysis_bivariate')
    print("feature analysis bivariate generated")
    reports.feature_interactions(train_X,f'{reports_path}/feature_interaction_report.html')
    print("feature_interactions generated")
    reports.key_drivers(train_X,train_y,f'{reports_path}/key_drivers_report.html')
    print("key drivers generated")
    reports.key_drivers(train_X,train_y,f'{reports_path}/key_drivers_report_shap.html', quick=False)
    print("key drivers shap generated")
    reports.data_exploration(train_X,train_y,f'{reports_path}/data_exploration_report.html')
    print("data data_exploration generated")
    cols = list(train_X.columns)
    vif = eda.calc_vif(train_X)
    while max(vif.VIF) > 15:
        #removing the largest variable from VIF
        cols.remove(vif[(vif.VIF==vif.VIF.max())].variables.tolist()[0])
        vif = eda.calc_vif(train_X[cols])
    
    reg_vars = vif.query('VIF < 15').variables
    reg_vars = list(reg_vars)

    reg_ppln = Pipeline([
    ('', FunctionTransformer(_custom_data_transform, kw_args={'cols2keep':reg_vars})),
    ('Linear Regression', SKLStatsmodelOLS())
    ])

    test_X = get_dataframe(
        features_transformer.transform(test_X), 
        get_feature_names_from_column_transformer(features_transformer)
    )
    test_X = test_X[curated_columns]

    reg_linear_report = RegressionReport(model=reg_ppln, x_train=train_X, y_train=train_y, x_test= test_X, y_test= test_y, refit=True)
    reg_linear_report.get_report(include_shap=False, file_path=f'{reports_path}/regression_linear_model_report')
    print("regression_linear_model_report generated")
    imp_features = ['model_family','sku','unit_cost','condition','brand','business_unit']

    estimator = XGBRegressor()
    xgb_training_pipe2 = Pipeline([
        ('', FunctionTransformer(_custom_data_transform, kw_args={'cols2keep':imp_features})),
        ('XGBoost', XGBRegressor())
    ])

    parameters = {
   'gamma':[0.03],
   'min_child_weight':[6],
   'learning_rate':[0.1],
   'max_depth':[3],
   'n_estimators':[500], 
    }
    est = XGBRegressor()
    xgb_grid = GridSearchCV(est,
                            parameters,
                            cv = 2,
                            n_jobs = 4,
                            verbose=True)

    xgb_grid.fit(train_X, train_y)

    xgb_pipeline_final = Pipeline([
    ('', FunctionTransformer(_custom_data_transform, kw_args={'cols2keep':imp_features})),
    ('XGBoost', xgb_grid.best_estimator_)
    ])
    xgb_pipeline_final.fit(train_X, train_y)

    reg_tree_report = RegressionReport(model=xgb_pipeline_final, x_train=train_X, y_train=train_y, x_test= test_X, y_test= test_y)
    reg_tree_report.get_report(include_shap=False, file_path=f'{reports_path}/regression_tree_model_report')
    print("regression_tree_model_report generated")
    reg_tree_report = RegressionReport(model=xgb_pipeline_final, x_train=train_X, y_train=train_y, x_test= test_X, y_test= test_y)
    reg_tree_report.get_report(include_shap=True, file_path=f'{reports_path}/regression_tree_model_report_withshap')
    print("regression_tree_model_report shap generated")
    model_pipelines = [reg_ppln, xgb_pipeline_final]
    model_comparison_report = RegressionComparison(models=model_pipelines,x=train_X, y=train_y)
    model_comparison_report.get_report(file_path=f'{reports_path}/regression_comparison')
    print("regression_comparison_report generated")
    reg_obj = RegressionReport(model=reg_ppln, x_train=train_X, y_train=train_y, x_test= test_X, y_test= test_y, refit=True)
    reg_obj.add_metric("Adj R^2", adjusted_r2, more_is_better=True, default_params={"idv":13})
    reg_obj.remove_metric("MAPE")
    def plot_func():
        train_plot = create_scatter(reg_obj.y_train, reg_obj.yhat_train, x_label="y train", y_label="yhat train")
        test_plot = create_scatter(reg_obj.y_test, reg_obj.yhat_test, x_label="y test", y_label="yhat test")
        return train_plot + test_plot
    reg_obj.add_eval_plot("y vs y hat", plot_func)
    reg_obj.remove_eval_plot("residual_plot")

    reg_obj.get_report(include_shap=False, file_path=f'{reports_path}/customized_regression_report')
    print("regression_comparison_report customized generated")
def gen_classification_reports():
    reports_path = op.join(HERE, 'classification')
    config_path = op.join(get_package_path(), '..', 'production', 'classification', 'python','conf', 'config.yml')
    context = create_context(config_path)
    data = dict()
    for i in dataset.list_datasets(context):
        if '/raw/' in i:
            key_ = i.replace('/raw/','')+'_df'
            data[key_] = dataset.load_dataset(context,i)
            # Standardize column names
            data[key_].columns = string_cleaning(data[key_].columns,lower=True)
    health_reports_gen = [health.summary_report(data[x],save_path=f'{reports_path}/health_report_'+x+'.html') for x in data.keys()]

    train_X = dataset.load_dataset(context, "train/attrition/features")
    train_y = dataset.load_dataset(context, "train/attrition/target")
    test_X = dataset.load_dataset(context, "test/attrition/features")
    test_y = dataset.load_dataset(context, "test/attrition/target")

    train_customers=train_X['customer_code'].tolist()
    test_customers=train_X['customer_code'].tolist()
    ref_date_for_churn = r'2013-05-01'
    ref_date=pd.to_datetime(ref_date_for_churn)

    num_columns = train_X.select_dtypes('number').columns

    feature_generation_ppln = Pipeline([('custom_features_generation', CustomFeatureGeneration(context=context, ref_date='2013-05-01')),])

    train_X = feature_generation_ppln.fit_transform(train_X, train_y)
    test_X = feature_generation_ppln.transform(test_X)
    train_X.set_index('customer_code', inplace=True)
    test_X.set_index('customer_code', inplace=True)
    train_y.set_index('customer_code', inplace=True)
    test_y.set_index('customer_code', inplace=True)

    bin_columns = ['overall_avg_sales_pri','overall_avg_roi_without_udaan_with_sub']
    binning_transformer = ColumnTransformer([
        ('binn',WoeBinningTransformer(encode='onehot'),bin_columns)
        ],remainder='passthrough')

    train_X_binned = get_dataframe(
        binning_transformer.fit_transform(train_X, train_y['target']), 
        get_feature_names_from_column_transformer(binning_transformer)
    )


    test_X_binned = get_dataframe(
        binning_transformer.transform(test_X), 
        get_feature_names_from_column_transformer(binning_transformer)
    )

    train_X_binned.index = train_X.index
    test_X_binned.index = test_X.index
    train_X = train_X_binned.infer_objects()
    test_X = test_X_binned.infer_objects()

    outlier_transformer = Outlier(method='percentile')
    train_X = outlier_transformer.fit_transform(train_X)
    cat_columns = train_X.select_dtypes('object').columns
    num_columns = train_X.select_dtypes('number').columns

    features_transformer = ColumnTransformer([
    # categorical features encoding
    ('onehot_encoding', OneHotEncoder(use_cat_names=True), cat_columns),
    
    # missing value imputations all columns except 'days_in_business'
    ('simple_imputation_constant', SimpleImputer(strategy='constant', fill_value=0), list(set(num_columns) - set(['days_in_business']))),
    
    # imputing days in business
    ('simple_imputation_median', SimpleImputer(strategy='median'), ['days_in_business']),
    ])

    train_X = get_dataframe(
    features_transformer.fit_transform(train_X, train_y), 
    get_feature_names_from_column_transformer(features_transformer)
    )
    univariate_plot = eda.get_density_plots(train_X, cols=['last_6_months_invoice_count', 'overall_mean_simple_avg_allocated_percent'])
    # save the plots are html
    print("univariate generated")
    reports.create_report({'univariate': univariate_plot}, path=reports_path, name='feature_analysis_univariate')
    print("feature analysis generated")
    health.feature_analysis(train_X.copy(),f'{reports_path}/feature_analysis_report.html')

    binary_num_columns = [x for x in train_X.columns if train_X[x].dropna().nunique()<=2]

    corr_table = eda.get_correlation_table(train_X[list(set(train_X.columns).difference(set(binary_num_columns)))])
    corr_table_drop = corr_table[corr_table["Abs Coer Coef"] > 0.6]
    columns_to_be_dropped = ['ref_date']
    columns_to_be_dropped = columns_to_drop(corr_table, features_to_be_dropped=columns_to_be_dropped, corr_threshold=0.6)

    curated_columns = list(set(train_X.columns) - set(columns_to_be_dropped))

    all_plots = dict()
    select_cols_for_bivariate_plots = list(set(curated_columns).difference(binary_num_columns))
    for ii, col1 in enumerate(select_cols_for_bivariate_plots): 
        for jj in range(ii+1, len(select_cols_for_bivariate_plots)):
            col2 = select_cols_for_bivariate_plots[jj]
            out = eda.get_bivariate_plots(train_X, x_cols=[col1], y_cols=[col2])
            all_plots.update({f'{col2} vs {col1}': out})

    reports.create_report(all_plots, path=reports_path, name='feature_analysis_bivariate')
    print("feature analysis bivariate generated")
    health.feature_interactions(train_X[curated_columns],f'{reports_path}/feature_interaction_report.html')
    print("feature inteactions generated")
    health.key_drivers(train_X, train_y[['target']],f'{reports_path}/key_drivers_report.html')
    print("key drivers generated")
    health.data_exploration(train_X,train_y,f'{reports_path}/data_exploration_report.html')
    print("data data_exploration generated")
    cols_vif_analysis = curated_columns.copy()
    vif = eda.calc_vif(train_X[cols_vif_analysis])
    while vif.VIF.max() > 15:
        #removing the largest variable from VIF
        print(len(cols_vif_analysis))
        cols_vif_analysis.remove(vif[(vif.VIF==vif.VIF.max())].variables.tolist()[0])
        vif = eda.calc_vif(train_X[cols_vif_analysis])
    reg_vars = vif.variables.tolist()

    variance_df = (train_X[reg_vars].var())
    reg_vars=variance_df[variance_df>0.1].index.tolist()

    logit_ppln = Pipeline([
    ('', FunctionTransformer(_custom_data_transform, kw_args={'cols2keep':reg_vars})),
    ('estimator', SKLStatsmodelLogit(method="l-bfgs-b"))
    ])


    test_X = get_dataframe(
        features_transformer.transform(test_X), 
        get_feature_names_from_column_transformer(features_transformer)
    )

    cols_not_in_test = list(set(curated_columns) - set(test_X.columns))
    cols_not_in_test_df = dict.fromkeys(cols_not_in_test, 0)
    test_X = test_X.assign(**cols_not_in_test_df)
    test_X = test_X[curated_columns]

    reg_logit_report = ClassificationReport(model=logit_ppln, x_train=train_X, y_train=train_y['target'], x_test= test_X, y_test= test_y['target'], refit=True)
    reg_logit_report.get_report(include_shap=False, file_path=f'{reports_path}/classification_logistic_model_report')
    print("classification report linear generated")
    reg_logit_report = ClassificationReport(model=logit_ppln, x_train=train_X, y_train=train_y['target'], x_test= test_X, y_test= test_y['target'], refit=True)
    reg_logit_report.get_report(include_shap=True, file_path=f'{reports_path}/classification_logistic_model_report_with_shap')
    print("classification report linear shap generated")
    estimator = RandomForestClassifier()
    rf_training_pipe_init = Pipeline([
        ('', FunctionTransformer(_custom_data_transform, kw_args={'cols2keep':curated_columns})),
        ('estimator', RandomForestClassifier())
    ])
    rf_training_pipe_init.fit(train_X, train_y)
    imp = pd.DataFrame({'importance': rf_training_pipe_init['estimator'].feature_importances_})
    imp.index = curated_columns
    imp.sort_values('importance',inplace=True)

    imp_features = imp.tail(10).index.to_list()
    estimator = RandomForestClassifier()
    rf_training_pipe2 = Pipeline([
    ('', FunctionTransformer(_custom_data_transform, kw_args={'cols2keep':imp_features})),
    ('estimator', RandomForestClassifier())
    ])
    parameters = {
    'n_estimators': [200],
    'max_features': ['auto'],
    'max_depth': [4, 5],
    'criterion': ['gini', 'entropy']
    }
    est = RandomForestClassifier()
    rf_grid = GridSearchCV(est,
                           parameters,
                           cv = 2,
                           n_jobs = 2,
                           verbose=True)

    rf_grid.fit(train_X[imp_features],
                train_y)
    rf_pipeline_final = Pipeline([
    ('', FunctionTransformer(_custom_data_transform, kw_args={'cols2keep':imp_features})),
    ('estimator', rf_grid.best_estimator_)
    ])
    rf_pipeline_final.fit(train_X, train_y)

    reg_tree_report = ClassificationReport(model=rf_pipeline_final, x_train=train_X, y_train=train_y['target'], x_test= test_X, y_test= test_y['target'], refit=True)
    reg_tree_report.get_report(include_shap=False, file_path=f'{reports_path}/classification_tree_model_report')
    print("classification report tree generated")
    model_pipelines = [logit_ppln, rf_pipeline_final]
    model_comparison_report = ClassificationComparison(models=model_pipelines,x=train_X, y=train_y)
    model_comparison_report.get_report(file_path=f'{reports_path}/classification_comparison')
    print("classification comparison generated")

if __name__ == "__main__":
    if sys.argv[1] == 'regression':
        gen_regression_reports()
    elif sys.argv[1] == 'classification':
        gen_classification_reports()