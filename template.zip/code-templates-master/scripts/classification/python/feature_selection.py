import pandas as pd
from sklearn.feature_selection import SelectFromModel, RFE
from mlxtend.feature_selection import SequentialFeatureSelector as sfs 
from sklearn.base import BaseEstimator, TransformerMixin
from model_gen import load_class
from sklearn.preprocessing import FunctionTransformer

class FeatureSelector(BaseEstimator,TransformerMixin):
    '''Base class that implements the fit transform on select features function
    Parameters:
    -----------
    cfg: dict
        dictionary object containing the config about the feature selection parameters
    x_train: dataframe
        dataframe for train data
    y_train: Series or np.array
        
    '''

    def __init__(self,cfg):
        self.cfg=cfg

    def fit(self,X,y=None):
        self.func_transformed=FunctionTransformer(select_features,kw_args={'cfg':self.cfg,'y_train':y})
        self.func_transformed.fit(X,y)
        self.output,self.features=self.func_transformed.transform(X)
        return self
    def transform(self,X,y=None):
        df_out=self.output.transform(X)
        x_train=pd.DataFrame(df_out,columns=self.features)
        return x_train

def select_features(x_train,y_train,cfg=None):
    '''This function takes the config, train data to select the features using SelectFromModel or SequentialFeatureSelector
    SelectFromModel takes estimator(Lasso/Ridge) as an input and after fitting we can select the features whose coefs are greater than 0
    SequentialFeatureSelector from mlxtend does a forward or backward feature selection based on the estimator we choose
    Parameters:
    -----------
    cfg: dict
        dictionary object containing the config about the feature selection parameters
    x_train: dataframe 
        train data to fit the estimator
    y_train: Series or np.array
        target variable 
    
    Returns:
    --------
    selected_features_list: list 
        list of features selected
    
    df_metrics: DataFrame
        features with scores from feature selection method
    
    '''
    fe_var=cfg['feature_selection'][cfg['fs']] # recursion or regularisation model
    _estimator = load_class(fe_var['estimator']) # loads the model constructor
    estimator_params=fe_var['estimator_params'] # estimator parameters
    if cfg['fs']=='regularization':    
        fe_sel_=SelectFromModel(_estimator(**estimator_params))
        fe_sel_.fit(x_train,y_train)
        
        selected_features = x_train.columns[(fe_sel_.get_support())] #get_support returs list of Bool values where a column is important or not
        df_metrics = pd.DataFrame({'feature_names' : list(x_train.columns)
                                   , 'score' : fe_sel_.estimator_.coef_[0]}) 
        
        print('selected features: {}'.format(selected_features))
        return selected_features, df_metrics
    
    else:
        
        params=fe_var['fs_params']
        fe_sel_=sfs(_estimator(**estimator_params),**params)
        fe_sel_.fit(x_train,y_train)
        
        selected_features = list(fe_sel_.k_feature_names_)
        
        df_metrics = pd.DataFrame.from_dict(fe_sel_.get_metric_dict()).T.sort_values(['avg_score'], ascending=False)
        df_metrics = df_metrics[['feature_names','avg_score']]
        
        print('selected features: {}'.format(selected_features)) #k_feature_names_ gives the column names that are selected
        return selected_features, df_metrics 