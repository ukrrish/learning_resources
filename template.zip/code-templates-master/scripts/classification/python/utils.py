## Imports
import yaml
import fsspec

def load_yml(file_path, *, ctxt=None, **kwargs):
    
    """
    
    Objective: This function is used to read yaml config files.    
    
    Input: file_path : File path of configuration.
    
    Output: yaml file with configurations.               
    
    """
    
    fs = fsspec if ctxt is None else ctxt.fs(file_path)
    with fs.open(file_path, mode="r") as fp:
        return yaml.safe_load(fp, **kwargs)