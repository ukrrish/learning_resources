## Imports
import importlib
import numpy as np
import pandas as pd

from utils import load_yml
from collections import defaultdict

from sklearn.model_selection import GridSearchCV,ParameterGrid

def load_class(qual_cls_name):
    
    """
    
    Objective: This function is used to load estimator class from specified string.
    
    Input: qual_cls_name : Estimator name.
    
    Output: Loads estimator class.
    
    """
    
    module_name, cls_name = qual_cls_name.rsplit('.', 1)
    try:
        mod = importlib.import_module(module_name)
    except Exception:
        logger.exception(f'Failed to import module : {module_name}')
    else:
        return getattr(mod, cls_name)

def score_summary( grid_searches, sort_by='mean_score'):
    
    """
    
    Objective: This function is used to collate performance for each grid 
               search model output.    
    
    Input: grid_searches : A dictionary with model classifier parameters
           sort_by : Parameter to sort dataframe by metric. 
    
    Output: The function generates an model outputs with model parameters and score.
    
    """
    
    def row(key, scores, params):
        d = {
                'estimator': key,
                'min_score': min(scores),
                'max_score': max(scores),
                'mean_score': np.mean(scores),
                'std_score': np.std(scores),
        }
        return pd.Series({**params,**d})

    rows = []
    for k in grid_searches:
        print(k)
        params = grid_searches[k].cv_results_['params']
        scores = []
        for i in range(grid_searches[k].cv):
            key = "split{}_test_score".format(i)
            r = grid_searches[k].cv_results_[key]        
            scores.append(r.reshape(len(params),1))

        all_scores = np.hstack(scores)
        for p, s in zip(params,all_scores):
            rows.append((row(k, s, p)))

    df = pd.concat(rows, axis=1).T.sort_values([sort_by], ascending=False)

    columns = ['estimator', 'min_score', 'mean_score', 'max_score', 'std_score']
    columns = columns + [c for c in df.columns if c not in columns]

    return df[columns]

def train_model(file_path, x_train, y_train):
    
    """
    
    Objective: This function is used to run the gridseach across different 
               classification algorithms.    
    
    Input:  file_path : configuration file path.
            x_train : Independent variables in train dataset.  
            y_train : Dependent variables in train dataset. 
    
    Output: The functions generates the model output with paramters
            and performance to a csv file.
    
    """

    config_file = load_yml(file_path)
    estimators_cfg = load_yml(config_file['estimator_config_path'])
    
    grid_searches = defaultdict()
    param_grid = defaultdict()
    estimators = []
    
    for estimator_name,estimator_ in estimators_cfg['classifier'].items():
        estimator_ = load_class(estimator_)
        params_grid = estimators_cfg['params'][estimator_name]
        
        print(estimator_)
        
        grid_search = GridSearchCV(
            estimator_(),
            param_grid=params_grid,
            cv=5,
            scoring="accuracy",
            return_train_score=True,
            verbose=100)

        grid_search.fit(x_train, y_train)
        
        print(f"Best estimator : {grid_search.best_estimator_}")
        grid_searches[estimator_name] = grid_search

    summary = score_summary(grid_searches)
    summary.to_csv(config_file['output_path'],index=False)

    ## Best model from grid search results (by mean score)
    best_gridsearch_model = estimators_cfg['classifier'][summary['estimator'].iloc[0]]
    best_fit = load_class(best_gridsearch_model)

    ## Best model's parameters from grid search results (by mean score)
    best_params = summary.iloc[0,5:].dropna().to_dict()

    return best_fit(**best_params)
	
def list_models_from_config(cfg):
    """List all combinations of models from the config
    Parameters:
    ----------
    cfg: dict
        dictonary that contains the configuration details of models
    Returns:
    --------
    models: list
        List of models along with params grid are returned
    """
    models = []
    assert cfg["classifier"] is not None, "No models specified in config in config"
    for algo, algo_spec in cfg["classifier"].items():
        _estimator = load_class(algo_spec)
        if cfg["params"][algo] is not None:
            grid_params = list(ParameterGrid(cfg["params"][algo]))
            for params in grid_params:
                models.append(_estimator(**params))
        else:
            models.append(_estimator())
    return models