## Imports
import pandas as pd
import tigerml.dataframe as td
from tigerml.dp import prep_data, Imputer, Encoder, DataProcessor, outliers

def data_processor(dataset, target_col, remove_cols):
    
    """
    
    Objective: This function is used to binarize the target variable.
    
    Input: dataset : Input dataframe. 
           target_col : Target variable.
           remove_cols : Columns to remove from input dataframe.
    Output: dataset : processed dataset.
    
    """
    
    
    if dataset[target_col].dtypes!=int:

        majority_class = dataset[target_col].value_counts(ascending = False).index[0]
        dataset[target_col] = dataset[target_col].apply(lambda x: 0 if x==majority_class else 1)

    else:
        pass
            
    dataset.drop(remove_cols, axis = 1, inplace = True)
    
    return dataset

def cols_naming_standards(cols_list):
    
    """
    
    Objective: This function is standarize column names of a dataframe.
    
    Input: cols_list : list of column names of the dataframe.
    
    Output: The function returns standardized column names.

    """


    cols_list = [i.replace(" ","_").lower() for i in cols_list]
    return cols_list

def load_dataset(file_path, target_col, drop_cols):
    
    """
    
    Objective: This function is used to process input dataset.
    
    Input: file_path   : Config file path.
    	   target_col  : Target variable.
           remove_cols : Columns to remove from input dataframe. 
    
    Output: The function loads and processes input as tiger dataframe.
    
    """
    
    df = td.read_csv(file_path)
    df = data_processor(df, target_col, drop_cols)
    df.columns = cols_naming_standards(df.columns)

    return df