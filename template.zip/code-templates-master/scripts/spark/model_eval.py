"""
Model Evaluation and Interpretation
"""
# TBD

# -----------------------------------------------------------------------
# Imports
# -----------------------------------------------------------------------
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import seaborn as sns


from collections import defaultdict
from IPython.display import display, HTML, display_html
from pyspark_dist_explore import Histogram, hist, distplot, pandas_histogram

from pyspark.sql import functions as F
from pyspark.sql import types as DT
from pyspark.ml.evaluation import RegressionEvaluator, BinaryClassificationEvaluator
from handy_spark_cd import BinaryClassificationMetrics
from pyspark.ml.linalg import DenseVector

from dp import _identify_col_data_type
sns.set()

# -----------------------------------------------------------------------
# Regression - Individual Model
# -----------------------------------------------------------------------
_VALID_REGRESSION_METRICS_ = {
	'Explained Variance': 'exp_var',
	'RMSE': 'rmse',
	'MAE': 'mae',
	'MSE': 'mse',
	'MAPE': 'mape',
	'WMAPE': 'wmape',
	'R.Sq': 'r2'
}

def get_regression_metrics(spark, data, y_col , y_pred_cols):
	"""Function to generate the regression summary and metrics for a model trained

	Parameters
	----------
		spark: SparkSession
		data: pyspark.sql.DataFrame
		y_pred:  list(str)
			list of col_names for predictions
			if list of 1 represents the results for 1 model
			len(list)>0 implies multiple model results are presented here
		y:  str
			colname of the actuals in the data

	Returns
	-------
		metrics: pyspark.sql.DataFrame
			metric included are explained_variance, mae, mape, mse, Rsq, wmape
			wmape uses custome function, rest use the Regression Evaluator
	"""
	df = defaultdict(list)
	metrics = _VALID_REGRESSION_METRICS_
	for metric in metrics.keys():
		df['metric'].append(metric)
		for y_pred_col in y_pred_cols:
			if metrics[metric] == 'wmape':
				val = _wmape(spark, data, y_col, y_pred_col)
			elif metrics[metric] == 'mape':
				val = _mape(spark, data, y_col, y_pred_col)
			elif metrics[metric] == 'exp_var':
				val = _exp_var(spark, data, y_col, y_pred_col)
			else:
				e = RegressionEvaluator(labelCol=y_col, predictionCol=y_pred_col)
				val = e.evaluate(data, {e.metricName: metrics[metric]})
			df[y_pred_col].append(val)
	df = dict(df)
	df = pd.DataFrame(df)
	df = spark.createDataFrame(df)
	return(df)

def _wmape(spark, data, y_col, y_hat_col):
	"""Function to calculate the WMAPE in a data

	Parameters
	----------
		spark: 
		data - spark.DataFrame
		y_col - str
		y_hat_col - str

	Returns
	-------
		wmape - numeric
	"""
	wmape = data.groupBy().agg((F.sum(F.abs(F.col(y_hat_col)-F.col(y_col)))/F.sum(F.col(y_col)))).collect()[0][0]
	return(wmape)

def _mape(spark, data, y_col, y_hat_col):
	"""Function to calculate the WMAPE in a data

	Parameters
	----------
		spark: SparkSession
		data:  pyspark.sql.DataFrame
		y_col: str
		y_hat_col: str

	Returns
	-------
		mape: numeric
	"""
	mape = data.groupBy().agg((F.mean(F.abs(F.col(y_hat_col)-F.col(y_col))/F.col(y_col)))).collect()[0][0]
	return(mape)

def _exp_var(spark, data, y_col, y_hat_col):
	"""Function to calculate the WMAPE in a data

	Parameters
	----------
		spark: SparkSession
		data - pyspark.sql.DataFrame
		y_col - str
		y_hat_col - str

	Returns
	-------
		exp_var - numeric
		explainedVariance = 1 - variance(y - \hat{y}) / variance(y)
	"""
	exp_var = data.groupby().agg(F.pow(F.stddev(F.col(y_col)-F.col(y_hat_col)), 2)/F.pow(F.stddev(F.col(y_col)), 2)).collect()[0][0]
	return(exp_var)

def generate_regression_plots(spark, data, y_col, y_pred_col):
	"""Function to generate the regression summary and metrics for a model trained

	Parameters
	----------
		spark: SparkSession
		data: pyspark.sql.DataFrame
		y_col: str
		y_pred_col: str

	Returns
	-------
		residual_distribution_plot - frequency dist
		actual v predicted - scatter
		residual vs predicted - scatter
	"""

	data = data.withColumn("residual", F.col(y_pred_col) - F.col(y_col))
	fig, axes = plt.subplots(nrows=3, ncols=1)
	fig.set_size_inches(10, 20)

	# Residual Distribution Plot
	hist(axes[0], [data.select("residual")], bins = 20)
	axes[0].set_title('01. Residual Histogram')

	# FIX ME Is toPandas inevitable for spark plots
	# Actual vs Predicted Scatter
	data.select(y_col, y_pred_col).toPandas().plot(kind='scatter', x=y_col, y=y_pred_col, ax=axes[1])
	axes[1].set_title('02. Actual vs Predicted')

	# Residual vs Predicted Scatter
	data.select("residual", y_pred_col).toPandas().plot(kind='scatter', x=y_pred_col, y='residual', ax=axes[2])
	axes[2].set_title('03. Residual vs Predicted')

	plt.show()

	return

# FIX ME
# Interactive y,yhat plot
# How can we get this in pyspark

# -----------------------------------------------------------------------
# Classification - Individual Model (WIP)
# -----------------------------------------------------------------------
_BINARY_CLASSIFICATION_METRICS_ = {
	'Accuracy': 'accuracy',
	'F1 Score': 'f1',
	'TPR': 'tpr',
	'FPR': 'fpr',
	'Precision': 'precision',
	'Recall': 'recall',
	'AuROC': 'auROC',
	'AuPR': 'auPR',
}

def get_binary_classification_metrics(spark, data, y_col , y_pred_cols, probability_cols, threshold=0.50, sig=2):
	"""Function to generate the regression summary and metrics for a model trained

	Parameters
	----------
		spark: SparkSession
		data: pyspark.sql.DataFrame
		y_pred_cols: list(str)
			list of col_names for predictions
			if list of 1 represents the results for 1 model
			len(list)>0 implies multiple model results are presented here
		y_col: str
			colname of actuals in the data

		probability_cols: list(str)
			list of col_names for probabilities of predictions
			if list of 1 represents the results for 1 model
			len(list)>0 implies multiple model results are presented here
			(have to orderd similar to ref the y_pred_cols)
		threshold: double
			threshold to consider for calculation of metrics
			0.5 y default
		sig: int
			significance in terms of decimals for metrics as well as threshold

	Returns
	-------
		metrics: pyspark.sql.DataFrame
	"""
	relevant_cols = [y_col] + y_pred_cols + probability_cols
	data = data.select(*relevant_cols)
	df = defaultdict(list)
	metrics = _BINARY_CLASSIFICATION_METRICS_
	for metric in metrics.keys():
		df['metric'].append(metric)

	for idx, y_pred_col in enumerate(y_pred_cols):
		bcm = BinaryClassificationMetrics(data, scoreCol=probability_cols[idx], labelCol=y_col)
		conf_matrix = bcm.confusionMatrix(threshold=threshold).toArray().tolist()
		tp = conf_matrix[1][1]
		fp = conf_matrix[0][1]
		tn = conf_matrix[0][0]
		fn = conf_matrix[1][0]

		accuracy = (tp+tn)/(tp+fp+tn+fn)
		tpr = tp/(tp+fn)
		fpr = fp/(fp+tn)
		precision = tp/(tp+fp)
		recall = tp/(tp+fn)
		f1 = 2*precision*recall/(precision+recall)

		auROC = bcm.areaUnderROC
		auPR = bcm.areaUnderPR

		for metric in df['metric']:
			val = round(eval(metrics[metric]),sig)
			df[y_pred_col].append(val)
	df = pd.DataFrame(df)
	df = spark.createDataFrame(df)
	return(df)



def get_binary_classification_plots(spark, data, y_col , y_pred_col, probability_col, feature_cols=[], threshold=0.5, feature_plots=False):
	"""Function to generate the regression summary and metrics for a model trained

	Parameters
	----------
		spark: SparkSession
		data: pyspark.sql.DataFrame
		y_pred_col: str
			column of prediction label in the data
		y_col: str
			colname of actuals in the data
		probability_cols: str
			colname of probability column in the data
		feature_cols: list(str)
			columns we consider as features in the data
			useful for feature level comparison of the performance
			they have to be present as columns in the data
		threshold: double
			threshold to consider for calculation of metrics
			0.5 y default
		sig: int
			significance in terms of decimals for metrics as well as threshold

	Returns
	-------
		Plots the following Plots
		Default - Confusion Matrix, ROC Curve, PR Curve
		if feature plots are True.
			plot relevant feature plots
	"""
	bcm = BinaryClassificationMetrics(data, scoreCol=probability_col, labelCol=y_col)
	fig, axs = plt.subplots(1, 3, figsize=(18, 6))
	bcm.plot_roc_curve(ax=axs[0])
	bcm.plot_pr_curve(ax=axs[1])

	
	cm = bcm.print_confusion_matrix(threshold=threshold)
	if 'Predicted' in cm.columns[0]:
		xlabel='Predicted'
		ylabel='Actual'
	else:
		xlabel='Actual'
		ylabel='Predicted'

	cm.columns=[x[1] for x in cm.columns]
	cm.index=[x[1] for x in cm.index]

	sns.heatmap(cm, annot=True, ax = axs[2])
	axs[2].set_title('Confusion Matrix')
	axs[2].set_xlabel(xlabel)
	axs[2].set_ylabel(ylabel)
	#fig.suptitle('Evaluation Plots', fontsize=10)
	plt.show()

	if feature_plots:
		# Plotting Interaction Plots with Confusion Cell
		data = generate_confusion_cell_col(spark, data, y_col, probability_col, confusion_cell_col="confusion_matrix_cell", threshold=threshold)
		fig, axs = plt.subplots(nrows=len(feature_cols), ncols=1 ,figsize=(18, 6*len(feature_cols)))
		for idx, feature in enumerate(feature_cols):
			axs[idx] = plot_interaction(spark, data, feature, "confusion_matrix_cell", ax=axs[idx])
		#fig.suptitle('Feature v Confusion Plots', fontsize=10)
		plt.show()



def generate_confusion_cell_col(spark, data, y_col, probability_col, confusion_cell_col="confusion_matrix_cell", threshold=0.5):
	"""Column to Generate the column to define the cell of confusion matrix the row belongs to

	Paramters:
	----------
		spark: SparkSession
		data: pyspark.sql.DataFrame
		y_col: str
		probability_col: str
		threshold: numeric
			probability threshold for calculating the prediction labels.

	Returns
	-------
		df - pyspark.sql.DataFrame
	"""

	def _get_label(probabilities):
		if probabilities[1] > threshold:
			return(1.0)
		else:
			return(0.0)

	def _get_conf_cell(pred_label, actual_label):
		if pred_label==1:
			if actual_label==1:
				return('TP')
			else:
				return('FP')
		else:
			if actual_label==0:
				return('TN')
			else:
				return('FN')

	_get_label = F.udf(_get_label, DT.DoubleType())
	_get_conf_cell = F.udf(_get_conf_cell, DT.StringType())

	data = data.withColumn("pred_label", _get_label(F.col(probability_col)))
	data = data.withColumn(confusion_cell_col, _get_conf_cell(F.col("pred_label"), F.col(y_col)))

	return(data)



def plot_interaction(spark, data, col1, col2, ax):
	"""Function to plot interaction b/w 2 columns in a dataframe
	Plots - 
		continuous vs continuous - scatter plot
		continuous vs categorical - distribution plot
		categorical vs categorical - stacked bar plot

	Parameters
	----------
		spark: SparkSession
		data - pyspark.sql.DataFrame
		col1 - str
		col2 - str
		ax - matplotlib axis

	Returns
	-------
		ax - matplotlib axis
	"""
	col1_type = _identify_col_data_type(data, col1)
	col2_type = _identify_col_data_type(data, col2)

	if (col1_type=="date_like") | (col2_type=="date_like"):
		raise(NotImplementedError("Datelike column interactions not applicable as of now"))

	if (col1_type!="numerical") & (col2_type!="numerical"):
		ax = stacked_bar_plot(spark, data, col1, col2, ax)
	elif col1_type!="numerical":
		ax = distribution_plot(spark, data, cat_col=col1, cont_col=col2, ax=ax)
	else:
		ax = distribution_plot(spark, data, cat_col=col2, cont_col=col1, ax=ax)
		
	return(ax)

def scatter_plot(spark, data, col1, col2, ax):
	"""Generating scatter plot for interaction b.w 2 continuous columns

	Parameters
	----------
		spark: SparkSession
		data: pyspark.sql.DataFrame
		col1: str
		col2: str
		ax: matplotlib axis

	Returns
	-------
		ax: matplotlib axis
	"""
	x = data.select(x).collect()
	y = data.select(x).collect()
	plt.scatter(x=x, y=y, market='o', ax=ax)
	ax.set_title("Scatter Plot")
	ax.set_xlabel(col1)
	ax.set_ylabel(col2)
	return(ax)


def distribution_plot(spark, data, cat_col, cont_col, ax):
	"""Generating scatter plot for interaction b.w a categorical and continuous variable

	Parameters
	----------
		spark: SparkSession
		data: pyspark.sql.DataFrame
		cat_col: str
			categorical column name
		cont_col: str
			numeric column name
		ax: matplotlib axis
	Returns
	-------
		ax: matplotlib axis
	"""
	df = data.select(cat_col,cont_col).toPandas()
	df.groupby(cat_col)[cont_col].plot(kind='density', legend=True, ax=ax)
	ax.set_title("Density Plot("+cont_col+")")
	return(ax)


def stacked_bar_plot(spark, data, col1, col2, ax):
	"""Generating scatter plot for interaction b.w a categorical and continuous variable

	Parameters
	----------
		spark: SparkSession
		data: pyspark.sql.DataFrame
		col1: str
		col2: str
		ax: matplotlib axis

	Returns
	-------
		ax: matplotlib axis
	"""
	df = data.groupBy(col1,col2).agg(F.count(F.col(col1)).alias('count')).toPandas()
	df = ((df.groupby([col1,col2])['count'].sum()/df.groupby(col1)['count'].sum())*100).reset_index()
	df = df.pivot(index=col1,columns=col2, values='count')
	df.plot(kind='bar', ax=ax)
	ax.set_title("Stacked Bar Plot")
	ax.set_xlabel(col1)
	return(ax)
	
