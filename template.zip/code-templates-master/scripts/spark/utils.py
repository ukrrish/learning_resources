"""
Common Utility functions
"""
import importlib


def load_class(qual_cls_name):
    """
    Load the class/object from string specified

    Parameters
    ----------
    	qual_cls_name - str
    		string representing the class/estimator

    Returns
    -------
    	class/Object

    Example
    -------
    	>>> load_class('pyspark.ml.regression.RandomForestRegressor')
    	RandomForestRegressor
    """
    module_name, cls_name = qual_cls_name.rsplit(".", 1)
    mod = importlib.import_module(module_name)
    return getattr(mod, cls_name)



def list_models_from_config(cfg):
    """
        List all combinations of models from the config
    """
    models = []
    assert cfg["models"] is not None, "No models specified in config in config"
    for algo, algo_spec in cfg["models"].items():
        _estimator = load_class(algo_spec["estimator"])
        if algo_spec["params"] is not None:
            grid_params = list(ParameterGrid(algo_spec["params"]))
            for params in grid_params:
                models.append(_estimator(**params))
        else:
            models.append(_estimator())
    return models


def flatten_list(args):
    '''To flatten the list of lists
    Parameters:
    -----------
    args: list of lists

    Returns:
    --------
    new_list: flattened list
    '''
    if not isinstance(args, list):
        args = [args]
    new_list = []
    for x in args:
        if isinstance(x, list):
            new_list += flatten_list(list(x))
        # elif isinstance(x, sp.Array):
        #   new_list += flatten_list(list(x))
        else:
            new_list.append(x)
    return new_list

