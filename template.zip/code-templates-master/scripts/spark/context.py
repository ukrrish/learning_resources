class SparkSession:
    from pyspark.sql import SparkSession
    
    def __init__(self, cfg):
        self._cfg = cfg
        self.spark = None   # The Spark Session
        self.sc = None      # The Spark Context
        self.scConf = None  # The Spark Context conf
        
    def CreateSparkSession(self, appName=None, master=None):
        cmd = f'self.SparkSession.builder'
        if (master != None): cmd += f'.master("{master}")'
        if (appName != None): cmd += f'.appName("{appName}")'
        for k,v in self._cfg['spark_config'].items():
                    cmd+=f'.config("{k}","{v}")'
        cmd+='.getOrCreate()'
        self.spark = eval(cmd)
        self.sc = self.spark.sparkContext
        self.scConf = self.sc.getConf()