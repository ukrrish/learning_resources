
# Pre-requisites

* Ensure you have `Miniconda` installed and can be run from your shell. If not, download the installer for your platform here: https://docs.conda.io/en/latest/miniconda.html

     **NOTE**

     * If you already have `Anaconda` installed, pls. still go ahead and install `Miniconda` and use it for development. 
     * If `conda` cmd is not in your path, you can configure your shell by running `conda init`. 


# Getting started

* [Download the repo from gdrive](https://drive.google.com/file/d/177NngnW6GVhzq6psKj7FX45YEKqJq65K/view?usp=sharing), unzip and switch to the root folder

* Setup a development environment and switch to it by running:
```
(base):~/$ conda env create -f env.yml 
(base):~/$ conda activate code-format-exercise
```

The above command should create a conda python environment named `code-format-exercise` 

In case of installation issues, remove and recreate. You can remove by running:
```
(base):~/$ conda remove --name code-format-exercise --all -y
```

# Idiomatic Code Exercise
 - Convert the  `nonstandardcode.py` into a standard format following best coding styles and standards manually.
 - You can check for code format by running.
	 - ```flake8 nonstandardcode.py```
 - Try to fix these bugs manually.
 - For errors saying "black will resolve" run the below to fix.
	 - ```black nonstandardcode.py``` .
 - For errors saying "isort" run the below to fix.
	 - ```isort -rc  nonstandardcode.py``` .
 
 ## Tips
 1. Instead of .py file, a folder can be used to evaluate all .py files recursively. This applies for all the above 3 commands.
 2. Add comment `#noqa` at the end of the line to skip a line from flake8.
 3. Use `setup.cfg` to adjust flake8 error config for your need.
