import re

import arviz as az
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from sklearn import linear_model
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.utils.validation import check_array, check_is_fitted

from BayesFramework import Regression as reg


class CustomSKLLassoCV(BaseEstimator, RegressorMixin):
    """Cusotmer class for LassoCV estimator from scikit-learn package."""

    def __init__(
        self,
        max_iter=10 ** 3,
        cv=None,
        positive_flag=False,
        random_state=None,
        selection="cyclic",
    ):
        """Initialize Estimator.

        Parameters
        ----------
        max_iter : int
            Maximum number of iterations to perform, by default 1000
        cv : int
            Determines the number of folds in cross-validation, by default None
        positive_flag : bool
            Restricts coefficients to be >=0, by default False
        random_state : int
            Set the seed of the pseudo random number generator, by default None
        selection : str {‘cyclic’, ‘random’}
            If set to ‘random’, a random coefficient is updated every iteration rather than looping over features sequentially by default. This often leads to significantly faster convergence.
        """

        self.positive_flag = positive_flag
        self.model = linear_model.LassoCV(
            max_iter=max_iter,
            cv=cv,
            positive=positive_flag,
            random_state=random_state,
            selection=selection,
        )

    def fit(self, X_train, y_train):
        """Fit the model using provided features and target.

        Parameters
        ----------
        X_train : pd.DataFrame or np.Array
            Dataframe/2D Array consisting of independant features
        y_train : pd.DataFrame or np.Array
            Dataframe/2D Array consisting of independant features
        lwr_bound : list
            Lower bound for each coefficient, by default None
        upr_bound : list
            Upper bound for each coefficient, by default None
        """

        # TODO: Add exception handling block
        self.X = X_train.copy()
        self.y = y_train.copy()
        self.nobs = len(self.X)
        self.idv_cols = self.X.columns.to_list()
        if self.positive_flag:
            lwr_bound, upr_bound = self.get_variable_bound(self.X.columns.to_list())
            self.idv_reverse_flag = [
                self.is_reverse(lwr_bound[i], upr_bound[i])
                for i in np.arange(len(self.idv_cols))
            ]
            self.X.loc[:, self.idv_reverse_flag] = (
                -1 * self.X.loc[:, self.idv_reverse_flag]
            )
        else:
            self.idv_reverse_flag = [False for i in np.arange(len(self.idv_cols))]

        self.model.fit(self.X, self.y)
        self.mdl_lambda = self.model.alpha_

        params_df = self.get_params_in_dataframe()
        self.intercept_ = params_df.loc[
            params_df["variable"] == "intercept_", "estimate"
        ].to_list()[0]
        self.coef_ = np.array(
            [
                params_df.loc[params_df["variable"] == i, "estimate"].to_list()[0]
                for i in self.idv_cols
            ]
        )

    def get_variable_bound(self, col_list):
        """Get upper and lower bound for model variables.

        Parameters
        ----------
        name : list of str
            Model variable names

        Returns
        -------
        list of int
        """
        # wk_sold_median_base_price_byppg_log   < -Inf to 0
        # tpr_discount_byppg,ACV_Metrics        <    0 to Inf
        # flag_qtrs & "category_trend"          < -Inf to Inf
        # tpr_discount_byppg_lag1 & lag2        < -Inf to 0
        # monthno                               < -Inf to Inf
        # Competitor Regular Price              < 0 to Inf
        # Competitor  Promoted Discount         < -Inf to 0
        # Interaction                           < -Inf to Inf

        lwr_bound_list = []
        upr_bound_list = []
        for col in col_list:
            if col in [
                "wk_sold_median_base_price_byppg_log",
                "tpr_discount_byppg_lag1",
                "tpr_discount_byppg_lag2",
            ]:
                lwr_bound = -np.inf
                upr_bound = 0
            elif col in [
                "tpr_discount_byppg",
                "ACV_Selling",
                "ACV_TPR_Only",
                "ACV_Feat_Only",
                "ACV_Disp_Only",
                "ACV_Feat_Disp",
            ]:
                lwr_bound = 0
                upr_bound = np.inf
            elif col in [
                "flag_qtr2",
                "flag_qtr3",
                "flag_qtr4",
                "category_trend",
                "monthno",
            ]:
                lwr_bound = -np.inf
                upr_bound = np.inf
            elif len(re.findall(".*RegularPrice.*RegularPrice", col)) > 0:
                lwr_bound = -np.inf
                upr_bound = np.inf
            elif len(re.findall(".*RegularPrice", col)) > 0:
                lwr_bound = 0
                upr_bound = np.inf
            elif len(re.findall(".*PromotedDiscount.*PromotedDiscount", col)) > 0:
                lwr_bound = -np.inf
                upr_bound = np.inf
            elif len(re.findall(".*PromotedDiscount", col)) > 0:
                lwr_bound = -np.inf
                upr_bound = 0
            else:
                lwr_bound = -np.inf
                upr_bound = -np.inf

            lwr_bound_list.append(lwr_bound)
            upr_bound_list.append(upr_bound)

        return lwr_bound_list, upr_bound_list

    def is_reverse(self, lwr, upr):
        """Return flag to reverse variable sign in train data.

        Parameters
        ----------
        lwr : int
            A coefficient's lower bound
        upr : int
            A coefficient's upper bound

        Returns
        -------
        bool
        """
        if lwr < 0 and upr == 0:
            return True
        elif lwr == 0 and upr > 0:
            return False
        elif lwr < 0 and upr > 0:
            return False
        else:
            # Handle rest of the combinations
            # lwr>0 and upr==0 | lwr==0 and upr<0 | lwr==0 and upr==0 | lwr<0 and upr<0 | lwr>0 and upr>0
            return False

    def get_params(self, deep=False):
        """Getter function to obtain the parameters of the estimator.

        Parameters
        ----------
        deep : bool, optional
            WIP, by default False

        Returns
        -------
        dict
            parameters dictionary
        """

        coef_ = self.model.coef_.copy()
        coef_[self.idv_reverse_flag] = -1 * coef_[self.idv_reverse_flag]

        tmp_dict = pd.Series(coef_, index=self.idv_cols).transpose().to_dict()
        tmp_dict["intercept_"] = self.model.intercept_
        return tmp_dict

    def get_params_in_dataframe(self):
        """Getter function to obtain the parameters of the estimator.

        Returns
        -------
        pd.DataFrame
            parameters
        """

        parms_dict = self.get_params()
        params_df = pd.DataFrame.from_records([parms_dict]).transpose().reset_index()
        params_df = params_df.rename(columns={"index": "variable", 0: "estimate"})

        return params_df

    def predict(self, X_test):
        """Score/predict the target variables from the input data.

        Parameters
        ----------
        X_test : pd.DataFrame or np.Array
            Dataframe/2D Array consisting of independant features

        Returns
        -------
        np.Array
            Predictions for the input data
        """

        self.X_test = X_test[self.idv_cols].copy()
        self.X_test.loc[:, self.idv_reverse_flag] = (
            -1 * self.X_test.loc[:, self.idv_reverse_flag]
        )
        return self.model.predict(self.X_test)

    def get_cv_metrics(self):
        """Getter function to obtain the cross-validation results.

        Returns
        -------
        list
            Mean and Standard deviation of MSE
        """

        mse_mean = self.model.mse_path_[
            np.where(self.model.alphas_ == self.mdl_lambda)[0]
        ].mean()
        mse_sd = self.model.mse_path_[
            np.where(self.model.alphas_ == self.mdl_lambda)[0]
        ].std()
        return mse_mean, mse_sd


class SKLBayesian:
    """sklearn wrapper estimator for Bayesian Framework Estimator."""

    def __init__(
        self,
        sampler="nuts",
        no_iter=500,
        no_warmup_iter=500,
        no_chain=4,
        no_leapfrog_steps=10,
        hmc_step_size=0.01,
        re_prior_df=None,
        fe_prior_df=None,
    ):
        """Initialize Estimator.

        Parameters
        ----------
        sampler : str {'nuts', 'hmc'}
            Sampling technique
        no_iter : int
            Number of iterations, by default 500
        no_warmup_iter: int
            Number of warmup iterations, by default 500
        no_chain: int
            Number of chains, by default 4
        no_leapfrog_steps: int
            Number of leapfrog steps, by default 10
        hmc_step_size: float
            Step size for HMC sampler, by default 0.01
        re_prior_df : pd.DataFrame, optional
            Dataframe consisting of random effects prior information
        re_prior_df : pd.DataFrame, optional
            Dataframe consisting of fixed effects prior information
        """
        # Initialization
        # Framework Parameter
        framework_dict = {
            "objective": ["regression"],
            "sampler": [sampler],
            "num_chains": [no_chain],
            "num_results": [no_iter],
            "num_burnin_steps": [no_warmup_iter],
            "num_leapfrog_steps": [no_leapfrog_steps],
            "hmc_step_size": [hmc_step_size],
        }
        self.framework_df = (
            pd.DataFrame.from_dict(framework_dict, orient="index")
            .reset_index()
            .rename(columns={"index": "TagName", 0: "Value"})
        )

        # Model Parameter
        self.mdl_params_df = pd.DataFrame(
            columns=[
                "DV",
                "IDV",
                "Include_IDV",
                "RandomEffect",
                "RandomFactor",
                "mu_d",
                "mu_d_loc_alpha",
                "mu_d_scale_beta",
                "sigma_d",
                "sigma_d_loc_alpha",
                "sigma_d_scale_beta",
                "mu_bijector",
                "sigma_bijector",
                "fixed_d",
                "fixed_d_loc_alpha",
                "fixed_d_scale_beta",
                "fixed_bijector",
            ]
        )
        if re_prior_df is not None:
            re_prior_df = re_prior_df.rename(
                columns={
                    "model_coefficient_name": "IDV",
                    "group_variable": "RandomFactor",
                    "mu_dist": "mu_d",
                    "mean_mdl_coef_est": "mu_d_loc_alpha",
                    "std_mdl_coef_est": "mu_d_scale_beta",
                    "mu_bijector": "mu_bijector",
                    "sigma_dist": "sigma_d",
                    "mean_mdl_coef_std_err": "sigma_d_loc_alpha",
                    "std_mdl_coef_std_err": "sigma_d_scale_beta",
                    "sigma_bijector": "sigma_bijector",
                }
            )
            re_prior_df["DV"] = "DV"
            re_prior_df["Include_IDV"] = 1
            re_prior_df["RandomEffect"] = 1
            self.mdl_params_df = self.mdl_params_df.append(
                re_prior_df, ignore_index=True
            )
        if fe_prior_df is not None:
            fe_prior_df = fe_prior_df.rename(
                columns={
                    "model_coefficient_name": "IDV",
                    "distribution": "fixed_d",
                    "model_coefficient_value": "fixed_d_loc_alpha",
                    "model_coefficient_std": "fixed_d_scale_beta",
                    "bijector": "fixed_bijector",
                }
            )
            fe_prior_df["DV"] = "DV"
            fe_prior_df["Include_IDV"] = 1
            fe_prior_df["RandomEffect"] = 0
            self.mdl_params_df = self.mdl_params_df.append(
                fe_prior_df, ignore_index=True
            )

    def fit(self, X, y, column_names=None, reverse_column_names=None):
        """Fit the model using provided features and target.

        Parameters
        ----------
        X : pd.DataFrame or np.Array
            Dataframe/2D Array consisting of independant features
        y : pd.DataFrame or pd.Series or np.Array
            Dataframe/Series/Numpy Array containing the target column
        column_names : list, optional
            List of column names for features relevant when X, Y are Arrays, by default None
        column_names : list, optional
            List of column names to reverse sign, by default None
        """

        if column_names is None:
            if hasattr(X, "columns"):
                column_names = X.columns.to_list()

        # Check that X and y have correct shape
        # X, y = check_X_y(X, y)

        X = pd.DataFrame(X)
        X.columns = column_names

        # Reverse column sign
        if reverse_column_names is not None:
            reverse_column_names = [
                col for col in reverse_column_names if col in X.columns
            ]
            X.loc[:, reverse_column_names] = (-1) * X.loc[:, reverse_column_names]
        else:
            reverse_column_names = []

        self.model_ = reg.BayesianEstimation(
            pd.concat((X, y), axis="columns"), self.mdl_params_df, self.framework_df
        )
        self.model_.train()

        self.feature_names_ = column_names
        self.reverse_feature_names_ = reverse_column_names
        self.X = X

        params_dict = self.get_params()
        if "global_intercept" in params_dict.keys():
            self.intercept_ = params_dict["global_intercept"]
        else:
            self.intercept_ = 0
        self.coef_ = {
            k: v for k, v in params_dict.items() if "global_intercept" not in k
        }

        return self

    def predict(self, X):
        """Score/predict the target variables from the input data.

        Parameters
        ----------
        X : pd.DataFrame or np.Array
            Dataframe/2D Array consisting of independant features

        Returns
        -------
        np.Array
            Predictions for the input data
        """

        # Check is fit had been called
        check_is_fitted(self, "model_")

        # Input validation
        # X = check_array(X)

        # Reverse column sign
        X.loc[:, self.reverse_feature_names_] = (-1) * X.loc[
            :, self.reverse_feature_names_
        ]

        temp_X = pd.concat(
            (X, pd.Series([1] * len(X), index=X.index, name="DV")), axis="columns"
        )
        y_pred = self.model_.predict(temp_X)[0]
        return y_pred

    def get_params(self, deep=False):
        """Getter function to obtain the parameters of the estimator.

        Parameters
        ----------
        deep : bool, optional
            WIP, by default False

        Returns
        -------
        dict
            parameters dictionary
        """

        try:
            summary = az.summary(self.model_.dict_sample)
        except Exception as e:
            raise e

        return summary["mean"].transpose().to_dict()  # summary

    def get_params_in_dataframe(self):
        """Getter function to obtain the parameters of the estimator.

        Returns
        -------
        pd.DataFrame
            parameters
        """
        parms_dict = self.get_params()
        params_df = pd.DataFrame.from_records([parms_dict]).transpose().reset_index()
        params_df = params_df.rename(columns={"index": "variable", 0: "estimate"})

        return params_df


class SKLStatsmodelMixedLM:
    """sklearn wrapper estimator for Mixed Effects Estimator."""

    def __init__(self):
        """Initialize Estimator.

        Parameters
        ----------
        fit_intercept: bool
            argument to specify whether to fit the intercept in the model
        """

    def fit(self, X, y, column_names=None):
        """Fit the model using provided features and target.

        Parameters
        ----------
        X : pd.DataFrame or np.Array
            Dataframe/2D Array consisting of independant features
        y : pd.DataFrame or pd.Series or np.Array
            Dataframe/Series/Numpy Array containing the target column
        column_names : list, optional
            List of column names for features relevant when X, Y are Arrays, by default None

        """

        if column_names is None:
            if hasattr(X, "columns"):
                column_names = X.columns.to_list()

        # Check that X and y have correct shape
        # X, y = check_X_y(X, y)

        X = pd.DataFrame(X)
        X.columns = column_names

        mdl_formula = "DV ~ 0 + " + " + ".join(
            [col for col in column_names if col not in ["ACV_Selling", "PPG_Item_No"]]
        )
        self.model_ = smf.mixedlm(
            mdl_formula,
            pd.concat((X, y), axis="columns"),
            groups=X["PPG_Item_No"],
            re_formula="~ 1 + ACV_Selling",
        )
        self.model_ = self.model_.fit()
        self.feature_names_ = column_names
        return self

    def predict(self, X):
        """Score/predict the target variables from the input data.

        Parameters
        ----------
        X : pd.DataFrame or np.Array
            Dataframe/2D Array consisting of independant features

        Returns
        -------
        np.Array
            Predictions for the input data
        """
        # Check is fit had been called
        check_is_fitted(self, "model_")

        # Input validation
        X = check_array(X)
        return self.model_.predict(X)

    def get_params(self, deep=False):
        """Getter function to obtain the parameters of the estimator.

        Parameters
        ----------
        deep : bool, optional
            WIP, by default False

        Returns
        -------
        list
            parameters
        """

        fe_params = self.model_.fe_params
        re_params = pd.Series([], dtype=np.float64)
        for _, params in self.model_.random_effects.items():
            re_params = re_params.append(params)
        return (fe_params, re_params)
