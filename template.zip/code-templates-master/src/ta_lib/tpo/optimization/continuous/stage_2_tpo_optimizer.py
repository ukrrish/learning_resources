# !/usr/bin/env python3
# -*- coding: utf-8 -*-
# Created on 02/06/20 11:46 PM
# @author: Gurusankar G
# @author: Saravanakumar V
# @author: Nilagnik C

from __future__ import division

import logging
import os
import re
import time
from functools import reduce

import numpy as np
import pyomo.environ as pyo

from ta_lib.core import dataset
from ta_lib.tpo.optimization.continuous.global_data_init_class import (  # noqa
    global_initializer,
)
from ta_lib.tpo.optimization.continuous.stage_1_tpo_optimizer import (
    Stage1_caller,
    TPR_Spend_calc_edge_case,
)

logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)
m_path = os.path.dirname(dataset.__file__).replace("\\", "/")


def Retailer_Unit_Sales_Stg_inter_Fn(Model, P, W):
    """Define pyomo callback for calculating product unit sales.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    P :    Integer, PPG number to calculate Unit sales for the given week.
    Will be iteratively called by Model Objective function.
    Wk : Integer, Week number for the year
    Returns:
    --------
    Pyomo Expression, containing Product Unit Sales equation for the given week

    """
    Self = pyo.exp(
        (
            pyo.log(Model.EDLP[P] * globals.Base_Price_stg2[P][W])
            * globals.EDLP_Coef[P][P]
        )
        * Model.FLAG[P, W]
        + (
            pyo.log(globals.Base_Price_stg2[P][W]) * globals.EDLP_Coef[P][P]
            + Model.TPR[P] * globals.TPR_Coef[P][P]
        )
        * (1 - Model.FLAG[P, W])
        + globals.Intercepts_stg2[W][P]
    )
    Comp = Competitor_Unit_Effect_Stg_inter_Fn(Model, P, W)
    EDLP_Inter_Val = EDLP_Interaction_Unit_Effect_Stg_inter_Fn(Model, P, W)
    TPR_Inter_Val = TPR_Interaction_Unit_Effect_Stg_inter_Fn(Model, P, W)
    Pantry_Loading_Val = Pantry_Loading_Unit_Effect_inter_Fn(Model, P, W)
    Unit_Sales = Self * Comp * EDLP_Inter_Val * TPR_Inter_Val * Pantry_Loading_Val
    return Unit_Sales


def Competitor_Unit_Effect_Stg_inter_Fn(Model, Cur_Ret, Wk):
    """Define pyomo callback for calculating competitor effect.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Cur_Ret :    Integer, PPG number to calculate EDLP Competitor Effect for the given week . Will be iteratively called by Model Objective function.
    Wk : Integer, Week number for the year
    Returns:
    --------
    Pyomo Expression, containing Competitor Unit Effect for the Product for the given week

    """
    Comp_Retailers_Unit_Sales = [
        pyo.exp(
            (
                pyo.log(Model.EDLP[i] * globals.Base_Price_stg2[i][Wk])
                * globals.EDLP_Coef[Cur_Ret][i]
            )
            * Model.FLAG[i, Wk]
            + (
                pyo.log(globals.Base_Price_stg2[i][Wk]) * globals.EDLP_Coef[Cur_Ret][i]
                + Model.TPR[i] * globals.TPR_Coef[Cur_Ret][i]
            )
            * (1 - Model.FLAG[i, Wk])
        )
        for i in Model.PPG_index
        if i != Cur_Ret
    ]
    return reduce(lambda x, y: x * y, Comp_Retailers_Unit_Sales, 1)


def EDLP_Interaction_Unit_Effect_Stg_inter_Fn(Model, P, Wk):
    """Define pyomo callback for calculating EDLP interactions.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    P :    Integer, PPG number to calculate EDLP Interaction Effect for the given week . Will be iteratively called by Model Objective function.
    Wk : Integer, Week number for the year
    Returns:
    --------
    Pyomo Expression, containing product EDLP Interaction equation for the given week

    """
    EDLP_Interaction_Unit_Effect = [1]
    P1 = int("".join(re.findall(r"[0-9]+", globals.Mapping_reverse[P])))
    for Inter in globals.EDLP_Interactions:
        if P1 in Inter:
            Pr_ind1, Pr_ind2 = Inter
            Comb = str(Pr_ind1) + "_" + str(Pr_ind2)
            Pr_ind1 = globals.Mapping["Product" + str(Pr_ind1) + "_Retailer"]
            Pr_ind2 = globals.Mapping["Product" + str(Pr_ind2) + "_Retailer"]
            Val1 = globals.Base_Price_stg2[Pr_ind1][Wk] * (
                1 - Model.FLAG[Pr_ind1, Wk]
            ) + (Model.EDLP[Pr_ind1] * globals.Base_Price_stg2[Pr_ind1][Wk]) * (
                Model.FLAG[Pr_ind1, Wk]
            )
            Val2 = globals.Base_Price_stg2[Pr_ind2][Wk] * (
                1 - Model.FLAG[Pr_ind2, Wk]
            ) + (Model.EDLP[Pr_ind2] * globals.Base_Price_stg2[Pr_ind2][Wk]) * (
                Model.FLAG[Pr_ind2, Wk]
            )
            Val = pyo.exp(
                pyo.log(Val1) * pyo.log(Val2) * globals.EDLP_Int_Coef_Values[Comb][P]
            )
            EDLP_Interaction_Unit_Effect.append(Val)
    return reduce(lambda x, y: x * y, EDLP_Interaction_Unit_Effect)


def TPR_Interaction_Unit_Effect_Stg_inter_Fn(Model, P, Wk):
    """Define pyomo callback for calculating TPR interactions.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    P :    Integer, PPG number to calculate TPR Interaction Effect for the given week . Will be iteratively called by Model Objective function.
    Wk : Integer, Week number for the year
    Returns:
    --------
    Pyomo Expression, containing product TPR Interaction equation for the given week

    """
    TPR_Interaction_Unit_Effect = [1]
    P1 = int("".join(re.findall(r"[0-9]+", globals.Mapping_reverse[P])))
    for Inter in globals.TPR_Interactions:
        if P1 in Inter:
            Pr_ind1, Pr_ind2 = Inter
            Comb = str(Pr_ind1) + "_" + str(Pr_ind2)
            Pr_ind1 = globals.Mapping["Product" + str(Pr_ind1) + "_Retailer"]
            Pr_ind2 = globals.Mapping["Product" + str(Pr_ind2) + "_Retailer"]
            Val = pyo.exp(
                (
                    Model.TPR[Pr_ind1]
                    * Model.TPR[Pr_ind2]
                    * globals.TPR_Int_Coef_Values[Comb][P]
                    * (1 - Model.FLAG[Pr_ind1, Wk])
                    * (1 - Model.FLAG[Pr_ind2, Wk])
                )
            )
            TPR_Interaction_Unit_Effect.append(Val)
    return reduce(lambda x, y: x * y, TPR_Interaction_Unit_Effect)


def Pantry_Loading_Unit_Effect_inter_Fn(Model, P, Wk):
    """Define pyomo callback for individual product pantry loading effect.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    P :    Integer, PPG number to calculate Pantry Loading Effect for the given week . Will be iteratively called by Model Objective function.
    Wk : Integer, Week number for the year
    Returns:
    --------
    Pyomo Expression, containing product Pantry Unit Effect equation for the given week

    """
    Pantry_1_Effect = Pantry_2_effect = 1
    PL_Coef1 = globals.Pantry_1[Wk][P]
    PL_Coef2 = globals.Pantry_2[Wk][P]
    if Wk > 0:
        Pantry_1_Effect = pyo.exp(Model.TPR[P] * PL_Coef1 * (1 - Model.FLAG[P, Wk - 1]))
    if Wk > 1:
        Pantry_2_effect = pyo.exp(Model.TPR[P] * PL_Coef2 * (1 - Model.FLAG[P, Wk - 2]))
    Pantry_Loading_Unit_Effect = Pantry_1_Effect * Pantry_2_effect
    return Pantry_Loading_Unit_Effect


def Retailer_Price_inter_Fn(Model, P, W):
    """Define pyomo callback for individual product price with model parameters.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    P :    Integer, PPG number to calculate Retailer Price for the given week . Will be iteratively called by Model Objective function.
    Wk : Integer, Week number for the year
    Returns:
    --------
    Pyomo Expression, containing product Retailer Price equation for the given week

    """
    Price = (
        globals.Base_Price_stg2[P][W] * (1 - Model.TPR[P]) * (1 - Model.FLAG[P, W])
    ) + (Model.EDLP[P] * globals.Base_Price_stg2[P][W] * Model.FLAG[P, W])
    return Price


# Dollar Sales Stage 2
def Dollar_Sales_Stg_inter_Fn(Model):
    """Define pyomo callback for calculating dollar sales.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Returns:
    --------
    Pyomo Expression, containing Dollar sales equation

    """
    return sum(
        [
            Retailer_Unit_Sales_Stg_inter_Fn(Model, P, W)
            * Retailer_Price_inter_Fn(Model, P, W)
            for W in Model.Wk_index
            for P in Model.PPG_index
        ]
    )


def Total_Trade_Spent_Bnd_Stg_inter_Fn(Model, Cur_Ret):
    """Define pyomo callback for calculating bound for total trade spent.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Cur_Ret :    Integer, PPG number to calculate Total Trade Spent for all the weeks.
    Will be iteratively called by Model Objective function
    Returns:
    --------
    Pyomo Expression, containing product Total Trade Spent equation

    """
    Val = sum(
        [
            (
                globals.Base_Price_stg2[Cur_Ret][Wk]
                - Retailer_Price_inter_Fn(Model, Cur_Ret, Wk)
            )
            * Retailer_Unit_Sales_Stg_inter_Fn(Model, Cur_Ret, Wk)
            for Wk in Model.Wk_index
        ]
    )
    return pyo.inequality(
        globals.Target_Trade_Spend[Cur_Ret] * (1 - globals.Ov_Perc_Limit / 100),
        Val,
        globals.Target_Trade_Spend[Cur_Ret] * (1 + globals.Ov_Perc_Limit / 100),
    )


# Trade Spend Constraints
def EDLP_Trade_Spent_Bnd_Stg_inter_Fn(Model, Cur_Ret):
    """Define pyomo callback for calculating bound for EDLP trade spent.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Cur_Ret :    Integer, PPG number to calculate EDLP Trade Spent for all the weeks . Will be iteratively called by Model Objective function
    Returns:
    --------
    Pyomo Expression, containing product EDLP Trade Spent equation

    """
    Val = sum(
        [
            (
                globals.Base_Price_stg2[Cur_Ret][Wk]
                - Retailer_Price_inter_Fn(Model, Cur_Ret, Wk)
            )
            * Retailer_Unit_Sales_Stg_inter_Fn(Model, Cur_Ret, Wk)
            * (Model.FLAG[Cur_Ret, Wk])
            for Wk in Model.Wk_index
        ]
    )
    return pyo.inequality(
        globals.Target_EDLP_Spend[Cur_Ret] * (1 - globals.EDLP_Perc_Limit / 100),
        Val,
        globals.Target_EDLP_Spend[Cur_Ret] * (1 + globals.EDLP_Perc_Limit / 100),
    )


def TPR_Trade_Spent_Bnd_Stg_inter_Fn(Model, Cur_Ret):
    """Define pyomo callback for calculating bound for TPR trade spent.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Cur_Ret :    Integer, PPG number to calculate TPR Trade Spent for all the weeks . Will be iteratively called by Model Objective function
    Returns:
    --------
    Pyomo Expression, containing product TPR Trade Spent equation

    """
    Val = sum(
        [
            (
                globals.Base_Price_stg2[Cur_Ret][Wk]
                - Retailer_Price_inter_Fn(Model, Cur_Ret, Wk)
            )
            * Retailer_Unit_Sales_Stg_inter_Fn(Model, Cur_Ret, Wk)
            * (1 - Model.FLAG[Cur_Ret, Wk])
            for Wk in Model.Wk_index
        ]
    )
    LHS = globals.Target_TPR_Spend[Cur_Ret] * (1 - globals.TPR_Perc_Limit / 100)
    RHS = globals.Target_TPR_Spend[Cur_Ret] * (1 + globals.TPR_Perc_Limit / 100)
    if RHS == 0:
        Max_Events, UB_TPR_Spend = TPR_Spend_calc_edge_case(Model, Cur_Ret)
        if globals.Tot_Week - globals.stage1_Num_Events_PPG[Cur_Ret] != 0:
            RHS = UB_TPR_Spend
    return pyo.inequality(LHS, Val, RHS)


def Overall_Total_Trade_Spent_Stg_inter_Fn(Model):
    """To establish constraint on overall trade spend for pyomo model.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Returns:
    --------
    Pyomo Expression, containing OVerall Trade equation

    """
    return sum(
        [
            sum(
                [
                    (
                        globals.Base_Price_stg2[Cur_Ret][Wk]
                        - Retailer_Price_inter_Fn(Model, Cur_Ret, Wk)
                    )
                    * Retailer_Unit_Sales_Stg_inter_Fn(Model, Cur_Ret, Wk)
                    for Wk in range(globals.Tot_Week)
                ]
            )
            for Cur_Ret in range(globals.Tot_Prod)
        ]
    ) == sum(globals.Target_Trade_Spend)


# Events constraints
def FLAG_Util_Fn(Model, Cur_Ret):
    """Define constraint bounds callback function for pyomo model on FLAGS for given model parameter values.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Cur_Ret : Integer, PPG number of the Product
    Returns:
    --------
    Pyomo Model, containing FLAG Constraint Function

    """
    return (
        sum(
            [
                Model.FLAG[Cur_Ret, Wk] * (1 - Model.FLAG[Cur_Ret, Wk])
                for Wk in range(globals.Tot_Week)
            ]
        )
        == 0
    )


def EDLP_Event_Fn(Model, P):
    """Define constraint bounds callback function for pyomo model on EDLP events for given model parameter values.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    P : Integer, PPG number of the Product
    Returns:
    --------
    Pyomo Model, containing containing EDLP Event Constraint Function

    """
    return (
        sum([Model.FLAG[P, W] for W in Model.Wk_index])
        == globals.stage1_Num_Events_PPG[P]
    )


def TPR_Event_Fn(Model, P):
    """Define constraint bounds callback function for pyomo model on TPR envents for given model parameter values.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    P : Integer, PPG number of the Product
     Returns:
    --------
    Pyomo Model, containing containing TPR Event Constraint Function

    """
    return (
        globals.Tot_Week - sum([Model.FLAG[P, W] for W in Model.Wk_index])
        == globals.Tot_Week - globals.stage1_Num_Events_PPG[P]
    )


def Create_Model_Stg_inter(flag_init):
    """To create a Pyomo model.

    Model consists of
    1. Functions to properly initialize FLAG values from previous operations
    2. Variables to optimize
    3. Objective function
    4. Constraints
    Parameters
    ----------
    flag_init = numpy Array / List of Lists for Initializing Flag variable for model
    Returns:
    --------
    Pyomo Model with required parameters

    """

    def FLAG_Initialize(Model, *Index):
        return flag_init[Index]

    Model = pyo.ConcreteModel(name="Spend_Optim")
    Model.PPGs = pyo.Param(initialize=globals.Tot_Prod, domain=pyo.PositiveIntegers)
    Model.Weeks = pyo.Param(initialize=globals.Tot_Week, domain=pyo.PositiveIntegers)
    Model.PPG_index = pyo.RangeSet(0, Model.PPGs - 1)
    Model.Wk_index = pyo.RangeSet(0, Model.Weeks - 1)
    # Model.EDLP = pyo.Param(Model.PPG_index, initialize={k: v for k, v in enumerate(EDLP_Init_PPG)})
    # Model.TPR = pyo.Param(Model.PPG_index, initialize={k: v for k, v in enumerate(TPR_Init_PPG)})
    Model.EDLP = pyo.Var(
        Model.PPG_index,
        initialize=globals.EDLP_LB,
        domain=pyo.NonNegativeReals,
        bounds=(globals.EDLP_LB, globals.EDLP_UB),
    )
    Model.TPR = pyo.Var(
        Model.PPG_index,
        initialize=globals.TPR_LB,
        domain=pyo.NonNegativeReals,
        bounds=(globals.TPR_LB, globals.TPR_UB),
    )
    Model.FLAG = pyo.Var(
        Model.PPG_index, Model.Wk_index, initialize=FLAG_Initialize, domain=pyo.Binary
    )
    Model.Obj = pyo.Objective(rule=Dollar_Sales_Stg_inter_Fn, sense=pyo.maximize)
    Model.Tot_Spent_Bnd = pyo.Constraint(
        Model.PPG_index, rule=Total_Trade_Spent_Bnd_Stg_inter_Fn
    )
    Model.EDLP_Bnd = pyo.Constraint(
        Model.PPG_index, rule=EDLP_Trade_Spent_Bnd_Stg_inter_Fn
    )
    Model.TPR_Bnd = pyo.Constraint(
        Model.PPG_index, rule=TPR_Trade_Spent_Bnd_Stg_inter_Fn
    )
    Model.FLAG_Util_c = pyo.Constraint(Model.PPG_index, rule=FLAG_Util_Fn)
    Model.TPR_Event = pyo.Constraint(Model.PPG_index, rule=TPR_Event_Fn)
    Model.EDLP_Event = pyo.Constraint(Model.PPG_index, rule=EDLP_Event_Fn)
    Model.Overall = pyo.Constraint(rule=Overall_Total_Trade_Spent_Stg_inter_Fn)
    return Model


def Call_Solver_Stg_Inter(PPGs, Wks, name="bonmin", obj=1):
    """To Generate and call a pyomo model.

    The function generates a generic model which can be ran across solvers
    which are supported in the Pyomo framework and can solve MINLP problems
    ex-Bonmin, Baron.Init value of FLAG passed to the function are coming from phase 1
    Parameters
    ----------
    PPG : Integer, Number of Total Products to be passed
    Wks : Integer, Number of Total Weeks to be passed
    name : String, (Optional) Name of the solver to be used
    obj : Initial value of the Objective (Optional) to keep running the solver till the maximum value is reached

    """
    flag_init = globals.historical_df.Event.tolist()
    flag_init = [(1 - x) for x in flag_init]
    flag_init = np.array(flag_init).reshape(globals.Tot_Prod, globals.Tot_Week)
    Model = Create_Model_Stg_inter(flag_init)  # create model
    path = (
        m_path
        + "/../../scripts/tpo_continuous/optimization/Triple_Stage_Optimizer/bonmin-win32/bonmin.exe"
    )  # noqa
    opt = pyo.SolverFactory(name, executable=path)  # solve model
    opt.options["tol"] = 1e-4
    opt.options["max_cpu_time"] = globals.TIME_STAGE2
    # opt.options['max_iter']= 50000
    # opt.options['bonmin.time_limit'] = 1800
    # opt.options['bonmin.integer_tolerance']= 1e-2
    opt.options["bonmin.algorithm"] = "B-Hyb"
    # Model.display()
    start_time = time.time()
    if globals.Stage1Success:  # check for previous stage covergence

        try:
            Result = opt.solve(Model)
            if str(Result.solver.status) != "ok":
                raise Exception("Solver Status should be OK")
            if str(Result.solver.termination_condition) != "optimal":
                raise Exception("Terminal Condition should be Optimal")
            globals.Stage2Success = True
        except Exception as e:
            logger.error("\nError in Solving problem" + str(e))
    end_time = time.time()
    Call_Solver_Stg_Inter.EDLP_Val = [pyo.value(Model.EDLP[i]) for i in range(PPGs)]
    Call_Solver_Stg_Inter.TPR_Val = [pyo.value(Model.TPR[i]) for i in range(PPGs)]
    Call_Solver_Stg_Inter.FLAG = [
        [pyo.value(Model.FLAG[i, W]) for W in Model.Wk_index] for i in range(PPGs)
    ]
    # Model.display()
    if (
        globals.Stage2Success and pyo.value(Model.Obj) > obj
    ):  # load model output to global data class if true optimization is achieved
        logger.info(
            "\n\n Optimizer Second Stage Results:\n##############################\n\n"
        )
        # log_infeasible_constraints(Model)
        # log_infeasible_bounds(Model)
        logger.info(pyo.value(Model.Obj))
        el_time = " The Elapsed Time is --- %s Seconds ---" % (end_time - start_time)
        btime = f"{name} Solver Execution Time: {Result['Solver'][0]['Time']}"
        logger.info(
            f"Elapsed_Time: {el_time}\n\nBonmin Time: {btime}\n\nObjective_Value: {pyo.value(Model.Obj)}"
        )
        logger.info(
            f"Message: {Result['Solver'][0]['Message']},Termination: {Result['Solver'][0]['Termination condition']},Status: {Result['Solver'][0]['Status']},Objective_Value: {pyo.value(Model.Obj)}"
        )
        Call_Solver_Stg_Inter.Obj_Val = pyo.value(Model.Obj)
        globals.Stage2Success = True
    else:
        # log_infeasible_constraints(Model)
        # log_infeasible_bounds(Model)
        Call_Solver_Stg_Inter.Obj_Val = obj
        globals.Stage2Success = False


def Stage2_caller(global_vars):
    """Task of the function is to get the initialized global data class.

    Inject class into first stage and wait for the outputs form the first stage solver. Then it shall
    call the second stage of the pipeline with interim FLAG values to be used as init values
    in this phase. Loaded result within the global data class is then passed on to the third stage
    Parameters
    ----------
    global_vars : Object, Globally defined variables is being passed

    """
    global globals
    globals = global_vars
    Stage1_caller(global_vars)

    logger.info(f"\n\nSolving Second Stage : Ret {globals.Ret} Cat {globals.Cat}")
    Call_Solver_Stg_Inter(
        PPGs=globals.Tot_Prod, Wks=globals.Tot_Week, name="bonmin", obj=1
    )
    globals.FLAG_Inter = np.array(Call_Solver_Stg_Inter.FLAG)
    globals.TPR_Inter = Call_Solver_Stg_Inter.TPR_Val
    globals.EDLP_Inter = Call_Solver_Stg_Inter.EDLP_Val


if __name__ == "__main__":  # only for testing purposes
    globals = global_initializer((11, 2))
    Stage2_caller(globals)
