#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Created on 05/06/20 2:42 AM
# @author: Gurusankar G
# @author: Saravanakumar V
# @author: Nilagnik C

from __future__ import division

import ast
import json
import logging
import os
import os.path as op
import re

import numpy as np

from ta_lib.core import dataset
from ta_lib.core.api import create_context, initialize_environment

initialize_environment(debug=False, hide_warnings=True)
m_path = os.path.dirname(dataset.__file__).replace("\\", "/")
config_path = op.join(
    m_path + "/../../notebooks/tpo/python/continuous_optimization/conf", "config.yml"
)  # noqa
context = create_context(config_path)
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# class Singleton(type):
#     _instances = WeakValueDictionary()

#     def __call__(cls, *args, **kwargs):
#         if cls not in cls._instances:
#             # This variable declaration is required to force a
#             # strong reference on the instance.
#             instance = super(Singleton, cls).__call__(*args, **kwargs)
#             cls._instances[cls] = instance
#         return cls._instances[cls]


class global_initializer:
    """Usage : The class is the main input format for the three stage optimizer.

    The input required is the retailer number and category numer to be
    created with the class construct
    ex - global_initializer(Retailer, Category)found
    in the Caller.py file. The class is internally
    used by all the three phases of the solver to save
    their interim and final values
    """

    def __init__(self, combo_data):

        # Config constants initialization complete ######
        def formatter(data, conv):
            if conv == "int":
                return int(data)
            elif conv == "float":
                return float(data)
            elif conv == "list":
                return json.loads(data)
            elif conv == "dict":
                return ast.literal_eval(data)
            else:
                return data

        self.Event_Buffer = formatter(combo_data["event_buffer"], conv="int")
        self.EDLP_Perc_Limit = formatter(combo_data["edlp_perc_limit"], conv="int")
        self.TPR_Perc_Limit = formatter(combo_data["tpr_perc_limit"], conv="int")
        self.Ov_Perc_Limit = formatter(combo_data["overall_perc_limit"], conv="int")
        self.Total_EDLP_Perc_Limit = formatter(
            combo_data["total_edlp_perc_limit"], conv="int"
        )  # noqa
        self.Total_TPR_Perc_Limit = formatter(
            combo_data["total_tpr_perc_limit"], conv="int"
        )
        self.EDLP_LB = formatter(combo_data["edlp_lb"], conv="float")
        self.EDLP_UB = formatter(combo_data["edlp_ub"], conv="float")
        self.TPR_LB = formatter(combo_data["tpr_lb"], conv="float")
        self.TPR_UB = formatter(combo_data["tpr_ub"], conv="float")
        self.TIME_STAGE2 = formatter(combo_data["time_step_2"], conv="int")
        self.TIME_STAGE3 = formatter(combo_data["time_step_3"], conv="int")
        self.TIME_SINGLESHOT = formatter(combo_data["time_step_single"], conv="int")

        # GLOBALS name definition  ########

        self.Ret = formatter(combo_data["retailer"], conv="int")
        self.Cat = formatter(combo_data["category"], conv="int")
        self.stage1_EDLP_Init_PPG = None
        self.stage1_TPR_Init_PPG = None
        self.stage1_Num_Events_PPG = None
        self.stage1_EDLP_Spend_Values = None
        self.stage1_TPR_Spend_Values = None
        self.stage1_Tot_Spend_Values = None
        self.FLAG_Inter = None
        self.EDLP_Inter = None
        self.TPR_Inter = None
        self.Solver_Model_Result = None
        self.EDLP_Final = None
        self.TPR_Final = None

        self.Stage1Success = False
        self.Stage2Success = False
        self.Stage3Success = False

    def class_loader(self):
        """Load historical data. coefficients and Base values."""
        try:
            self.load_retailer_category()
            self.prepare_data()
            return 1
        except Exception as e:
            logger.error("\n\nError in loading data" + str(e))
            return 0

    def load_retailer_category(self):
        """Load Historical data. coefficients Helper Function1."""
        Ret = self.Ret
        Cat = self.Cat

        annual_df = dataset.load_dataset(context, "raw/Final_Spend")
        annual_df = annual_df[
            (annual_df.Retailer == "Retailer" + str(Ret))
            & (annual_df.Category == "Category" + str(Cat))
        ].reset_index(drop=True)
        coef_df = dataset.load_dataset(
            context, "raw/Coeff_Matrix", Ret=str(Ret), Cat=str(Cat)
        )
        #     coef_df = coef_df.drop("Unnamed: 0",1)
        quarter_df = dataset.load_dataset(context, "raw/Final_BasePrice")
        quarter_df = quarter_df[
            (quarter_df.Retailer == "Retailer" + str(Ret))
            & (quarter_df.Category == "Category" + str(Cat))
        ].reset_index(drop=True)
        historical_df = dataset.load_dataset(context, "raw/Historical_Events")
        historical_df = historical_df[
            (historical_df.Retailer == "Retailer" + str(Ret))
            & (historical_df.Category == "Category" + str(Cat))
        ].reset_index(drop=True)

        # #################################proposed#####################################
        try:
            historical_edlp_init = dataset.load_dataset(
                context, "raw/Historical_EDLP", Ret=str(Ret), Cat=str(Cat)
            )

        except Exception:
            historical_edlp_init = None

        self.annual_df = annual_df
        self.coef_df = coef_df
        self.quarter_df = quarter_df
        self.historical_df = historical_df
        self.historical_edlp_init = historical_edlp_init

    def prepare_data(self):
        """Load Historical data. coefficients Helper Function2."""
        annual_df = self.annual_df
        coef_df = self.coef_df
        quarter_df = self.quarter_df
        #         historical_df = self.historical_df
        Event_Buffer = self.Event_Buffer

        Tot_Prod = coef_df["Product"].nunique()
        Tot_Week = coef_df["wk"].nunique()

        EDLP_Events = list(annual_df["RP_Events"])
        Min_EDLP_Events = [
            i - Event_Buffer if i - Event_Buffer >= 0 else 0 for i in EDLP_Events
        ]
        Max_EDLP_Events = [
            i + Event_Buffer if i + Event_Buffer < Tot_Week + 1 else Tot_Week
            for i in EDLP_Events
        ]

        TPR_Events = list(annual_df["TPR_Events"])
        Min_TPR_Events = [
            i - Event_Buffer if i - Event_Buffer >= 0 else 0 for i in TPR_Events
        ]
        Max_TPR_Events = [
            i + Event_Buffer if i + Event_Buffer < Tot_Week + 1 else Tot_Week
            for i in TPR_Events
        ]

        Target_EDLP_Spend = [i for i in annual_df["PPG_RP_Spend"]]
        Target_TPR_Spend = [i for i in annual_df["PPG_TPR_Spend"]]
        Target_Trade_Spend = [i for i in annual_df["PPG_Total_Spend"]]

        Mapping = {}
        Prod_Ind = coef_df["Product"][0:Tot_Prod]
        for i, j in zip(Prod_Ind.index, Prod_Ind.values):
            Mapping[j] = i
        Mapping_reverse = {i: j for j, i in Mapping.items()}

        constants = [i for i in coef_df["constant"]]
        Base_Price_stg1 = [i for i in quarter_df["Final_baseprice"]]
        Intercepts_stg1 = []
        for pr in range(Tot_Prod):
            Intercepts_stg1.append(
                np.mean([constants[j * Tot_Prod + pr] for j in range(0, Tot_Week)])
            )

        Base_Price_stg2 = [[i] * Tot_Week for i in quarter_df["Final_baseprice"]]
        Intercepts_stg2 = [
            constants[j : j + Tot_Prod] for j in range(0, len(constants), Tot_Prod)
        ]

        EDLP_Coef = np.array(
            coef_df[[i for i in coef_df.columns if i.count("Retailer_Regular") == 1]]
        )
        TPR_Coef = np.array(
            coef_df[[i for i in coef_df.columns if i.count("Retailer_Promoted") == 1]]
        )

        # ################################ Available EDLP Interactions pairs ##############################

        EDLP = [
            re.findall(r"[0-9]+", i)
            for i in coef_df.columns
            if i.count("Retailer_Regular") > 1
        ]
        EDLP_Interactions = []
        for i in EDLP:
            temp = []
            for j in i:
                temp.append(int(j))
            EDLP_Interactions.append(temp)

        # ###################################### Available TPR Interactions pairs #########################

        TPR = [
            re.findall(r"[0-9]+", i)
            for i in coef_df.columns
            if i.count("Retailer_Promoted") > 1
        ]
        TPR_Interactions = []
        for i in TPR:
            temp = []
            for j in i:
                temp.append(int(j))
            TPR_Interactions.append(temp)

        # ###################################### EDLP_Interaction_Coef_Values ############################

        EDLP_Int_Coef_Values = {}
        for col in coef_df.columns:
            if col.count("Retailer_Regular") > 1:
                Pair_name = "_".join([str(int(i)) for i in re.findall(r"[0-9]+", col)])
                EDLP_Int_Coef_Values[Pair_name] = list(coef_df[col])

        # ###################################### TPR_Interaction_Coef_Values #############################

        TPR_Int_Coef_Values = {}
        for col in coef_df.columns:
            if col.count("Retailer_Promoted") > 1:
                Pair_name = "_".join([str(int(i)) for i in re.findall(r"[0-9]+", col)])
                TPR_Int_Coef_Values[Pair_name] = list(coef_df[col])

        # ##################################### Loading Pantry Loading Coefficients #######################

        Pantry_1 = list(coef_df["Pantry_Loading_1"])
        Pantry_1 = [
            Pantry_1[j : j + Tot_Prod] for j in range(0, len(Pantry_1), Tot_Prod)
        ]
        Pantry_2 = list(coef_df["Pantry_Loading_2"])
        Pantry_2 = [
            Pantry_2[j : j + Tot_Prod] for j in range(0, len(Pantry_2), Tot_Prod)
        ]

        self.Tot_Prod = Tot_Prod
        self.Tot_Week = Tot_Week
        self.EDLP_Events = EDLP_Events
        self.Min_EDLP_Events = Min_EDLP_Events
        self.Max_EDLP_Events = Max_EDLP_Events
        self.TPR_Events = TPR_Events
        self.Min_TPR_Events = Min_TPR_Events
        self.Max_TPR_Events = Max_TPR_Events

        self.Target_EDLP_Spend = Target_EDLP_Spend
        self.Target_TPR_Spend = Target_TPR_Spend
        self.Target_Trade_Spend = Target_Trade_Spend
        self.Mapping = Mapping
        self.Mapping_reverse = Mapping_reverse
        self.constants = constants
        self.EDLP_Coef = EDLP_Coef
        self.TPR_Coef = TPR_Coef

        self.EDLP_Interactions = EDLP_Interactions
        self.TPR_Interactions = TPR_Interactions
        self.EDLP_Int_Coef_Values = EDLP_Int_Coef_Values
        self.TPR_Int_Coef_Values = TPR_Int_Coef_Values
        self.Pantry_1 = Pantry_1
        self.Pantry_2 = Pantry_2

        self.Base_Price_stg1 = Base_Price_stg1
        self.Intercepts_stg1 = Intercepts_stg1
        self.Base_Price_stg2 = Base_Price_stg2
        self.Intercepts_stg2 = Intercepts_stg2
