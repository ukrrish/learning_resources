import logging
import re
import string

import numpy as np
import pandas as pd
import pyutilib.subprocess.GlobalData

pd.options.mode.chained_assignment = None

pyutilib.subprocess.GlobalData.DEFINE_SIGNAL_HANDLERS_DEFAULT = False

logger = logging.getLogger("Data_Prep_log")
# Todo: Use context from config.yml
hdlr = logging.FileHandler("../../logs/tpo_continuous/Data_Prep_log.log")
formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
hdlr.setFormatter(formatter)
logger.addHandler(hdlr)
logger.setLevel(logging.INFO)


def Data_Load(Category, Retailer):  # noqa
    logger.info("Preparing Data from TPM")
    logger.info("========================")
    # Import Required Data Sets
    new_model_coeff = pd.read_csv(
        "../../data/output/new_model_coeff_optimizer.csv"
    )  # new_model csv
    BaseData = pd.read_csv(
        "../../data/output/Base_Data_Transformed_Category1_Retailer1 Total TA_Optimizer.csv"
    )  # 5000 rows
    model_data_set_2 = pd.read_csv(
        "../../data/output/Model_dataset_2.csv"
    )  # srinath input
    model_coefficient = pd.read_csv(
        "../../data/output/Model_Coefficients_EDLP_TPR_Tranformed_Category1_Retailer1 Total TA_Optimizer.csv"
    )  # Model_Coefficients_EDLP_TPR_Tranformed_Category1_Retailer1 Total TA_Optimizer

    Flag_Update = {i: j for i, j in BaseData[["PPG_Item_No", "Model_flag"]].values}

    model_coefficient["Model_flag"] = model_coefficient["Modelled_PPG_Item_No"].map(
        Flag_Update
    )
    BaseData = BaseData[BaseData.PPG_Cat == "Category" + str(Category)].reset_index(
        drop=True
    )
    BaseData_2 = BaseData[
        (BaseData.PPG_Item_No.str.contains("Retailer")) & (BaseData.PPG_MFG == "NPP")
    ].reset_index(drop=True)
    BaseData_2 = BaseData_2[
        [
            "PPG_Item_No",
            "PPG_Description",
            "Date",
            "tpr_discount_byppg",
            "tpr_discount_byppg_lag1",
            "tpr_discount_byppg_lag2",
            "median_baseprice",
            "Final_baseprice",
            "Estimated_baseprice",
            "ACV_Feat_Only",
            "ACV_Disp_Only",
            "ACV_Feat_Disp",
            "ACV_Selling",
            "flag_qtr2",
            "flag_qtr3",
            "flag_qtr4",
            "category_trend",
            "monthno",
            "wk_sold_avg_price_byppg",
            "Spend",
            "Model_flag",
            "wk_sold_doll_byppg",
        ]
    ].reset_index(drop=True)
    BaseData_2 = BaseData_2[BaseData_2.Date >= "2019-01-01"].reset_index(drop=True)
    # Base data one year ppg
    BaseData_oneyr = BaseData_2[BaseData_2.Model_flag == 1].reset_index(drop=True)
    BaseData_oneyr = BaseData_oneyr[
        [
            "PPG_Item_No",
            "PPG_Description",
            "Date",
            "median_baseprice",
            "tpr_discount_byppg",
            "Final_baseprice",
            "wk_sold_avg_price_byppg",
            "wk_sold_doll_byppg",
            "Spend",
            "Model_flag",
        ]
    ]
    BaseData_oneyr["Date"] = pd.to_datetime(BaseData_oneyr.Date)
    BaseData_oneyr["Week"] = BaseData_oneyr["Date"].dt.week
    #     ppg_list = BaseData_2.PPG_Item_No.unique().tolist()
    BaseData_2 = BaseData_2[BaseData_2.Model_flag == 2].reset_index(drop=True)
    # Remove duplicate rows
    BaseData_2 = BaseData_2.drop_duplicates(["PPG_Description", "Date"]).reset_index(
        drop=True
    )
    BaseData_oneyr = BaseData_oneyr.drop_duplicates(
        ["PPG_Description", "Date"]
    ).reset_index(drop=True)
    new_model_coeff = new_model_coeff[new_model_coeff.Model_flag == 2].reset_index(
        drop=True
    )
    model_data_set_2 = model_data_set_2[model_data_set_2.Model_flag == 2].reset_index(
        drop=True
    )
    model_coefficient = model_coefficient[
        model_coefficient.Model_flag == 2
    ].reset_index(drop=True)
    model_coefficient = model_coefficient[
        model_coefficient.PPG_Cat == "Category" + str(Category)
    ].reset_index(drop=True)
    model_data_set_2 = model_data_set_2[
        model_data_set_2.PPG_Cat == "Category" + str(Category)
    ].reset_index(drop=True)
    new_model_coeff = new_model_coeff[
        new_model_coeff.PPG_Cat == "Category" + str(Category)
    ].reset_index(drop=True)
    # filter out 2 years PPGs data

    # ====================Weekly data preparation==================================================================
    model_coefficient = model_coefficient[
        (model_coefficient.Modelled_PPG_Item_No.str.contains("Retailer"))
    ].reset_index(drop=True)

    coefficient_matrix_final = pd.DataFrame()
    if len(BaseData_2) > 0:
        # cetegory format function
        def category_format_fn(category):
            category = re.sub("_", " ", category)
            category = re.sub("SNACKS", "Treats", category)
            category = string.capwords(category)
            return category

        Category = category_format_fn(Category)

        for wk in range(52):
            week_no = wk + 1

            BaseData_2["week_num"] = pd.to_datetime(BaseData_2.Date)
            BaseData_2["week_num"] = BaseData_2["week_num"].dt.week
            BaseData_2_wk = BaseData_2[(BaseData_2.week_num == week_no)].reset_index(
                drop=True
            )
            del (BaseData_2["week_num"], BaseData_2_wk["week_num"])

            BaseData_last_quarter_retailer = BaseData_2[
                (BaseData_2.flag_qtr4 == 1)
            ].reset_index(drop=True)
            BaseData_last_quarter_retailer = BaseData_last_quarter_retailer[
                [
                    "PPG_Item_No",
                    "Date",
                    "median_baseprice",
                    "Estimated_baseprice",
                    "tpr_discount_byppg",
                    "Final_baseprice",
                    "ACV_Selling",
                    "wk_sold_avg_price_byppg",
                ]
            ].reset_index(drop=True)

            # ------------------------------------------------------------------------------
            # #### groupby and mutation #####
            # #### To recreate similar dplyr pip effect ####

            # funcs = dict(median_FBP=np.median)
            # d1 = BaseData_last_quarter_retailer.join(BaseData_last_quarter_retailer.groupby(['PPG_Item_No']).Estimated_baseprice.agg(funcs), on=['PPG_Item_No'])
            # d2 = BaseData_last_quarter_retailer.join(BaseData_last_quarter_retailer.groupby(['PPG_Item_No'])[ll[0]].agg(funcs), on=['PPG_Item_No'])
            columns_for_mutation = [
                "Estimated_baseprice",
                "tpr_discount_byppg",
                "Final_baseprice",
                "ACV_Selling",
                "wk_sold_avg_price_byppg",
            ]
            #    funcs_list =[dict(median_FBP=np.median),dict(median_tpr = np.median),dict(Qtr_BP = np.mean),dict(Qtr_acv_selling=np.median),dict(median_price = np.median)]
            mutated_dataframe_list = []
            #    v = []
            for i in range(len(columns_for_mutation)):
                if columns_for_mutation[i] == "Final_baseprice":
                    mutated_dataframe_list.append(
                        BaseData_last_quarter_retailer.groupby(["PPG_Item_No"])[
                            columns_for_mutation[i]
                        ].agg(["mean"])
                    )
                else:
                    mutated_dataframe_list.append(
                        BaseData_last_quarter_retailer.groupby(["PPG_Item_No"])[
                            columns_for_mutation[i]
                        ].agg(["median"])
                    )
            BaseData_last_quarter_retailer_1 = pd.DataFrame()
            for mutate_data in mutated_dataframe_list:
                BaseData_last_quarter_retailer_1 = pd.concat(
                    [BaseData_last_quarter_retailer_1, mutate_data], axis="columns"
                )
            BaseData_last_quarter_retailer_1.columns = [
                "median_EBP",
                "median_tpr",
                "median_FBP",
                "Qtr_acv_selling",
                "median_price",
            ]
            BaseData_last_quarter_retailer_1.reset_index(inplace=True)

            # ------------------------------------------------------------------------------

            j = len(BaseData_last_quarter_retailer_1.PPG_Item_No.unique().tolist())

            model_coeff_canibalisation = new_model_coeff.copy()
            #        column_list = list(model_coefficient.columns)

            df = model_coeff_canibalisation[
                model_coeff_canibalisation.CompKey.str.contains("_Comp_", na=False)
            ]
            df = df[
                [
                    "CompKey",
                    "model_coefficient_name",
                    "PPG_Item_No",
                    "model_coefficient_value",
                ]
            ].drop_duplicates()
            df = df[df.PPG_Item_No.str.contains("Retailer")].reset_index(drop=True)

            # creating constant terms which involves acv, category trend and other constant values
            model_coefficient = model_coefficient[
                model_coefficient.Modelled_PPG_Item_No.str.contains("Retailer")
            ].reset_index(drop=True)
            model_cols = [
                "Modelled_PPG_Item_No",
                "PPG_Description",
                "ACV_Selling",
                "ACV_Feat_Only",
                "ACV_Disp_Only",
                "ACV_Feat_Disp",
                "flag_qtr2",
                "flag_qtr3",
                "flag_qtr4",
                "category_trend",
                "monthno",
                "Intercept",
            ]
            model_columns = model_cols.copy()
            model_cols.clear()
            model_cols_missing_list = [
                not model_columns[i] in list(model_coefficient.columns)
                for i in range(len(model_columns))
            ]
            model_cols_list = [
                model_columns[i] in list(model_coefficient.columns)
                for i in range(len(model_columns))
            ]
            model_cols_missing = []
            indices = list(
                filter(
                    lambda i: model_cols_missing_list[i],
                    range(len(model_cols_missing_list)),
                )
            )
            for i in indices:
                model_cols_missing.append(model_columns[i])
            indices = list(
                filter(lambda i: model_cols_list[i], range(len(model_cols_list)))
            )
            for i in indices:
                model_cols.append(model_columns[i])

            # ### anyway this is not necessary anymore ####
            del model_columns

            model_coeff_constant = model_coefficient[model_cols]
            if len(model_cols_missing) > 0:
                for cols in model_cols_missing:
                    model_coeff_constant[cols] = 0

            model_coeff_constant.ACV_Feat_Disp = (
                BaseData_2_wk.ACV_Feat_Disp * model_coeff_constant.ACV_Feat_Disp
            )
            model_coeff_constant.ACV_Selling = (
                BaseData_last_quarter_retailer_1.Qtr_acv_selling
                * model_coeff_constant.ACV_Selling
            )
            model_coeff_constant.ACV_Feat_Only = (
                BaseData_2_wk.ACV_Feat_Only * model_coeff_constant.ACV_Feat_Only
            )
            model_coeff_constant.ACV_Disp_Only = (
                BaseData_2_wk.ACV_Disp_Only * model_coeff_constant.ACV_Disp_Only
            )
            model_coeff_constant.flag_qtr2 = (
                BaseData_2_wk.flag_qtr2 * model_coeff_constant.flag_qtr2
            )
            model_coeff_constant.flag_qtr3 = (
                BaseData_2_wk.flag_qtr3 * model_coeff_constant.flag_qtr3
            )
            model_coeff_constant.flag_qtr4 = (
                BaseData_2_wk.flag_qtr4 * model_coeff_constant.flag_qtr4
            )
            model_coeff_constant.category_trend = (
                BaseData_2_wk.category_trend * model_coeff_constant.category_trend
            )
            model_coeff_constant.monthno = (
                BaseData_2_wk.monthno
            ) * model_coeff_constant.monthno
            coeff_constant = model_coeff_constant.iloc[
                :, 2 : len(list(model_coeff_constant.columns))
            ]
            model_coeff_constant["constant"] = coeff_constant.sum(
                axis=1
            )  # ## rowsums in r
            del coeff_constant

            # creating only rp and tpr coefficient matrix for ppg modelled
            model_coeff_rp_tpr = model_coefficient[
                [
                    "Modelled_PPG_Item_No",
                    "PPG_Description",
                    "Regular_Price",
                    "Promoted_Discount",
                ]
            ]
            model_coeff_rp_tpr = pd.melt(
                model_coeff_rp_tpr,
                id_vars=["Modelled_PPG_Item_No", "PPG_Description"],
                value_vars=["Regular_Price", "Promoted_Discount"],
            )
            model_coeff_rp_tpr["variable"] = (
                model_coeff_rp_tpr["Modelled_PPG_Item_No"]
                + "_"
                + model_coeff_rp_tpr["variable"]
            )
            retail_ppg_order = (
                model_coeff_rp_tpr.variable.sort_values(ascending=True)
                .reset_index(drop=True)
                .tolist()
            )
            model_coeff_rp_tpr_temp = model_coeff_rp_tpr.copy()
            #             ppg_list = model_coeff_rp_tpr.Modelled_PPG_Item_No.unique().tolist()

            # merging both the matrices to compute coefficient matrix
            model_coeff_comp = model_coefficient[
                ["Modelled_PPG_Item_No"]
                + list(
                    model_coefficient.columns[
                        model_coefficient.columns.str.contains("Comp")
                    ]
                )
            ]
            model_coeff_comp_melt = pd.melt(
                model_coeff_comp,
                id_vars=["Modelled_PPG_Item_No"],
                value_vars=list(
                    model_coefficient.columns[
                        model_coefficient.columns.str.contains("Comp")
                    ]
                ),
            )

            model_coeff_rp_tpr_2 = model_coeff_rp_tpr_temp[
                ["Modelled_PPG_Item_No", "variable", "value"]
            ]
            #            model_coeff_rp_tpr_2 = pd.concat([model_coeff_rp_tpr_2,merged_df_temp],axis=0) # axis = 0 row wise concatenation

            # #### dcast in r, pivot_table in python
            # #### post pivot table operation, it is necessary to reset_index to obtain the hidden first column
            model_coeff_rp_tpr_3 = pd.pivot_table(
                model_coeff_rp_tpr_2,
                values="value",
                index=["Modelled_PPG_Item_No"],
                columns="variable",
            )
            model_coeff_rp_tpr_3.reset_index(inplace=True)
            model_coeff_rp_tpr_3 = pd.DataFrame(model_coeff_rp_tpr_3)
            # ##### check this line -->
            model_coeff_rp_tpr_4 = model_coeff_rp_tpr_3[
                ["Modelled_PPG_Item_No"]
                + list(
                    set(model_coeff_rp_tpr_3.columns.tolist()) & set(retail_ppg_order)
                )
            ].reset_index(
                drop=True
            )  # #set function sorts and takes the unique values

            # #### since set function sorts in ascending order and then the columns are created for the data frame
            # #### so inorder to replicate the same data frame, columns have been ra-arranged, hence this line of code
            col_names_pd = [
                str(string_val)
                for string_val in model_coeff_rp_tpr_4.columns.tolist()
                if ("_Promoted_Discount" in string_val)
            ]
            col_names_rp = [
                str(string_val)
                for string_val in model_coeff_rp_tpr_4.columns.tolist()
                if ("_Regular_Price" in string_val)
            ]
            tot_cols = []
            for str_val in model_coeff_rp_tpr_4.Modelled_PPG_Item_No.tolist():
                tot_cols = tot_cols + [
                    str(string_val)
                    for string_val in col_names_pd
                    if (str_val in string_val)
                ]
                tot_cols = tot_cols + [
                    str(string_val)
                    for string_val in col_names_rp
                    if (str_val in string_val)
                ]
            tot_cols = ["Modelled_PPG_Item_No"] + tot_cols
            model_coeff_rp_tpr_4 = model_coeff_rp_tpr_4[tot_cols]

            model_coeff_rp_tpr_4 = pd.merge(
                model_coeff_rp_tpr_4,
                model_coeff_constant[["Modelled_PPG_Item_No", "constant"]],
                sort=True,
            )
            if len(df) > 0:

                merged_df = pd.merge(
                    df,
                    model_coeff_comp_melt,
                    left_on=["PPG_Item_No", "CompKey"],
                    right_on=["Modelled_PPG_Item_No", "variable"],
                    sort=True,
                )
                merged_df = merged_df[
                    [
                        "PPG_Item_No",
                        "CompKey",
                        "model_coefficient_name",
                        "model_coefficient_value",
                        "value",
                    ]
                ]
                merged_df_temp = merged_df[
                    ["PPG_Item_No", "model_coefficient_name", "value"]
                ]
                merged_df_temp["model_coefficient_name"] = merged_df_temp[
                    "model_coefficient_name"
                ].apply(lambda x: re.sub("_RegularPrice", "_Regular_Price", x))
                merged_df_temp["model_coefficient_name"] = merged_df_temp[
                    "model_coefficient_name"
                ].apply(lambda x: re.sub("_PromotedDiscount", "_Promoted_Discount", x))
                merged_df_temp.rename(
                    columns={
                        "PPG_Item_No": "Modelled_PPG_Item_No",
                        "model_coefficient_name": "variable",
                    },
                    inplace=True,
                )

                merged_df = pd.pivot_table(
                    merged_df,
                    values="model_coefficient_value",
                    index=["PPG_Item_No"],
                    columns="model_coefficient_name",
                )
                merged_df.reset_index(drop=False, inplace=True)
                merged_df = pd.DataFrame(merged_df)
                model_coeff_rp_tpr_2 = model_coeff_rp_tpr_temp[
                    ["Modelled_PPG_Item_No", "variable", "value"]
                ]
                model_coeff_rp_tpr_2 = pd.concat(
                    [model_coeff_rp_tpr_2, merged_df_temp], axis=0
                )  # # axis = 0 row wise concatenation

                # #### dcast in r, pivot_table in python
                # #### post pivot table operation, it is necessary to reset_index to obtain the hidden first column
                model_coeff_rp_tpr_3 = pd.pivot_table(
                    model_coeff_rp_tpr_2,
                    values="value",
                    index=["Modelled_PPG_Item_No"],
                    columns="variable",
                )
                model_coeff_rp_tpr_3.reset_index(inplace=True)
                model_coeff_rp_tpr_3 = pd.DataFrame(model_coeff_rp_tpr_3)
                # ##### check this line -->
                model_coeff_rp_tpr_4 = model_coeff_rp_tpr_3[
                    ["Modelled_PPG_Item_No"]
                    + list(
                        set(model_coeff_rp_tpr_3.columns.tolist())
                        & set(retail_ppg_order)
                    )
                ].reset_index(
                    drop=True
                )  # #set function sorts and takes the unique values

                # #### since set function sorts in ascending order and then the columns are created for the data frame
                # #### so inorder to replicate the same data frame, columns have been ra-arranged, hence this line of code
                col_names_pd = [
                    str(string_val)
                    for string_val in model_coeff_rp_tpr_4.columns.tolist()
                    if ("_Promoted_Discount" in string_val)
                ]
                col_names_rp = [
                    str(string_val)
                    for string_val in model_coeff_rp_tpr_4.columns.tolist()
                    if ("_Regular_Price" in string_val)
                ]
                tot_cols = []
                for str_val in model_coeff_rp_tpr_4.Modelled_PPG_Item_No.tolist():
                    tot_cols = tot_cols + [
                        str(string_val)
                        for string_val in col_names_pd
                        if (str_val in string_val)
                    ]
                    tot_cols = tot_cols + [
                        str(string_val)
                        for string_val in col_names_rp
                        if (str_val in string_val)
                    ]
                tot_cols = ["Modelled_PPG_Item_No"] + tot_cols
                model_coeff_rp_tpr_4 = model_coeff_rp_tpr_4[tot_cols]

                model_coeff_rp_tpr_4 = pd.merge(
                    model_coeff_rp_tpr_4,
                    model_coeff_constant[["Modelled_PPG_Item_No", "constant"]],
                    sort=True,
                )

                # #########interaction terms
                merged_df_interaction = merged_df[
                    ["PPG_Item_No"]
                    + [
                        str(string_val)
                        for string_val in merged_df.columns.tolist()
                        if (string_val.count("ITEM") == 2)
                    ]
                ]

                if len(merged_df_interaction.columns.tolist()) > 1:
                    merged_df_interaction = merged_df_interaction[
                        ["PPG_Item_No"]
                        + sorted(
                            [
                                str(string_val)
                                for string_val in merged_df_interaction.columns.tolist()
                                if ("RegularPrice" in string_val)
                            ]
                        )
                        + sorted(
                            [
                                str(string_val)
                                for string_val in merged_df_interaction.columns.tolist()
                                if ("PromotedDiscount" in string_val)
                            ]
                        )
                    ]

                merged_df = pd.DataFrame(merged_df)
                merged_df_acting = merged_df[
                    ["PPG_Item_No"]
                    + [
                        str(string_val)
                        for string_val in merged_df.columns.tolist()
                        if (string_val.count("ITEM") == 1)
                    ]
                ]

                if len(merged_df_acting.columns.tolist()) > 1:
                    merged_df_acting = merged_df_acting[
                        [
                            str(string_val)
                            for string_val in merged_df_acting.columns.tolist()
                            if ("ROM_PromotedDiscount" not in string_val)
                        ]
                    ]
                    if len(merged_df_acting.columns.tolist()) > 1:
                        merged_df_acting = merged_df_acting[
                            [
                                str(string_val)
                                for string_val in merged_df_acting.columns.tolist()
                                if ("PromotedDiscount" not in string_val)
                            ]
                        ]
                        retail_ppg_order_2 = [
                            re.sub("Regular_Price", "RegularPrice", string_val)
                            for string_val in retail_ppg_order
                        ]
                        retail_ppg_order_2 = [
                            re.sub("Promoted_Discount", "PromotedDiscount", string_val)
                            for string_val in retail_ppg_order_2
                        ]
                        if len(merged_df_acting.columns.tolist()) > 1:
                            # this code chunk can also be used
                            # set(merged_df_acting.columns.tolist())-set(retail_ppg_order_2)
                            merged_df_acting = merged_df_acting[
                                [
                                    col_name
                                    for col_name in merged_df_acting.columns.tolist()
                                    if col_name not in retail_ppg_order_2
                                ]
                            ]

                if len(merged_df_acting.columns.tolist()) > 1:
                    coefficient_matrix = pd.merge(
                        model_coeff_rp_tpr_4,
                        merged_df_acting,
                        left_on=["Modelled_PPG_Item_No"],
                        right_on=["PPG_Item_No"],
                        how="left",
                        sort=True,
                    )
                else:
                    coefficient_matrix = model_coeff_rp_tpr_4.copy()

                coefficient_matrix.fillna(0, inplace=True)

                length = len(coefficient_matrix.columns.tolist())

                model_data_set_3 = model_data_set_2.copy()
                model_data_set_3.Date = model_data_set_3.Date.astype(str)
                model_data_set_3 = model_data_set_3[
                    (model_data_set_3.Date >= "2019-01-01")
                    & (model_data_set_3.Date <= "2019-12-31")
                ].reset_index(drop=True)
                model_data_set_3["week_num"] = pd.to_datetime(model_data_set_3.Date)
                model_data_set_3["week_num"] = model_data_set_3["week_num"].dt.week
                model_data_set_3_wk = model_data_set_3[
                    (model_data_set_3.week_num == week_no)
                ].reset_index(drop=True)
                del (model_data_set_3["week_num"], model_data_set_3_wk["week_num"])

                #                regular_inter_no = 0
                #                tpr_inter_no = 0
                coefficient_matrix = pd.DataFrame(coefficient_matrix)

                if len(coefficient_matrix.columns.tolist()) > ((j * 2) + 2):
                    cols = coefficient_matrix.columns.tolist()
                    cols = cols[((2 * j) + 2) : (length)]
                    cols1 = [
                        re.sub("_RegularPrice", "", string_val) for string_val in cols
                    ]
                    model_data_set_3_wk = model_data_set_3_wk[
                        model_data_set_3_wk.PPG_Item_No.isin(cols1)
                    ]
                    for i in range(j):
                        for k in range(1, len(cols)):

                            #            term = model_data_set_3_wk[model_data_set_3_wk$PPG_Item_No==(gsub("_RegularPrice","",k)),"Final_baseprice"]

                            term = model_data_set_3_wk[
                                model_data_set_3_wk.PPG_Item_No == cols1[k]
                            ]
                            term = term["Final_baseprice"]
                            term = np.log(term)
                            coefficient_matrix.loc[i, cols[k]] = coefficient_matrix.loc[
                                i, cols[k]
                            ] * np.array(term)

                    coeff_constant = coefficient_matrix.iloc[
                        :, ((2 * j) + 2 - 1) : length
                    ]
                    coefficient_matrix["constant"] = coeff_constant.sum(
                        axis=1
                    )  # ## rowsums in r
                    del coeff_constant
                    coefficient_matrix.drop(cols, axis=1, inplace=True)

                length = len(coefficient_matrix.columns.tolist())
                ncol_inter = len(merged_df_interaction.columns.tolist())
                # #merge with interaction terms
                if ncol_inter > 1:
                    cols_interaction = merged_df_interaction.columns.tolist()
                    cols_interaction = cols_interaction[1:ncol_inter]
                    #                    constant_col = None # ## please check the purpose of this line in r
                    coefficient_matrix = pd.merge(
                        coefficient_matrix,
                        merged_df_interaction,
                        left_on=["Modelled_PPG_Item_No"],
                        right_on=["PPG_Item_No"],
                        how="left",
                        sort=True,
                    )
                    coefficient_matrix.drop(["PPG_Item_No"], axis=1, inplace=True)
                    coefficient_matrix.fillna(0, inplace=True)

            #                    regular_inter_no = len([str(string_val) for string_val in cols_interaction if("RegularPrice" in string_val) ])
            #                    tpr_inter_no = len([str(string_val) for string_val in cols_interaction if("PromotedDiscount" in string_val) ])
            else:
                coefficient_matrix = pd.DataFrame(model_coeff_rp_tpr_4)
                coefficient_matrix = coefficient_matrix.replace(np.nan, 0)
            coefficient_matrix["week"] = week_no - 1
            coefficient_matrix = coefficient_matrix.merge(
                model_coefficient[
                    ["Modelled_PPG_Item_No", "Pantry_Loading_1", "Pantry_Loading_2"]
                ],
                on="Modelled_PPG_Item_No",
            ).reset_index(drop=True)
            coefficient_matrix.rename(
                columns={"Modelled_PPG_Item_No": "PPG_Item_No"}, inplace=True
            )
            coefficient_matrix_final = pd.concat(
                [coefficient_matrix_final, coefficient_matrix], axis=0
            )  # # axis = 0 row wise concatenation - rbind
        # ------------------------------------------------------------------------------
        st_pt = BaseData_2[
            [
                "PPG_Item_No",
                "Date",
                "tpr_discount_byppg",
                "tpr_discount_byppg_lag1",
                "tpr_discount_byppg_lag2",
                "median_baseprice",
                "wk_sold_avg_price_byppg",
                "Spend",
                "Final_baseprice",
                "wk_sold_doll_byppg",
            ]
        ].reset_index(drop=True)
        st_pt["Category"] = Category
        st_pt["Retailer"] = Retailer
        BaseData_last_quarter_retailer_1.Category = Category
        BaseData_last_quarter_retailer_1.Retailer = Retailer
        # --MAP Data
        baseline_sales = st_pt
        baseline_sales["events"] = np.where(
            baseline_sales.tpr_discount_byppg < 0.05, 1, 0
        )
        baseline_sales["week"] = pd.to_datetime(baseline_sales.Date).dt.week - 1
        coefficient_matrix = coefficient_matrix_final.merge(
            baseline_sales[
                [
                    "PPG_Item_No",
                    "week",
                    "tpr_discount_byppg_lag1",
                    "tpr_discount_byppg_lag2",
                    "events",
                    "median_baseprice",
                    "tpr_discount_byppg",
                ]
            ],
            on=["PPG_Item_No", "week"],
        )
        coefficient_matrix["Retailer"] = "Retailer" + Retailer
        coefficient_matrix["Category"] = "Category" + Category

        logger.info("Data preparation done")
        logger.info("*********************")

        # --------------------------------- Data Conversion --------------------------------------------

        coef = coefficient_matrix.copy()
        new_col_names = []
        for col in coef.columns:
            if "ITEM" in col and "Retailer_Regular_Price" in col:
                new_col_names.append(
                    "_".join(
                        [
                            "Product" + i + "_Retailer_Regular_Price"
                            for i in re.findall(r"[0-9]+", col)
                        ]
                    )
                )
            elif "ITEM" in col and "Retailer_Promoted_Discount" in col:
                new_col_names.append(
                    "_".join(
                        [
                            "Product" + i + "_Retailer_Promoted_Discount"
                            for i in re.findall(r"[0-9]+", col)
                        ]
                    )
                )

            else:
                new_col_names.append(col)
        coef.columns = new_col_names
        coef.rename(columns={"PPG_Item_No": "Product", "week": "wk"}, inplace=True)
        coef["Product"] = coef["Product"].apply(
            lambda x: "Product" + "".join(re.findall(r"[0-9]+", x)) + "_Retailer"
        )

        Historical_Events = coef[["Product", "Category", "Retailer", "events", "wk"]]
        Historical_Events.rename(
            columns={"events": "Event", "wk": "WeekNumber"}, inplace=True
        )
        Historical_Events["Product"] = Historical_Events["Product"].apply(
            lambda x: "Product" + "".join(re.findall(r"[0-9]+", x)) + "_Retailer"
        )

        Final_Base_Price = coef[["Product", "Category", "Retailer", "median_baseprice"]]
        Final_Base_Price = Final_Base_Price.pivot_table(
            index=["Product", "Category", "Retailer"], aggfunc="max"
        ).reset_index()
        Final_Base_Price["Product"] = Final_Base_Price["Product"].apply(
            lambda x: "Product" + "".join(re.findall(r"[0-9]+", x)) + "_Retailer"
        )
        Final_Base_Price.rename(
            columns={"median_baseprice": "Final_baseprice"}, inplace=True
        )

        Final_Spend_Data = baseline_sales.copy()
        Final_Spend_Data["PPG_RP_Spend"] = (
            Final_Spend_Data["events"] * Final_Spend_Data["Spend"]
        )
        Final_Spend_Data["PPG_TPR_Spend"] = (
            1 - Final_Spend_Data["events"]
        ) * Final_Spend_Data["Spend"]
        Final_Spend_Data["RP_Events"] = Final_Spend_Data["events"]
        Final_Spend_Data["TPR_Events"] = 1 - Final_Spend_Data["events"]
        Final_Spend_Data.rename(columns={"PPG_Item_No": "Product"}, inplace=True)
        Final_Spend_Data = Final_Spend_Data.pivot_table(
            index=["Product"], aggfunc="sum"
        ).reset_index()
        Final_Spend_Data["Retailer"] = "Retailer" + Retailer
        Final_Spend_Data["Category"] = "Category" + Category
        Final_Spend_Data["Product"] = Final_Spend_Data["Product"].apply(
            lambda x: "Product" + "".join(re.findall(r"[0-9]+", x)) + "_Retailer"
        )
        Final_Spend_Data["PPG_Total_Spend"] = (
            Final_Spend_Data["PPG_RP_Spend"] + Final_Spend_Data["PPG_TPR_Spend"]
        )
        Final_Spend_Data = Final_Spend_Data[
            [
                "Product",
                "Category",
                "Retailer",
                "PPG_RP_Spend",
                "PPG_TPR_Spend",
                "PPG_Total_Spend",
                "RP_Events",
                "TPR_Events",
            ]
        ]

        exclude = [
            "tpr_discount_byppg_lag1",
            "tpr_discount_byppg_lag2",
            "events",
            "median_baseprice",
            "tpr_discount_byppg",
        ]
        coef = coef[[col for col in coef.columns if col not in exclude]]

        #         coef.to_csv("../../data/tpo_continuous/Optimization/Coeff Matrix/Coeff_Matrix_Category2_Retailer11.csv",index=False)

        #         Final_Base_Price.to_csv("../../data/tpo_continuous/Optimization/FinalBasePrice.csv",index=False)

        #         Final_Spend_Data.to_csv("../../data/tpo_continuous/Optimization/FinalSpendsData.csv",index=False)

        #         Historical_Events.to_csv("../../data/tpo_continuous/Optimization/HistoricalEvents.csv",index=False)
        #         coef.to_csv("Coeff_Matrix_Category2_Retailer11.csv", index=False)

        #         Final_Base_Price.to_csv("FinalBasePrice.csv", index=False)

        #         Final_Spend_Data.to_csv("FinalSpendsData.csv", index=False)

        #         Historical_Events.to_csv("HistoricalEvents.csv", index=False)

        return (coef, Final_Base_Price, Final_Spend_Data, Historical_Events)


if __name__ == "__main__":
    try:
        Data_Load("1", "1")
    except Exception as e:
        logger.error("\n Error in Preparing data : " + str(e))
