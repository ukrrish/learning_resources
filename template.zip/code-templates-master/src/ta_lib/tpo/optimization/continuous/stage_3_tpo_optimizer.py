#!/usr/bin/env python3
# -*- coding: utf-8 -*#
# Created on 02/06/20 11:46 PM
# @author: Gurusankar G
# @author: Saravanakumar V
# @author: Nilagnik C


from __future__ import division

import logging
import os
import os.path as op
import re
import time
from functools import reduce

import numpy as np
import pyomo.environ as pyo

from ta_lib.core import dataset
from ta_lib.core.api import create_context, initialize_environment
from ta_lib.tpo.optimization.continuous.stage_2_tpo_optimizer import (
    Stage2_caller,
    TPR_Spend_calc_edge_case,
)

logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)

initialize_environment(debug=False, hide_warnings=True)
m_path = os.path.dirname(dataset.__file__).replace("\\", "/")
config_path = op.join(
    m_path + "/../../notebooks/tpo/python/continuous_optimization/conf", "config.yml"
)  # noqa
context = create_context(config_path)

temp = None
temp_EDLP_Val = None
temp_TPR_Val = None
temp_FLAG_Val = None


def Retailer_Unit_Sales_Stg3_Fn(Model, P, W):
    """Define pyomo callback for calculating product unit sales.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    P :    Integer, PPG number to calculate Unit sales for the given week . Will be iteratively called by Model Objective function
    Wk : Integer, Week number for the year
    Returns:
    --------
    Pyomo Expression, containing Product Unit Sales equation for the given week

    """
    Self = pyo.exp(
        (
            pyo.log(Model.EDLP[P, W] * globals.Base_Price_stg2[P][W])
            * globals.EDLP_Coef[P][P]
        )
        * globals.FLAG_Inter[P, W]
        + (
            pyo.log(globals.Base_Price_stg2[P][W]) * globals.EDLP_Coef[P][P]
            + Model.TPR[P, W] * globals.TPR_Coef[P][P]
        )
        * (1 - globals.FLAG_Inter[P, W])
        + globals.Intercepts_stg2[W][P]
    )
    Comp = Competitor_Unit_Effect_Stg3_Fn(Model, P, W)
    EDLP_Inter_Val = EDLP_Interaction_Unit_Effect_Stg3_Fn(Model, P, W)
    TPR_Inter_Val = TPR_Interaction_Unit_Effect_Stg3_Fn(Model, P, W)
    Pantry_Loading_Val = Pantry_Loading_Unit_Effect_Fn(Model, P, W)
    Unit_Sales = Self * Comp * EDLP_Inter_Val * TPR_Inter_Val * Pantry_Loading_Val
    return Unit_Sales


def Competitor_Unit_Effect_Stg3_Fn(Model, Cur_Ret, Wk):
    """Define pyomo callback for calculating competitor effect.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Cur_Ret :    Integer, PPG number to calculate EDLP Competitor Effect for the given week . Will be iteratively called by Model Objective function
    Wk : Integer, Week number for the year
    Returns:
    --------
    Pyomo Expression, containing Competitor Unit Effect for the Product for the given week

    """
    Comp_Retailers_Unit_Sales = [
        pyo.exp(
            (
                pyo.log(Model.EDLP[i, Wk] * globals.Base_Price_stg2[i][Wk])
                * globals.EDLP_Coef[Cur_Ret][i]
            )
            * globals.FLAG_Inter[i, Wk]
            + (
                pyo.log(globals.Base_Price_stg2[i][Wk]) * globals.EDLP_Coef[Cur_Ret][i]
                + Model.TPR[i, Wk] * globals.TPR_Coef[Cur_Ret][i]
            )
            * (1 - globals.FLAG_Inter[i, Wk])
        )
        for i in Model.PPG_index
        if i != Cur_Ret
    ]
    return reduce(lambda x, y: x * y, Comp_Retailers_Unit_Sales, 1)


def EDLP_Interaction_Unit_Effect_Stg3_Fn(Model, P, Wk):
    """Define pyomo callback for calculating EDLP interactions.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    P :    Integer, PPG number to calculate EDLP Interaction Effect for the given week . Will be iteratively called by Model Objective function
    Wk : Integer, Week number for the year
    Returns:
    --------
    Pyomo Expression, containing product EDLP Interaction equation for the given week

    """
    EDLP_Interaction_Unit_Effect = [1]
    P1 = int("".join(re.findall(r"[0-9]+", globals.Mapping_reverse[P])))
    for Inter in globals.EDLP_Interactions:
        if P1 in Inter:
            Pr_ind1, Pr_ind2 = Inter
            Comb = str(Pr_ind1) + "_" + str(Pr_ind2)
            Pr_ind1 = globals.Mapping["Product" + str(Pr_ind1) + "_Retailer"]
            Pr_ind2 = globals.Mapping["Product" + str(Pr_ind2) + "_Retailer"]
            Val1 = globals.Base_Price_stg2[Pr_ind1][Wk] * (
                1 - globals.FLAG_Inter[Pr_ind1, Wk]
            ) + (Model.EDLP[Pr_ind1, Wk] * globals.Base_Price_stg2[Pr_ind1][Wk]) * (
                globals.FLAG_Inter[Pr_ind1, Wk]
            )
            Val2 = globals.Base_Price_stg2[Pr_ind2][Wk] * (
                1 - globals.FLAG_Inter[Pr_ind2, Wk]
            ) + (Model.EDLP[Pr_ind2, Wk] * globals.Base_Price_stg2[Pr_ind2][Wk]) * (
                globals.FLAG_Inter[Pr_ind2, Wk]
            )
            Val = pyo.exp(
                pyo.log(Val1) * pyo.log(Val2) * globals.EDLP_Int_Coef_Values[Comb][P]
            )
            EDLP_Interaction_Unit_Effect.append(Val)
    return reduce(lambda x, y: x * y, EDLP_Interaction_Unit_Effect)


def TPR_Interaction_Unit_Effect_Stg3_Fn(Model, P, Wk):
    """Define pyomo callback for calculating TPR interactions.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    P :    Integer, PPG number to calculate TPR Interaction Effect for the given week . Will be iteratively called by Model Objective function
    Wk : Integer, Week number for the year
    Returns:
    --------
    Pyomo Expression, containing product TPR Interaction equation for the given week

    """
    TPR_Interaction_Unit_Effect = [1]
    P1 = int("".join(re.findall(r"[0-9]+", globals.Mapping_reverse[P])))
    for Inter in globals.TPR_Interactions:
        if P1 in Inter:
            Pr_ind1, Pr_ind2 = Inter
            Comb = str(Pr_ind1) + "_" + str(Pr_ind2)
            Pr_ind1 = globals.Mapping["Product" + str(Pr_ind1) + "_Retailer"]
            Pr_ind2 = globals.Mapping["Product" + str(Pr_ind2) + "_Retailer"]
            Val = pyo.exp(
                (
                    Model.TPR[Pr_ind1, Wk]
                    * Model.TPR[Pr_ind2, Wk]
                    * globals.TPR_Int_Coef_Values[Comb][P]
                    * (1 - globals.FLAG_Inter[Pr_ind1, Wk])
                    * (1 - globals.FLAG_Inter[Pr_ind2, Wk])
                )
            )
            TPR_Interaction_Unit_Effect.append(Val)
    return reduce(lambda x, y: x * y, TPR_Interaction_Unit_Effect)


def Pantry_Loading_Unit_Effect_Fn(Model, P, Wk):
    """Define pyomo callback for individual product pantry loading effect.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    P :    Integer, PPG number to calculate Pantry Loading Effect for the given week . Will be iteratively called by Model Objective function
    Wk : Integer, Week number for the year
    Returns:
    --------
    Pyomo Expression, containing product Pantry Unit Effect equation for the given week

    """
    Pantry_1_Effect = Pantry_2_effect = 1
    PL_Coef1 = globals.Pantry_1[Wk][P]
    PL_Coef2 = globals.Pantry_2[Wk][P]
    if Wk > 0:
        Pantry_1_Effect = pyo.exp(
            Model.TPR[P, Wk - 1] * PL_Coef1 * (1 - globals.FLAG_Inter[P, Wk - 1])
        )
    if Wk > 1:
        Pantry_2_effect = pyo.exp(
            Model.TPR[P, Wk - 2] * PL_Coef2 * (1 - globals.FLAG_Inter[P, Wk - 2])
        )
    Pantry_Loading_Unit_Effect = Pantry_1_Effect * Pantry_2_effect
    return Pantry_Loading_Unit_Effect


def Retailer_Price_Fn(Model, P, W):
    """Define pyomo callback for individual product price with model parameters.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    P :    Integer, PPG number to calculate Retailer Price for the given week . Will be iteratively called by Model Objective function
    Wk : Integer, Week number for the year
    Returns:
    --------
    Pyomo Expression, containing product Retailer Price equation for the given week

    """
    Price = (
        globals.Base_Price_stg2[P][W]
        * (1 - Model.TPR[P, W])
        * (1 - globals.FLAG_Inter[P, W])
    ) + (Model.EDLP[P, W] * globals.Base_Price_stg2[P][W] * globals.FLAG_Inter[P, W])
    return Price


def Dollar_Sales_Fn(Model):
    """Define pyomo callback for calculating dollar sales.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Returns:
    --------
    Pyomo Expression, containing Dollar sales equation

    """
    return sum(
        [
            Retailer_Unit_Sales_Stg3_Fn(Model, P, W) * Retailer_Price_Fn(Model, P, W)
            for W in Model.Wk_index
            for P in Model.PPG_index
        ]
    )


# Trade Spend Constraints
def Total_Trade_Spent_Bnd_Fn(Model, Cur_Ret):
    """Define pyomo callback for calculating bound for total trade spent.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Cur_Ret :    Integer, PPG number to calculate Total Trade Spent for all the weeks . Will be iteratively called by Model Objective function
    Returns:
    --------
    Pyomo Expression, containing product Total Trade Spent equation

    """
    Val = sum(
        [
            (
                globals.Base_Price_stg2[Cur_Ret][Wk]
                - Retailer_Price_Fn(Model, Cur_Ret, Wk)
            )
            * Retailer_Unit_Sales_Stg3_Fn(Model, Cur_Ret, Wk)
            for Wk in Model.Wk_index
        ]
    )
    return pyo.inequality(
        globals.Target_Trade_Spend[Cur_Ret] * (1 - globals.Ov_Perc_Limit / 100),
        Val,
        globals.Target_Trade_Spend[Cur_Ret] * (1 + globals.Ov_Perc_Limit / 100),
    )


def EDLP_Trade_Spent_Bnd_Fn(Model, Cur_Ret):
    """Define pyomo callback for calculating bound for EDLP trade spent.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Cur_Ret :    Integer, PPG number to calculate EDLP Trade Spent for all the weeks . Will be iteratively called by Model Objective function
    Returns:
    --------
    Pyomo Expression, containing product EDLP Trade Spent equation

    """
    Val = sum(
        [
            (
                globals.Base_Price_stg2[Cur_Ret][Wk]
                - Retailer_Price_Fn(Model, Cur_Ret, Wk)
            )
            * Retailer_Unit_Sales_Stg3_Fn(Model, Cur_Ret, Wk)
            * (globals.FLAG_Inter[Cur_Ret, Wk])
            for Wk in Model.Wk_index
        ]
    )
    return pyo.inequality(
        globals.Target_EDLP_Spend[Cur_Ret] * (1 - globals.EDLP_Perc_Limit / 100),
        Val,
        globals.Target_EDLP_Spend[Cur_Ret] * (1 + globals.EDLP_Perc_Limit / 100),
    )


def TPR_Trade_Spent_Bnd_Fn(Model, Cur_Ret):
    """Define pyomo callback for calculating bound for TPR trade spent.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Cur_Ret :    Integer, PPG number to calculate TPR Trade Spent for all the weeks . Will be iteratively called by Model Objective function
    Returns:
    --------
    Pyomo Expression, containing product TPR Trade Spent equation

    """
    Val = sum(
        [
            (
                globals.Base_Price_stg2[Cur_Ret][Wk]
                - Retailer_Price_Fn(Model, Cur_Ret, Wk)
            )
            * Retailer_Unit_Sales_Stg3_Fn(Model, Cur_Ret, Wk)
            * (1 - globals.FLAG_Inter[Cur_Ret, Wk])
            for Wk in range(globals.Tot_Week)
        ]
    )
    LHS = globals.Target_TPR_Spend[Cur_Ret] * (1 - globals.TPR_Perc_Limit / 100)
    RHS = globals.Target_TPR_Spend[Cur_Ret] * (1 + globals.TPR_Perc_Limit / 100)
    if RHS == 0:
        Max_Events, UB_TPR_Spend = TPR_Spend_calc_edge_case(Model, Cur_Ret)
        if UB_TPR_Spend:
            # []
            RHS = UB_TPR_Spend
    return pyo.inequality(LHS, Val, RHS)


def Overall_Total_Trade_Spent_Fn(Model):
    """To establish constraint on overall trade spend for pyomo model.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables
    Returns:
    --------
    Pyomo Expression, containing OVerall Trade equation

    """
    return sum(
        [
            sum(
                [
                    (
                        globals.Base_Price_stg2[Cur_Ret][Wk]
                        - Retailer_Price_Fn(Model, Cur_Ret, Wk)
                    )
                    * Retailer_Unit_Sales_Stg3_Fn(Model, Cur_Ret, Wk)
                    for Wk in range(globals.Tot_Week)
                ]
            )
            for Cur_Ret in range(globals.Tot_Prod)
        ]
    ) == sum(globals.Target_Trade_Spend)


# Creating Pyomo Model


def Create_Model_Stg3(EDLP_Init, TPR_Init, fallback, historical_edlp):
    """To create a Pyomo model.

    Model consists of
    1. Functions to properly initialize EDLP and TPR values from previous operations
    2. Variables to optimize
    3. Objective function
    4. Constraints
    Parameters
    ----------
    EDLP_Init : numpy Array / List of Lists for Initializing EDLP variable for model
    TPR_Init : numpy Array / List of Lists for Initializing TPR variable for model
    fallback : Boolean, True to use historical EDLP value as initialization
    historical_edlp : numpy Array / List of Lists for Initializing EDLP variable for model

    """

    def EDLP_Initialize(Model, *Index):
        if not fallback:
            if EDLP_Init:
                return EDLP_Init[Index[0]]
            else:
                return globals.EDLP_LB
        else:
            if historical_edlp:
                return historical_edlp[Index[0]]
            else:
                if EDLP_Init:
                    return EDLP_Init[Index[0]]
                else:
                    return globals.EDLP_LB

    def TPR_Initialize(Model, *Index):
        if TPR_Init:
            return TPR_Init[Index[0]]
        else:
            return globals.TPR_UB

    Model = pyo.ConcreteModel(name="Spend_Optim")
    Model.Weeks = pyo.Param(initialize=globals.Tot_Week, domain=pyo.PositiveIntegers)
    Model.PPGs = pyo.Param(initialize=globals.Tot_Prod, domain=pyo.PositiveIntegers)
    Model.Wk_index = pyo.RangeSet(0, Model.Weeks - 1)
    Model.PPG_index = pyo.RangeSet(0, Model.PPGs - 1)
    Model.EDLP = pyo.Var(
        Model.PPG_index,
        Model.Wk_index,
        initialize=EDLP_Initialize,
        domain=pyo.NonNegativeReals,
        bounds=(globals.EDLP_LB, globals.EDLP_UB),
    )
    Model.TPR = pyo.Var(
        Model.PPG_index,
        Model.Wk_index,
        initialize=TPR_Initialize,
        domain=pyo.NonNegativeReals,
        bounds=(globals.TPR_LB, globals.TPR_UB),
    )
    Model.Obj = pyo.Objective(rule=Dollar_Sales_Fn, sense=pyo.maximize)
    Model.Tot_Spent_Bnd = pyo.Constraint(Model.PPG_index, rule=Total_Trade_Spent_Bnd_Fn)
    Model.EDLP_Bnd = pyo.Constraint(Model.PPG_index, rule=EDLP_Trade_Spent_Bnd_Fn)
    Model.TPR_Bnd = pyo.Constraint(Model.PPG_index, rule=TPR_Trade_Spent_Bnd_Fn)
    Model.Overall = pyo.Constraint(rule=Overall_Total_Trade_Spent_Fn)
    return Model


# Solver Calling With Pyomo Model


def Call_Solver_Stg3(
    EDLP_Init,
    TPR_Init,
    PPGs,
    Wks,
    name="bonmin",
    obj=1,
    fallback=False,
    historical_edlp=None,
):
    """To Generate and call a pyomo model.

    The function generates a generic model which can be ran across solvers
    which are supported in the Pyomo framework and can solve MINLP problems
    ex-Bonmin, Baron. Init values of TPR and EDLP passed to the function
    are coming from phase 2 or are historically biased
    Parameters
    ----------
    EDLP_Init : numpy Array / List of Lists for Initializing EDLP variable for model
    TPR_Init : numpy Array / List of Lists for Initializing TPR variable for model
    PPG : Integer, Number of Total Products to be passed
    Wks : Integer, Number of Total Weeks to be passed
    name : String, (Optional) Name of the solver to be used
    obj : Initial value of the Objective (Optional) to keep running the solver till the maximum value is reached
    fallback : Boolean, True to use historical EDLP value as initialization
    historical_edlp : numpy Array / List of Lists for Initializing EDLP variable for model
    Returns:
    --------
    Pyomo Model, containing Model Object with required variables

    """
    Model = Create_Model_Stg3(
        EDLP_Init, TPR_Init, fallback, historical_edlp
    )  # create model
    path = (
        m_path
        + "/../../scripts/tpo_continuous/optimization/Triple_Stage_Optimizer/bonmin-win32/bonmin.exe"
    )  # noqa

    Opt = pyo.SolverFactory(name, executable=path)  # solve model
    Opt.options["tol"] = 1e-4
    Opt.options["max_cpu_time"] = globals.TIME_STAGE3
    # opt.options['max_iter']= 50000
    # Opt.options['bonmin.time_limit'] = 1800
    Opt.options["bonmin.algorithm"] = "B-Hyb"
    start_time = time.time()
    if globals.Stage2Success:  # check for previous stage covergence
        try:
            Result = Opt.solve(Model)
            if str(Result.solver.status) != "ok":
                raise Exception("Solver Status should be OK")
            if str(Result.solver.termination_condition) != "optimal":
                raise Exception("Terminal Condition should be Optimal")
            globals.Stage3Success = True
        except Exception as e:
            logger.error("\nError in Solving problem" + str(e))
            globals.Stage3Success = False
    end_time = time.time()
    #    Model.display()
    EDLP_Val = np.array(
        [pyo.value(Model.EDLP[i, j]) for i in range(PPGs) for j in range(Wks)]
    ).reshape(PPGs, Wks)
    TPR_Val = np.array(
        [pyo.value(Model.TPR[i, j]) for i in range(PPGs) for j in range(Wks)]
    ).reshape(PPGs, Wks)
    #     FLAG_Val = globals.FLAG_Inter

    if (
        globals.Stage3Success and pyo.value(Model.Obj) > obj
    ):  # load model output to global data class if true optimization is achieved
        logger.info(
            "\n\n Optimizer Third Stage Results:\n##############################\n\n"
        )
        # log_infeasible_constraints(Model)
        # log_infeasible_bounds(Model)
        logger.info(pyo.value(Model.Obj))
        globals.Solver_Model_Result = Model
        globals.EDLP_Final = EDLP_Val
        globals.TPR_Final = TPR_Val
        el_time = " The Elapsed Time is --- %s Seconds ---" % (end_time - start_time)
        btime = f"{name} Solver Execution Time: {Result['Solver'][0]['Time']}"
        logger.info(
            f"Elapsed_Time: {el_time}\n\nBonmin Time: {btime}\n\nObjective_Value: {pyo.value(Model.Obj)}"
        )
        logger.info(
            f"Message: {Result['Solver'][0]['Message']},Termination: {Result['Solver'][0]['Termination condition']},Status: {Result['Solver'][0]['Status']},Objective_Value: {pyo.value(Model.Obj)}"
        )
        Call_Solver_Stg3.Obj_Val = pyo.value(Model.Obj)
    else:
        # log_infeasible_constraints(Model)
        # log_infeasible_bounds(Model)
        Call_Solver_Stg3.Obj_Val = obj
        globals.Stage3Success = False
        globals.Solver_Model_Result = Model


def Stage3_caller(global_vars):
    """Task of the function is to get the initialized global data class.

    Inject it into second stage and wait for the outputs
    form the second stage solver then shall call the third stage solver of the pipeline with
    interim FLAG EDLP and TPR values to be used as init values in this phase
    If solution is not achieved with the above approach we move to a fallback logic
    Parameters
    ----------
    global_vars : Object, Globally defined variables is being passed

    """
    global globals
    globals = global_vars
    Stage2_caller(global_vars)
    # time.sleep(1000)
    logger.info(f"\n\nSolving Third Stage : Ret {globals.Ret} Cat {globals.Cat}")

    Call_Solver_Stg3(
        globals.EDLP_Inter,
        globals.TPR_Inter,
        globals.Tot_Prod,
        globals.Tot_Week,
        name="bonmin",
        obj=1,
        fallback=False,
        historical_edlp=globals.historical_edlp_init,
    )

    if not (check_positive_increment(globals.Solver_Model_Result)) or (
        not globals.Stage3Success
    ):
        fallback_Stage3_caller()  # Fallback Caller


def check_positive_increment(Model):
    """To check if an increment from baseline is achieved.

    Parameters
    ----------
    Model : Pyomo Model Object created with the required variables

    """
    try:
        baseline = dataset.load_dataset(context, "raw/Base_Output")
    except Exception as e:
        logger.error("\n Error in saving results : " + str(e))
    try:
        baseline_array = np.array(
            baseline[
                (baseline.Retailer == "Retailer" + str(globals.Ret))
                & (baseline.Category == "Category" + str(globals.Cat))
            ]
        )[0]

        Baseline_Sales = baseline_array[2]
        Optimized_Sales = pyo.value(Model.Obj)
        Incremental_Sales = Optimized_Sales - Baseline_Sales
        return Incremental_Sales > 0

    except Exception:
        return True


def fallback_Stage3_caller():
    """To cover Fallback case.

    Fallback logic is triggered after a solution has not been acheived by
    using init values from stage 2.Function biases the init values by directly
    injecting the historical values and running the third phase again

    """
    logger.info(
        f"\n\nSolving Third Stage with historical bias : Ret {globals.Ret} Cat {globals.Cat}"
    )
    globals.Stage3Success = False
    globals.Stage2Success = True

    globals.TPR_Inter = globals.EDLP_Inter = None
    flag_init = globals.historical_df.Event.tolist()
    flag_init = [(1 - x) for x in flag_init]
    flag_init = np.array(flag_init).reshape(globals.Tot_Prod, globals.Tot_Week)
    globals.FLAG_Inter = flag_init
    Call_Solver_Stg3(
        globals.EDLP_Inter,
        globals.TPR_Inter,
        globals.Tot_Prod,
        globals.Tot_Week,
        name="bonmin",
        obj=1,
        fallback=True,
        historical_edlp=globals.historical_edlp_init,
    )


if (
    __name__ == "__main__"
):  # only for testing purposes shall not be fired if ran with Caller.py
    globals.init(2, 7)
    Stage2_caller()
    Call_Solver_Stg3(
        globals.EDLP_Inter,
        globals.TPR_Inter,
        globals.Tot_Prod,
        globals.Tot_Week,
        name="bonmin",
        obj=1,
    )
