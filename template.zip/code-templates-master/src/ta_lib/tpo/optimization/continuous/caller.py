# !/usr/bin/env python3
# -*- coding: utf-8 -*-

# Created on 05/06/20 3:55 PM
# @author: Gurusankar G
# @author: Saravanakumar V
# @author: Nilagnik C

# Necessary imports includes importing a Single Stage Optimizer package
# which has to be relative to the this triple optimizer package

import collections
import logging
import os
import time

from tqdm import tqdm

import results_helper as res
import xmltodict
from global_data_init_class import global_initializer
from stage_3_tpo_optimizer import Stage3_caller

logger = logging.getLogger(__name__)
# hdlr = logging.FileHandler("optim_continuous_log.log")
# formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
# hdlr.setFormatter(formatter)
# logger.addHandler(hdlr)
# logger.setLevel(logging.INFO)

# # importing triple optimizer
# sys.path.insert(0, '../Single_Stage_Optimizer')
# sys.path.insert(0, '../')
m_path = os.path.dirname(res.__file__).replace("\\", "/")


if __name__ == "__main__":
    # Retailer_Category_Combo = [(13,4)]  #dummy combos for testing (2, 5),

    fire_single = True

    counter = 0  # track how many combinations converge
    # working with all the combos available

    with open(
        m_path
        + "/../../../../data/raw/tpo/optimization_input/continuous/input_xml_formatter/input.xml"
    ) as fd:  # noqa
        doc = xmltodict.parse(fd.read())
    head = doc["data"]
    Retailer_Category_Combo = head["ret_cat_combo"]
    if isinstance(Retailer_Category_Combo, collections.OrderedDict):
        Retailer_Category_Combo = [Retailer_Category_Combo]

    for single_combo in tqdm(Retailer_Category_Combo):
        global globals
        # calling the global initializer for creating a concrete class
        # for global data availability across optimizer stages
        #         os.chdir("../../../../notebooks/tpo_continuous/")
        globals = global_initializer(single_combo)

        if globals.class_loader():  # run if class loading was a success
            s = time.time()
            # call stage3 caller which shall intern
            # call stage 2 and which intern shall call stage 1 slover
            Stage3_caller(globals)
            e = time.time()
            # if all the stages have been successfully then save the results
            St1 = globals.Stage1Success
            St2 = globals.Stage2Success
            St3 = globals.Stage3Success

            if St1 & St2 & St3:

                res.save_results(globals, e - s)
