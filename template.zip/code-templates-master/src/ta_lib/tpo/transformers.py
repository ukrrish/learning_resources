import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin


class OwnEffectsTransformer(BaseEstimator, TransformerMixin):
    """Compute Own effects from X & y."""

    def __init__(
        self, start_date, end_date, ppg_sales_df, optimizer_flag, exlude_missing_flag
    ):
        self.start_date = start_date
        self.end_date = end_date
        self.ppg_sales_df = ppg_sales_df
        self.optimizer_flag = optimizer_flag
        self.exlude_missing_flag = exlude_missing_flag

    def fit(self, X, y=None):
        """Compute Own effects from X & y."""

        return self

    def transform(self, X, y=None):
        """Apply Own effects from X & y."""

        X_transformed = (
            X.create_missing_records(self.ppg_sales_df)
            .generate_final_baseprice("New_base_price", "Final_baseprice")
            .generate_edlp_tpr_component(
                "wk_sold_avg_price_byppg", "Estimated_baseprice"
            )
            .create_median_acv("ACV_Selling", "median_acv_selling")
            .create_seasonality_features()
            .create_category_trend()
            .prepare_optimizer_data(self.optimizer_flag, self.exlude_missing_flag)
            .transform_columns(
                ["wk_sold_avg_price_byppg", "median_baseprice"],
                np.log,
                new_column_names={
                    "wk_sold_avg_price_byppg": "wk_sold_avg_price_byppg_log",
                    "median_baseprice": "wk_sold_median_base_price_byppg_log",
                },
            )
            .create_pantry_effects_features()
            .query("(Date>=@self.start_date) & (Date<@self.end_date)")
            .sort_values(
                by=["PPG_Cat", "PPG_MFG", "PPG_Item_No", "Date"], ignore_index=True
            )
        )
        return X_transformed


class CompetitorEffectsTransformer(BaseEstimator, TransformerMixin):
    """Compute CompetitorEffects from X & y."""

    def __init__(
        self,
        rp_acting_items,
        tpr_acting_items,
        rp_interaction_items,
        tpr_interaction_items,
        model_df,
    ):

        self.slct_cols = [
            "PPG_Cat",
            "PPG_MFG",
            "PPG_Item_No",
            "PPG_Description",
            "Date",
            "wk_sold_median_base_price_byppg_log",
            "tpr_discount_byppg",
            "ACV_Feat_Only",
            "ACV_Disp_Only",
            "ACV_Feat_Disp",
            "ACV_Selling",
            "flag_qtr2",
            "flag_qtr3",
            "flag_qtr4",
            "category_trend",
            "tpr_discount_byppg_lag1",
            "tpr_discount_byppg_lag2",
            "monthno",
            "Missing_data_flag",
        ]

        self.rp_acting_items = rp_acting_items
        self.tpr_acting_items = tpr_acting_items
        self.rp_interaction_items = rp_interaction_items
        self.tpr_interaction_items = tpr_interaction_items
        self.model_df = model_df

    def fit(self, X, y=None):
        """Compute CompetitorEffects from X & y."""

        return self

    def transform(self, X, y=None):
        """Apply CompetitorEffects from X & y."""

        X_transformed = (
            X.select_columns(self.slct_cols + ["wk_sold_avg_price_byppg"])
            .add_competitor_regular_price_var(self.rp_acting_items, self.model_df)
            .add_competitor_tpr_var(self.tpr_acting_items, self.model_df)
            .add_RegularPrice_InteractionVariables(
                self.rp_interaction_items, self.model_df
            )
            .add_TradePromotions_InteractionVariables(
                self.tpr_interaction_items, self.model_df
            )
            .remove_zero_acv_weeks()
            .set_features_wt_low_variance_to_zero()
            .filter_on("Missing_data_flag==0")
            .remove_columns(["Missing_data_flag", "wk_sold_avg_price_byppg"])
            .impute_missing_values()
        )
        return X_transformed
