import os.path as op

import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline

from scripts import (
    get_competitor_regular_price_var,
    get_competitor_tpr_var,
    get_RegularPrice_InteractionVariables,
    get_TradePromotions_InteractionVariables,
)
from ta_lib.core import dataset
from ta_lib.core.api import get_package_path, register_processor, save_pipeline
from ta_lib.tpo.transformers import (
    CompetitorEffectsTransformer,
    OwnEffectsTransformer,
)

pd.options.mode.use_inf_as_na = True


@register_processor("feat-engg", "filter-sales")
def filter_sales_table(context, params):
    """Filter the ``SALES`` data table.

    The table obtained containts the syndicated sales data and has information
    on the item purchased, description of the item, the price etc.
    """
    # Initialization
    slct_retailer = params["slct_retailer"]
    slct_category = params["slct_category"]

    start_date = params["start_date"]
    end_date = params["end_date"]

    # Load datasets
    ppg_sales_df = dataset.load_dataset(
        context,
        "processed/sales",
        retailer=params["slct_retailer"],
        category=params["slct_category"],
    )
    filtered_ppg_sales_df = ppg_sales_df.query("Date>=@start_date & Date<@end_date")

    # PPG Selection
    # Initialization
    # PPG Summary (contains reason for exclusion)
    ppg_summary_df = pd.DataFrame(columns=["PPG_Item_No", "Reason"])

    # Get total quarters and weeks available
    slct_ppg_sales_df = filtered_ppg_sales_df.copy()
    slct_ppg_sales_df["Year_Qtr"] = (
        slct_ppg_sales_df["Date"].dt.year.astype(str)
        + "-Q"
        + slct_ppg_sales_df["Date"].dt.quarter.astype(str)
    )
    slct_ppg_sales_df.rename(
        columns={"wk_avg_price_perunit_byppg": "wk_sold_avg_price_byppg"}, inplace=True
    )

    overall_qtrs_count = slct_ppg_sales_df["Year_Qtr"].nunique()
    overall_weeks_count = slct_ppg_sales_df["Date"].nunique()

    # Remove PPGs based on the following metrics
    # 1 Dollar Sales per Quarter
    agg_ppg_df = slct_ppg_sales_df.groupby(
        ["PPG_Cat", "PPG_MFG", "PPG_Item_No"], as_index=False
    ).agg({"wk_sold_doll_byppg": np.sum})
    agg_ppg_df = agg_ppg_df.rename(columns={"wk_sold_doll_byppg": "sum_sales"})
    agg_ppg_df["avg_qtrly_sales"] = agg_ppg_df["sum_sales"] / overall_qtrs_count

    min_revenue_threshold = params["min_revenue_threshold"]
    low_revenue_ppgs = agg_ppg_df.loc[
        agg_ppg_df["avg_qtrly_sales"] <= min_revenue_threshold, "PPG_Item_No"
    ].unique()

    if len(low_revenue_ppgs) > 0:
        ppg_to_append = pd.DataFrame(
            {
                "PPG_Item_No": low_revenue_ppgs,
                "Reason": ["Low Revenue"] * len(low_revenue_ppgs),
            }
        )
        ppg_summary_df = ppg_summary_df.append(ppg_to_append, ignore_index=True)

    slct_ppg_sales_df = slct_ppg_sales_df[
        ~slct_ppg_sales_df["PPG_Item_No"].isin(low_revenue_ppgs)
    ]

    # 2 Consistent Sales
    min_qtr_sales_share = 0.02
    agg_ppg_df = (
        slct_ppg_sales_df.copy()
        # Sales distribution by Quarter
        .groupby(by=["PPG_Item_No", "Year_Qtr"], as_index=False)
        .agg({"wk_sold_doll_byppg": np.sum})
        .rename_column("wk_sold_doll_byppg", "sum_sales")
        .groupby_agg(
            by="PPG_Item_No",
            agg=np.sum,
            agg_column_name="sum_sales",
            new_column_name="tot_sum_sales",
        )
        .assign(sales_share_in_qtr=lambda x: x["sum_sales"] / x["tot_sum_sales"])
        # Quarters with Sales
        .groupby_agg(
            by="PPG_Item_No",
            agg=len,
            agg_column_name="Year_Qtr",
            new_column_name="quarters_cnt",
        )
        .groupby_agg(
            by="PPG_Item_No",
            agg=lambda s: np.sum(s <= min_qtr_sales_share),
            agg_column_name="sales_share_in_qtr",
            new_column_name="quarters_cnt_lt_min_sales",
        )
        # Keep at PPG level
        .select_columns(
            [
                "PPG_Item_No",
                "tot_sum_sales",
                "quarters_cnt",
                "quarters_cnt_lt_min_sales",
            ]
        )
        .drop_duplicates()
    )

    min_num_qtr_wt_sales = params["min_num_qtr_wt_sales"]
    low_num_qtr_wt_sales_ppgs = agg_ppg_df.loc[
        agg_ppg_df["quarters_cnt"] < min_num_qtr_wt_sales, "PPG_Item_No"
    ].unique()

    min_sales_quarters = 0.5 * min_num_qtr_wt_sales
    low_num_qtr_wt_min_sales_ppgs = agg_ppg_df.query(
        "PPG_Item_No not in @low_num_qtr_wt_sales_ppgs & quarters_cnt_lt_min_sales>=@min_sales_quarters"
    )["PPG_Item_No"].unique()

    inconsistent_ppgs = np.append(
        low_num_qtr_wt_sales_ppgs, low_num_qtr_wt_min_sales_ppgs
    )
    if len(inconsistent_ppgs) > 0:
        ppg_to_append = pd.DataFrame(
            {
                "PPG_Item_No": inconsistent_ppgs,
                "Reason": ["Inconsistent Sales"] * len(inconsistent_ppgs),
            }
        )
        ppg_summary_df = ppg_summary_df.append(ppg_to_append, ignore_index=True)

    slct_ppg_sales_df = slct_ppg_sales_df[
        ~slct_ppg_sales_df["PPG_Item_No"].isin(inconsistent_ppgs)
    ]

    # 3 Data Availability
    agg_ppg_df = slct_ppg_sales_df.groupby("PPG_Item_No", as_index=False).agg(
        {"Date": len}
    )
    agg_ppg_df = agg_ppg_df.rename(columns={"Date": "weeks_count"})
    agg_ppg_df["pct_datapoints"] = agg_ppg_df["weeks_count"] / overall_weeks_count

    min_pct_data_points = params["min_pct_data_points"]
    low_data_ppgs = agg_ppg_df.loc[
        agg_ppg_df["pct_datapoints"] <= min_pct_data_points, "PPG_Item_No"
    ].unique()

    if len(low_data_ppgs) > 0:
        ppg_to_append = pd.DataFrame(
            {"PPG_Item_No": low_data_ppgs, "Reason": ["Low Data"] * len(low_data_ppgs)}
        )
        ppg_summary_df = ppg_summary_df.append(ppg_to_append, ignore_index=True)

    slct_ppg_sales_df = slct_ppg_sales_df[
        ~slct_ppg_sales_df["PPG_Item_No"].isin(low_data_ppgs)
    ]

    # 4 Variance in Sold Price and Units
    agg_ppg_df = slct_ppg_sales_df.groupby("PPG_Item_No", as_index=False).agg(
        {"wk_sold_qty_byppg": np.std, "wk_sold_avg_price_byppg": np.std}
    )
    agg_ppg_df = agg_ppg_df.rename(
        columns={
            "wk_sold_qty_byppg": "sd_by_mean_sales_vol",
            "wk_sold_avg_price_byppg": "sd_by_mean_avg_price",
        }
    )

    sd_by_mean_sales_vol_threshold = params["sd_by_mean_sales_vol_threshold"]
    sd_by_mean_avg_price_threshold = params["sd_by_mean_avg_price_threshold"]
    low_variance_ppgs = agg_ppg_df.loc[
        (agg_ppg_df["sd_by_mean_sales_vol"] <= sd_by_mean_sales_vol_threshold)
        & (agg_ppg_df["sd_by_mean_avg_price"] <= sd_by_mean_avg_price_threshold),
        "PPG_Item_No",
    ].unique()

    if len(low_variance_ppgs) > 0:
        ppg_to_append = pd.DataFrame(
            {
                "PPG_Item_No": low_variance_ppgs,
                "Reason": ["Low Variance"] * len(low_variance_ppgs),
            }
        )
        ppg_summary_df = ppg_summary_df.append(ppg_to_append, ignore_index=True)

    slct_ppg_sales_df = slct_ppg_sales_df[
        ~slct_ppg_sales_df["PPG_Item_No"].isin(low_variance_ppgs)
    ]

    # 5 ACV Selling
    agg_ppg_df = slct_ppg_sales_df.groupby("PPG_Item_No", as_index=False).agg(
        {"ACV_Selling": np.nanmean}
    )
    agg_ppg_df = agg_ppg_df.rename(columns={"ACV_Selling": "ACV_Selling_mean"})

    acv_cutoff = params["acv_cutoff"]
    low_acv_ppgs = agg_ppg_df.loc[
        agg_ppg_df["ACV_Selling_mean"] <= acv_cutoff, "PPG_Item_No"
    ].unique()

    if len(low_data_ppgs) > 0:
        ppg_to_append = pd.DataFrame(
            {"PPG_Item_No": low_acv_ppgs, "Reason": ["Low ACV"] * len(low_acv_ppgs)}
        )
        ppg_summary_df = ppg_summary_df.append(ppg_to_append, ignore_index=True)

    slct_ppg_sales_df = slct_ppg_sales_df[
        ~slct_ppg_sales_df["PPG_Item_No"].isin(low_acv_ppgs)
    ]

    # 6 Recent Sales Trend
    cutoff_date = np.sort(slct_ppg_sales_df["Date"].unique())[-26]
    agg_ppg_df = (
        slct_ppg_sales_df.copy()
        .transform_column(
            column_name="Date",
            function=lambda x: 1 if x > cutoff_date else 0,
            dest_column_name="date_flag",
            elementwise=True,
        )
        .groupby_agg(
            by=["PPG_Item_No", "date_flag"],
            agg=np.sum,
            agg_column_name="wk_sold_doll_byppg",
            new_column_name="sum_sales",
        )
        .groupby_agg(
            by=["PPG_Item_No"],
            agg=np.sum,
            agg_column_name="wk_sold_doll_byppg",
            new_column_name="tot_sum_sales",
        )
        .assign(
            sales_share_by_cutoff_date=lambda x: x["sum_sales"] / x["tot_sum_sales"]
        )
        .groupby_agg(
            by=["PPG_Item_No", "date_flag"],
            agg=np.nanmean,
            agg_column_name="ACV_Selling",
            new_column_name="avg_acv",
        )
        .select_columns(
            ["PPG_Item_No", "date_flag", "sales_share_by_cutoff_date", "avg_acv"]
        )
        .drop_duplicates()
        .reset_index(drop=True)
        .filter_on("date_flag==1")
    )

    sales_share_in_recent_period = params["sales_share_in_recent_period"]
    dying_down_ppgs = agg_ppg_df.loc[
        (agg_ppg_df["avg_acv"] < acv_cutoff)
        | (agg_ppg_df["sales_share_by_cutoff_date"] < sales_share_in_recent_period),
        "PPG_Item_No",
    ].unique()

    if len(dying_down_ppgs) > 0:
        ppg_to_append = pd.DataFrame(
            {
                "PPG_Item_No": dying_down_ppgs,
                "Reason": ["Dying PPGs"] * len(dying_down_ppgs),
            }
        )
        ppg_summary_df = ppg_summary_df.append(ppg_to_append, ignore_index=True)

    slct_ppg_sales_df = slct_ppg_sales_df[
        ~slct_ppg_sales_df["PPG_Item_No"].isin(dying_down_ppgs)
    ]

    # Add PPG specific columns
    agg_sales_df = (
        filtered_ppg_sales_df.copy()
        .query("Date>=@start_date & Date<@end_date")
        .groupby(
            ["PPG_Item_No", "PPG_MFG", "PPG_Retailer", "PPG_Description"],
            as_index=False,
        )
        .agg({"wk_sold_doll_byppg": np.sum})
        .rename_column("wk_sold_doll_byppg", "TotalSales")
    )
    ppg_summary_df = agg_sales_df.merge(ppg_summary_df, how="left", on="PPG_Item_No")

    # Save PPG Summary
    time_stamp = "_".join([start_date, "to", end_date])
    dataset.save_dataset(
        context,
        ppg_summary_df,
        "output/ppg_summary",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=time_stamp,
    )


@register_processor("feat-engg", "transform-features")
def transform_features(context, params):
    """Transform dataset to create training datasets."""
    # Initialization
    artifacts_folder = op.join(get_package_path(), "artifacts")

    slct_retailer = params["slct_retailer"]
    slct_category = params["slct_category"]
    slct_vendor = params["slct_vendor"]

    start_date = params["start_date"]
    end_date = params["end_date"]

    # Load datasets
    ppg_sales_df = dataset.load_dataset(
        context, "processed/sales", retailer=slct_retailer, category=slct_category
    )
    train_X = dataset.load_dataset(
        context, "train/sales/features", retailer=slct_retailer, category=slct_category
    )
    train_y = dataset.load_dataset(
        context, "train/sales/target", retailer=slct_retailer, category=slct_category
    )
    acting_items_df = dataset.load_dataset(
        context, "cleaned/acting_items", retailer=slct_retailer, category=slct_category
    )

    time_stamp = "_".join([start_date, "to", end_date])
    ppg_summary_df = dataset.load_dataset(
        context,
        "output/ppg_summary",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=time_stamp,
    )

    filtered_ppg_sales_df = ppg_sales_df.query("Date>=@start_date & Date<@end_date")
    train_X = train_X.query("Date>=@start_date & Date<@end_date")
    train_y = train_y.query("Date>=@start_date & Date<@end_date")

    # Subset data
    ppg_list_to_include = ppg_summary_df.loc[
        ~ppg_summary_df["Reason"].isin(
            ["Dying PPGs", "Inconsistent Sales", "Low ACV", "Low Data", "Low Revenue"]
        ),
        "PPG_Item_No",
    ].to_list()
    slct_ppg_sales_df = filtered_ppg_sales_df.query(
        "PPG_Item_No in @ppg_list_to_include"
    )
    train_X = train_X.query("PPG_Item_No in @ppg_list_to_include")
    train_y = train_y.query("PPG_Item_No in @ppg_list_to_include")

    # List of PPGs to model
    ppg_list_to_model = slct_ppg_sales_df.loc[
        slct_ppg_sales_df["PPG_MFG"] == slct_vendor, "PPG_Item_No"
    ].unique()

    # Feature Engineering Pipelines
    # 1 Own effects features
    own_feat_trans = Pipeline(
        steps=[
            (
                "num_transformer",
                OwnEffectsTransformer(start_date, end_date, ppg_sales_df, False, False),
            ),
        ]
    )

    opt_own_feat_trans = Pipeline(
        steps=[
            (
                "num_transformer",
                OwnEffectsTransformer(start_date, end_date, ppg_sales_df, True, False),
            ),
        ]
    )

    # Price Elasticity
    own_feat_trans.fit(train_X)
    trans_X = own_feat_trans.transform(train_X)
    trans_X["Model_flag"] = 2

    trans_y = (
        train_y.copy()
        .merge(
            trans_X.loc[:, ["PPG_Item_No", "Date", "Missing_data_flag"]],
            how="right",
            on=["PPG_Item_No", "Date"],
        )
        .assign(
            wk_sold_qty_byppg=lambda x: x.apply(
                lambda y: 0 if y["Missing_data_flag"] == 1 else y["wk_sold_qty_byppg"],
                axis=1,
            )
        )
        .transform_columns(
            ["wk_sold_qty_byppg"],
            np.log1p,
            new_column_names={"wk_sold_qty_byppg": "wk_sold_qty_byppg_log"},
        )
        .sort_values(by=["PPG_Item_No", "Date"], ignore_index=True)
    )

    # Optimizer
    opt_own_feat_trans.fit(train_X)
    opt_trans_X = opt_own_feat_trans.transform(train_X)
    opt_trans_X["Model_flag"] = 2

    opt_trans_y = (
        train_y.copy()
        .merge(
            opt_trans_X.loc[:, ["PPG_Item_No", "Date", "Missing_data_flag"]],
            how="right",
            on=["PPG_Item_No", "Date"],
        )
        .assign(
            wk_sold_qty_byppg=lambda x: x.apply(
                lambda y: 0 if y["Missing_data_flag"] == 1 else y["wk_sold_qty_byppg"],
                axis=1,
            )
        )
        .transform_columns(
            ["wk_sold_qty_byppg"],
            np.log1p,
            new_column_names={"wk_sold_qty_byppg": "wk_sold_qty_byppg_log"},
        )
        .sort_values(by=["PPG_Item_No", "Date"], ignore_index=True)
    )

    # 2 Competitor effects features
    # Extract acting items (Competitors)
    acting_ppg = pd.DataFrame(columns=["PPG_Item_No", "Acting_Items"])
    for i in ppg_list_to_model:
        ppg = i.replace("_ROM", "") if "_ROM" in i else i.replace("_Retailer", "")
        acting_items = acting_items_df[
            acting_items_df["Base_Item"].str.contains(ppg, regex=False)
        ]["Acting_Item"].unique()
        acting_items = [j + "_Retailer" for j in acting_items] + [
            j + "_ROM" for j in acting_items
        ]
        acting_items = [item for item in acting_items if i not in item]
        acting_items = [
            item for item in acting_items if item in trans_X["PPG_Item_No"].unique()
        ]
        if len(acting_items) == 0:
            continue
        temp_1 = pd.DataFrame(
            {"PPG_Item_No": [i] * len(acting_items), "Acting_Items": acting_items}
        )
        acting_ppg = acting_ppg.append(temp_1, ignore_index=True)
        len(acting_ppg)

    # Create acting item list for PPGs (without AIs)
    ppg_wt_acting_items = acting_ppg["PPG_Item_No"].unique()
    ppg_wo_acting_items = [
        ppg for ppg in ppg_list_to_model if ppg not in ppg_wt_acting_items
    ]
    upc_list = trans_X.loc[
        (trans_X["PPG_Item_No"].isin(ppg_wo_acting_items))
        & (trans_X["PPG_Item_No"] == "ITEM" + trans_X["PPG_Description"]),
        "PPG_Item_No",
    ].unique()
    for i in upc_list:
        acting_items = [j + "_Retailer" for j in ppg_list_to_model] + [
            j + "_ROM" for j in ppg_list_to_model
        ]
        acting_items = [item for item in acting_items if i not in item]
        acting_items = [
            item for item in acting_items if item in trans_X["PPG_Item_No"].unique()
        ]
        temp_1 = pd.DataFrame(
            {"PPG_Item_No": [i] * len(acting_items), "Acting_Items": acting_items}
        )
        acting_ppg = acting_ppg.append(temp_1, ignore_index=True)

    # Extract acting items (Competitors) for interaction features
    PPG = trans_X.loc[
        (trans_X["PPG_MFG"] == "NPPC")
        & (~trans_X["PPG_Item_No"].str.contains("ROM", regex=False)),
        "PPG_Item_No",
    ].unique()  # model_df_1["PPG_Retailer"]!="ROM"
    inter_ppg = pd.DataFrame(columns=["PPG_Item_No", "Acting_Items"])
    if len(acting_ppg) > 0:
        inter_ppg = acting_ppg[
            (acting_ppg["PPG_Item_No"].isin(PPG))
            & (acting_ppg["Acting_Items"].str.contains("Retailer", regex=False))
        ]

    # Shortlist Acting items
    rp_acting_items = get_competitor_regular_price_var(acting_ppg, trans_X, trans_y)
    tpr_acting_items = get_competitor_tpr_var(acting_ppg, trans_X, trans_y)
    rp_interaction_items = get_RegularPrice_InteractionVariables(
        PPG, inter_ppg, trans_X, trans_y
    )
    tpr_interaction_items = get_TradePromotions_InteractionVariables(
        PPG, inter_ppg, trans_X, trans_y
    )

    # Pipeline Initialization
    comp_feat_trans = Pipeline(
        steps=[
            (
                "num_transformer",
                CompetitorEffectsTransformer(
                    rp_acting_items,
                    tpr_acting_items,
                    rp_interaction_items,
                    tpr_interaction_items,
                    trans_X,
                ),
            ),
        ]
    )
    opt_comp_feat_trans = Pipeline(
        steps=[
            (
                "num_transformer",
                CompetitorEffectsTransformer(
                    rp_acting_items,
                    tpr_acting_items,
                    rp_interaction_items,
                    tpr_interaction_items,
                    opt_trans_X,
                ),
            ),
        ]
    )

    # Save pipeline
    save_pipeline(
        own_feat_trans,
        op.abspath(
            op.join(
                artifacts_folder, "own_effects_features_{}.joblib".format(time_stamp)
            )
        ),
    )
    save_pipeline(
        opt_own_feat_trans,
        op.abspath(
            op.join(
                artifacts_folder,
                "opt_own_effects_features_{}.joblib".format(time_stamp),
            )
        ),
    )
    save_pipeline(
        comp_feat_trans,
        op.abspath(
            op.join(
                artifacts_folder,
                "competitor_effects_features_{}.joblib".format(time_stamp),
            )
        ),
    )
    save_pipeline(
        opt_comp_feat_trans,
        op.abspath(
            op.join(
                artifacts_folder,
                "opt_competitor_effects_features_{}.joblib".format(time_stamp),
            )
        ),
    )


@register_processor("model-gen", "transform-features-spl-case")
def transform_features_spl_case(context, params):
    """Transform dataset to create training datasets for PPGs with 1-2 years of data."""
    # Intialization
    artifacts_folder = op.join(get_package_path(), "artifacts")

    slct_retailer = params["slct_retailer"]
    slct_category = params["slct_category"]
    slct_vendor = params["slct_vendor"]

    start_date = params["start_date"]
    end_date = params["end_date"]

    # Load datasets
    ppg_sales_df = dataset.load_dataset(
        context, "processed/sales", retailer=slct_retailer, category=slct_category
    )
    train_X = dataset.load_dataset(
        context, "train/sales/features", retailer=slct_retailer, category=slct_category
    )
    train_y = dataset.load_dataset(
        context, "train/sales/target", retailer=slct_retailer, category=slct_category
    )
    acting_items_df = dataset.load_dataset(
        context, "cleaned/acting_items", retailer=slct_retailer, category=slct_category
    )

    time_stamp = "_".join([start_date, "to", end_date])
    ppg_summary_df = dataset.load_dataset(
        context,
        "output/ppg_summary",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=time_stamp,
    )

    filtered_ppg_sales_df = ppg_sales_df.query("Date>=@start_date & Date<@end_date")
    train_X = train_X.query("Date>=@start_date & Date<@end_date")
    train_y = train_y.query("Date>=@start_date & Date<@end_date")

    # PPG Selection
    # Initialization
    slct_ppg_sales_df = filtered_ppg_sales_df.copy()

    # Average Dollar Sales
    low_revenue_ppgs = ppg_summary_df.loc[
        ppg_summary_df["Reason"] == "Low Revenue", "PPG_Item_No"
    ].to_list()
    slct_ppg_sales_df = slct_ppg_sales_df[
        ~slct_ppg_sales_df["PPG_Item_No"].isin(low_revenue_ppgs)
    ]

    # Data Availability (Remove PPGs with less than 1 year data)
    agg_ppg_df = slct_ppg_sales_df.groupby(by=["PPG_Item_No"], as_index=False).agg(
        {"Date": len, "ACV_Selling": np.count_nonzero}
    )
    agg_ppg_df = agg_ppg_df.rename(
        columns={"Date": "week_cnt", "ACV_Selling": "nonzero_week_cnt"}
    )

    ppgs_lt_yr_data = agg_ppg_df.loc[
        agg_ppg_df["week_cnt"] <= 51, "PPG_Item_No"
    ].to_list()
    ppgs_wt_zero_acvs = agg_ppg_df.loc[
        agg_ppg_df["week_cnt"] <= 52 & ~agg_ppg_df["PPG_Item_No"].isin(ppgs_lt_yr_data),
        "PPG_Item_No",
    ].to_list()
    slct_ppg_sales_df = slct_ppg_sales_df[
        ~slct_ppg_sales_df["PPG_Item_No"].isin(ppgs_lt_yr_data + ppgs_wt_zero_acvs)
    ]

    # Subset data
    train_X = train_X[train_X["PPG_Item_No"].isin(slct_ppg_sales_df["PPG_Item_No"])]
    train_y = train_y[train_y["PPG_Item_No"].isin(slct_ppg_sales_df["PPG_Item_No"])]

    # List of PPGs to model
    ppg_list_to_model = slct_ppg_sales_df.loc[
        (slct_ppg_sales_df["PPG_MFG"] == slct_vendor)
        & (
            ~slct_ppg_sales_df["PPG_Item_No"].isin(
                ppg_summary_df.loc[
                    ppg_summary_df["Reason"].isin(["PPGs Considered for Modelling"]),
                    "PPG_Item_No",
                ]
            )
        ),
        "PPG_Item_No",
    ].unique()

    # Feature Engineering Pipelines
    # 1 Own effects features
    # Use pre-trained feature pipelines and other artifacts
    own_feat_trans = Pipeline(
        steps=[
            (
                "num_transformer",
                OwnEffectsTransformer(start_date, end_date, ppg_sales_df, False, False),
            ),
        ]
    )

    opt_own_feat_trans = Pipeline(
        steps=[
            (
                "num_transformer",
                OwnEffectsTransformer(start_date, end_date, ppg_sales_df, True, True),
            ),
        ]
    )

    # Transform data
    # Price Elasticity
    own_feat_trans.fit(train_X)
    trans_X = own_feat_trans.transform(train_X)
    trans_X = trans_X.merge(
        ppg_summary_df[["PPG_Item_No", "Reason"]], how="left", on="PPG_Item_No"
    )
    trans_X.loc[
        trans_X["Reason"] != "PPGs Considered for Modelling",
        ["flag_qtr2", "flag_qtr3", "flag_qtr4"],
    ] = 0
    trans_X["Model_flag"] = trans_X["Reason"].apply(
        lambda x: 2 if x == "PPGs Considered for Modelling" else 1
    )

    trans_y = (
        train_y.copy()
        .merge(
            trans_X.loc[:, ["PPG_Item_No", "Date", "Missing_data_flag"]],
            how="right",
            on=["PPG_Item_No", "Date"],
        )
        .assign(
            wk_sold_qty_byppg=lambda x: x.apply(
                lambda y: 0 if y["Missing_data_flag"] == 1 else y["wk_sold_qty_byppg"],
                axis=1,
            )
        )
        .transform_columns(
            ["wk_sold_qty_byppg"],
            np.log1p,
            new_column_names={"wk_sold_qty_byppg": "wk_sold_qty_byppg_log"},
        )
        .sort_values(by=["PPG_Item_No", "Date"], ignore_index=True)
    )

    # Optimizer
    opt_own_feat_trans.fit(train_X)
    opt_trans_X = opt_own_feat_trans.transform(train_X)
    opt_trans_X = opt_trans_X.merge(
        ppg_summary_df[["PPG_Item_No", "Reason"]], how="left", on="PPG_Item_No"
    )
    opt_trans_X.loc[
        opt_trans_X["Reason"] != "PPGs Considered for Modelling",
        ["flag_qtr2", "flag_qtr3", "flag_qtr4"],
    ] = 0
    opt_trans_X["Model_flag"] = opt_trans_X["Reason"].apply(
        lambda x: 2 if x == "PPGs Considered for Modelling" else 1
    )

    opt_trans_y = (
        train_y.copy()
        .merge(
            opt_trans_X.loc[:, ["PPG_Item_No", "Date", "Missing_data_flag"]],
            how="right",
            on=["PPG_Item_No", "Date"],
        )
        .assign(
            wk_sold_qty_byppg=lambda x: x.apply(
                lambda y: 0 if y["Missing_data_flag"] == 1 else y["wk_sold_qty_byppg"],
                axis=1,
            )
        )
        .transform_columns(
            ["wk_sold_qty_byppg"],
            np.log1p,
            new_column_names={"wk_sold_qty_byppg": "wk_sold_qty_byppg_log"},
        )
        .sort_values(by=["PPG_Item_No", "Date"], ignore_index=True)
    )

    # 2 Competitor effects features
    # Extracting acting items (Competitors)
    acting_ppg = pd.DataFrame(columns=["PPG_Item_No", "Acting_Items"])
    for i in ppg_list_to_model:
        ppg = i.replace("_ROM", "") if "_ROM" in i else i.replace("_Retailer", "")
        acting_items = acting_items_df[
            acting_items_df["Base_Item"].str.contains(ppg, regex=False)
        ]["Acting_Item"].unique()
        acting_items = [j + "_Retailer" for j in acting_items] + [
            j + "_ROM" for j in acting_items
        ]
        acting_items = [item for item in acting_items if i not in item]
        acting_items = [
            item
            for item in acting_items
            if item
            in trans_X.loc[
                trans_X["Reason"] == "PPGs Considered for Modelling", "PPG_Item_No"
            ].unique()
        ]
        if len(acting_items) == 0:
            continue
        temp_1 = pd.DataFrame(
            {"PPG_Item_No": [i] * len(acting_items), "Acting_Items": acting_items}
        )
        acting_ppg = acting_ppg.append(temp_1, ignore_index=True)
        len(acting_ppg)

    # Create acting item list for PPGs (without AIs)
    ppg_wt_acting_items = acting_ppg["PPG_Item_No"].unique()
    ppg_wo_acting_items = [
        ppg for ppg in ppg_list_to_model if ppg not in ppg_wt_acting_items
    ]
    upc_list = trans_X.loc[
        (trans_X["PPG_Item_No"].isin(ppg_wo_acting_items))
        & (trans_X["PPG_Item_No"] == "ITEM" + trans_X["PPG_Description"]),
        "PPG_Item_No",
    ].unique()
    for i in upc_list:
        acting_items = [j + "_Retailer" for j in ppg_list_to_model] + [
            j + "_ROM" for j in ppg_list_to_model
        ]
        acting_items = [item for item in acting_items if i not in item]
        acting_items = [
            item
            for item in acting_items
            if item
            in trans_X.loc[
                trans_X["Reason"] == "PPGs Considered for Modelling", "PPG_Item_No"
            ].unique()
        ]
        temp_1 = pd.DataFrame(
            {"PPG_Item_No": [i] * len(acting_items), "Acting_Items": acting_items}
        )
        acting_ppg = acting_ppg.append(temp_1, ignore_index=True)

    # Extract acting items (Competitors) for interaction features
    PPG = trans_X.loc[
        (trans_X["PPG_MFG"] == slct_vendor)
        & (trans_X["Reason"] != "PPGs Considered for Modelling")
        & (~trans_X["PPG_Item_No"].str.contains("ROM", regex=False)),
        "PPG_Item_No",
    ].unique()  # model_df_1["PPG_Retailer"]!="ROM"
    inter_ppg = pd.DataFrame(columns=["PPG_Item_No", "Acting_Items"])
    if len(acting_ppg) > 0:
        inter_ppg = acting_ppg[
            (acting_ppg["PPG_Item_No"].isin(PPG))
            & (acting_ppg["Acting_Items"].str.contains("Retailer", regex=False))
        ]

    # Shortlist acting items
    rp_acting_items = get_competitor_regular_price_var(
        acting_ppg, trans_X, trans_y, decompose_flag=False
    )
    tpr_acting_items = get_competitor_tpr_var(acting_ppg, trans_X, trans_y)
    rp_interaction_items = get_RegularPrice_InteractionVariables(
        PPG, inter_ppg, trans_X, trans_y
    )
    tpr_interaction_items = get_TradePromotions_InteractionVariables(
        PPG, inter_ppg, trans_X, trans_y
    )

    # Pipeline Initialization
    comp_feat_trans = Pipeline(
        steps=[
            (
                "num_transformer",
                CompetitorEffectsTransformer(
                    rp_acting_items,
                    tpr_acting_items,
                    rp_interaction_items,
                    tpr_interaction_items,
                    trans_X,
                ),
            ),
        ]
    )
    opt_comp_feat_trans = Pipeline(
        steps=[
            (
                "num_transformer",
                CompetitorEffectsTransformer(
                    rp_acting_items,
                    tpr_acting_items,
                    rp_interaction_items,
                    tpr_interaction_items,
                    opt_trans_X,
                ),
            ),
        ]
    )

    # Save pipeline
    save_pipeline(
        own_feat_trans,
        op.abspath(
            op.join(
                artifacts_folder,
                "own_effects_features_spl_case_{}.joblib".format(time_stamp),
            )
        ),
    )
    save_pipeline(
        opt_own_feat_trans,
        op.abspath(
            op.join(
                artifacts_folder,
                "opt_own_effects_features_spl_case_{}.joblib".format(time_stamp),
            )
        ),
    )
    save_pipeline(
        comp_feat_trans,
        op.abspath(
            op.join(
                artifacts_folder,
                "competitor_effects_features_spl_case_{}.joblib".format(time_stamp),
            )
        ),
    )
    save_pipeline(
        opt_comp_feat_trans,
        op.abspath(
            op.join(
                artifacts_folder,
                "opt_competitor_effects_features_spl_case_{}.joblib".format(time_stamp),
            )
        ),
    )
