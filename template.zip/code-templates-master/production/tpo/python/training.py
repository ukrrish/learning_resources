import os.path as op
import random
import re

import mlflow
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.pipeline import Pipeline

from scripts import (
    cannibalisation_module,
    cross_validation,
    extract_pack_size,
    select_features,
    select_features_for_bayesian_model,
)
from ta_lib.core import dataset
from ta_lib.core.api import get_package_path, load_pipeline, register_processor
from ta_lib.tpo.estimators import (
    CustomSKLLassoCV,
    SKLBayesian,
    SKLStatsmodelMixedLM,
)

pd.options.mode.use_inf_as_na = True


@register_processor("model-gen", "model-elasticity-lasso-regression")
def model_elasticity_by_lasso_regression(context, params):
    """Train elasticity model using Lasso regression."""
    # Initialization
    artifacts_folder = op.join(get_package_path(), "artifacts")

    slct_retailer = params["slct_retailer"]
    slct_category = params["slct_category"]
    slct_vendor = params["slct_vendor"]

    start_date = params["start_date"]
    end_date = params["end_date"]

    # Load datasets
    ppg_sales_df = dataset.load_dataset(
        context, "processed/sales", retailer=slct_retailer, category=slct_category
    )
    train_X = dataset.load_dataset(
        context, "train/sales/features", retailer=slct_retailer, category=slct_category
    )
    train_y = dataset.load_dataset(
        context, "train/sales/target", retailer=slct_retailer, category=slct_category
    )

    time_stamp = "_".join([start_date, "to", end_date])
    ppg_summary_df = dataset.load_dataset(
        context,
        "output/ppg_summary",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=time_stamp,
    )

    filtered_ppg_sales_df = ppg_sales_df.query("Date>=@start_date & Date<@end_date")
    train_X = train_X.query("Date>=@start_date & Date<@end_date")
    train_y = train_y.query("Date>=@start_date & Date<@end_date")

    # Subset data
    ppg_list_to_include = ppg_summary_df.loc[
        ~ppg_summary_df["Reason"].isin(
            ["Dying PPGs", "Inconsistent Sales", "Low ACV", "Low Data", "Low Revenue"]
        ),
        "PPG_Item_No",
    ].to_list()
    slct_ppg_sales_df = filtered_ppg_sales_df.query(
        "PPG_Item_No in @ppg_list_to_include"
    )
    train_X = train_X.query("PPG_Item_No in @ppg_list_to_include")
    train_y = train_y.query("PPG_Item_No in @ppg_list_to_include")

    # List of PPGs to model
    ppg_list_to_model = slct_ppg_sales_df.loc[
        slct_ppg_sales_df["PPG_MFG"] == slct_vendor, "PPG_Item_No"
    ].unique()

    # Load pre-trained feature pipelines and other artifacts
    own_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder, "own_effects_features_{}.joblib".format(time_stamp)
            )
        )
    )
    opt_own_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder,
                "opt_own_effects_features_{}.joblib".format(time_stamp),
            )
        )
    )
    comp_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder,
                "competitor_effects_features_{}.joblib".format(time_stamp),
            )
        )
    )
    opt_comp_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder,
                "opt_competitor_effects_features_{}.joblib".format(time_stamp),
            )
        )
    )

    # Transform data
    # Price Elasticity
    own_feat_trans.fit(train_X)
    trans_X = own_feat_trans.transform(train_X)
    trans_X["Model_flag"] = 2

    trans_y = (
        train_y.copy()
        .merge(
            trans_X.loc[:, ["PPG_Item_No", "Date", "Missing_data_flag"]],
            how="right",
            on=["PPG_Item_No", "Date"],
        )
        .assign(
            wk_sold_qty_byppg=lambda x: x.apply(
                lambda y: 0 if y["Missing_data_flag"] == 1 else y["wk_sold_qty_byppg"],
                axis=1,
            )
        )
        .transform_columns(
            ["wk_sold_qty_byppg"],
            np.log1p,
            new_column_names={"wk_sold_qty_byppg": "wk_sold_qty_byppg_log"},
        )
        .sort_values(by=["PPG_Item_No", "Date"], ignore_index=True)
    )

    # Optimizer
    opt_own_feat_trans.fit(train_X)
    opt_trans_X = opt_own_feat_trans.transform(train_X)
    opt_trans_X["Model_flag"] = 2

    opt_trans_y = (
        train_y.copy()
        .merge(
            opt_trans_X.loc[:, ["PPG_Item_No", "Date", "Missing_data_flag"]],
            how="right",
            on=["PPG_Item_No", "Date"],
        )
        .assign(
            wk_sold_qty_byppg=lambda x: x.apply(
                lambda y: 0 if y["Missing_data_flag"] == 1 else y["wk_sold_qty_byppg"],
                axis=1,
            )
        )
        .transform_columns(
            ["wk_sold_qty_byppg"],
            np.log1p,
            new_column_names={"wk_sold_qty_byppg": "wk_sold_qty_byppg_log"},
        )
        .sort_values(by=["PPG_Item_No", "Date"], ignore_index=True)
    )

    # Model Elasticity
    # Create model training pipeline
    reg_ppln_ols = Pipeline([("estimator", CustomSKLLassoCV())])

    # Initialization
    # Model Results
    model_results_final = pd.DataFrame(columns=[])  # Final model version

    # Cross-Validation Model Results
    model_results_cv = pd.DataFrame(columns=[])

    # Baseline Sales
    glbl_base_df = pd.DataFrame(columns=[])
    glbl_opt_base_df = pd.DataFrame(columns=[])

    # Cannibalisation Sales
    glbl_cannibal_df = pd.DataFrame(columns=[])
    glbl_opt_cannibal_df = pd.DataFrame(columns=[])

    # List of ppgs with just intercept turning out
    ppg_wt_intercept = []

    cols_in_model_df = [
        "PPG_Cat",
        "PPG_MFG",
        "PPG_Item_No",
        "PPG_Description",
        "Date",
        # "wk_sold_qty_byppg_log",
        "wk_sold_median_base_price_byppg_log",
        "tpr_discount_byppg",
        "ACV_Feat_Only",
        "ACV_Disp_Only",
        "ACV_Feat_Disp",
        "ACV_Selling",
        "flag_qtr2",
        "flag_qtr3",
        "flag_qtr4",
        "category_trend",
        "tpr_discount_byppg_lag1",
        "tpr_discount_byppg_lag2",
        "monthno",
        "Missing_data_flag",
    ]
    cols_in_base_df = [
        "PPG_Cat",
        "PPG_MFG",
        "PPG_Item_No",
        "PPG_Description",
        "Date",
        # "wk_sold_qty_byppg",
        "wk_sold_avg_price_byppg",
        "median_baseprice",
        "Final_baseprice",
        "Estimated_baseprice",
        "tpr_discount_byppg",
        "ACV_Feat_Only",
        "ACV_Disp_Only",
        "ACV_Feat_Disp",
        "ACV_Selling",
        "median_acv_selling",
        "flag_qtr2",
        "flag_qtr3",
        "flag_qtr4",
        "category_trend",
        "tpr_discount_byppg_lag1",
        "tpr_discount_byppg_lag2",
        "monthno",
        "Missing_data_flag",
    ]

    for i, ppg in enumerate(ppg_list_to_model):

        try:
            print("{} Selected PPG: {}".format(i + 1, ppg))

            # Subset data
            slct_trans_X = trans_X.loc[trans_X["PPG_Item_No"] == ppg].reset_index(
                drop=True
            )
            slct_trans_y = trans_y.loc[trans_y["PPG_Item_No"] == ppg].reset_index(
                drop=True
            )

            slct_opt_trans_X = opt_trans_X.loc[
                opt_trans_X["PPG_Item_No"] == ppg
            ].reset_index(drop=True)
            slct_opt_trans_y = opt_trans_y.loc[
                opt_trans_y["PPG_Item_No"] == ppg
            ].reset_index(drop=True)

            ppg_tpr_df = slct_trans_X[["Date", "tpr_discount_byppg"]].merge(
                slct_trans_y[["Date", "wk_sold_qty_byppg_log"]], how="left", on="Date"
            )
            ppg_tpr_df = ppg_tpr_df.rename(
                columns={
                    "wk_sold_qty_byppg_log": "DV",
                    "tpr_discount_byppg": "tpr_temp",
                }
            )
            ppg_tpr_df = ppg_tpr_df.set_index("Date")

            # Add new features
            # Competitor EDLP & TPR
            comp_feat_trans.fit(slct_trans_X)
            slct_trans_X = comp_feat_trans.transform(slct_trans_X)
            slct_trans_y = (
                slct_trans_y.copy()
                .filter_on("Missing_data_flag == 0", complement=False)
                .reset_index(drop=True)
                .select_columns(["wk_sold_qty_byppg_log"])
                .rename_column("wk_sold_qty_byppg_log", "DV")
            )["DV"]

            opt_comp_feat_trans.fit(slct_opt_trans_X)
            slct_opt_trans_X = comp_feat_trans.transform(slct_opt_trans_X)
            slct_opt_trans_y = (
                slct_opt_trans_y.copy()
                .filter_on("Missing_data_flag == 0", complement=False)
                .reset_index(drop=True)
                .select_columns(["wk_sold_qty_byppg_log"])
                .rename_column("wk_sold_qty_byppg_log", "DV")
            )["DV"]

            # Feature Selection
            slct_features = select_features(
                ppg, slct_trans_X, slct_trans_y, reg_ppln_ols
            )
            slct_trans_X = slct_trans_X.loc[:, slct_features]
            slct_opt_trans_X = slct_opt_trans_X.loc[:, slct_features]

            # Build model with shortlisted features
            seed = 123
            random.seed(seed)
            X = slct_trans_X.drop(
                columns=["Date", "PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
            )
            y = slct_trans_y.to_numpy()
            opt_X = slct_opt_trans_X.drop(
                columns=["Date", "PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
            )
            opt_y = slct_opt_trans_y.to_numpy()

            reg_ppln_ols.fit(X, y)

            # Model coefficients
            model = reg_ppln_ols["estimator"]
            model_coef = pd.DataFrame(
                {
                    "model_coefficient_name": X.columns.to_list(),
                    "model_coefficient_value": model.coef_,
                }
            )
            model_coef = model_coef.append(
                {
                    "model_coefficient_name": "(Intercept)",
                    "model_coefficient_value": model.intercept_,
                },
                ignore_index=True,
            )
            model_coef = model_coef[model_coef["model_coefficient_value"].abs() > 0]

            # Model performance metric
            train_set_prediction = pd.DataFrame(
                {"PPG_Item_No": [ppg] * len(X), "Prediction": np.exp(model.predict(X))}
            )
            train_set_rsq = r2_score((y), np.log(train_set_prediction["Prediction"]))
            train_set_MAPE = mean_absolute_error(
                np.array([1] * len(y)), train_set_prediction["Prediction"] / np.exp(y)
            )
            cv_mse_mean, cv_mse_sd = model.get_cv_metrics()

            # Save the model results
            temp_4 = slct_trans_X[
                ["PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
            ].drop_duplicates()  # pd.DataFrame({"PPG_Item_No": [ppg]})
            temp_4["model_RSq"] = train_set_rsq
            temp_4["TrainMAPE"] = train_set_MAPE
            temp_4["model_CVErrorMean"] = cv_mse_mean
            temp_4["model_CVErrorSD"] = cv_mse_sd

            temp_4["dummy"] = 1
            model_coef["dummy"] = 1
            temp_5 = temp_4.merge(model_coef, how="left", on="dummy")
            temp_5 = temp_5.drop(columns="dummy")
            model_results_final = model_results_final.append(temp_5, ignore_index=True)

            # Base volume estimation
            X_wt_dt = pd.concat((X, slct_trans_X["Date"]), axis="columns").set_index(
                "Date"
            )  # Temp Fix
            base_df = (
                trans_X.copy()
                .query("PPG_Item_No==@ppg")
                .reset_index(drop=True)
                .select_columns(cols_in_base_df)
                .tpr_acv_smoothing()
                .edlp_acv_smoothing()
                .filter_on("Missing_data_flag==0")
                .remove_columns(["Missing_data_flag"])
                .estimate_base_volume(ppg, model, X_wt_dt, slct_trans_X, trans_X)
            )
            glbl_base_df = glbl_base_df.append(base_df, ignore_index=True)

            opt_X_wt_dt = pd.concat(
                (opt_X, slct_opt_trans_X["Date"]), axis="columns"
            ).set_index(
                "Date"
            )  # Temp Fix
            opt_base_df = (
                opt_trans_X.copy()
                .query("PPG_Item_No==@ppg")
                .reset_index(drop=True)
                .select_columns(cols_in_base_df)
                .tpr_acv_smoothing()
                .edlp_acv_smoothing()
                .filter_on("Missing_data_flag==0")
                .remove_columns(["Missing_data_flag"])
                .estimate_base_volume(
                    ppg, model, opt_X_wt_dt, slct_opt_trans_X, opt_trans_X
                )
            )
            glbl_opt_base_df = glbl_opt_base_df.append(opt_base_df, ignore_index=True)

            # Compute Cannibalisation Dollar Sales to exclude it from gross lift
            cannibal_df = cannibalisation_module(
                ppg, model, X_wt_dt, model_coef, ppg_list_to_model, trans_X
            )
            glbl_cannibal_df = glbl_cannibal_df.append(cannibal_df, ignore_index=True)

            opt_cannibal_df = cannibalisation_module(
                ppg, model, opt_X_wt_dt, model_coef, ppg_list_to_model, opt_trans_X
            )
            glbl_opt_cannibal_df = glbl_opt_cannibal_df.append(
                opt_cannibal_df, ignore_index=True
            )

            # Cross Validation
            temp_model_results_cv = cross_validation(
                ppg, X_wt_dt, slct_trans_X, ppg_tpr_df
            )
            model_results_cv = model_results_cv.append(
                temp_model_results_cv, ignore_index=True
            )

        except Exception:
            print("Exception Occured for {}".format(ppg))
            continue

    # Update PPG summary
    ppg_summary_df.loc[
        ppg_summary_df["Reason"].isna(), "Reason"
    ] = "PPGs Considered for Modelling"
    ppg_summary_df = ppg_summary_df.merge(
        model_results_final[
            ["PPG_MFG", "PPG_Item_No", "model_RSq", "TrainMAPE"]
        ].drop_duplicates(),
        how="left",
        on=["PPG_Item_No", "PPG_MFG"],
    )
    ppg_summary_df["Model_flag"] = ppg_summary_df["Reason"].apply(
        lambda x: 2 if x == "PPGs Considered for Modelling" else 0
    )

    # # Tag output files
    model_df = trans_X.merge(
        trans_y[["PPG_Item_No", "Date", "wk_sold_qty_byppg", "wk_sold_qty_byppg_log"]],
        how="left",
        on=["PPG_Item_No", "Date"],
    )
    opt_model_df = opt_trans_X.merge(
        opt_trans_y[
            ["PPG_Item_No", "Date", "wk_sold_qty_byppg", "wk_sold_qty_byppg_log"]
        ],
        how="left",
        on=["PPG_Item_No", "Date"],
    )

    glbl_base_df = glbl_base_df.merge(
        trans_y[["PPG_Item_No", "Date", "wk_sold_qty_byppg"]],
        how="left",
        on=["PPG_Item_No", "Date"],
    )
    glbl_opt_base_df = glbl_opt_base_df.merge(
        opt_trans_y[["PPG_Item_No", "Date", "wk_sold_qty_byppg"]],
        how="left",
        on=["PPG_Item_No", "Date"],
    )
    glbl_base_df["Model_flag"] = 2
    glbl_opt_base_df["Model_flag"] = 2

    glbl_cannibal_df["Model_flag"] = 2
    glbl_opt_cannibal_df["Model_flag"] = 2

    model_results_final["Model_flag"] = 2
    model_results_cv["Model_flag"] = 2

    # Save model results
    time_stamp = "_".join([start_date, "to", end_date])
    dataset.save_dataset(
        context,
        ppg_summary_df,
        "output/ppg_summary",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=time_stamp,
    )
    dataset.save_dataset(
        context,
        model_results_final,
        "output/model_results",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=time_stamp,
    )

    dataset.save_dataset(
        context,
        model_df,
        "output/model_data",
        retailer=slct_retailer,
        category=slct_category,
        data_type="elasticity",
        model_variant=time_stamp,
    )
    dataset.save_dataset(
        context,
        opt_model_df,
        "output/model_data",
        retailer=slct_retailer,
        category=slct_category,
        data_type="optimizer",
        model_variant=time_stamp,
    )

    dataset.save_dataset(
        context,
        glbl_base_df,
        "output/base_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="elasticity",
        model_variant=time_stamp,
    )
    dataset.save_dataset(
        context,
        glbl_opt_base_df,
        "output/base_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="optimizer",
        model_variant=time_stamp,
    )

    dataset.save_dataset(
        context,
        glbl_cannibal_df,
        "output/cannibal_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="elasticity",
        model_variant=time_stamp,
    )
    dataset.save_dataset(
        context,
        glbl_opt_cannibal_df,
        "output/cannibal_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="optimizer",
        model_variant=time_stamp,
    )


@register_processor("model-gen", "model-elasticity-bayesian-regression")
def model_elasticity_by_bayesian_regression(context, params):
    """Train elasticity model using Bayesian regression."""
    # Initialization
    artifacts_folder = op.join(get_package_path(), "artifacts")

    slct_retailer = params["slct_retailer"]
    slct_category = params["slct_category"]
    slct_vendor = params["slct_vendor"]

    start_date = params["start_date"]
    end_date = params["end_date"]

    # Load datasets
    ppg_sales_df = dataset.load_dataset(
        context, "processed/sales", retailer=slct_retailer, category=slct_category
    )
    train_X = dataset.load_dataset(
        context, "train/sales/features", retailer=slct_retailer, category=slct_category
    )
    train_y = dataset.load_dataset(
        context, "train/sales/target", retailer=slct_retailer, category=slct_category
    )

    time_stamp = "_".join([start_date, "to", end_date])
    ppg_summary_df = dataset.load_dataset(
        context,
        "output/ppg_summary",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=time_stamp,
    )

    filtered_ppg_sales_df = ppg_sales_df.query("Date>=@start_date & Date<@end_date")
    train_X = train_X.query("Date>=@start_date & Date<@end_date")
    train_y = train_y.query("Date>=@start_date & Date<@end_date")

    time_stamp_0 = "_".join([start_date, "to", end_date])
    lasso_model_results_0 = dataset.load_dataset(
        context,
        "output/model_results",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=time_stamp_0,
    )

    time_stamp_1 = "_".join(["2017-10-01", "to", "2019-09-30"])
    lasso_model_results_1 = dataset.load_dataset(
        context,
        "output/model_results",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=time_stamp_1,
    )

    time_stamp_2 = "_".join(["2017-07-01", "to", "2019-06-30"])
    lasso_model_results_2 = dataset.load_dataset(
        context,
        "output/model_results",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=time_stamp_2,
    )

    time_stamp_3 = "_".join(["2017-04-01", "to", "2019-03-31"])
    lasso_model_results_3 = dataset.load_dataset(
        context,
        "output/model_results",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=time_stamp_3,
    )

    time_stamp_base = "_".join(["2017-01-01", "to", "2018-12-31"])
    base_model_results = dataset.load_dataset(
        context,
        "output/model_results",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=time_stamp_base,
    )

    # Subset data
    ppg_list_to_include = ppg_summary_df.loc[
        ~ppg_summary_df["Reason"].isin(
            ["Dying PPGs", "Inconsistent Sales", "Low ACV", "Low Data", "Low Revenue"]
        ),
        "PPG_Item_No",
    ].to_list()
    slct_ppg_sales_df = filtered_ppg_sales_df.query(
        "PPG_Item_No in @ppg_list_to_include"
    )
    train_X = train_X.query("PPG_Item_No in @ppg_list_to_include")
    train_y = train_y.query("PPG_Item_No in @ppg_list_to_include")

    # List of PPGs to model
    ppg_list_to_model = slct_ppg_sales_df.loc[
        slct_ppg_sales_df["PPG_MFG"] == slct_vendor, "PPG_Item_No"
    ].unique()

    # Load pre-trained feature pipelines and other artifacts
    own_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder, "own_effects_features_{}.joblib".format(time_stamp)
            )
        )
    )
    opt_own_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder,
                "opt_own_effects_features_{}.joblib".format(time_stamp),
            )
        )
    )
    comp_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder,
                "competitor_effects_features_{}.joblib".format(time_stamp),
            )
        )
    )
    opt_comp_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder,
                "opt_competitor_effects_features_{}.joblib".format(time_stamp),
            )
        )
    )

    # Transform data
    # Price Elasticity
    own_feat_trans.fit(train_X)
    trans_X = own_feat_trans.transform(train_X)
    trans_X["Model_flag"] = 2

    trans_y = (
        train_y.copy()
        .merge(
            trans_X.loc[:, ["PPG_Item_No", "Date", "Missing_data_flag"]],
            how="right",
            on=["PPG_Item_No", "Date"],
        )
        .assign(
            wk_sold_qty_byppg=lambda x: x.apply(
                lambda y: 0 if y["Missing_data_flag"] == 1 else y["wk_sold_qty_byppg"],
                axis=1,
            )
        )
        .transform_columns(
            ["wk_sold_qty_byppg"],
            np.log1p,
            new_column_names={"wk_sold_qty_byppg": "wk_sold_qty_byppg_log"},
        )
        .sort_values(by=["PPG_Item_No", "Date"], ignore_index=True)
    )

    # Optimizer
    opt_own_feat_trans.fit(train_X)
    opt_trans_X = opt_own_feat_trans.transform(train_X)
    opt_trans_X["Model_flag"] = 2

    opt_trans_y = (
        train_y.copy()
        .merge(
            opt_trans_X.loc[:, ["PPG_Item_No", "Date", "Missing_data_flag"]],
            how="right",
            on=["PPG_Item_No", "Date"],
        )
        .assign(
            wk_sold_qty_byppg=lambda x: x.apply(
                lambda y: 0 if y["Missing_data_flag"] == 1 else y["wk_sold_qty_byppg"],
                axis=1,
            )
        )
        .transform_columns(
            ["wk_sold_qty_byppg"],
            np.log1p,
            new_column_names={"wk_sold_qty_byppg": "wk_sold_qty_byppg_log"},
        )
        .sort_values(by=["PPG_Item_No", "Date"], ignore_index=True)
    )

    # Model Elasticity
    hist_model_results = (
        lasso_model_results_3,
        lasso_model_results_2,
        lasso_model_results_1,
        lasso_model_results_0,
    )

    # Initialization
    # Model Results
    model_results_final = pd.DataFrame(columns=[])  # Final model version

    # Baseline Sales
    glbl_base_df = pd.DataFrame(columns=[])
    glbl_opt_base_df = pd.DataFrame(columns=[])

    # Cannibalisation Sales
    glbl_cannibal_df = pd.DataFrame(columns=[])
    glbl_opt_cannibal_df = pd.DataFrame(columns=[])

    # List of ppgs with just intercept turning out
    glbl_intercept_df = pd.DataFrame()

    cols_in_model_df = [
        "PPG_Cat",
        "PPG_MFG",
        "PPG_Item_No",
        "PPG_Description",
        "Date",
        # "wk_sold_qty_byppg_log",
        "wk_sold_median_base_price_byppg_log",
        "tpr_discount_byppg",
        "ACV_Feat_Only",
        "ACV_Disp_Only",
        "ACV_Feat_Disp",
        "ACV_Selling",
        "flag_qtr2",
        "flag_qtr3",
        "flag_qtr4",
        "category_trend",
        "tpr_discount_byppg_lag1",
        "tpr_discount_byppg_lag2",
        "monthno",
        "Missing_data_flag",
    ]
    cols_in_base_df = [
        "PPG_Cat",
        "PPG_MFG",
        "PPG_Item_No",
        "PPG_Description",
        "Date",
        # "wk_sold_qty_byppg",
        "wk_sold_avg_price_byppg",
        "median_baseprice",
        "Final_baseprice",
        "Estimated_baseprice",
        "tpr_discount_byppg",
        "ACV_Feat_Only",
        "ACV_Disp_Only",
        "ACV_Feat_Disp",
        "ACV_Selling",
        "median_acv_selling",
        "flag_qtr2",
        "flag_qtr3",
        "flag_qtr4",
        "category_trend",
        "tpr_discount_byppg_lag1",
        "tpr_discount_byppg_lag2",
        "monthno",
        "Missing_data_flag",
    ]

    for i, ppg in enumerate(ppg_list_to_model[0:3]):

        try:
            print("{} Selected PPG: {}".format(i + 1, ppg))

            # Subset data
            slct_trans_X = trans_X.loc[trans_X["PPG_Item_No"] == ppg].reset_index(
                drop=True
            )
            slct_trans_y = trans_y.loc[trans_y["PPG_Item_No"] == ppg].reset_index(
                drop=True
            )

            slct_opt_trans_X = opt_trans_X.loc[
                opt_trans_X["PPG_Item_No"] == ppg
            ].reset_index(drop=True)
            slct_opt_trans_y = opt_trans_y.loc[
                opt_trans_y["PPG_Item_No"] == ppg
            ].reset_index(drop=True)

            ppg_tpr_df = slct_trans_X[["Date", "tpr_discount_byppg"]].merge(
                slct_trans_y[["Date", "wk_sold_qty_byppg_log"]], how="left", on="Date"
            )
            ppg_tpr_df = ppg_tpr_df.rename(
                columns={
                    "wk_sold_qty_byppg_log": "DV",
                    "tpr_discount_byppg": "tpr_temp",
                }
            )
            ppg_tpr_df = ppg_tpr_df.set_index("Date")

            # Add new features
            # Competitor EDLP & TPR
            comp_feat_trans.fit(slct_trans_X)
            slct_trans_X = comp_feat_trans.transform(slct_trans_X)
            slct_trans_y = (
                slct_trans_y.copy()
                .filter_on("Missing_data_flag == 0", complement=False)
                .reset_index(drop=True)
                .select_columns(["wk_sold_qty_byppg_log"])
                .rename_column("wk_sold_qty_byppg_log", "DV")
            )["DV"]

            opt_comp_feat_trans.fit(slct_opt_trans_X)
            slct_opt_trans_X = comp_feat_trans.transform(slct_opt_trans_X)
            slct_opt_trans_y = (
                slct_opt_trans_y.copy()
                .filter_on("Missing_data_flag == 0", complement=False)
                .reset_index(drop=True)
                .select_columns(["wk_sold_qty_byppg_log"])
                .rename_column("wk_sold_qty_byppg_log", "DV")
            )["DV"]

            # Feature Selection
            slct_features, model_coef_prior = select_features_for_bayesian_model(
                ppg,
                slct_trans_X,
                trans_X,
                trans_X.loc[trans_X["PPG_Item_No"] == ppg].reset_index(drop=True),
                base_model_results,
                hist_model_results,
            )
            slct_trans_X = slct_trans_X.loc[:, slct_features]
            slct_opt_trans_X = slct_opt_trans_X.loc[:, slct_features]

            if len(slct_features) == 0:
                glbl_intercept_df = lasso_model_results_0[
                    lasso_model_results_0["PPG_Item_No"] == ppg
                ].append(glbl_intercept_df, ignore_index=True)
                continue

            # Bayesian model
            # Data initialisation
            seed = 123
            random.seed(seed)
            X = slct_trans_X.drop(
                columns=["Date", "PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
            )
            y = slct_trans_y
            opt_X = slct_opt_trans_X.drop(
                columns=["Date", "PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
            )
            opt_y = slct_opt_trans_y

            # Set prior for Bayesian
            prior_df = model_coef_prior.copy()
            prior_df["distribution"] = "Normal"
            prior_df["bijector"] = prior_df["model_coefficient_name"].apply(
                lambda x: "Identity"
                if x == "global_intercept"
                else ["Identity", "Exp"][1]
            )
            # Add prior for intercept, if not present
            intercept_df = pd.DataFrame(
                {
                    "model_coefficient_name": ["global_intercept"],
                    "model_coefficient_value": [np.median(y)],
                    "model_coefficient_std": [2.5],
                    "distribution": ["Normal"],
                    "bijector": ["Identity"],
                }
            )
            prior_df = prior_df.append(intercept_df, ignore_index=True)

            # Reverse sign for prior distribution - Log-normal
            # reverse_cols = prior_df.loc[prior_df["model_coefficient_value"]<0,"model_coefficient_name"].to_list()
            reverse = [
                "wk_sold_median_base_price_byppg_log",
                "tpr_discount_byppg_lag1",
                "tpr_discount_byppg_lag2",
            ]
            reverse = reverse + [
                col
                for col in X.columns.to_list()
                if ("_PromotedDiscount" in col)
                and (re.search(".*PromotedDiscount.*PromotedDiscount", col) is None)
            ]
            interactions = [
                col
                for col in X.columns.to_list()
                if re.search("ITEM.*ITEM.*", col) is not None
            ]
            flag_qtr = [col for col in X.columns.to_list() if "flag_qtr" in col]
            unbounded = interactions + flag_qtr + ["monthno", "category_trend"]
            reverse = (
                reverse
                + model_coef_prior.loc[
                    (model_coef_prior["model_coefficient_name"].isin(unbounded))
                    & (model_coef_prior["model_coefficient_value"] < 0),
                    "model_coefficient_name",
                ].to_list()
            )
            prior_df["model_coefficient_value"] = prior_df[
                "model_coefficient_value"
            ].abs()

            # Build model
            mlflow.end_run()  # Nested run turned off, so it is needed
            bayes_model = SKLBayesian(fe_prior_df=prior_df)
            bayes_model.fit(X.copy(), y.copy(), reverse_column_names=reverse)
            tmp_model_coef = bayes_model.get_params_in_dataframe()

            # Model coefficients
            model_coef_prior = (
                model_coef_prior.copy().select_columns(
                    ["model_coefficient_name", "model_coefficient_value"]
                )
                # Align variable name to generic format
                .transform_column(
                    column_name="model_coefficient_name",
                    function=lambda x: x
                    if x == "global_intercept|intercept"
                    else re.sub("_", "", x),
                    dest_column_name="model_coefficient_name_adj",
                    elementwise=True,
                )
            )

            model_coef = (
                tmp_model_coef.copy()
                .rename_columns(
                    {
                        "variable": "model_coefficient_name_adj",
                        "estimate": "model_coefficient_value",
                    }
                )
                # Align variable name to generic format
                .transform_column(
                    column_name="model_coefficient_name_adj",
                    function=lambda x: re.sub("fixed_slope_|slope_", "", x),
                    elementwise=True,
                )
                # Get original variable name
                .merge(
                    model_coef_prior[
                        ["model_coefficient_name", "model_coefficient_name_adj"]
                    ],
                    how="left",
                    on="model_coefficient_name_adj",
                )
                .assign(
                    model_coefficient_name=lambda x: x.apply(
                        lambda y: "(Intercept)"
                        if y["model_coefficient_name_adj"] == "global_intercept"
                        else y["model_coefficient_name"],
                        axis=1,
                    )
                )
                # Reverse variable sign
                .select_columns(["model_coefficient_name", "model_coefficient_value"])
                .assign(
                    model_coefficient_value=lambda x: x.apply(
                        lambda y: (-1) * y["model_coefficient_value"]
                        if y["model_coefficient_name"]
                        in bayes_model.reverse_feature_names_
                        else y["model_coefficient_value"],
                        axis=1,
                    )
                )
            )

            # Model performance metric
            train_set_prediction = pd.DataFrame(
                {
                    "PPG_Item_No": [ppg] * len(X),
                    "Prediction": np.exp(bayes_model.predict(X.copy())),
                }
            )
            train_set_rsq = r2_score((y), np.log(train_set_prediction["Prediction"]))
            train_set_MAPE = mean_absolute_error(
                np.array([1] * len(y)), train_set_prediction["Prediction"] / np.exp(y)
            )
            cv_mse_mean, cv_mse_sd = (np.nan, np.nan)  # model.get_cv_metrics()

            # Save the model results
            temp_4 = slct_trans_X[
                ["PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
            ].drop_duplicates()
            temp_4["model_RSq"] = train_set_rsq
            temp_4["TrainMAPE"] = train_set_MAPE
            temp_4["model_CVErrorMean"] = cv_mse_mean
            temp_4["model_CVErrorSD"] = cv_mse_sd

            temp_4["dummy"] = 1
            model_coef["dummy"] = 1
            temp_5 = temp_4.merge(model_coef, how="left", on="dummy")
            temp_5 = temp_5.drop(columns="dummy")
            model_results_final = model_results_final.append(temp_5, ignore_index=True)

            # Base volume estimation
            X_wt_dt = pd.concat((X, slct_trans_X["Date"]), axis="columns").set_index(
                "Date"
            )  # Temp Fix
            base_df = (
                trans_X.copy()
                .query("PPG_Item_No==@ppg")
                .reset_index(drop=True)
                .select_columns(cols_in_base_df)
                .tpr_acv_smoothing()
                .edlp_acv_smoothing()
                .filter_on("Missing_data_flag==0")
                .remove_columns(["Missing_data_flag"])
                .estimate_base_volume(ppg, bayes_model, X_wt_dt, slct_trans_X, trans_X)
            )
            glbl_base_df = glbl_base_df.append(base_df, ignore_index=True)

            opt_X_wt_dt = pd.concat(
                (opt_X, slct_opt_trans_X["Date"]), axis="columns"
            ).set_index(
                "Date"
            )  # Temp Fix
            opt_base_df = (
                opt_trans_X.copy()
                .query("PPG_Item_No==@ppg")
                .reset_index(drop=True)
                .select_columns(cols_in_base_df)
                .tpr_acv_smoothing()
                .edlp_acv_smoothing()
                .filter_on("Missing_data_flag==0")
                .remove_columns(["Missing_data_flag"])
                .estimate_base_volume(
                    ppg, bayes_model, opt_X_wt_dt, slct_opt_trans_X, opt_trans_X
                )
            )
            glbl_opt_base_df = glbl_opt_base_df.append(opt_base_df, ignore_index=True)

            # Compute Cannibalisation Dollar Sales to exclude it from gross lift
            cannibal_df = cannibalisation_module(
                ppg, bayes_model, X_wt_dt, model_coef, ppg_list_to_model, trans_X
            )
            glbl_cannibal_df = glbl_cannibal_df.append(cannibal_df, ignore_index=True)

            opt_cannibal_df = cannibalisation_module(
                ppg,
                bayes_model,
                opt_X_wt_dt,
                model_coef,
                ppg_list_to_model,
                opt_trans_X,
            )
            glbl_opt_cannibal_df = glbl_opt_cannibal_df.append(
                opt_cannibal_df, ignore_index=True
            )

        except Exception:
            print("Exception Occured for {}".format(ppg))
            continue

    # If Bayesian model is not build, borrow results from lasso model
    if len(glbl_intercept_df) > 0:
        temp_model_results_final = dataset.load_dataset(
            context,
            "output/model_results",
            retailer=slct_retailer,
            category=slct_category,
            model_variant=time_stamp,
        )
        temp_gbl_base_df = dataset.load_dataset(
            context,
            "output/base_volume",
            retailer=slct_retailer,
            category=slct_category,
            data_type="elasticity",
            model_variant=time_stamp,
        )
        temp_gbl_opt_base_df = dataset.load_dataset(
            context,
            "output/base_volume",
            retailer=slct_retailer,
            category=slct_category,
            data_type="optimizer",
            model_variant=time_stamp,
        )

        temp_model_results_final = temp_model_results_final[
            temp_model_results_final["PPG_Item_No"].isin(
                glbl_intercept_df["PPG_Item_No"]
            )
        ]
        temp_gbl_base_df = temp_gbl_base_df[
            temp_gbl_base_df["PPG_Item_No"].isin(glbl_intercept_df["PPG_Item_No"])
        ]
        temp_gbl_opt_base_df = temp_gbl_opt_base_df[
            temp_gbl_opt_base_df["PPG_Item_No"].isin(glbl_intercept_df["PPG_Item_No"])
        ]

        model_results_final = model_results_final.append(
            temp_model_results_final, ignore_index=True
        )
        glbl_base_df = glbl_base_df.append(temp_gbl_base_df, ignore_index=True)
        glbl_opt_base_df = glbl_opt_base_df.append(
            temp_gbl_opt_base_df, ignore_index=True
        )

    ppg_summary_df.loc[
        ~ppg_summary_df["Reason"].isin(
            ["Dying PPGs", "Inconsistent Sales", "Low ACV", "Low Data", "Low Revenue"]
        ),
        "Reason",
    ] = "PPGs Considered for Modelling"
    ppg_summary_df = ppg_summary_df.drop(columns=["model_RSq", "TrainMAPE"]).merge(
        model_results_final[
            ["PPG_MFG", "PPG_Item_No", "model_RSq", "TrainMAPE"]
        ].drop_duplicates(),
        how="left",
        on=["PPG_Item_No", "PPG_MFG"],
    )
    ppg_summary_df["Model_flag"] = ppg_summary_df["Reason"].apply(
        lambda x: 2 if x == "PPGs Considered for Modelling" else 0
    )

    # Tag output files
    model_df = trans_X.merge(
        trans_y[["PPG_Item_No", "Date", "wk_sold_qty_byppg", "wk_sold_qty_byppg_log"]],
        how="left",
        on=["PPG_Item_No", "Date"],
    )
    opt_model_df = opt_trans_X.merge(
        opt_trans_y[
            ["PPG_Item_No", "Date", "wk_sold_qty_byppg", "wk_sold_qty_byppg_log"]
        ],
        how="left",
        on=["PPG_Item_No", "Date"],
    )

    glbl_base_df = glbl_base_df.merge(
        trans_y[["PPG_Item_No", "Date", "wk_sold_qty_byppg"]],
        how="left",
        on=["PPG_Item_No", "Date"],
    )
    glbl_opt_base_df = glbl_opt_base_df.merge(
        opt_trans_y[["PPG_Item_No", "Date", "wk_sold_qty_byppg"]],
        how="left",
        on=["PPG_Item_No", "Date"],
    )
    glbl_base_df["Model_flag"] = 2
    glbl_opt_base_df["Model_flag"] = 2

    glbl_cannibal_df["Model_flag"] = 2
    glbl_opt_cannibal_df["Model_flag"] = 2

    model_results_final["Model_flag"] = 2

    # Save model results
    dataset.save_dataset(
        context,
        ppg_summary_df,
        "output/ppg_summary",
        retailer=slct_retailer,
        category=slct_category,
        model_variant="fnl",
    )

    model_type = "2yr"
    dataset.save_dataset(
        context,
        model_results_final,
        "output/model_results",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=model_type,
    )

    dataset.save_dataset(
        context,
        model_df,
        "output/model_data",
        retailer=slct_retailer,
        category=slct_category,
        data_type="elasticity",
        model_variant=model_type,
    )
    dataset.save_dataset(
        context,
        opt_model_df,
        "output/model_data",
        retailer=slct_retailer,
        category=slct_category,
        data_type="optimizer",
        model_variant=model_type,
    )

    dataset.save_dataset(
        context,
        glbl_base_df,
        "output/base_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="elasticity",
        model_variant=model_type,
    )
    dataset.save_dataset(
        context,
        glbl_opt_base_df,
        "output/base_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="optimizer",
        model_variant=model_type,
    )

    dataset.save_dataset(
        context,
        glbl_cannibal_df,
        "output/cannibal_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="elasticity",
        model_variant=model_type,
    )
    dataset.save_dataset(
        context,
        glbl_opt_cannibal_df,
        "output/cannibal_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="optimizer",
        model_variant=model_type,
    )


@register_processor("model-gen", "model-elasticity-lasso-regression-spl-case")
def model_elasticity_by_lasso_regression_spl_case(context, params):
    """Train elasticity model for PPGs with 1-2 years of data using Lasso regression."""
    # Intialization
    artifacts_folder = op.join(get_package_path(), "artifacts")

    slct_retailer = params["slct_retailer"]
    slct_category = params["slct_category"]
    slct_vendor = params["slct_vendor"]

    start_date = params["start_date"]
    end_date = params["end_date"]

    # Load datasets
    ppg_sales_df = dataset.load_dataset(
        context, "processed/sales", retailer=slct_retailer, category=slct_category
    )
    train_X = dataset.load_dataset(
        context, "train/sales/features", retailer=slct_retailer, category=slct_category
    )
    train_y = dataset.load_dataset(
        context, "train/sales/target", retailer=slct_retailer, category=slct_category
    )

    time_stamp = "_".join([start_date, "to", end_date])
    ppg_summary_df = dataset.load_dataset(
        context,
        "output/ppg_summary",
        retailer=slct_retailer,
        category=slct_category,
        model_variant="fnl",
    )

    filtered_ppg_sales_df = ppg_sales_df.query("Date>=@start_date & Date<@end_date")
    train_X = train_X.query("Date>=@start_date & Date<@end_date")
    train_y = train_y.query("Date>=@start_date & Date<@end_date")

    # PPG Selection
    # Initialization
    slct_ppg_sales_df = filtered_ppg_sales_df.copy()

    # Average Dollar Sales
    low_revenue_ppgs = ppg_summary_df.loc[
        ppg_summary_df["Reason"] == "Low Revenue", "PPG_Item_No"
    ].to_list()
    slct_ppg_sales_df = slct_ppg_sales_df[
        ~slct_ppg_sales_df["PPG_Item_No"].isin(low_revenue_ppgs)
    ]

    # Data Availability (Remove PPGs with less than 1 year data)
    agg_ppg_df = slct_ppg_sales_df.groupby(by=["PPG_Item_No"], as_index=False).agg(
        {"Date": len, "ACV_Selling": np.count_nonzero}
    )
    agg_ppg_df = agg_ppg_df.rename(
        columns={"Date": "week_cnt", "ACV_Selling": "nonzero_week_cnt"}
    )

    ppgs_lt_yr_data = agg_ppg_df.loc[
        agg_ppg_df["week_cnt"] <= 51, "PPG_Item_No"
    ].to_list()
    ppgs_wt_zero_acvs = agg_ppg_df.loc[
        agg_ppg_df["week_cnt"] <= 52 & ~agg_ppg_df["PPG_Item_No"].isin(ppgs_lt_yr_data),
        "PPG_Item_No",
    ].to_list()
    slct_ppg_sales_df = slct_ppg_sales_df[
        ~slct_ppg_sales_df["PPG_Item_No"].isin(ppgs_lt_yr_data + ppgs_wt_zero_acvs)
    ]

    # Subset data
    train_X = train_X[train_X["PPG_Item_No"].isin(slct_ppg_sales_df["PPG_Item_No"])]
    train_y = train_y[train_y["PPG_Item_No"].isin(slct_ppg_sales_df["PPG_Item_No"])]

    # List of PPGs to model
    ppg_list_to_model = slct_ppg_sales_df.loc[
        (slct_ppg_sales_df["PPG_MFG"] == slct_vendor)
        & (
            ~slct_ppg_sales_df["PPG_Item_No"].isin(
                ppg_summary_df.loc[
                    ppg_summary_df["Reason"].isin(["PPGs Considered for Modelling"]),
                    "PPG_Item_No",
                ]
            )
        ),
        "PPG_Item_No",
    ].unique()

    # Load pre-trained feature pipelines and other artifacts
    own_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder,
                "own_effects_features_spl_case_{}.joblib".format(time_stamp),
            )
        )
    )
    opt_own_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder,
                "opt_own_effects_features_spl_case_{}.joblib".format(time_stamp),
            )
        )
    )
    comp_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder,
                "competitor_effects_features_spl_case_{}.joblib".format(time_stamp),
            )
        )
    )
    opt_comp_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder,
                "opt_competitor_effects_features_spl_case_{}.joblib".format(time_stamp),
            )
        )
    )

    # Transform data
    # Price Elasticity
    own_feat_trans.fit(train_X)
    trans_X = own_feat_trans.transform(train_X)
    trans_X = trans_X.merge(
        ppg_summary_df[["PPG_Item_No", "Reason"]], how="left", on="PPG_Item_No"
    )
    trans_X.loc[
        trans_X["Reason"] != "PPGs Considered for Modelling",
        ["flag_qtr2", "flag_qtr3", "flag_qtr4"],
    ] = 0
    trans_X["Model_flag"] = trans_X["Reason"].apply(
        lambda x: 2 if x == "PPGs Considered for Modelling" else 1
    )

    trans_y = (
        train_y.copy()
        .merge(
            trans_X.loc[:, ["PPG_Item_No", "Date", "Missing_data_flag"]],
            how="right",
            on=["PPG_Item_No", "Date"],
        )
        .assign(
            wk_sold_qty_byppg=lambda x: x.apply(
                lambda y: 0 if y["Missing_data_flag"] == 1 else y["wk_sold_qty_byppg"],
                axis=1,
            )
        )
        .transform_columns(
            ["wk_sold_qty_byppg"],
            np.log1p,
            new_column_names={"wk_sold_qty_byppg": "wk_sold_qty_byppg_log"},
        )
        .sort_values(by=["PPG_Item_No", "Date"], ignore_index=True)
    )

    # Optimizer
    opt_own_feat_trans.fit(train_X)
    opt_trans_X = opt_own_feat_trans.transform(train_X)
    opt_trans_X = opt_trans_X.merge(
        ppg_summary_df[["PPG_Item_No", "Reason"]], how="left", on="PPG_Item_No"
    )
    opt_trans_X.loc[
        opt_trans_X["Reason"] != "PPGs Considered for Modelling",
        ["flag_qtr2", "flag_qtr3", "flag_qtr4"],
    ] = 0
    opt_trans_X["Model_flag"] = opt_trans_X["Reason"].apply(
        lambda x: 2 if x == "PPGs Considered for Modelling" else 1
    )

    opt_trans_y = (
        train_y.copy()
        .merge(
            opt_trans_X.loc[:, ["PPG_Item_No", "Date", "Missing_data_flag"]],
            how="right",
            on=["PPG_Item_No", "Date"],
        )
        .assign(
            wk_sold_qty_byppg=lambda x: x.apply(
                lambda y: 0 if y["Missing_data_flag"] == 1 else y["wk_sold_qty_byppg"],
                axis=1,
            )
        )
        .transform_columns(
            ["wk_sold_qty_byppg"],
            np.log1p,
            new_column_names={"wk_sold_qty_byppg": "wk_sold_qty_byppg_log"},
        )
        .sort_values(by=["PPG_Item_No", "Date"], ignore_index=True)
    )

    # Model Elasticity
    # Create model training pipeline
    reg_ppln_ols = Pipeline([("estimator", CustomSKLLassoCV())])

    # Initialization
    # Model Results
    model_results_final = pd.DataFrame(columns=[])  # Final model version

    # Cross-Validation Model Results
    model_results_cv = pd.DataFrame(columns=[])

    # Baseline Sales
    glbl_base_df = pd.DataFrame(columns=[])
    glbl_opt_base_df = pd.DataFrame(columns=[])

    # Cannibalisation Sales
    glbl_cannibal_df = pd.DataFrame(columns=[])
    glbl_opt_cannibal_df = pd.DataFrame(columns=[])

    # List of ppgs with just intercept turning out
    ppg_wt_intercept = []

    cols_in_model_df = [
        "PPG_Cat",
        "PPG_MFG",
        "PPG_Item_No",
        "PPG_Description",
        "Date",  # "wk_sold_qty_byppg_log",
        "wk_sold_median_base_price_byppg_log",
        "tpr_discount_byppg",
        "ACV_Feat_Only",
        "ACV_Disp_Only",
        "ACV_Feat_Disp",
        "ACV_Selling",
        "flag_qtr2",
        "flag_qtr3",
        "flag_qtr4",
        "category_trend",
        "tpr_discount_byppg_lag1",
        "tpr_discount_byppg_lag2",
        "monthno",
        "Missing_data_flag",
    ]
    cols_in_base_df = [
        "PPG_Cat",
        "PPG_MFG",
        "PPG_Item_No",
        "PPG_Description",
        "Date",  # "wk_sold_qty_byppg",
        "wk_sold_avg_price_byppg",
        "median_baseprice",
        "Final_baseprice",
        "Estimated_baseprice",
        "tpr_discount_byppg",
        "ACV_Feat_Only",
        "ACV_Disp_Only",
        "ACV_Feat_Disp",
        "ACV_Selling",
        "median_acv_selling",
        "flag_qtr2",
        "flag_qtr3",
        "flag_qtr4",
        "category_trend",
        "tpr_discount_byppg_lag1",
        "tpr_discount_byppg_lag2",
        "monthno",
        "Missing_data_flag",
    ]

    for i, ppg in enumerate(ppg_list_to_model):

        try:
            print("{} Selected PPG: {}".format(i + 1, ppg))

            # Subset data
            slct_trans_X = trans_X.loc[trans_X["PPG_Item_No"] == ppg].reset_index(
                drop=True
            )
            slct_trans_y = trans_y.loc[trans_y["PPG_Item_No"] == ppg].reset_index(
                drop=True
            )

            slct_opt_trans_X = opt_trans_X.loc[
                opt_trans_X["PPG_Item_No"] == ppg
            ].reset_index(drop=True)
            slct_opt_trans_y = opt_trans_y.loc[
                opt_trans_y["PPG_Item_No"] == ppg
            ].reset_index(drop=True)

            ppg_tpr_df = slct_trans_X[["Date", "tpr_discount_byppg"]].merge(
                slct_trans_y[["Date", "wk_sold_qty_byppg_log"]], how="left", on="Date"
            )
            ppg_tpr_df = ppg_tpr_df.rename(
                columns={
                    "wk_sold_qty_byppg_log": "DV",
                    "tpr_discount_byppg": "tpr_temp",
                }
            )
            ppg_tpr_df = ppg_tpr_df.set_index("Date")

            # Add new features
            # Competitor EDLP & TPR
            comp_feat_trans.fit(slct_trans_X)
            slct_trans_X = comp_feat_trans.transform(slct_trans_X)
            slct_trans_y = (
                slct_trans_y.copy()
                .filter_on("Missing_data_flag == 0", complement=False)
                .reset_index(drop=True)
                .select_columns(["wk_sold_qty_byppg_log"])
                .rename_column("wk_sold_qty_byppg_log", "DV")
            )["DV"]

            opt_comp_feat_trans.fit(slct_opt_trans_X)
            slct_opt_trans_X = comp_feat_trans.transform(slct_opt_trans_X)
            slct_opt_trans_y = (
                slct_opt_trans_y.copy()
                .filter_on("Missing_data_flag == 0", complement=False)
                .reset_index(drop=True)
                .select_columns(["wk_sold_qty_byppg_log"])
                .rename_column("wk_sold_qty_byppg_log", "DV")
            )["DV"]

            # Feature Selection
            slct_features = select_features(
                ppg, slct_trans_X, slct_trans_y, reg_ppln_ols
            )
            slct_trans_X = slct_trans_X.loc[:, slct_features]
            slct_opt_trans_X = slct_opt_trans_X.loc[:, slct_features]

            # Build model with shortlisted features
            seed = 123
            random.seed(seed)
            X = slct_trans_X.drop(
                columns=["Date", "PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
            )
            y = slct_trans_y.to_numpy()
            opt_X = slct_opt_trans_X.drop(
                columns=["Date", "PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
            )
            opt_y = slct_opt_trans_y.to_numpy()

            reg_ppln_ols.fit(X, y)

            # Model coefficients
            model = reg_ppln_ols["estimator"]
            model_coef = pd.DataFrame(
                {
                    "model_coefficient_name": X.columns.to_list(),
                    "model_coefficient_value": model.coef_,
                }
            )
            model_coef = model_coef.append(
                {
                    "model_coefficient_name": "(Intercept)",
                    "model_coefficient_value": model.intercept_,
                },
                ignore_index=True,
            )
            model_coef = model_coef[model_coef["model_coefficient_value"].abs() > 0]

            # Model performance metric
            train_set_prediction = pd.DataFrame(
                {"PPG_Item_No": [ppg] * len(X), "Prediction": np.exp(model.predict(X))}
            )
            train_set_rsq = r2_score((y), np.log(train_set_prediction["Prediction"]))
            train_set_MAPE = mean_absolute_error(
                np.array([1] * len(y)), train_set_prediction["Prediction"] / np.exp(y)
            )
            cv_mse_mean, cv_mse_sd = model.get_cv_metrics()

            # Save the model results
            temp_4 = slct_trans_X[
                ["PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
            ].drop_duplicates()  # pd.DataFrame({"PPG_Item_No": [ppg]})
            temp_4["model_RSq"] = train_set_rsq
            temp_4["TrainMAPE"] = train_set_MAPE
            temp_4["model_CVErrorMean"] = cv_mse_mean
            temp_4["model_CVErrorSD"] = cv_mse_sd

            temp_4["dummy"] = 1
            model_coef["dummy"] = 1
            temp_5 = temp_4.merge(model_coef, how="left", on="dummy")
            temp_5 = temp_5.drop(columns="dummy")
            model_results_final = model_results_final.append(temp_5, ignore_index=True)

            # Base volume estimation
            X_wt_dt = pd.concat((X, slct_trans_X["Date"]), axis="columns").set_index(
                "Date"
            )  # Temp Fix
            base_df = (
                trans_X.copy()
                .query("PPG_Item_No==@ppg")
                .reset_index(drop=True)
                .select_columns(cols_in_base_df)
                .tpr_acv_smoothing()
                .edlp_acv_smoothing()
                .filter_on("Missing_data_flag==0")
                .remove_columns(["Missing_data_flag"])
                .estimate_base_volume(ppg, model, X_wt_dt, slct_trans_X, trans_X)
            )
            glbl_base_df = glbl_base_df.append(base_df, ignore_index=True)

            opt_X_wt_dt = pd.concat(
                (opt_X, slct_opt_trans_X["Date"]), axis="columns"
            ).set_index(
                "Date"
            )  # Temp Fix
            opt_base_df = (
                opt_trans_X.copy()
                .query("PPG_Item_No==@ppg")
                .reset_index(drop=True)
                .select_columns(cols_in_base_df)
                .tpr_acv_smoothing()
                .edlp_acv_smoothing()
                .filter_on("Missing_data_flag==0")
                .remove_columns(["Missing_data_flag"])
                .estimate_base_volume(
                    ppg, model, opt_X_wt_dt, slct_opt_trans_X, opt_trans_X
                )
            )
            glbl_opt_base_df = glbl_opt_base_df.append(opt_base_df, ignore_index=True)

            # Compute Cannibalisation Dollar Sales to exclude it from gross lift
            cannibal_df = cannibalisation_module(
                ppg, model, X_wt_dt, model_coef, ppg_list_to_model, trans_X
            )
            glbl_cannibal_df = glbl_cannibal_df.append(cannibal_df, ignore_index=True)

            opt_cannibal_df = cannibalisation_module(
                ppg, model, opt_X_wt_dt, model_coef, ppg_list_to_model, opt_trans_X
            )
            glbl_opt_cannibal_df = glbl_opt_cannibal_df.append(
                opt_cannibal_df, ignore_index=True
            )

            # Cross Validation
            temp_model_results_cv = cross_validation(
                ppg, X_wt_dt, slct_trans_X, ppg_tpr_df
            )
            model_results_cv = model_results_cv.append(
                temp_model_results_cv, ignore_index=True
            )

        except Exception:
            print("Exception Occured for {}".format(ppg))
            continue

    # Update PPG summary
    ppg_summary_df["model_RSq"] = ppg_summary_df.apply(
        lambda x: model_results_final.loc[
            model_results_final["PPG_Item_No"] == x["PPG_Item_No"], "model_RSq"
        ].to_list()[0]
        if x["PPG_Item_No"] in model_results_final["PPG_Item_No"].to_list()
        else x["model_RSq"],
        axis=1,
    )
    ppg_summary_df["TrainMAPE"] = ppg_summary_df.apply(
        lambda x: model_results_final.loc[
            model_results_final["PPG_Item_No"] == x["PPG_Item_No"], "TrainMAPE"
        ].to_list()[0]
        if x["PPG_Item_No"] in model_results_final["PPG_Item_No"].to_list()
        else x["TrainMAPE"],
        axis=1,
    )
    ppg_summary_df["Model_flag"] = ppg_summary_df.apply(
        lambda x: 1
        if (x["PPG_Item_No"] in trans_X["PPG_Item_No"])
        and (x["Reason"] != "PPGs Considered for Modelling")
        else x["Model_flag"],
        axis=1,
    )

    # Tag output files
    model_df = trans_X.merge(
        trans_y[["PPG_Item_No", "Date", "wk_sold_qty_byppg", "wk_sold_qty_byppg_log"]],
        how="left",
        on=["PPG_Item_No", "Date"],
    )
    opt_model_df = opt_trans_X.merge(
        opt_trans_y[
            ["PPG_Item_No", "Date", "wk_sold_qty_byppg", "wk_sold_qty_byppg_log"]
        ],
        how="left",
        on=["PPG_Item_No", "Date"],
    )

    glbl_base_df = glbl_base_df.merge(
        trans_y[["PPG_Item_No", "Date", "wk_sold_qty_byppg"]],
        how="left",
        on=["PPG_Item_No", "Date"],
    )
    glbl_opt_base_df = glbl_opt_base_df.merge(
        opt_trans_y[["PPG_Item_No", "Date", "wk_sold_qty_byppg"]],
        how="left",
        on=["PPG_Item_No", "Date"],
    )
    glbl_base_df["Model_flag"] = 1
    glbl_opt_base_df["Model_flag"] = 1

    glbl_cannibal_df["Model_flag"] = 1
    glbl_opt_cannibal_df["Model_flag"] = 1

    model_results_final["Model_flag"] = 1
    model_results_cv["Model_flag"] = 1

    # Save model results
    dataset.save_dataset(
        context,
        ppg_summary_df,
        "output/ppg_summary",
        retailer=slct_retailer,
        category=slct_category,
        model_variant="fnl",
    )

    model_type = "1yr"
    dataset.save_dataset(
        context,
        model_results_final,
        "output/model_results",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=model_type,
    )

    dataset.save_dataset(
        context,
        model_df,
        "output/model_data",
        retailer=slct_retailer,
        category=slct_category,
        data_type="elasticity",
        model_variant=model_type,
    )
    dataset.save_dataset(
        context,
        opt_model_df,
        "output/model_data",
        retailer=slct_retailer,
        category=slct_category,
        data_type="optimizer",
        model_variant=model_type,
    )

    dataset.save_dataset(
        context,
        glbl_base_df,
        "output/base_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="elasticity",
        model_variant=model_type,
    )
    dataset.save_dataset(
        context,
        glbl_opt_base_df,
        "output/base_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="optimizer",
        model_variant=model_type,
    )

    dataset.save_dataset(
        context,
        glbl_cannibal_df,
        "output/cannibal_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="elasticity",
        model_variant=model_type,
    )
    dataset.save_dataset(
        context,
        glbl_opt_cannibal_df,
        "output/cannibal_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="optimizer",
        model_variant=model_type,
    )


@register_processor("model-gen", "model-elasticity-mixed-effects-spl-case")
def model_elasticity_by_mixed_effects_regression_spl_case(context, params):
    """Train elasticity model for PPGs with <1 year of data using Mixed effects regression."""
    # Initialization
    artifacts_folder = op.join(get_package_path(), "artifacts")

    slct_retailer = params["slct_retailer"]
    slct_category = params["slct_category"]
    slct_vendor = params["slct_vendor"]

    start_date = params["start_date"]
    end_date = params["end_date"]

    # Load datasets
    ppg_sales_df = dataset.load_dataset(
        context, "processed/sales", retailer=slct_retailer, category=slct_category
    )
    train_X = dataset.load_dataset(
        context, "train/sales/features", retailer=slct_retailer, category=slct_category
    )
    train_y = dataset.load_dataset(
        context, "train/sales/target", retailer=slct_retailer, category=slct_category
    )

    time_stamp = "_".join([start_date, "to", end_date])
    ppg_summary_df = dataset.load_dataset(
        context,
        "output/ppg_summary",
        retailer=slct_retailer,
        category=slct_category,
        model_variant="fnl",
    )

    filtered_ppg_sales_df = ppg_sales_df.query("Date>=@start_date & Date<@end_date")
    train_X = train_X.query("Date>=@start_date & Date<@end_date")
    train_y = train_y.query("Date>=@start_date & Date<@end_date")

    # PPG Selection
    # Initialization
    slct_ppg_sales_df = filtered_ppg_sales_df.copy()

    # Average Dollar Sales
    low_revenue_ppgs = ppg_summary_df.loc[
        ppg_summary_df["Reason"] == "Low Revenue", "PPG_Item_No"
    ].to_list()
    slct_ppg_sales_df = slct_ppg_sales_df[
        ~slct_ppg_sales_df["PPG_Item_No"].isin(low_revenue_ppgs)
    ]

    # Data Availability (Remove PPGs with 1-2 years data)
    slct_ppg_sales_df = slct_ppg_sales_df[
        slct_ppg_sales_df["PPG_Item_No"].isin(
            ppg_summary_df.loc[ppg_summary_df["Model_flag"] != 1, "PPG_Item_No"]
        )
    ]
    slct_ppg_sales_df = slct_ppg_sales_df[slct_ppg_sales_df["ACV_Selling"] > 0]

    # Subset data
    train_X = train_X[train_X["PPG_Item_No"].isin(slct_ppg_sales_df["PPG_Item_No"])]
    train_y = train_y[train_y["PPG_Item_No"].isin(slct_ppg_sales_df["PPG_Item_No"])]

    # List of PPGs to model
    ppg_list_to_model = slct_ppg_sales_df.loc[
        (slct_ppg_sales_df["PPG_MFG"] == slct_vendor)
        & (~slct_ppg_sales_df["PPG_Item_No"].str.contains("ROM", regex=False))
        & (
            ~slct_ppg_sales_df["PPG_Item_No"].isin(
                ppg_summary_df.loc[
                    ppg_summary_df["Reason"].isin(
                        ["PPGs Considered for Modelling", "Low Revenue"]
                    ),
                    "PPG_Item_No",
                ]
            )
        ),
        "PPG_Item_No",
    ].unique()  # slct_ppg_sales_df["PPG_Retailer"]!="ROM"

    # Load pre-trained feature pipelines and other artifacts
    own_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder,
                "own_effects_features_spl_case_{}.joblib".format(time_stamp),
            )
        )
    )
    opt_own_feat_trans = load_pipeline(
        op.abspath(
            op.join(
                artifacts_folder,
                "opt_own_effects_features_spl_case_{}.joblib".format(time_stamp),
            )
        )
    )

    # Price Elasticity
    own_feat_trans.fit(train_X)
    trans_X = own_feat_trans.transform(train_X)
    trans_X = trans_X.merge(
        ppg_summary_df[["PPG_Item_No", "Reason"]], how="left", on="PPG_Item_No"
    )
    trans_X["Model_flag"] = trans_X["Reason"].apply(
        lambda x: 2 if x == "PPGs Considered for Modelling" else 0
    )
    trans_X = trans_X[~trans_X["tpr_discount_byppg"].isna()]

    trans_y = (
        train_y.copy()
        .merge(
            trans_X.loc[:, ["PPG_Item_No", "Date", "Missing_data_flag"]],
            how="right",
            on=["PPG_Item_No", "Date"],
        )
        .assign(
            wk_sold_qty_byppg=lambda x: x.apply(
                lambda y: 0 if y["Missing_data_flag"] == 1 else y["wk_sold_qty_byppg"],
                axis=1,
            )
        )
        .transform_columns(
            ["wk_sold_qty_byppg"],
            np.log1p,
            new_column_names={"wk_sold_qty_byppg": "wk_sold_qty_byppg_log"},
        )
        .sort_values(by=["PPG_Item_No", "Date"], ignore_index=True)
    )

    # Optimizer
    opt_own_feat_trans.fit(train_X)
    opt_trans_X = opt_own_feat_trans.transform(train_X)
    opt_trans_X = opt_trans_X.merge(
        ppg_summary_df[["PPG_Item_No", "Reason"]], how="left", on="PPG_Item_No"
    )
    opt_trans_X["Model_flag"] = opt_trans_X["Reason"].apply(
        lambda x: 2 if x == "PPGs Considered for Modelling" else 0
    )
    opt_trans_X = opt_trans_X[~opt_trans_X["tpr_discount_byppg"].isna()]

    opt_trans_y = (
        train_y.copy()
        .merge(
            opt_trans_X.loc[:, ["PPG_Item_No", "Date", "Missing_data_flag"]],
            how="right",
            on=["PPG_Item_No", "Date"],
        )
        .assign(
            wk_sold_qty_byppg=lambda x: x.apply(
                lambda y: 0 if y["Missing_data_flag"] == 1 else y["wk_sold_qty_byppg"],
                axis=1,
            )
        )
        .transform_columns(
            ["wk_sold_qty_byppg"],
            np.log1p,
            new_column_names={"wk_sold_qty_byppg": "wk_sold_qty_byppg_log"},
        )
        .sort_values(by=["PPG_Item_No", "Date"], ignore_index=True)
    )

    # Extract Pack Size
    trans_X["pack_size"] = trans_X["PPG_Description"].apply(
        lambda x: extract_pack_size(x)
    )

    # Select PPGs for Pooling
    # 2 year PPGs to be considered pooling
    PPG = trans_X.loc[
        (trans_X["PPG_MFG"] == slct_vendor)
        & (trans_X["Model_flag"] == 2)
        & (~trans_X["PPG_Item_No"].str.contains("ROM", regex=False)),
        "PPG_Item_No",
    ].unique()  # model_df_1["PPG_Retailer"]!="ROM"

    # Keep data of PPGs to be modelled + PPGs for pooling
    trans_X = trans_X[
        (trans_X["PPG_MFG"] == slct_vendor)
        & (~trans_X["PPG_Item_No"].str.contains("ROM", regex=False))
        & (trans_X["Reason"] != "Low Revenue")
    ]
    trans_y = trans_y[trans_y["PPG_Item_No"].isin(trans_X["PPG_Item_No"])]

    # Model Elasticity
    # Create model training pipeline
    linear_mixed_effects = Pipeline([("estimator", SKLStatsmodelMixedLM())])
    bayesian_mixed_effects = Pipeline([("estimator", SKLBayesian())])

    # Initialization
    # Model Results
    model_results_final = pd.DataFrame(columns=[])  # Final model version

    # Baseline Sales
    glbl_base_df = pd.DataFrame(columns=[])
    glbl_opt_base_df = pd.DataFrame(columns=[])

    # Cannibalisation Sales
    glbl_cannibal_df = pd.DataFrame(columns=[])
    glbl_opt_cannibal_df = pd.DataFrame(columns=[])

    # Select columns in model df
    cols_in_model_df = [
        "PPG_Cat",
        "PPG_MFG",
        "PPG_Item_No",
        "PPG_Description",
        "Date",  # "wk_sold_qty_byppg_log",
        "wk_sold_median_base_price_byppg_log",
        "tpr_discount_byppg",
        "ACV_Feat_Only",
        "ACV_Disp_Only",
        "ACV_Feat_Disp",
        "ACV_Selling",
        "flag_qtr2",
        "flag_qtr3",
        "flag_qtr4",
        "category_trend",
        "tpr_discount_byppg_lag1",
        "tpr_discount_byppg_lag2",
        "monthno",
        "Missing_data_flag",
    ]

    # Select columns in base df
    cols_in_base_df = [
        "PPG_Cat",
        "PPG_MFG",
        "PPG_Item_No",
        "PPG_Description",
        "Date",  # "wk_sold_qty_byppg",
        "wk_sold_avg_price_byppg",
        "median_baseprice",
        "Final_baseprice",
        "Estimated_baseprice",
        "tpr_discount_byppg",
        "ACV_Feat_Only",
        "ACV_Disp_Only",
        "ACV_Feat_Disp",
        "ACV_Selling",
        "median_acv_selling",
        "flag_qtr2",
        "flag_qtr3",
        "flag_qtr4",
        "category_trend",
        "tpr_discount_byppg_lag1",
        "tpr_discount_byppg_lag2",
        "monthno",
        "Missing_data_flag",
    ]

    for i, ppg in enumerate(ppg_list_to_model):

        try:
            print("{} Selected PPG: {}".format(i + 1, ppg))

            # Subset data
            slct_trans_X = trans_X.loc[trans_X["PPG_Item_No"] == ppg].reset_index(
                drop=True
            )
            slct_opt_trans_X = opt_trans_X.loc[
                opt_trans_X["PPG_Item_No"] == ppg
            ].reset_index(drop=True)

            # Prepare data
            # Price elasticity
            slct_trans_X = (
                slct_trans_X.copy()
                .append_similar_ppg_data(
                    ppg,
                    "BRAND GROUP(C)",
                    "pack_size",
                    "wk_sold_avg_price_byppg",
                    PPG,
                    trans_X,
                )
                .select_columns(cols_in_model_df + ["wk_sold_avg_price_byppg"])
                .filter_on("Missing_data_flag==0")
                .remove_zero_acv_weeks()
                .set_features_wt_low_variance_to_zero()
                .remove_columns(["Missing_data_flag", "wk_sold_avg_price_byppg"])
                .impute_missing_values()
                .reset_index(drop=True)
            )
            slct_trans_y = (
                slct_trans_X.copy()
                .select_columns(["PPG_Item_No", "Date"])
                .merge(trans_y, how="left", on=["PPG_Item_No", "Date"])
                .rename_columns({"wk_sold_qty_byppg_log": "DV"})
            )

            # Optimizer
            slct_opt_trans_X = (
                slct_opt_trans_X.copy()
                .select_columns(cols_in_model_df + ["wk_sold_avg_price_byppg"])
                .filter_on("Missing_data_flag==0")
                .remove_zero_acv_weeks()
                .set_features_wt_low_variance_to_zero()
                .remove_columns(["Missing_data_flag", "wk_sold_avg_price_byppg"])
                .impute_missing_values()
                .reset_index(drop=True)
            )
            slct_opt_trans_y = (
                slct_opt_trans_X.copy()
                .select_columns(["PPG_Item_No", "Date"])
                .merge(opt_trans_y, how="left", on=["PPG_Item_No", "Date"])
                .rename_columns({"wk_sold_qty_byppg_log": "DV"})
            )

            # If no similiar PPGs exist, skip modelling
            if len(slct_trans_X) <= len(
                trans_X.loc[
                    (trans_X["PPG_Item_No"] == ppg)
                    & (trans_X["Missing_data_flag"] == 0)
                ]
            ):
                continue

            # Linear mixed effects model
            X = slct_trans_X.drop(
                columns=["Date", "PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
            )
            y = slct_trans_y[["DV"]]
            opt_X = slct_opt_trans_X.drop(
                columns=["Date", "PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
            )
            opt_y = slct_opt_trans_y[["DV"]]

            # Remove linear dependent columns
            qr_matrix = np.linalg.qr(X.to_numpy())
            column_names = X.loc[
                :, np.abs(np.diag(qr_matrix[1])) >= 1e-10
            ].columns  # TODO - check it is dropping important cols
            X = X.loc[:, column_names]

            # Build model
            group_var = "PPG_Item_No"
            linear_mixed_effects = Pipeline([("estimator", SKLStatsmodelMixedLM())])
            linear_mixed_effects.fit(
                pd.concat((X, slct_trans_X["PPG_Item_No"]), axis="columns"), y
            )
            fe_params, re_params = linear_mixed_effects["estimator"].get_params()

            # Bayesian mixed effects model
            # Fixed effects prior - mean and std. deviation kept same
            fe_model_coef_prior = pd.DataFrame(
                {
                    "model_coefficient_name": fe_params.index,
                    "model_coefficient_value": fe_params.to_numpy(),
                }
            )
            fe_model_coef_prior["model_coefficient_std"] = fe_model_coef_prior[
                "model_coefficient_value"
            ]
            fe_model_coef_prior["distribution"] = "Normal"
            fe_model_coef_prior["bijector"] = "Exp"

            # Random effects prior - mu's alpha and beta kept same - sigma's alpha and beta set 0 and 2 resp.
            re_model_coef_prior = pd.DataFrame(
                {
                    "model_coefficient_name": re_params.groupby(by=re_params.index)
                    .mean()
                    .index.to_list(),
                    "group_variable": [group_var] * re_params.index.nunique(),
                    "mean_mdl_coef_est": re_params.groupby(by=re_params.index)
                    .mean()
                    .to_numpy(),
                    "std_mdl_coef_est": re_params.groupby(by=re_params.index)
                    .std()
                    .to_numpy(),
                }
            )
            re_model_coef_prior.loc[
                re_model_coef_prior["model_coefficient_name"] == "Group",
                "model_coefficient_name",
            ] = ("intercept" + "_" + group_var)
            re_model_coef_prior["mu_dist"] = "Normal"
            re_model_coef_prior["mu_bijector"] = "Exp"
            re_model_coef_prior["mean_mdl_coef_std_err"] = 0
            re_model_coef_prior["std_mdl_coef_std_err"] = 2
            re_model_coef_prior["sigma_dist"] = "HalfCauchy"
            re_model_coef_prior["sigma_bijector"] = "Identity"

            # Reverse sign for columns with negative coefficient estimate (Log-normal/Gamma prior)
            reverse = [
                "wk_sold_median_base_price_byppg_log",
                "tpr_discount_byppg_lag1",
                "tpr_discount_byppg_lag2",
            ]
            flag_qtr = [col for col in X.columns.to_list() if "flag_qtr" in col]
            unbounded = flag_qtr + ["monthno", "category_trend"]
            reverse = (
                reverse
                + fe_model_coef_prior.loc[
                    (fe_model_coef_prior["model_coefficient_name"].isin(unbounded))
                    & (fe_model_coef_prior["model_coefficient_value"] < 0),
                    "model_coefficient_name",
                ].to_list()
            )
            reverse = (
                reverse
                + re_model_coef_prior.loc[
                    (re_model_coef_prior["model_coefficient_name"].isin(unbounded))
                    & (re_model_coef_prior["mean_mdl_coef_est"] < 0),
                    "model_coefficient_name",
                ].to_list()
            )

            fe_model_coef_prior["model_coefficient_value"] = fe_model_coef_prior[
                "model_coefficient_value"
            ].abs()
            fe_model_coef_prior["model_coefficient_std"] = fe_model_coef_prior[
                "model_coefficient_std"
            ].abs()
            re_model_coef_prior["mean_mdl_coef_est"] = re_model_coef_prior[
                "mean_mdl_coef_est"
            ].abs()
            re_model_coef_prior["std_mdl_coef_est"] = re_model_coef_prior[
                "std_mdl_coef_est"
            ].abs()

            # Build model
            mlflow.end_run()  # Nested run turned off, so it is needed
            bayes_model = SKLBayesian(
                re_prior_df=re_model_coef_prior, fe_prior_df=fe_model_coef_prior
            )
            bayes_model.fit(
                pd.concat((X, slct_trans_X["PPG_Item_No"]), axis="columns"),
                y,
                reverse_column_names=reverse,
            )
            tmp_model_coef = bayes_model.get_params_in_dataframe()

            # Model coefficients
            model_coef_prior = (
                re_model_coef_prior.copy()
                .rename_column("mean_mdl_coef_est", "model_coefficient_value")
                .select_columns(["model_coefficient_name", "model_coefficient_value"])
                # Append fixed effects variable
                .append(
                    fe_model_coef_prior[
                        ["model_coefficient_name", "model_coefficient_value"]
                    ],
                    ignore_index=True,
                )
                # Align variable name to generic format
                .transform_column(
                    column_name="model_coefficient_name",
                    function=lambda x: x if x == "intercept" else re.sub("_", "", x),
                    dest_column_name="model_coefficient_name_adj",
                    elementwise=True,
                )
            )

            model_coef = (
                tmp_model_coef.copy()
                .rename_columns(
                    {
                        "variable": "model_coefficient_name_adj",
                        "estimate": "model_coefficient_value",
                    }
                )
                # Retain selected PPG variables
                .filter_string(
                    "model_coefficient_name_adj",
                    search_string="|".join(PPG),
                    complement=True,
                )
                # Align variable name to generic format
                .transform_column(
                    column_name="model_coefficient_name_adj",
                    function=lambda x: re.sub(
                        "_PPGItemNo\\[\\'" + ppg + "\\'\\]", "", x
                    ),
                    elementwise=True,
                )
                .transform_column(
                    column_name="model_coefficient_name_adj",
                    function=lambda x: re.sub("fixed_slope_|slope_", "", x),
                    elementwise=True,
                )
                # Get original variable name
                .merge(
                    model_coef_prior[
                        ["model_coefficient_name", "model_coefficient_name_adj"]
                    ],
                    how="left",
                    on="model_coefficient_name_adj",
                )
                .assign(
                    model_coefficient_name=lambda x: x.apply(
                        lambda y: "(Intercept)"
                        if y["model_coefficient_name_adj"] == "intercept"
                        else y["model_coefficient_name"],
                        axis=1,
                    )
                )
                # Reverse variable sign
                .select_columns(["model_coefficient_name", "model_coefficient_value"])
                .assign(
                    model_coefficient_value=lambda x: x.apply(
                        lambda y: (-1) * y["model_coefficient_value"]
                        if y["model_coefficient_name"]
                        in bayes_model.reverse_feature_names_
                        else y["model_coefficient_value"],
                        axis=1,
                    )
                )
            )

            # Model performance metric
            X = X[slct_trans_X["PPG_Item_No"] == ppg].reset_index(drop=True)
            y = y.loc[slct_trans_y["PPG_Item_No"] == ppg, "DV"].reset_index(drop=True)
            slct_trans_X = slct_trans_X[slct_trans_X["PPG_Item_No"] == ppg].reset_index(
                drop=True
            )
            X = pd.concat((X, slct_trans_X["PPG_Item_No"]), axis="columns")

            opt_X = opt_X[slct_opt_trans_X["PPG_Item_No"] == ppg].reset_index(drop=True)
            opt_y = opt_y.loc[slct_opt_trans_y["PPG_Item_No"] == ppg, "DV"].reset_index(
                drop=True
            )
            slct_opt_trans_X = slct_opt_trans_X[
                slct_opt_trans_X["PPG_Item_No"] == ppg
            ].reset_index(drop=True)
            opt_X = pd.concat((opt_X, slct_opt_trans_X["PPG_Item_No"]), axis="columns")

            train_set_prediction = pd.DataFrame(
                {
                    "PPG_Item_No": [ppg] * len(X),
                    "Prediction": np.exp(bayes_model.predict(X)),
                }
            )
            train_set_rsq = r2_score((y), np.log(train_set_prediction["Prediction"]))
            train_set_MAPE = mean_absolute_error(
                np.array([1] * len(y)), train_set_prediction["Prediction"] / np.exp(y)
            )

            # Save the model results
            temp_4 = pd.DataFrame({"PPG_Item_No": [ppg]})
            temp_4["model_RSq"] = train_set_rsq
            temp_4["TrainMAPE"] = train_set_MAPE
            temp_4["dummy"] = 1
            model_coef["dummy"] = 1
            temp_5 = temp_4.merge(model_coef, how="left", on="dummy")
            temp_5 = temp_5.drop(columns="dummy")
            model_results_final = model_results_final.append(temp_5, ignore_index=True)

            # Base volume estimation
            X_wt_dt = pd.concat((X, slct_trans_X["Date"]), axis="columns").set_index(
                "Date"
            )  # Temp Fix
            base_df = (
                trans_X.copy()
                .query("PPG_Item_No==@ppg")
                .reset_index(drop=True)
                .select_columns(cols_in_base_df)
                .tpr_acv_smoothing()
                .edlp_acv_smoothing()
                .filter_on("Missing_data_flag==0")
                .remove_columns(["Missing_data_flag"])
                .estimate_base_volume(ppg, bayes_model, X_wt_dt, slct_trans_X, trans_X)
            )
            glbl_base_df = glbl_base_df.append(base_df, ignore_index=True)

            opt_X_wt_dt = pd.concat(
                (opt_X, slct_opt_trans_X["Date"]), axis="columns"
            ).set_index(
                "Date"
            )  # Temp Fix
            opt_base_df = (
                opt_trans_X.copy()
                .query("PPG_Item_No==@ppg")
                .reset_index(drop=True)
                .select_columns(cols_in_base_df)
                .tpr_acv_smoothing()
                .edlp_acv_smoothing()
                .filter_on("Missing_data_flag==0")
                .remove_columns(["Missing_data_flag"])
                .estimate_base_volume(
                    ppg, bayes_model, opt_X_wt_dt, slct_opt_trans_X, opt_trans_X
                )
            )
            glbl_opt_base_df = glbl_opt_base_df.append(opt_base_df, ignore_index=True)

            # Compute Cannibalisation Dollar Sales to exclude it from gross lift
            cannibal_df = cannibalisation_module(
                ppg, bayes_model, X_wt_dt, model_coef, ppg_list_to_model, trans_X
            )
            glbl_cannibal_df = glbl_cannibal_df.append(cannibal_df, ignore_index=True)

            opt_cannibal_df = cannibalisation_module(
                ppg,
                bayes_model,
                opt_X_wt_dt,
                model_coef,
                ppg_list_to_model,
                opt_trans_X,
            )
            glbl_opt_cannibal_df = glbl_opt_cannibal_df.append(
                opt_cannibal_df, ignore_index=True
            )

        except Exception:
            print("Exception Occured for {}".format(ppg))
            continue

    # Update PPG summary
    ppg_summary_df["model_RSq"] = ppg_summary_df.apply(
        lambda x: model_results_final.loc[
            model_results_final["PPG_Item_No"] == x["PPG_Item_No"], "model_RSq"
        ].to_list()[0]
        if x["PPG_Item_No"] in model_results_final["PPG_Item_No"]
        else x["model_RSq"],
        axis=1,
    )
    ppg_summary_df["TrainMAPE"] = ppg_summary_df.apply(
        lambda x: model_results_final.loc[
            model_results_final["PPG_Item_No"] == x["PPG_Item_No"], "TrainMAPE"
        ].to_list()[0]
        if x["PPG_Item_No"] in model_results_final["PPG_Item_No"]
        else x["TrainMAPE"],
        axis=1,
    )
    ppg_summary_df["Model_flag"] = ppg_summary_df.apply(
        lambda x: 0
        if (x["PPG_Item_No"] in trans_X["PPG_Item_No"])
        and (x["Reason"] != "PPGs Considered for Modelling")
        else x["Model_flag"],
        axis=1,
    )

    # Tag output files
    model_df = trans_X.merge(
        trans_y[["PPG_Item_No", "Date", "wk_sold_qty_byppg", "wk_sold_qty_byppg_log"]],
        how="left",
        on=["PPG_Item_No", "Date"],
    )
    opt_model_df = opt_trans_X.merge(
        opt_trans_y[
            ["PPG_Item_No", "Date", "wk_sold_qty_byppg", "wk_sold_qty_byppg_log"]
        ],
        how="left",
        on=["PPG_Item_No", "Date"],
    )

    glbl_base_df = glbl_base_df.merge(
        trans_y[["PPG_Item_No", "Date", "wk_sold_qty_byppg"]],
        how="left",
        on=["PPG_Item_No", "Date"],
    )
    glbl_opt_base_df = glbl_opt_base_df.merge(
        opt_trans_y[["PPG_Item_No", "Date", "wk_sold_qty_byppg"]],
        how="left",
        on=["PPG_Item_No", "Date"],
    )
    glbl_base_df["Model_flag"] = 0
    glbl_opt_base_df["Model_flag"] = 0

    glbl_cannibal_df["Model_flag"] = 0
    glbl_opt_cannibal_df["Model_flag"] = 0

    model_results_final["Model_flag"] = 0

    # Save model results
    dataset.save_dataset(
        context,
        ppg_summary_df,
        "output/ppg_summary",
        retailer=slct_retailer,
        category=slct_category,
        model_variant="fnl",
    )

    model_type = "lt_1yr"
    dataset.save_dataset(
        context,
        model_results_final,
        "output/model_results",
        retailer=slct_retailer,
        category=slct_category,
        model_variant=model_type,
    )

    dataset.save_dataset(
        context,
        model_df,
        "output/model_data",
        retailer=slct_retailer,
        category=slct_category,
        data_type="elasticity",
        model_variant=model_type,
    )
    dataset.save_dataset(
        context,
        opt_model_df,
        "output/model_data",
        retailer=slct_retailer,
        category=slct_category,
        data_type="optimizer",
        model_variant=model_type,
    )

    dataset.save_dataset(
        context,
        glbl_base_df,
        "output/base_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="elasticity",
        model_variant=model_type,
    )
    dataset.save_dataset(
        context,
        glbl_opt_base_df,
        "output/base_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="optimizer",
        model_variant=model_type,
    )

    dataset.save_dataset(
        context,
        glbl_cannibal_df,
        "output/cannibal_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="elasticity",
        model_variant=model_type,
    )
    dataset.save_dataset(
        context,
        glbl_opt_cannibal_df,
        "output/cannibal_volume",
        retailer=slct_retailer,
        category=slct_category,
        data_type="optimizer",
        model_variant=model_type,
    )
