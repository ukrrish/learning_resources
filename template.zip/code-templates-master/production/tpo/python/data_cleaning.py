import numpy as np
import pandas as pd

from ta_lib.core import dataset
from ta_lib.core.api import register_processor

pd.options.mode.use_inf_as_na = True


@register_processor("data-cleaning", "sales")
def clean_sales_table(context, params):
    """Clean the ``SALES`` data table.

    The table containts the syndicated sales data and has information
    on the item purchased, description of the item, the price etc.
    """
    # Initialization
    slct_retailer = params["slct_retailer"]
    slct_retailer_mkt_desc = params["slct_retailer_mkt_desc"]
    slct_rom_mkt_desc = params["slct_rom_mkt_desc"]
    slct_mkt_desc = [slct_retailer_mkt_desc, slct_rom_mkt_desc]
    slct_category = params["slct_category"]
    slct_vendor = params["slct_vendor"]
    other_vendors = "Non" + "-" + slct_vendor
    brand_to_fill_na = params["brand_to_fill_na"]

    # Load datasets
    sales_df = dataset.load_dataset(context, "raw/sales")

    sales_df_clean = (
        sales_df.copy()
        # Subset selected retailer and category type
        .filter_column_isin(
            column_name="MarketDescription", iterable=slct_mkt_desc, complement=False,
        )
        .filter_column_isin(
            column_name="PPG_Category", iterable=[slct_category], complement=False,
        )
        # Type cast date column
        .to_datetime("WeekEndDt", format="%Y-%m-%d")
        # Rename columns
        .rename_column("WeekEndDt", "Date")
        .rename_column("Product_UPC", "Item Number")
        # Handle missing values
        .filter_column_isin(
            column_name="PPG_Category", iterable=["NA"], complement=True
        )
        .impute(column_name="VENDOR(C)", value=other_vendors)
        .impute(column_name="BRAND GROUP(C)", value=brand_to_fill_na)
        # Impute PPG name by Item
        .groupby_agg(
            by="ITEM",
            agg=lambda s: s.mode(dropna=True).to_list()[0]
            if len(s.dropna()) > 0
            else np.nan,
            agg_column_name="PPGName",
            new_column_name="PPGName_2",
        )
        .assign(
            PPGName=lambda x: x.apply(
                lambda y: y["PPGName_2"] if pd.isnull(y["PPGName"]) else y["PPGName"],
                axis=1,
            )
        )
        .remove_columns(column_names=["PPGName_2"])
        # Clean PPG name column
        .clean_ppg_name()
        # Remove SKU/UPC with zero sales
        .groupby_agg(
            by=["MarketDescription", "Item Number"],
            agg=np.nansum,
            agg_column_name="Dollars",
            new_column_name="agg_dollar_sales",
        )
        .filter_on("agg_dollar_sales > 0")
        .remove_columns(column_names=["agg_dollar_sales"])
        # Create new columns
        .transform_column(
            column_name="VENDOR(C)",
            function=lambda x: slct_vendor if x == slct_vendor else other_vendors,
            dest_column_name="PPG_MFG",
            elementwise=True,
        )
        .transform_column(
            column_name="MarketDescription",
            function=lambda x: "Retailer" if x == slct_retailer_mkt_desc else "ROM",
            dest_column_name="PPG_Retailer",
            elementwise=True,
        )
        .adjust_acv_columns()
        # Resolve more than one values for PPG columns
        .resolve_ppg_level_duplicates_values("PPG_MFG", "Dollars")
        .resolve_ppg_level_duplicates_values("BRAND GROUP(C)", "Dollars")
    )

    # PPG Mapping
    ppg_mapping = sales_df_clean[
        ["PPG_Item", "PPG_Description", "PPGName", "PPG_Category"]
    ].drop_duplicates()
    ppg_mapping["Retailer"] = slct_retailer

    dataset.save_dataset(
        context,
        sales_df_clean,
        "cleaned/sales",
        retailer=slct_retailer,
        category=slct_category,
    )

    dataset.save_dataset(
        context,
        ppg_mapping,
        "cleaned/ppg_mapping",
        retailer=slct_retailer,
        category=slct_category,
    )

    return sales_df_clean


@register_processor("data-cleaning", "acting-items")
def clean_acting_items_table(context, params):
    """Clean the ``ACTING ITEMS`` data table.

    The table contains the acting items for the items sold.
    """
    # Initialization
    slct_retailer = params["slct_retailer"]
    slct_category = params["slct_category"]

    # Load datasets
    acting_items_df = dataset.load_dataset(context, "raw/acting_items")
    sales_df_clean = dataset.load_dataset(
        context, "cleaned/sales", retailer=slct_retailer, category=slct_category
    )

    # Acting Item List Creation
    acting_items_df_clean = (
        acting_items_df.copy()
        # Keep categories present in sales data
        .filter_column_isin(
            column_name="Category",
            iterable=sales_df_clean["PPG_Category"].to_list(),
            complement=False,
        )
        .drop_duplicates()
        # Get cleaned PPG name from sales data
        .merge(
            sales_df_clean[["PPG_Item", "PPGName", "PPG_Category"]].drop_duplicates(),
            how="inner",
            left_on=["Base_PPG", "Category"],
            right_on=["PPGName", "PPG_Category"],
        )
        .rename_column("PPG_Item", "Base_Item")
        .merge(
            sales_df_clean[["PPG_Item", "PPGName", "PPG_Category"]].drop_duplicates(),
            how="inner",
            left_on=["Acting_PPG", "Category"],
            right_on=["PPGName", "PPG_Category"],
        )
        .rename_column("PPG_Item", "Acting_Item")
        .select_columns(["Base_Item", "Acting_Item"])
    )

    dataset.save_dataset(
        context,
        acting_items_df_clean,
        "cleaned/acting_items",
        retailer=slct_retailer,
        category=slct_category,
    )

    return acting_items_df_clean


@register_processor("data-cleaning", "aggegrate-sales")
def aggegrate_sales_table(context, params):
    """Aggegrate the ``SALES`` data table.

    The table is obtained by doing aggegration of the ``SALES`` table
    from ``UPC/SKU x Week`` to ``PPG x Week`` level.
    """
    # Initialization
    slct_retailer = params["slct_retailer"]
    slct_category = params["slct_category"]

    # Load datasets
    sales_df_clean = dataset.load_dataset(
        context, "cleaned/sales", retailer=slct_retailer, category=slct_category
    )

    # Sales data aggegration
    agg_sales_df = (
        sales_df_clean.copy()
        # Aggegrate UPC to PPG level
        .groupby(
            by=[
                "MarketDescription",
                "PPG_Retailer",
                "PPG_Category",
                "BRAND GROUP(C)",
                "PPG_MFG",
                "PPGName",
                "PPG_Item",
                "Date",
            ],
            as_index=False,
        )
        .agg(
            {
                "Dollars": np.sum,
                "Units": np.sum,
                "BaseDollars": np.sum,
                "BaseUnits": np.sum,
                "PCTACV": np.max,
                "PriceDecrOnlyPctACV": np.max,
                "FeatwoDispPctACV": np.max,
                "DispwoFeatPctACV": np.max,
                "FeatandDispPctACV": np.max,
            }
        )
        .rename(
            columns={
                "Dollars": "wk_sold_doll_byppg",
                "Units": "wk_sold_qty_byppg",
                "BaseDollars": "wk_sold_doll_base_byppg",
                "BaseUnits": "wk_sold_qty_base_byppg",
                "PCTACV": "ACV_Selling",
                "PriceDecrOnlyPctACV": "ACV_TPR_Only",
                "FeatwoDispPctACV": "ACV_Feat_Only",
                "DispwoFeatPctACV": "ACV_Disp_Only",
                "FeatandDispPctACV": "ACV_Feat_Disp",
            }
        )
        .transform_column(
            column_name="wk_sold_doll_byppg", function=lambda x: 0 if x < 0 else x
        )
        .transform_column(
            column_name="wk_sold_qty_byppg", function=lambda x: 0 if x < 0 else x
        )
        .transform_column(
            column_name="wk_sold_doll_base_byppg", function=lambda x: 0 if x < 0 else x
        )
        .transform_column(
            column_name="wk_sold_qty_base_byppg", function=lambda x: 0 if x < 0 else x
        )
        # Calculate Unit Price
        .assign(
            wk_avg_price_perunit_byppg=lambda x: x.apply(
                lambda y: np.nan
                if y["wk_sold_qty_byppg"] == 0
                else (y["wk_sold_doll_byppg"] / y["wk_sold_qty_byppg"]),
                axis=1,
            ),
            wk_base_price_perunit_byppg=lambda x: x.apply(
                lambda y: np.nan
                if y["wk_sold_qty_base_byppg"] == 0
                else (y["wk_sold_doll_base_byppg"] / y["wk_sold_qty_base_byppg"]),
                axis=1,
            ),
        )
        .transform_column(
            column_name="wk_avg_price_perunit_byppg",
            function=lambda x: np.nan if (x < 0 | np.isnan(x) | ~np.isfinite(x)) else x,
        )
        .transform_column(
            column_name="wk_base_price_perunit_byppg",
            function=lambda x: np.nan if (x < 0 | np.isnan(x) | ~np.isfinite(x)) else x,
        )
        # Remove invalidate data-points
        .query(
            "wk_sold_doll_byppg>=0 & wk_sold_doll_byppg.notnull() & wk_sold_qty_byppg>=0 & wk_sold_qty_byppg.notnull()",
            engine="python",
        )
        # Append Retailer/ROM to PPG Item
        .rename(
            columns={
                "PPG_Item": "PPG_Item_No",
                "PPGName": "PPG_Description",
                "PPG_Category": "PPG_Cat",
                "wk_avg_price_perunit_byppg": "wk_sold_avg_price_byppg",
            }
        )
        .assign(
            PPG_Item_No=lambda x: x.apply(
                lambda y: y["PPG_Item_No"] + "_" + y["PPG_Retailer"], axis=1
            )
        )
    )

    dataset.save_dataset(
        context,
        agg_sales_df,
        "processed/sales",
        retailer=slct_retailer,
        category=slct_category,
    )

    # Save features and target separate
    train_X = agg_sales_df.drop(columns=["wk_sold_qty_byppg"])
    train_y = agg_sales_df[["PPG_Item_No", "Date", "wk_sold_qty_byppg"]]

    dataset.save_dataset(
        context,
        train_X,
        "train/sales/features",
        retailer=slct_retailer,
        category=slct_category,
    )
    dataset.save_dataset(
        context,
        train_y,
        "train/sales/target",
        retailer=slct_retailer,
        category=slct_category,
    )
