import random
import re
from typing import List

import numpy as np
import pandas as pd
import pandas_flavor as pf
import statsmodels.api as sm
from sklearn import preprocessing
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import StratifiedKFold

from ta_lib.tpo.estimators import CustomSKLLassoCV


def handle_spl_cases_in_ppg_name(name, fmt_name):
    """Handle special cases in PPG name formatting.

    Parameters
    ----------
    name : str
        Unformatted PPG name
    fmt_name : str
        Formatted PPG name

    Returns
    -------
    str
    """
    if fmt_name == "" and name[0].isnumeric():
        final_name = re.split("\\s+", name)[0]
    elif fmt_name == "CT " and name[3].isnumeric():
        final_name = re.split("\\s+", name)[1]
    else:
        final_name = fmt_name

    return final_name


@pf.register_dataframe_method
def clean_ppg_name(df):
    """Clean ``PPG Name`` column."""
    # PPG Mapping File Creation
    ppg_mapping = (
        df[["PPGName", "PPG_Category"]]
        .drop_duplicates()
        .sort_values(by=["PPGName", "PPG_Category"])
    )
    ppg_mapping = ppg_mapping[
        ppg_mapping["PPGName"].notna() & ppg_mapping["PPG_Category"].notna()
    ]

    if ppg_mapping.shape[0] > 0:
        ppg_mapping["PPG_ID"] = np.arange(len(ppg_mapping)) + 1
        ppg_mapping["PPG_Description"] = (
            "ITEM" + ppg_mapping["PPG_ID"].astype(str) + ppg_mapping["PPGName"]
        )

        #
        ppg_mapping["temp_name"] = (
            ppg_mapping["PPGName"].str.split(pat="[0-9]+", expand=True).iloc[:, 0]
        )
        ppg_mapping["temp_name"] = ppg_mapping.apply(
            lambda row: handle_spl_cases_in_ppg_name(row["PPGName"], row["temp_name"]),
            axis=1,
        )
        # if ppg_mapping[ppg_mapping["temp_name"]==""].shape[0]>0:
        #     sys.exit("Empty PPG names found; Recheck temp_name column")

        # Remove all spl chars
        ppg_mapping["temp_name"] = ppg_mapping["temp_name"].str.replace(
            "&", "N", regex=False
        )
        ppg_mapping["PPG_Item"] = (
            "ITEM" + ppg_mapping["PPG_ID"].astype(str) + ppg_mapping["temp_name"]
        )
        ppg_mapping["PPG_Item"] = ppg_mapping["PPG_Item"].apply(
            lambda x: re.sub(
                "[^[:alnum:]]", "", re.sub("-|_", "", re.sub(" ", "", str(x)))
            )
        )

        df_clean = df.merge(
            ppg_mapping[["PPGName", "PPG_Description", "PPG_Item"]],
            on="PPGName",
            how="left",
        )
        df_clean["PPG_Description"] = df_clean.apply(
            lambda x: "ITEM" + str(x["Item Number"])
            if pd.isnull(x["PPG_Description"])
            else x["PPG_Description"],
            axis=1,
        )
        df_clean["PPG_Item"] = df_clean.apply(
            lambda x: "ITEM" + str(x["Item Number"])
            if pd.isnull(x["PPG_Item"])
            else x["PPG_Item"],
            axis=1,
        )
        df_clean["PPGName"] = df_clean.apply(
            lambda x: x["ITEM"] if pd.isnull(x["PPGName"]) else x["PPGName"], axis=1
        )
    else:
        df_clean = df
        df_clean["PPG_Description"] = "ITEM" + df_clean["Item Number"].astype(str)
        df_clean["PPG_Item"] = "ITEM" + df_clean["Item Number"].astype(str)
        df_clean["PPGName"] = "ITEM" + df_clean["ITEM"]

    return df_clean


@pf.register_dataframe_method
def resolve_ppg_level_duplicates_values(df, col_to_resolve: str, col_to_agg: str):
    """Resolve more than one values for PPG columns."""
    resolved_col = "_".join([col_to_resolve, "2"])
    ppg_summary = pd.pivot_table(
        df,
        values=col_to_agg,
        index=["PPG_Item"],
        columns=[col_to_resolve],
        aggfunc=np.sum,
        fill_value=0,
        dropna=False,
    )
    ppg_summary[resolved_col] = ppg_summary.apply(lambda x: x.idxmax(), axis=1)
    ppg_summary = ppg_summary.reset_index()

    df = df.merge(ppg_summary[["PPG_Item", resolved_col]], how="left", on="PPG_Item")
    df[col_to_resolve] = df[resolved_col]
    df = df.drop(columns=[resolved_col])

    return df


@pf.register_dataframe_method
def adjust_acv_columns(df):
    """Transform ACV columns to 0-1 scale."""
    # ACV Adjustment
    acv_cols = [x for x in df.columns.to_list() if "ACV" in x]
    df.loc[:, acv_cols] = df.loc[:, acv_cols] / 100

    return df


def get_ppg_distribution(
    df, by_col, bin_level, bin_label, include_sales=False, sales_col=None
):
    """Get distribution of PPGs.

    Parameters
    ----------
    df : pd.DataFrame
        Dataframe consisting of PPG level columns
    by_col : str
        Column to bin
    bin_level : list
        Bin levels
    bin_label : list
        Bin labels
    include_sales : str
        Flag to include aggregated ``Dollar Sales``, by default False
    sales_col : str
        Sales column, by default None

    Returns
    -------
    str
    """
    df["var_bin"] = pd.cut(
        df[by_col], bins=bin_level, labels=bin_label, include_lowest=True
    )
    ppg_dist = (
        df.groupby(by=["var_bin"], as_index=True)
        .agg({"PPG_Item_No": len})
        .rename(columns={"PPG_Item_No": "ppg_cnt"})
    )
    ppg_dist["ppg_cnt"] = ppg_dist["ppg_cnt"].fillna(0)
    ppg_dist["cum_ppg_cnt"] = ppg_dist["ppg_cnt"].cumsum()
    ppg_dist["cum_ppg_pct"] = (
        100 * ppg_dist["cum_ppg_cnt"] / ppg_dist["ppg_cnt"].sum()
    ).round(2)

    if include_sales:
        temp_ppg_dist = (
            df.groupby(by=["var_bin"], as_index=True)
            .agg({sales_col: np.sum})
            .rename(columns={sales_col: "sum_sales"})
        )
        ppg_dist = ppg_dist.merge(temp_ppg_dist, on=["var_bin"], how="left")
        ppg_dist["sum_sales"] = ppg_dist["sum_sales"].fillna(0).astype(int)
        ppg_dist["cum_sales"] = ppg_dist["sum_sales"].cumsum().astype(int)
        ppg_dist["pct_cum_sales"] = (
            100 * ppg_dist["cum_sales"] / ppg_dist["sum_sales"].sum()
        ).round(2)

    return ppg_dist


@pf.register_dataframe_method
def create_missing_records(df, overall_df: pd.DataFrame):
    """Add missing data-points for ``Base price`` calculation."""
    # total_weeks_count = df["Date"].nunique()
    # total_weeks_df = df[["Date"]].drop_duplicates().reset_index(drop=True)
    total_weeks_df = pd.DataFrame(
        pd.date_range("2016-10-01", "2019-12-31", freq="7D", name="Date")
    )

    overall_df_1 = overall_df[overall_df["PPG_Item_No"].isin(df["PPG_Item_No"])].copy()
    overall_df_1["Missing_data_flag"] = 0
    df["Missing_data_flag"] = 0

    overall_df_2 = overall_df_1[~overall_df_1["Date"].isin(df["Date"])].copy()

    temp_1 = (
        overall_df_1.groupby("PPG_Item_No", as_index=False)
        .agg({"Date": len})
        .rename(columns={"Date": "count_of_weeks"})
    )
    temp_1 = temp_1[temp_1["count_of_weeks"] < len(total_weeks_df)]

    temp_2 = overall_df_1[overall_df_1["PPG_Item_No"].isin(temp_1["PPG_Item_No"])][
        [
            "MarketDescription",
            "PPG_Retailer",
            "PPG_Cat",
            "PPG_MFG",
            "BRAND GROUP(C)",
            "PPG_Description",
            "PPG_Item_No",
            "Missing_data_flag",
            "Date",
        ]
    ].drop_duplicates()
    temp_3 = overall_df_1[overall_df_1["PPG_Item_No"].isin(temp_1["PPG_Item_No"])][
        [
            "MarketDescription",
            "PPG_Retailer",
            "PPG_Cat",
            "PPG_MFG",
            "BRAND GROUP(C)",
            "PPG_Description",
            "PPG_Item_No",
            "Missing_data_flag",
        ]
    ].drop_duplicates()

    if len(temp_3) > 0:
        temp_3["id"] = 1
        total_weeks_df["id"] = 1
        temp_4 = temp_3.merge(total_weeks_df, on="id").drop(columns=["id"])
        temp_4["index"] = temp_4.index
        total_weeks_df = total_weeks_df.drop(columns=["id"])
        temp_5 = temp_4.merge(
            temp_2,
            how="inner",
            on=[
                "MarketDescription",
                "PPG_Retailer",
                "PPG_Cat",
                "PPG_MFG",
                "BRAND GROUP(C)",
                "PPG_Description",
                "PPG_Item_No",
                "Missing_data_flag",
                "Date",
            ],
        )
        temp_4 = temp_4[~temp_4.index.isin(temp_5["index"])].drop(columns=["index"])
        temp_5 = overall_df_1[0:0].append(temp_4, ignore_index=True)

        temp_5["Missing_data_flag"] = 1
        temp_5[
            [
                "ACV_Selling",
                "ACV_TPR_Only",
                "ACV_Feat_Only",
                "ACV_Disp_Only",
                "ACV_Feat_Disp",
            ]
        ] = 0
        df_wt_missing_records = df.append(
            temp_5.loc[:, temp_5.columns.isin(df.columns)], ignore_index=True
        )
        df_wt_missing_records = df_wt_missing_records.append(
            overall_df_2.loc[:, overall_df_2.columns.isin(df.columns)],
            ignore_index=True,
        )
    else:
        df_wt_missing_records = overall_df_2.loc[
            :, overall_df_2.columns.isin(df.columns)
        ].append(df, ignore_index=True)

    return df_wt_missing_records


@pf.register_dataframe_method
def generate_final_baseprice(df, src_col: str, dest_col: str):
    """Calculate ``Base price``."""
    df = df.sort_values(["PPG_Item_No", "Date"])
    df["New_base_price"] = df[
        ["wk_base_price_perunit_byppg", "wk_sold_avg_price_byppg"]
    ].apply(np.max, axis=1)

    num_lag = 7
    for i in np.arange(1, num_lag + 1):
        df[src_col + "_" + str(i)] = df.groupby("PPG_Item_No")[src_col].shift(
            i, fill_value=None
        )

    lag_cols = [src_col + "_" + str(i) for i in np.arange(1, num_lag + 1)]
    df["max_lag_val"] = df[lag_cols].apply(np.max, axis=1)

    for lag_col in lag_cols:
        df[lag_col] = df.apply(
            lambda x: x[lag_col]
            if x["max_lag_val"] > 0
            and np.abs((x[lag_col] / x["max_lag_val"]) - 1) <= 0.05
            else np.nan,
            axis=1,
        )
    df[dest_col] = df[lag_cols].apply(np.nanmedian, axis=1)
    df = df.drop(columns=lag_cols)

    # Inputation
    df[dest_col] = df.groupby("PPG_Item_No")[dest_col].fillna(method="ffill")
    df[dest_col] = df.groupby("PPG_Item_No")[dest_col].fillna(method="bfill")

    # Replace missing value in sold price (weekly average) with final base price
    df["wk_sold_avg_price_byppg"] = df.apply(
        lambda x: x[dest_col]
        if np.isnan(x["wk_sold_avg_price_byppg"])
        else x["wk_sold_avg_price_byppg"],
        axis=1,
    )
    df[dest_col] = df[[src_col, dest_col]].apply(np.max, axis=1)

    return df


@pf.register_dataframe_method
def generate_edlp_tpr_component(df, src_col: str, dest_col: str):
    """Generate EDLP and TPR features."""
    num_lag = 7
    for i in np.arange(1, num_lag + 1):
        df[src_col + "_" + str(i)] = df.groupby("PPG_Item_No")[src_col].shift(
            i, fill_value=None
        )

    lag_cols = [src_col + "_" + str(i) for i in np.arange(1, num_lag + 1)]
    df["max_lag_val"] = df[lag_cols].apply(np.max, axis=1)

    for lag_col in lag_cols:
        df[lag_col] = df.apply(
            lambda x: x[lag_col]
            if x["max_lag_val"] > 0
            and np.abs((x[lag_col] / x["max_lag_val"]) - 1) <= 0.05
            else np.nan,
            axis=1,
        )
    df[dest_col] = df[lag_cols].apply(np.nanmedian, axis=1)
    df = df.drop(columns=lag_cols)

    df["median_baseprice"] = df.apply(
        lambda x: x["wk_sold_avg_price_byppg"]
        if (1 - x["wk_sold_avg_price_byppg"] / x[dest_col]) <= 0.05
        else x[dest_col],
        axis=1,
    )
    df["tpr_discount_byppg"] = df.apply(
        lambda x: (1 - x["wk_sold_avg_price_byppg"] / x["median_baseprice"])
        if (1 - x["wk_sold_avg_price_byppg"] / x["median_baseprice"]) > 0.05
        else 0,
        axis=1,
    )
    df["tpr_discount_byppg"] = df.apply(
        lambda x: 0 if x["Missing_data_flag"] == 1 else x["tpr_discount_byppg"], axis=1
    )
    df["median_baseprice"] = df.apply(
        lambda x: x["Final_baseprice"]
        if np.isnan(x["median_baseprice"])
        else x["median_baseprice"],
        axis=1,
    )

    return df


@pf.register_dataframe_method
def create_median_acv(df, src_col: str, dest_col: str):
    """Add median value of ACV Selling variable."""
    # ACV Lag  (TPR ACV smoothing)
    temp_1 = (
        df[df["tpr_discount_byppg"] == 0].sort_values(["PPG_Item_No", "Date"]).copy()
    )

    num_lag = 6
    for i in np.arange(1, num_lag + 1):
        temp_1[src_col + "_" + str(i)] = temp_1.groupby("PPG_Item_No")[src_col].shift(
            i, fill_value=None
        )

    lag_cols = [src_col + "_" + str(i) for i in np.arange(1, num_lag + 1)]
    temp_1[dest_col] = temp_1[[src_col] + lag_cols].apply(np.nanmedian, axis=1)
    temp_1 = temp_1.drop(columns=lag_cols)

    # Imputation
    temp_2 = df.merge(
        temp_1[["PPG_Item_No", "PPG_Retailer", "Date", dest_col]],
        how="left",
        on=["PPG_Item_No", "PPG_Retailer", "Date"],
    )
    temp_2[dest_col] = temp_2.groupby("PPG_Item_No")[dest_col].fillna(method="ffill")
    df = df.merge(
        temp_2[["PPG_Item_No", "PPG_Retailer", "Date", dest_col]],
        how="left",
        on=["PPG_Item_No", "PPG_Retailer", "Date"],
    )

    return df


@pf.register_dataframe_method
def create_seasonality_features(df):
    """Create seasonality features like dummy variable for quarters and month based trendline."""
    # Create Quarter flag
    df["flag_qtr2"] = (df["Date"].dt.quarter == 2).astype(int)
    df["flag_qtr3"] = (df["Date"].dt.quarter == 3).astype(int)
    df["flag_qtr4"] = (df["Date"].dt.quarter == 4).astype(int)
    df["Year_Qtr"] = (
        df["Date"].dt.year.astype(str) + "_" + df["Date"].dt.quarter.astype(str)
    )

    # Create month based trendline
    df["month"] = df["Date"].dt.month
    df["year"] = df["Date"].dt.year

    month_df = df[["month", "year"]].drop_duplicates(ignore_index=True)
    month_df = month_df.sort_values(by=["year", "month"])
    month_df["monthno"] = np.arange(len(month_df)) + 1
    df = df.merge(month_df, how="left", on=["month", "year"])
    df = df.drop(columns=["month", "year"])

    return df


@pf.register_dataframe_method
def create_category_trend(df):
    """Create normalized category sales variable."""
    # Category Trend Variable
    df = df[~df["median_baseprice"].isna()]
    temp_1 = (
        df.groupby(["Date"], as_index=False)
        .agg({"wk_sold_doll_byppg": np.sum})
        .rename(columns={"wk_sold_doll_byppg": "cumsum_wk_sold_doll"})
    )
    temp_1["category_trend"] = (
        temp_1["cumsum_wk_sold_doll"] / temp_1["cumsum_wk_sold_doll"].mean()
    )
    temp_1 = temp_1.drop(columns=["cumsum_wk_sold_doll"])
    df = df.merge(temp_1, how="left", on="Date")

    return df


def prepare_optimizer_data_at_ppg_level(df, exclude_missing_obs=False):
    """Prepare data for Optimizer at PPG level.

    Parameters
    ----------
    df : pd.DataFrame
        Dataframe consisting IDVs of a PPG at Week level
    exclude_missing_obs : bool
        Flag to exclude missing observation

    Returns
    -------
    pd.DataFrame
    """
    if exclude_missing_obs:
        max_qtr = df.loc[df["Missing_data_flag"] == 0, "Year_Qtr"].sort_values(
            ascending=False
        )[0:1]
    else:
        max_qtr = df.loc[:, "Year_Qtr"].sort_values(ascending=False)[0:1]
    last_qtr_sales = df[df["Year_Qtr"].isin(max_qtr.to_list())][
        [
            "PPG_Item_No",
            "PPG_Retailer",
            "PPG_MFG",
            "Estimated_baseprice",
            "ACV_Selling",
        ]
    ]
    last_qtr_sales_agg = last_qtr_sales.groupby(
        by=["PPG_Item_No", "PPG_Retailer", "PPG_MFG"], as_index=False
    ).agg({"Estimated_baseprice": np.nanmedian, "ACV_Selling": np.nanmedian})
    last_qtr_sales_agg.rename(
        columns={"Estimated_baseprice": "median_ebp", "ACV_Selling": "ACV_median"},
        inplace=True,
    )

    df["percent_diff_med_bp"] = 1 - (df["median_baseprice"] / df["Estimated_baseprice"])
    df = df.merge(
        last_qtr_sales_agg, how="left", on=["PPG_Item_No", "PPG_Retailer", "PPG_MFG"],
    )
    df["ACV_Selling"] = df["ACV_median"]
    df = df.drop(columns=["ACV_median"])
    df["median_baseprice_1"] = df.apply(
        lambda x: x["median_ebp"]
        if x["percent_diff_med_bp"] < 0
        else x["median_ebp"] * (1 - x["percent_diff_med_bp"]),
        axis=1,
    )

    df_edlp = df[df["tpr_discount_byppg"] == 0].copy()
    df_edlp["percent_diff_avg_price"] = 1 - (
        df_edlp["wk_sold_avg_price_byppg"] / df_edlp["Estimated_baseprice"]
    )
    df_edlp["wk_sold_avg_price_byppg_1"] = df_edlp.apply(
        lambda x: x["median_ebp"]
        if x["percent_diff_avg_price"] < 0
        else x["median_ebp"] * (1 - x["percent_diff_avg_price"]),
        axis=1,
    )
    df = df.merge(
        df_edlp[
            [
                "PPG_Item_No",
                "PPG_Retailer",
                "PPG_MFG",
                "Date",
                "wk_sold_avg_price_byppg_1",
            ]
        ],
        how="left",
        on=["PPG_Item_No", "PPG_Retailer", "PPG_MFG", "Date"],
    )
    df["wk_sold_avg_price_byppg"] = df.apply(
        lambda x: x["wk_sold_avg_price_byppg_1"]
        if x["tpr_discount_byppg"] == 0
        else x["wk_sold_avg_price_byppg"],
        axis=1,
    )
    df["median_baseprice"] = df["median_baseprice_1"]
    df["Estimated_baseprice"] = df["median_ebp"]
    df["Final_baseprice"] = df["median_ebp"]
    df = df.drop(columns=["wk_sold_avg_price_byppg_1"])

    df_tpr = df[df["tpr_discount_byppg"] != 0].copy()
    df_tpr["wk_sold_avg_price_byppg_1"] = df_tpr["Estimated_baseprice"] * (
        1 - df_tpr["tpr_discount_byppg"]
    )
    df = df.merge(
        df_tpr[
            [
                "PPG_Item_No",
                "PPG_Retailer",
                "PPG_MFG",
                "Date",
                "wk_sold_avg_price_byppg_1",
            ]
        ],
        how="left",
        on=["PPG_Item_No", "PPG_Retailer", "PPG_MFG", "Date"],
    )
    df["wk_sold_avg_price_byppg"] = df.apply(
        lambda x: x["wk_sold_avg_price_byppg_1"]
        if x["tpr_discount_byppg"] != 0
        else x["wk_sold_avg_price_byppg"],
        axis=1,
    )
    df = df.drop(
        columns=[
            "wk_sold_avg_price_byppg_1",
            "median_baseprice_1",
            "percent_diff_med_bp",
            "median_ebp",
        ]
    )
    df[["ACV_Feat_Only", "ACV_TPR_Only", "ACV_Disp_Only", "ACV_Feat_Disp"]] = 0
    df["flag"] = df.apply(
        lambda x: 1 if x["PPG_Retailer"] == "ROM" or x["PPG_MFG"] == "Non-NPPC" else 0,
        axis=1,
    )
    df.loc[df["flag"] == 1, "wk_sold_avg_price_byppg"] = df.loc[
        df["flag"] == 1, "Final_baseprice"
    ]
    df.loc[df["flag"] == 1, "median_baseprice"] = df.loc[
        df["flag"] == 1, "Final_baseprice"
    ]
    df.loc[df["flag"] == 1, "tpr_discount_byppg"] = 0
    df = df.drop(columns=["flag"])

    return df


@pf.register_dataframe_method
def prepare_optimizer_data(df, optimizer_flag: bool, exlude_missing_flag: bool):
    """Prepare data for Optimizer."""
    if optimizer_flag:
        temp_df = df.copy()
        if exlude_missing_flag:
            ppg_list = temp_df["PPG_Item_No"].unique()
            return_df = pd.DataFrame()
            for ppg in ppg_list:
                ppg_df = prepare_optimizer_data_at_ppg_level(
                    temp_df[temp_df["PPG_Item_No"] == ppg],
                    exclude_missing_obs=exlude_missing_flag,
                )
                return_df = return_df.append(ppg_df, ignore_index=True)
        else:
            return_df = prepare_optimizer_data_at_ppg_level(
                temp_df, exclude_missing_obs=exlude_missing_flag
            )
        return_df = return_df.sort_values(["PPG_Cat", "PPG_MFG", "PPG_Item_No", "Date"])
    else:
        return_df = df.copy()

    return return_df


@pf.register_dataframe_method
def create_pantry_effects_features(df):
    """Create features to capture pantry loading effects."""
    df["tpr_discount_byppg_lag1"] = df.groupby("PPG_Item_No")[
        "tpr_discount_byppg"
    ].shift(1, fill_value=0)
    df["tpr_discount_byppg_lag2"] = df.groupby("PPG_Item_No")[
        "tpr_discount_byppg"
    ].shift(2, fill_value=0)

    return df


def get_competitor_regular_price_var(acting_ppg, model_df, y, decompose_flag=True):
    """Select EDLP acting items for each PPG.

    Parameters
    ----------
    acting_ppg : pd.DataFrame
        Dataframe consisting of Base PPG and Acting PPG
    model_df : pd.DataFrame
        Dataframe consisting of EDLP and TPR at PPG x Week level
    y : pd.DataFrame
        Dataframe consisting of Quatity Sold at PPG x Week level
    decompose_flag : bool
        Flag to decompose trend from Quatity Sold and EDLP

    Returns
    -------
    pd.DataFrame
    """
    model_correlation_feature_shortlist = 0.05
    model_correlation_price_trend_cutoff = 0.50

    ppg_list = acting_ppg["PPG_Item_No"].unique()
    rp_acting_items = pd.DataFrame(columns=["BasePPG", "ActingPPG"])
    for ppg in ppg_list:
        action_items = acting_ppg.loc[
            acting_ppg["PPG_Item_No"] == ppg, "Acting_Items"
        ].to_list()
        if len(action_items) == 0:
            continue

        corr_acting_items = []
        for i in action_items:
            ppg_vol = y.loc[
                y["PPG_Item_No"] == ppg, ["wk_sold_qty_byppg_log", "Date"]
            ].set_index("Date")
            ppg_base_price = model_df.loc[
                model_df["PPG_Item_No"] == ppg,
                ["wk_sold_median_base_price_byppg_log", "Date"],
            ].set_index("Date")
            action_vol = y.loc[
                y["PPG_Item_No"] == i, ["wk_sold_qty_byppg_log", "Date"]
            ].set_index("Date")
            action_base_price = model_df.loc[
                model_df["PPG_Item_No"] == i,
                ["wk_sold_median_base_price_byppg_log", "Date"],
            ].set_index("Date")
            common_index = ppg_vol.index.intersection(action_base_price.index)
            ppg_vol = ppg_vol[ppg_vol.index.isin(common_index)]
            action_base_price = action_base_price[
                action_base_price.index.isin(common_index)
            ]

            action_corr = ppg_vol["wk_sold_qty_byppg_log"].corr(
                action_base_price["wk_sold_median_base_price_byppg_log"]
            )
            price_corr = ppg_vol["wk_sold_qty_byppg_log"].corr(
                ppg_base_price["wk_sold_median_base_price_byppg_log"]
            )
            price_corr = 0.5 if np.isnan(price_corr) else price_corr
            if decompose_flag:
                # TODO - Expection Handling
                ppg_vol_decomposed = sm.tsa.seasonal_decompose(
                    ppg_vol["wk_sold_qty_byppg_log"].asfreq("W-SAT")
                )
                # TODO - Expection Handling
                action_base_price_decomposed = sm.tsa.seasonal_decompose(
                    action_base_price["wk_sold_median_base_price_byppg_log"]
                )
                trend_corr = ppg_vol_decomposed.trend.corr(
                    action_base_price_decomposed.trend
                )
                final_corr = trend_corr
            else:
                final_corr = action_corr

            if ~np.isnan(final_corr) and (
                (abs(final_corr) < abs(price_corr))
                or abs(final_corr) < model_correlation_price_trend_cutoff
            ):
                corr_acting_items.append(action_corr)
            else:
                corr_acting_items.append(np.nan)

        ppg_adj = (
            re.sub("_ROM", "_Retailer", ppg)
            if "_ROM" in ppg
            else re.sub("_ROM", "_Retailer", ppg)
        )
        slct_action_items = [
            item
            for ptr, item in enumerate(action_items)
            if (
                (
                    ~np.isnan(corr_acting_items[ptr])
                    and corr_acting_items[ptr] >= model_correlation_feature_shortlist
                )
                or ((item == ppg_adj) & ~np.isnan(corr_acting_items[ptr]))
            )
        ]

        temp_acting_items = pd.DataFrame(
            {"BasePPG": [ppg] * len(slct_action_items), "ActingPPG": slct_action_items}
        )
        rp_acting_items = rp_acting_items.append(temp_acting_items, ignore_index=True)

    return rp_acting_items


@pf.register_dataframe_method
def add_competitor_regular_price_var(
    df, rp_acting_items: pd.DataFrame, model_df: pd.DataFrame
):
    """Add EDLP acting items as features for a given PPG."""
    ppg = df["PPG_Item_No"].unique()[0]
    slct_action_items = rp_acting_items.loc[
        rp_acting_items["BasePPG"] == ppg, "ActingPPG"
    ].to_list()

    slct_action_items_df = model_df.loc[
        model_df["PPG_Item_No"].isin(slct_action_items),
        ["PPG_Item_No", "Date", "wk_sold_median_base_price_byppg_log"],
    ]
    if len(slct_action_items_df) > 0:
        final_df = slct_action_items_df.pivot_table(
            values="wk_sold_median_base_price_byppg_log",
            index="Date",
            columns="PPG_Item_No",
        )
        final_df.columns = [i + "_RegularPrice" for i in final_df.columns.to_list()]
        final_df.reset_index(inplace=True)
        # return final_df
        df = df.merge(final_df, how="left", on="Date")
        return df
    else:
        # return None
        return df


def get_competitor_tpr_var(acting_ppg, model_df, y):
    """Select TPR acting items for each PPG.

    Parameters
    ----------
    acting_ppg : pd.DataFrame
        Dataframe consisting of Base PPG and Acting PPG
    model_df : pd.DataFrame
        Dataframe consisting of EDLP and TPR at PPG x Week level
    y : pd.DataFrame
        Dataframe consisting of Quatity Sold at PPG x Week level

    Returns
    -------
    pd.DataFrame
    """
    model_correlation_feature_shortlist_tpr = -0.05

    ppg_list = acting_ppg["PPG_Item_No"].unique()
    tpr_acting_items = pd.DataFrame(columns=["BasePPG", "ActingPPG"])
    for ppg in ppg_list:
        action_items = acting_ppg.loc[
            acting_ppg["PPG_Item_No"] == ppg, "Acting_Items"
        ].to_list()
        if len(action_items) == 0:
            continue

        corr_acting_items = []
        for i in action_items:
            ppg_vol = y.loc[
                y["PPG_Item_No"] == ppg, ["wk_sold_qty_byppg_log", "Date"]
            ].set_index("Date")
            action_tpr = model_df.loc[
                model_df["PPG_Item_No"] == i, ["tpr_discount_byppg", "Date"]
            ].set_index("Date")
            common_index = ppg_vol.index.intersection(action_tpr.index)
            ppg_vol = ppg_vol[ppg_vol.index.isin(common_index)]
            action_tpr = action_tpr[action_tpr.index.isin(common_index)]

            action_corr = ppg_vol["wk_sold_qty_byppg_log"].corr(
                action_tpr["tpr_discount_byppg"]
            )
            corr_acting_items.append(action_corr)

        ppg_adj = (
            re.sub("_ROM", "_Retailer", ppg)
            if "_ROM" in ppg
            else re.sub("_ROM", "_Retailer", ppg)
        )
        slct_action_items = [
            item
            for ptr, item in enumerate(action_items)
            if (
                (
                    ~np.isnan(corr_acting_items[ptr])
                    and corr_acting_items[ptr]
                    <= model_correlation_feature_shortlist_tpr
                )
                or ((item == ppg_adj) and ~np.isnan(corr_acting_items[ptr]))
            )
        ]

        temp_acting_items = pd.DataFrame(
            {"BasePPG": [ppg] * len(slct_action_items), "ActingPPG": slct_action_items}
        )
        tpr_acting_items = tpr_acting_items.append(temp_acting_items, ignore_index=True)

    return tpr_acting_items


@pf.register_dataframe_method
def add_competitor_tpr_var(df, tpr_acting_items: pd.DataFrame, model_df: pd.DataFrame):
    """Add TPR acting items as features for a given PPG."""
    ppg = df["PPG_Item_No"].unique()[0]
    slct_action_items = tpr_acting_items.loc[
        tpr_acting_items["BasePPG"] == ppg, "ActingPPG"
    ].to_list()

    slct_action_items_df = model_df.loc[
        model_df["PPG_Item_No"].isin(slct_action_items),
        ["PPG_Item_No", "Date", "tpr_discount_byppg"],
    ]
    if len(slct_action_items_df) > 0:
        final_df = slct_action_items_df.pivot_table(
            values="tpr_discount_byppg", index="Date", columns="PPG_Item_No"
        )
        final_df.columns = [i + "_PromotedDiscount" for i in final_df.columns.to_list()]
        final_df.reset_index(inplace=True)
        # return final_df
        df = df.merge(final_df, how="left", on="Date")
        return df
    else:
        # return None
        return df


# Interaction Variables
def get_RegularPrice_InteractionVariables(PPG, inter_ppg, model_df_1, y):
    """Select ELDP acting items for interaction variable.

    Parameters
    ----------
    PPG : list of str
        List of PPGs to select acting items
    inter_ppg : pd.DataFrame
        Dataframe consisting of Base PPG and Acting PPG
    model_df_1 : pd.DataFrame
        Dataframe consisting of EDLP and TPR at PPG x Week level
    y : pd.DataFrame
        Dataframe consisting of Quatity Sold at PPG x Week level

    Returns
    -------
    pd.DataFrame
    """
    # Interactions cutoff
    min_interaction_rp_cutoff = 0.1
    max_interaction_rp_cutoff = 0.9

    RegularPrice = model_df_1[model_df_1["PPG_Item_No"].isin(PPG)][
        ["PPG_Item_No", "Date", "wk_sold_median_base_price_byppg_log"]
    ]
    CoPromotions_RegularPrice = RegularPrice.pivot_table(
        values="wk_sold_median_base_price_byppg_log",
        index="Date",
        columns="PPG_Item_No",
    )  # .reset_index()
    # CoPromotions_RegularPrice.columns = CoPromotions_RegularPrice.columns.replace("wk_sold_median_base_price_byppg_log.","")
    CoPromotions_RegularPrice.columns = [
        i + "_RegularPrice" for i in CoPromotions_RegularPrice.columns.to_list()
    ]
    corr_1 = (
        CoPromotions_RegularPrice.corr().reset_index().rename(columns={"index": "var1"})
    )
    corr_2 = corr_1.melt(id_vars="var1", var_name="var2", value_name="corr_value")
    corr_2 = corr_2[
        (corr_2["corr_value"] > min_interaction_rp_cutoff)
        & (corr_2["corr_value"] < max_interaction_rp_cutoff)
    ]

    rp_interaction = pd.DataFrame(columns=["BasePPG", "InteractionPPG"])
    for ppg in PPG:
        ppg_adj = ppg + "_" + "RegularPrice"
        temp_1 = corr_2[corr_2["var1"] == ppg_adj]["var2"]
        temp_1 = temp_1[
            temp_1.isin(
                [
                    i + "_" + "RegularPrice"
                    for i in inter_ppg[inter_ppg["PPG_Item_No"] == ppg]["Acting_Items"]
                ]
            )
        ]
        ppg_interact_list = [ppg_adj] + temp_1.to_list()

        if len(ppg_interact_list) > 1:
            # TODO - Build interaction model using glinternet with exception handling
            # mdl_df = y.loc[y["PPG_Item_No"]==ppg, ["Date","wk_sold_qty_byppg_log"]]
            # glinternet.cv(CoPromotions_RegularPrice[ppg_interact_list],mdl_df["wk_sold_qty_byppg_log"],numLevels = rep(1,len(ppg_interact_list)),interactionCandidates=1)
            temp_interaction = pd.DataFrame(
                {
                    "BasePPG": [ppg] * len(ppg_interact_list),
                    "InteractionPPG": [
                        re.sub("_RegularPrice", "", j) for j in ppg_interact_list
                    ],
                }
            )
            rp_interaction = rp_interaction.append(temp_interaction, ignore_index=True)

    return rp_interaction


@pf.register_dataframe_method
def add_RegularPrice_InteractionVariables(
    df, rp_interaction: pd.DataFrame, model_df_1: pd.DataFrame
):
    """Add ELDP interaction variables as features."""
    ppg = df["PPG_Item_No"].unique()[0]

    # Extract EDLP Interactions
    RP_Interaction = rp_interaction.loc[
        rp_interaction["BasePPG"] == ppg, "InteractionPPG"
    ].to_list()
    if len(RP_Interaction) > 0:
        RegularPrice = model_df_1.loc[
            model_df_1["PPG_Item_No"].isin([ppg] + RP_Interaction),
            ["PPG_Item_No", "Date", "wk_sold_median_base_price_byppg_log"],
        ]
        CoPromotions_RegularPrice = RegularPrice.pivot_table(
            values="wk_sold_median_base_price_byppg_log",
            index="Date",
            columns="PPG_Item_No",
            fill_value=0,
            dropna=False,
        )
        CoPromotions_RegularPrice.columns = [
            col + "_RegularPrice" for col in CoPromotions_RegularPrice.columns.to_list()
        ]
        CoPromotions_RegularPrice.reset_index(inplace=True)
        preprocessor = preprocessing.PolynomialFeatures(
            2, interaction_only=True, include_bias=False
        )
        preprocessed_df = preprocessor.fit_transform(
            CoPromotions_RegularPrice.drop(columns="Date")
        )
        preprocessed_cols = preprocessor.get_feature_names(
            input_features=CoPromotions_RegularPrice.columns.to_list()[1:]
        )
        preprocessed_cols = [re.sub(" ", "_", col) for col in preprocessed_cols]
        CoPromotions_RegularPrice_Final = pd.DataFrame(
            preprocessed_df, columns=preprocessed_cols
        )

        List_1 = [col for col in preprocessed_cols if ppg in col]
        List_1 = [col for col in List_1 if col != (ppg + "_RegularPrice")]
        List_1 = [col for col in List_1 if col not in df.columns.to_list()]
        List_2 = [col for col in preprocessed_cols if "RegularPrice_" not in col]
        List_2 = [col for col in List_2 if col != (ppg + "_RegularPrice")]
        List_2 = [col for col in List_2 if col not in df.columns.to_list()]

        CoPromotions_RegularPrice_Final["Date"] = CoPromotions_RegularPrice["Date"]
        List = ["Date"] + List_1 + List_2  # + ["Date"]
        CoPromotions_RegularPrice_Final = CoPromotions_RegularPrice_Final[List]
        # lwr_bound = lwr_bound + [-np.inf]*len(List_1) + [0]*len(List_2)
        # upr_bound = upr_bound + [np.inf]*len(List_1) + [np.inf]*len(List_2)
        # RP_selectedVars = CoPromotions_RegularPrice_Final.columns.to_list()[1:]
        df = df.merge(CoPromotions_RegularPrice_Final, how="left", on="Date")
        # temp_colsc = temp_colsc + List_1 + List_2

    return df


def get_TradePromotions_InteractionVariables(PPG, inter_ppg, model_df_1, y):
    """Select TPR acting items for interaction variable.

    Parameters
    ----------
    PPG : list of str
        List of PPGs to select acting items
    inter_ppg : pd.DataFrame
        Dataframe consisting of Base PPG and Acting PPG
    model_df_1 : pd.DataFrame
        Dataframe consisting of EDLP and TPR at PPG x Week level
    y : pd.DataFrame
        Dataframe consisting of Quatity Sold at PPG x Week level

    Returns
    -------
    pd.DataFrame
    """
    TradePromotions = model_df_1[model_df_1["PPG_Item_No"].isin(PPG)][
        ["PPG_Item_No", "Date", "tpr_discount_byppg"]
    ]
    # Handles Expection
    TPR_weeks = TradePromotions.groupby("PPG_Item_No", as_index=False).agg(
        {"tpr_discount_byppg": lambda x: np.sum(x > 0.05)}
    )
    TPR_weeks.rename(
        columns={"PPG_Item_No": "Base", "tpr_discount_byppg": "Base_Promotion_TPR"},
        inplace=True,
    )

    CoPromotions_TPR = TradePromotions.pivot_table(
        values="tpr_discount_byppg", index="Date", columns="PPG_Item_No"
    ).reset_index()
    TPR_interaction = pd.DataFrame(
        columns=["BasePPG", "InteractionPPG", "CrossPromotion_TPR"]
    )
    for i in PPG:
        for j in PPG:
            cross_promotion = (
                (CoPromotions_TPR[i] > 0.05) & (CoPromotions_TPR[j] > 0.05)
            ).sum()
            temp_interaction = pd.DataFrame(
                {
                    "BasePPG": [i],
                    "InteractionPPG": [j],
                    "CrossPromotion_TPR": [cross_promotion],
                }
            )
            TPR_interaction = TPR_interaction.append(
                temp_interaction, ignore_index=True
            )
    TPR_interaction["CrossPromotion_TPR"] = TPR_interaction[
        "CrossPromotion_TPR"
    ].fillna(0)
    TPR_interaction = TPR_interaction.merge(
        TPR_weeks, how="left", left_on="BasePPG", right_on="Base"
    )
    TPR_weeks.rename(
        columns={
            "Base": "Interaction",
            "Base_Promotion_TPR": "Interaction_Promotion_TPR",
        },
        inplace=True,
    )
    TPR_interaction = TPR_interaction.merge(
        TPR_weeks, how="left", left_on="InteractionPPG", right_on="Interaction"
    )
    TPR_interaction["Overall_TPR"] = (
        TPR_interaction["Base_Promotion_TPR"]
        + TPR_interaction["Interaction_Promotion_TPR"]
        - TPR_interaction["CrossPromotion_TPR"]
    )
    TPR_interaction["OnlyBase"] = (
        TPR_interaction["Base_Promotion_TPR"] - TPR_interaction["CrossPromotion_TPR"]
    )
    TPR_interaction["OnlyInteraction"] = (
        TPR_interaction["Interaction_Promotion_TPR"]
        - TPR_interaction["CrossPromotion_TPR"]
    )
    TPR_interaction["Cross_Base"] = (
        TPR_interaction["CrossPromotion_TPR"] / TPR_interaction["Base_Promotion_TPR"]
    )
    TPR_interaction["Cross_Interaction"] = (
        TPR_interaction["CrossPromotion_TPR"]
        / TPR_interaction["Interaction_Promotion_TPR"]
    )
    TPR_interaction["Cross_Overall"] = (
        TPR_interaction["CrossPromotion_TPR"] / TPR_interaction["Overall_TPR"]
    )
    TPR_interaction = TPR_interaction[
        (TPR_interaction["CrossPromotion_TPR"] > 1)
        & (TPR_interaction["OnlyBase"] > 1)
        & (TPR_interaction["OnlyInteraction"] > 1)
        & (TPR_interaction["Cross_Overall"] < 1)
        & (TPR_interaction["Cross_Base"] < 1)
        & (TPR_interaction["Cross_Interaction"] < 1)
    ]

    CoPromotions_TPR.columns = [i + "_TPR" for i in CoPromotions_TPR.columns.to_list()]

    tpr_interaction = pd.DataFrame(columns=["BasePPG", "InteractionPPG"])
    for ppg in PPG:
        temp_1 = TPR_interaction[TPR_interaction["BasePPG"] == ppg]["InteractionPPG"]
        temp_1 = temp_1[
            temp_1.isin(
                inter_ppg[inter_ppg["PPG_Item_No"] == ppg]["Acting_Items"].to_list()
            )
        ]
        ppg_interact_list = [ppg] + temp_1.to_list()

        if len(ppg_interact_list) > 1:
            # TODO - Build interaction model using glinternet with exception handling
            # mdl_df = y.loc[y["PPG_Item_No"]==ppg, ["Date","wk_sold_qty_byppg_log"]]
            # glinternet.cv(CoPromotions_TPR[,ppg_interact_list],mdl_df["wk_sold_qty_byppg_log"],numLevels = rep(1,len(ppg_interact_list)),interactionCandidates=1)
            temp_interaction = pd.DataFrame(
                {
                    "BasePPG": [ppg] * len(ppg_interact_list),
                    "InteractionPPG": [
                        re.sub("_TPR", "", j) for j in ppg_interact_list
                    ],
                }
            )
            tpr_interaction = tpr_interaction.append(
                temp_interaction, ignore_index=True
            )

    return tpr_interaction


@pf.register_dataframe_method
def add_TradePromotions_InteractionVariables(
    df, tpr_interaction: pd.DataFrame, model_df_1: pd.DataFrame
):
    """Add TPR interaction variables as features."""
    ppg = df["PPG_Item_No"].unique()[0]

    # Extract TPR Interactions
    TPR_Interaction = tpr_interaction.loc[
        tpr_interaction["BasePPG"] == ppg, "InteractionPPG"
    ].to_list()
    if len(TPR_Interaction) > 0:
        TradePromotions = model_df_1.loc[
            model_df_1["PPG_Item_No"].isin([ppg] + TPR_Interaction),
            ["PPG_Item_No", "Date", "tpr_discount_byppg"],
        ]
        CoPromotions_TPR = TradePromotions.pivot_table(
            values="tpr_discount_byppg",
            index="Date",
            columns="PPG_Item_No",
            fill_value=0,
            dropna=False,
        )
        CoPromotions_TPR.columns = [
            col + "_PromotedDiscount" for col in CoPromotions_TPR.columns.to_list()
        ]
        CoPromotions_TPR.reset_index(inplace=True)
        preprocessor = preprocessing.PolynomialFeatures(
            2, interaction_only=True, include_bias=False
        )
        preprocessed_df = preprocessor.fit_transform(
            CoPromotions_TPR.drop(columns="Date")
        )
        preprocessed_cols = preprocessor.get_feature_names(
            input_features=CoPromotions_TPR.columns.to_list()[1:]
        )
        preprocessed_cols = [re.sub(" ", "_", col) for col in preprocessed_cols]
        CoPromotions_TPR_Final = pd.DataFrame(
            preprocessed_df, columns=preprocessed_cols
        )

        List_1 = [col for col in preprocessed_cols if ppg in col]
        List_1 = [col for col in List_1 if col != (ppg + "_PromotedDiscount")]
        List_1 = [col for col in List_1 if col not in df.columns.to_list()]
        List_2 = [col for col in preprocessed_cols if "PromotedDiscount_" not in col]
        List_2 = [col for col in List_2 if col != (ppg + "_PromotedDiscount")]
        List_2 = [col for col in List_2 if col not in df.columns.to_list()]

        CoPromotions_TPR_Final["Date"] = CoPromotions_TPR["Date"]
        List = ["Date"] + List_1 + List_2  # + ["Date"]
        CoPromotions_TPR_Final = CoPromotions_TPR_Final[List]
        # lwr_bound = lwr_bound + [-np.inf]*len(List_1) + [-np.inf]*len(List_2)
        # upr_bound = upr_bound + [np.inf]*len(List_1) + [0]*len(List_2)
        # TPR_selectedVars = CoPromotions_TPR_Final.columns.to_list()[1:]
        df = df.merge(CoPromotions_TPR_Final, how="left", on="Date")
        # temp_colsc = temp_colsc + List_1 + List_2

    return df


@pf.register_dataframe_method
def remove_zero_acv_weeks(df):
    """Remove initial weeks where ACV is zero."""
    acv_min_date = df.loc[df["ACV_Selling"] > 0, "Date"].min()
    df = df[~((df["ACV_Selling"] == 0) & (df["Date"] < acv_min_date))]

    return df


@pf.register_dataframe_method
def set_features_wt_low_variance_to_zero(df):
    """Set select features to 0 if its variance is too low."""
    # Set median price wt low variance to 0
    if df.loc[df["tpr_discount_byppg"] == 0, "wk_sold_avg_price_byppg"].var() < 0.001:
        df["wk_sold_median_base_price_byppg_log"] = 0

    # Set ACV selling wt low variance to 0
    if df["ACV_Selling"].var() < 0.001:
        df["ACV_Selling"] = 0

    return df


@pf.register_dataframe_method
def impute_missing_values(df):
    """Impute missing value for numeric columns."""
    num_cols = [
        col
        for col in df.columns.to_list()
        if col
        not in ["Date", "PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description", "DV"]
    ]
    impute_cols = [
        col
        for col in num_cols
        if (
            ("flag" not in col)
            and (col != "tpr_discount_byppg")
            and ("_PromotedDiscount" not in col)
            and (col not in ["tpr_discount_byppg_lag1", "tpr_discount_byppg_lag2"])
        )
    ]
    if len(impute_cols) > 0:
        impute_dict_1 = df[impute_cols].mean(skipna=True).to_dict()
        df = df.fillna(impute_dict_1)

    df[num_cols] = df[num_cols].fillna(0)
    # df.loc[abs(df)==np.inf, num_cols] = 0

    return df


def select_features(ppg, train_df, y, reg_ppln_ols):
    """Select features for Price elasticity modelling by Lasso regression.

    Parameters
    ----------
    ppg : str
        PPG
    train_df : pd.DataFrame
        Dataframe consisting of IDVs and DV
    reg_ppln_ols : Estimator class
        Model training pipeline

    Returns
    -------
    list of str
    """
    # Initialization
    model_coef_list = pd.DataFrame(
        columns=["model_coefficient_name", "model_coefficient_value"]
    )
    # Seed list to select common features
    seeds = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71]

    X = train_df.drop(
        columns=["Date", "PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
    )
    y = y.to_numpy()

    for seed in seeds:
        random.seed(seed)

        # Build model
        reg_ppln_ols.fit(X, y)

        # Model coefficients
        model = reg_ppln_ols["estimator"]
        model_coef = pd.DataFrame(
            {
                "model_coefficient_name": X.columns.to_list(),
                "model_coefficient_value": model.coef_,
            }
        )
        model_coef = model_coef.append(
            {
                "model_coefficient_name": "(Intercept)",
                "model_coefficient_value": model.intercept_,
            },
            ignore_index=True,
        )
        model_coef = model_coef[model_coef["model_coefficient_value"].abs() > 0]
        model_coef_list = model_coef_list.append(model_coef, ignore_index=True)

        # Model performance metric
        train_set_prediction = pd.DataFrame(
            {"PPG_Item_No": [ppg] * len(X), "Prediction": np.exp(model.predict(X))}
        )
        train_set_rsq = r2_score((y), np.log(train_set_prediction["Prediction"]))
        train_set_MAPE = mean_absolute_error(
            np.array([1] * len(y)), train_set_prediction["Prediction"] / np.exp(y)
        )

        model_results = model_coef.copy()
        model_results["PPG"] = ppg
        model_results["R_Square"] = train_set_rsq
        model_results["train_MAPE"] = train_set_MAPE
        model_results["seed"] = seed
        # Append the results
        # model_results_seed = model_results_seed.append(model_results, ignore_index=True)

    # Extract features which turned out >15 times out of 20 Seeds
    model_coef_agg = (
        model_coef_list.groupby(by=["model_coefficient_name"], as_index=False)
        .agg({"model_coefficient_value": len})
        .rename(columns={"model_coefficient_value": "cnt"})
    )
    model_coef_final = model_coef_agg[
        (model_coef_agg["cnt"] > 15)
        & (model_coef_agg["model_coefficient_name"] != "(Intercept)")
    ]["model_coefficient_name"].to_list()

    # TODO - Not used
    # if len(model_coef_final)<2:
    #     ppg_wo_features.append(ppg)

    # Create dataset for the final model with consistent features
    own_effects_cols = [
        "Date",
        "PPG_Cat",
        "PPG_MFG",
        "PPG_Item_No",
        "PPG_Description",  # "DV",
        "wk_sold_median_base_price_byppg_log",
        "tpr_discount_byppg",
        "ACV_Feat_Only",
        "ACV_Disp_Only",
        "ACV_Feat_Disp",
        "ACV_Selling",
        "flag_qtr2",
        "flag_qtr3",
        "flag_qtr4",
        "category_trend",
        "tpr_discount_byppg_lag1",
        "tpr_discount_byppg_lag2",
        "monthno",
    ]
    own_effects_coeff = [
        "wk_sold_median_base_price_byppg_log",
        "tpr_discount_byppg",
        "ACV_Feat_Only",
        "ACV_Disp_Only",
        "ACV_Feat_Disp",
        "ACV_Selling",
        "flag_qtr2",
        "flag_qtr3",
        "flag_qtr4",
        "category_trend",
        "tpr_discount_byppg_lag1",
        "tpr_discount_byppg_lag2",
        "monthno",
    ]

    if len(model_coef_final) < 2 or model_coef_final is None:
        comp_effects_cols = [
            col for col in model_coef_final if col not in own_effects_cols
        ]
        # train_df = train_df[own_effects_cols]
        # temp_2b = temp_2b[own_effects_cols]
    else:
        comp_effects_cols = [
            col for col in model_coef_final if col not in own_effects_cols
        ]
        # train_df = train_df[own_effects_cols+[col for col in train_df.columns.to_list() if col in comp_effects_cols]]
        # temp_2b = temp_2b[own_effects_cols+[col for col in temp_2b.columns.to_list() if col in actionppg]]

    # model_coef_final = own_effects_coeff+[col for col in model_coef_final if col not in own_effects_coeff]
    model_coef_final = own_effects_cols + [
        col for col in train_df.columns.to_list() if col in comp_effects_cols
    ]
    return model_coef_final


def select_features_for_bayesian_model(
    ppg, temp_2, model_df_1, model_base_df_1, base_model_results, hist_model_results
):
    """Select features for Price elasticity modelling by Bayesian regression.

    Parameters
    ----------
    ppg : str
        PPG
    temp_2 : pd.DataFrame
        Dataframe consisting of IDVs and DV of selected PPG
    model_df_1 : pd.DataFrame
        Dataframe consisting of IDVs and DV of all PPGs
    model_base_df_1 : pd.DataFrame
        Dataframe consisting of base price information
    base_model_results : pd.DataFrame
        Dataframe consisting of coefficients of base model
    hist_model_results : pd.DataFrame
        Dataframe consisting of coefficients of models built after the base model

    Returns
    -------
    list of str
    """
    # Initialization
    features_count = 3  # Threshold to consider features in final model
    model_coefficients_base_1 = base_model_results
    (
        model_results_lasso_3,
        model_results_lasso_2,
        model_results_lasso_1,
        model_results_lasso_0,
    ) = hist_model_results
    # Temporary
    # temp_2b = temp_2
    # model_df_2 = model_df_1

    ppg_model_coef_base = model_coefficients_base_1.loc[
        model_coefficients_base_1["PPG_Item_No"] == ppg,
        ["model_coefficient_name", "model_coefficient_value"],
    ]
    ppg_model_coef_lasso_0 = model_results_lasso_0.loc[
        model_results_lasso_0["PPG_Item_No"] == ppg,
        ["model_coefficient_name", "model_coefficient_value"],
    ]
    ppg_model_coef_lasso_1 = model_results_lasso_1.loc[
        model_results_lasso_1["PPG_Item_No"] == ppg,
        ["model_coefficient_name", "model_coefficient_value"],
    ]
    ppg_model_coef_lasso_2 = model_results_lasso_2.loc[
        model_results_lasso_2["PPG_Item_No"] == ppg,
        ["model_coefficient_name", "model_coefficient_value"],
    ]
    ppg_model_coef_lasso_3 = model_results_lasso_3.loc[
        model_results_lasso_3["PPG_Item_No"] == ppg,
        ["model_coefficient_name", "model_coefficient_value"],
    ]

    ppg_model_coef_base = ppg_model_coef_base[
        ppg_model_coef_base["model_coefficient_name"] != "(Intercept)"
    ]
    ppg_model_coef_lasso_0 = ppg_model_coef_lasso_0[
        ppg_model_coef_lasso_0["model_coefficient_name"] != "(Intercept)"
    ]
    ppg_model_coef_lasso_1 = ppg_model_coef_lasso_1[
        ppg_model_coef_lasso_1["model_coefficient_name"] != "(Intercept)"
    ]
    ppg_model_coef_lasso_2 = ppg_model_coef_lasso_2[
        ppg_model_coef_lasso_2["model_coefficient_name"] != "(Intercept)"
    ]
    ppg_model_coef_lasso_3 = ppg_model_coef_lasso_3[
        ppg_model_coef_lasso_3["model_coefficient_name"] != "(Intercept)"
    ]

    # Remove TPR features if there is no TPR weeks
    if len(temp_2[temp_2["tpr_discount_byppg"] > 0]) == 0:
        ppg_model_coef_base = ppg_model_coef_base[
            ~ppg_model_coef_base["model_coefficient_name"].str.contains(
                "tpr_discount_byppg", regex=False
            )
        ]
        ppg_model_coef_lasso_0 = ppg_model_coef_lasso_0[
            ~ppg_model_coef_lasso_0["model_coefficient_name"].str.contains(
                "tpr_discount_byppg", regex=False
            )
        ]
        ppg_model_coef_lasso_1 = ppg_model_coef_lasso_1[
            ~ppg_model_coef_lasso_1["model_coefficient_name"].str.contains(
                "tpr_discount_byppg", regex=False
            )
        ]
        ppg_model_coef_lasso_2 = ppg_model_coef_lasso_2[
            ~ppg_model_coef_lasso_2["model_coefficient_name"].str.contains(
                "tpr_discount_byppg", regex=False
            )
        ]
        ppg_model_coef_lasso_3 = ppg_model_coef_lasso_3[
            ~ppg_model_coef_lasso_3["model_coefficient_name"].str.contains(
                "tpr_discount_byppg", regex=False
            )
        ]
    if len(temp_2[temp_2["tpr_discount_byppg_lag1"] > 0]) == 0:
        ppg_model_coef_base = ppg_model_coef_base[
            ~ppg_model_coef_base["model_coefficient_name"].str.contains(
                "tpr_discount_byppg_lag1", regex=False
            )
        ]
        ppg_model_coef_lasso_0 = ppg_model_coef_lasso_0[
            ~ppg_model_coef_lasso_0["model_coefficient_name"].str.contains(
                "tpr_discount_byppg_lag1", regex=False
            )
        ]
        ppg_model_coef_lasso_1 = ppg_model_coef_lasso_1[
            ~ppg_model_coef_lasso_1["model_coefficient_name"].str.contains(
                "tpr_discount_byppg_lag1", regex=False
            )
        ]
        ppg_model_coef_lasso_2 = ppg_model_coef_lasso_2[
            ~ppg_model_coef_lasso_2["model_coefficient_name"].str.contains(
                "tpr_discount_byppg_lag1", regex=False
            )
        ]
        ppg_model_coef_lasso_3 = ppg_model_coef_lasso_3[
            ~ppg_model_coef_lasso_3["model_coefficient_name"].str.contains(
                "tpr_discount_byppg_lag1", regex=False
            )
        ]
    if len(temp_2[temp_2["tpr_discount_byppg_lag2"] > 0]) == 0:
        ppg_model_coef_base = ppg_model_coef_base[
            ~ppg_model_coef_base["model_coefficient_name"].str.contains(
                "tpr_discount_byppg_lag2", regex=False
            )
        ]
        ppg_model_coef_lasso_0 = ppg_model_coef_lasso_0[
            ~ppg_model_coef_lasso_0["model_coefficient_name"].str.contains(
                "tpr_discount_byppg_lag2", regex=False
            )
        ]
        ppg_model_coef_lasso_1 = ppg_model_coef_lasso_1[
            ~ppg_model_coef_lasso_1["model_coefficient_name"].str.contains(
                "tpr_discount_byppg_lag2", regex=False
            )
        ]
        ppg_model_coef_lasso_2 = ppg_model_coef_lasso_2[
            ~ppg_model_coef_lasso_2["model_coefficient_name"].str.contains(
                "tpr_discount_byppg_lag2", regex=False
            )
        ]
        ppg_model_coef_lasso_3 = ppg_model_coef_lasso_3[
            ~ppg_model_coef_lasso_3["model_coefficient_name"].str.contains(
                "tpr_discount_byppg_lag2", regex=False
            )
        ]

    # Remove EDLP feature if the EDLP variance is low
    if (
        model_base_df_1.loc[
            model_base_df_1["tpr_discount_byppg"] == 0, "wk_sold_avg_price_byppg"
        ].var(skipna=True)
        < 0.001
    ):
        ppg_model_coef_base = ppg_model_coef_base[
            ppg_model_coef_base["model_coefficient_name"]
            != "wk_sold_median_base_price_byppg_log"
        ]
        ppg_model_coef_lasso_0 = ppg_model_coef_lasso_0[
            ppg_model_coef_lasso_0["model_coefficient_name"]
            != "wk_sold_median_base_price_byppg_log"
        ]
        ppg_model_coef_lasso_1 = ppg_model_coef_lasso_1[
            ppg_model_coef_lasso_1["model_coefficient_name"]
            != "wk_sold_median_base_price_byppg_log"
        ]
        ppg_model_coef_lasso_2 = ppg_model_coef_lasso_2[
            ppg_model_coef_lasso_2["model_coefficient_name"]
            != "wk_sold_median_base_price_byppg_log"
        ]
        ppg_model_coef_lasso_3 = ppg_model_coef_lasso_3[
            ppg_model_coef_lasso_3["model_coefficient_name"]
            != "wk_sold_median_base_price_byppg_log"
        ]

    # Remove ACV_Selling feature if ACV variance is low
    if temp_2["ACV_Selling"].var(skipna=True) < 0.001:
        ppg_model_coef_base = ppg_model_coef_base[
            ppg_model_coef_base["model_coefficient_name"] != "ACV_Selling"
        ]
        ppg_model_coef_lasso_0 = ppg_model_coef_lasso_0[
            ppg_model_coef_lasso_0["model_coefficient_name"] != "ACV_Selling"
        ]
        ppg_model_coef_lasso_1 = ppg_model_coef_lasso_1[
            ppg_model_coef_lasso_1["model_coefficient_name"] != "ACV_Selling"
        ]
        ppg_model_coef_lasso_2 = ppg_model_coef_lasso_2[
            ppg_model_coef_lasso_2["model_coefficient_name"] != "ACV_Selling"
        ]
        ppg_model_coef_lasso_3 = ppg_model_coef_lasso_3[
            ppg_model_coef_lasso_3["model_coefficient_name"] != "ACV_Selling"
        ]

    # If the base model is not available for the PPG, shift base to the next immediate
    if len(ppg_model_coef_base) > 0:
        base_change = 0
    elif len(ppg_model_coef_lasso_3) > 0:
        ppg_model_coef_base = ppg_model_coef_lasso_3.copy()
        base_change = 1
    elif len(ppg_model_coef_lasso_2) > 0:
        ppg_model_coef_base = ppg_model_coef_lasso_2.copy()
        base_change = 1
    elif len(ppg_model_coef_lasso_1) > 0:
        ppg_model_coef_base = ppg_model_coef_lasso_1.copy()
        base_change = 1
    else:
        ppg_model_coef_base = ppg_model_coef_lasso_0.copy()
        base_change = 1

    # Create df for feature frequency across last 3 and current quarter
    model_coef_freq = pd.concat(
        (
            ppg_model_coef_lasso_0,
            ppg_model_coef_lasso_1,
            ppg_model_coef_lasso_2,
            ppg_model_coef_lasso_3,
        ),
        axis=0,
        ignore_index=True,
    )
    if base_change == 0:
        model_coef_avg = model_coef_freq.append(ppg_model_coef_base, ignore_index=True)
    else:
        model_coef_avg = model_coef_freq.copy()

    # Handle directionality of unbounded features
    inter_features = model_coef_avg.loc[
        model_coef_avg["model_coefficient_name"].str.contains(
            "ITEM.*ITEM.*", regex=True
        ),
        "model_coefficient_name",
    ].unique()
    flag_qtr_features = model_coef_avg.loc[
        model_coef_avg["model_coefficient_name"].str.contains("flag_qtr", regex=False),
        "model_coefficient_name",
    ].unique()
    month_feature = model_coef_avg.loc[
        model_coef_avg["model_coefficient_name"].str.contains("monthno", regex=False),
        "model_coefficient_name",
    ].unique()
    category_feature = model_coef_avg.loc[
        model_coef_avg["model_coefficient_name"].str.contains(
            "category_trend", regex=False
        ),
        "model_coefficient_name",
    ].unique()
    unbounded_features = (
        inter_features.tolist()
        + flag_qtr_features.tolist()
        + month_feature.tolist()
        + category_feature.tolist()
    )

    model_coef_unbnd = model_coef_avg[
        model_coef_avg["model_coefficient_name"].isin(unbounded_features)
    ]
    if len(model_coef_unbnd) > 0:
        model_coef_unbnd["Pos"] = model_coef_unbnd["model_coefficient_value"].apply(
            lambda x: "neg" if x < 0 else "pos"
        )
        model_coef_unbnd_avg = model_coef_unbnd.groupby(
            by=["model_coefficient_name", "Pos"], as_index=False
        ).agg({"model_coefficient_value": [np.mean, np.std, len]})
        model_coef_unbnd_avg.columns = [
            i + "_" + j for i, j in model_coef_unbnd_avg.columns
        ]
        model_coef_unbnd_avg.columns = [
            "model_coefficient_name",
            "Pos",
            "model_coefficient_value",
            "model_coefficient_std",
            "model_coefficient_value_len",
        ]
        model_coef_dir = model_coef_unbnd_avg.pivot_table(
            values="model_coefficient_value_len",
            index="model_coefficient_name",
            columns="Pos",
            aggfunc=sum,
            fill_value=0,
            dropna=False,
        ).reset_index()
        if "neg" not in model_coef_dir.columns:
            model_coef_dir["neg"] = 0
        elif "pos" not in model_coef_dir.columns:
            model_coef_dir["pos"] = 0
        model_coef_dir["dir"] = model_coef_dir.apply(
            lambda x: "pos" if x["pos"] > x["neg"] else "neg", axis=1
        )
        model_coef_dir.loc[
            model_coef_dir["pos"] == model_coef_dir["neg"], "dir"
        ] = "equal"
        model_coef_unbnd_avg = model_coef_dir[["model_coefficient_name", "dir"]].merge(
            model_coef_unbnd_avg, how="inner", on="model_coefficient_name"
        )

        equal_count = model_coef_unbnd_avg.loc[
            model_coef_unbnd_avg["dir"] == "equal", "model_coefficient_name"
        ].unique()
        if len(equal_count) > 0:
            equal_count_coef = model_coef_unbnd[
                model_coef_unbnd["model_coefficient_name"].isin(equal_count)
            ]
            equal_count_coef = equal_count_coef.drop_duplicates(
                subset=["model_coefficient_name"], ignore_index=True
            )
            equal_count_coef["model_coefficient_std"] = equal_count_coef[
                "model_coefficient_value"
            ]
            equal_count_coef = equal_count_coef.drop(columns=["Pos"])

        model_coef_unbnd_avg_2 = model_coef_unbnd_avg[
            model_coef_unbnd_avg["dir"] == model_coef_unbnd_avg["Pos"]
        ]
        model_coef_unbnd_avg_2 = model_coef_unbnd_avg_2.drop(
            columns=["dir", "Pos", "model_coefficient_value_len"]
        )
        if len(equal_count) > 0:
            model_coef_unbnd_avg_2 = model_coef_unbnd_avg_2.append(
                equal_count_coef, ignore_index=True
            )

    # Calculate average values of 5 lasso model
    model_coef_prior_avg = model_coef_avg.groupby(
        by=["model_coefficient_name"], as_index=False
    ).agg({"model_coefficient_value": [np.mean, np.std]})
    model_coef_prior_avg.columns = [
        i + (("_" + j) if j != "" else j) for i, j in model_coef_prior_avg.columns
    ]
    model_coef_prior_avg.columns = [
        "model_coefficient_name",
        "model_coefficient_value",
        "model_coefficient_std",
    ]
    model_coef_prior_avg = model_coef_prior_avg[
        ~model_coef_prior_avg["model_coefficient_name"].isin(unbounded_features)
    ]
    if len(model_coef_unbnd) > 0 and len(model_coef_unbnd_avg_2) > 0:
        model_coef_prior_avg = model_coef_prior_avg.append(
            model_coef_unbnd_avg_2, ignore_index=True
        )

    # Calculate feature frequency in all 4 lasso models
    model_coefficients_Acting = (
        model_coef_freq.groupby(by=["model_coefficient_name"], as_index=False)
        .agg({"model_coefficient_value": len})
        .rename(columns={"model_coefficient_value": "cnt"})
    )
    model_coef_addition = model_coefficients_Acting.loc[
        (model_coefficients_Acting["cnt"] >= features_count)
        & (model_coefficients_Acting["model_coefficient_name"] != "(Intercept)"),
        ["model_coefficient_name"],
    ]
    model_coefficients_extra = model_coef_addition[
        ~model_coef_addition["model_coefficient_name"].isin(
            ppg_model_coef_base["model_coefficient_name"]
        )
    ]

    # Remove features from base model
    ppg_model_coef_base = ppg_model_coef_base[
        ppg_model_coef_base["model_coefficient_name"].isin(
            model_coefficients_Acting["model_coefficient_name"]
        )
    ]
    ppg_model_coef_base = ppg_model_coef_base.drop(columns=["model_coefficient_value"])
    model_coef_prior_names = ppg_model_coef_base.append(
        model_coefficients_extra, ignore_index=False
    )
    if len(model_coef_prior_names) < 1:
        model_coef_prior = ppg_model_coef_lasso_0.copy()
        model_coef_prior["model_coefficient_std"] = model_coef_prior[
            "model_coefficient_value"
        ]
    else:
        model_coef_prior = model_coef_prior_avg[
            model_coef_prior_avg["model_coefficient_name"].isin(
                model_coef_prior_names["model_coefficient_name"]
            )
        ]
    model_coef_prior.loc[
        model_coef_prior["model_coefficient_std"].isna(), "model_coefficient_std"
    ] = model_coef_prior.loc[
        model_coef_prior["model_coefficient_std"].isna(), "model_coefficient_value"
    ]

    # Force EDLP and TPR coefficients in prior
    # if "wk_sold_median_base_price_byppg_log" not in model_coef_prior["model_coefficient_name"]:
    #     temp_prior = {"model_coefficient_name": "wk_sold_median_base_price_byppg_log",
    #                   "model_coefficient_value": -0.1,
    #                   "model_coefficient_std": 0.1}
    #     model_coef_prior = model_coef_prior.append(temp_prior, ignore_index=True)
    # if ("tpr_discount_byppg" not in model_coef_prior["model_coefficient_name"]) and len(model_ppg_1[model_ppg_1["tpr_discount_byppg"]!=0])>0:
    #     temp_prior = {"model_coefficient_name": "tpr_discount_byppg",
    #                   "model_coefficient_value": -0.1,
    #                   "model_coefficient_std": 0.1}
    #     model_coef_prior = model_coef_prior.append(temp_prior, ignore_index=True)
    # if temp_2["Low_variance_flag"].sum()>0:
    #     model_coef_prior = model_coef_prior[model_coef_prior["model_coefficient_name"]!="wk_sold_median_base_price_byppg_log"]
    # if temp_2["ACV_Selling"].sum()>0:
    #     model_coef_prior = model_coef_prior[model_coef_prior["model_coefficient_name"]!="ACV_Selling"]

    model_coefficients_final = model_coef_prior.loc[
        ~model_coef_prior["model_coefficient_name"].isin(["(Intercept)", "Intercept"]),
        "model_coefficient_name",
    ]
    model_coefficients_final = model_coefficients_final.unique().tolist()
    actionppg = [var for var in model_coefficients_final]  # if ppg not in var
    return (
        ["Date", "PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
        + model_coefficients_final,
        model_coef_prior,
    )

    # Create a dataset for the final model with features selected by all lasso model
    # temp_2 = temp_2[["Date","PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description","DV"] + [col for col in temp_2.columns if col in actionppg]]
    # temp_2b = temp_2b[["Date","PPG_Cat","PPG_MFG","PPG_Item_No","PPG_Description","DV"] + [col for col in temp_2b.columns if col in actionppg]]

    # # Add acting items forcibly
    # extra_features = [var for var in actionppg if var not in temp_2.columns]
    # extra_edlp = [var for var in extra_features if re.search("ITEM.*RegularPrice",var) is not None]
    # extra_edlp = [re.sub("_RegularPrice","",var) for var in extra_edlp]
    # extra_tpr = [var for var in extra_features if re.search("ITEM.*PromotedDiscount",var) is not None]
    # extra_tpr = [re.sub("_PromotedDiscount","",var) for var in extra_tpr]

    # temp_1_edlp = model_df_1[model_df_1["PPG_Item_No"].isin(extra_edlp)]
    # temp_1_edlp = temp_1_edlp[["PPG_Item_No","Date","wk_sold_median_base_price_byppg_log"]]
    # temp_2_edlp = model_df_2[model_df_2["PPG_Item_No"].isin(extra_edlp)]
    # temp_2_edlp = temp_2_edlp[["PPG_Item_No","Date","wk_sold_median_base_price_byppg_log"]]
    # if len(temp_1_edlp)>0:
    #     acting_item_edlp_1 = temp_1_edlp.pivot_table(values="wk_sold_median_base_price_byppg_log", index="Date", columns="PPG_Item_No", fill_value=0, dropna=True)
    #     acting_item_edlp_1.columns = [col+"_RegularPrice" for col in acting_item_edlp_1.columns]
    #     acting_item_edlp_1 = acting_item_edlp_1.reset_index()
    #     temp_2 = temp_2.merge(acting_item_edlp_1, how="left", on="Date")

    #     acting_item_edlp_2 = temp_2_edlp.pivot_table(values="wk_sold_median_base_price_byppg_log", index="Date", columns="PPG_Item_No", fill_value=0, dropna=True)
    #     acting_item_edlp_2.columns = [col+"_RegularPrice" for col in acting_item_edlp_2.columns]
    #     acting_item_edlp_2 = acting_item_edlp_2.reset_index()
    #     temp_2b = temp_2b.merge(acting_item_edlp_2, how="left", on="Date")

    # temp_1_tpr = model_df_1[model_df_1["PPG_Item_No"].isin(extra_tpr)]
    # temp_1_tpr = temp_1_tpr[["PPG_Item_No","Date","tpr_discount_byppg"]]
    # temp_2_tpr = model_df_2[model_df_2["PPG_Item_No"].isin(extra_tpr)]
    # temp_2_tpr = temp_2_tpr[["PPG_Item_No","Date","tpr_discount_byppg"]]
    # tpr_summary = temp_1_tpr.groupby(by=["PPG_Item_No"], as_index=False).agg({"tpr_discount_byppg": np.sum})
    # tpr_summary.rename(columns={"tpr_discount_byppg": "tpr_sum"}, inplace=True)
    # acting_items_wo_tpr = tpr_summary.loc[tpr_summary["tpr_sum"]==0,"PPG_Item_No"].to_list()
    # temp_1_tpr = temp_1_tpr[~temp_1_tpr["PPG_Item_No"].isin(acting_items_wo_tpr)]
    # temp_2_tpr = temp_2_tpr[~temp_2_tpr["PPG_Item_No"].isin(acting_items_wo_tpr)]
    # if len(temp_1_tpr)>0:
    #     acting_item_tpr_1 = temp_1_tpr.pivot_table(values="tpr_discount_byppg", index="Date", columns="PPG_Item_No", fill_value=0, dropna=True)
    #     acting_item_tpr_1.columns = [col+"_PromotedDiscount" for col in acting_item_tpr_1.columns]
    #     acting_item_tpr_1 = acting_item_tpr_1.reset_index()
    #     temp_2 = temp_2.merge(acting_item_tpr_1, how="left", on="Date")

    #     acting_item_tpr_2 = temp_1_tpr.pivot_table(values="tpr_discount_byppg", index="Date", columns="PPG_Item_No", fill_value=0, dropna=True)
    #     acting_item_tpr_2.columns = [col+"_PromotedDiscount" for col in acting_item_tpr_2.columns]
    #     acting_item_tpr_2 = acting_item_tpr_2.reset_index()
    #     temp_2b = temp_2b.merge(acting_item_tpr_2, how="left", on="Date")

    # # Remove acting items with cumulative TPR = 0
    # if len(acting_items_wo_tpr)>0:
    #     acting_items_wo_tpr = [ppg+"_PromotedDiscount" for ppg in acting_items_wo_tpr]
    #     model_coef_prior = model_coef_prior[~model_coef_prior["model_coefficient_name"].isin(acting_items_wo_tpr)]
    #     model_coefficients_final = model_coef_prior["model_coefficient_name"].unique()

    # # Add Interactions forcibly
    # extra_tpr_interaction = [var for var in model_coefficients_final if re.search(".*PromotedDiscount.*PromotedDiscount",var) is not None]
    # extra_tpr_interaction = [re.sub("_PromotedDiscount","",var) for var in extra_tpr_interaction]
    # extra_tpr_interaction = [re.sub(ppg+"_","",var) for var in extra_tpr_interaction]
    # extra_tpr_interaction = [re.sub("_"+ppg,"",var) for var in extra_tpr_interaction]
    # extra_rp_interaction = [var for var in model_coefficients_final if re.search(".*RegularPrice.*RegularPrice",var) is not None]
    # extra_rp_interaction = [re.sub("_RegularPrice","",var) for var in extra_rp_interaction]
    # extra_rp_interaction = [re.sub(ppg+"_","",var) for var in extra_rp_interaction]
    # extra_rp_interaction = [re.sub("_"+ppg,"",var) for var in extra_rp_interaction]

    # TPR_Interaction = [var for var in extra_tpr_interaction if len(model_df_1[model_df_1["PPG_Item_No"].str.contains(var)])>0]
    # RP_Interaction = [var for var in extra_rp_interaction if len(model_df_1[model_df_1["PPG_Item_No"].str.contains(var)])>0]
    # TotalInteraction = [var+"_PromotedDiscount" for var in TPR_Interaction]+[var+"_RegularPrice" for var in RP_Interaction]
    # # TotalInteraction=TotalInteraction[regexpr("_",TotalInteraction)>1]


@pf.register_dataframe_method
def append_similar_ppg_data(
    df,
    ppg: str,
    brand_col: str,
    pack_size_col: str,
    price_col: str,
    PPG: List,
    model_df: pd.DataFrame,
):
    """Select similar PPGs for a given PPG and appends the data-points to that of the given PPG."""
    slct_ppg = ppg  # df["PPG_Item_No"].unique()[0]

    # Identify similar PPGs based on following criteria
    # Brand criteria
    ppg_brand = model_df.loc[model_df["PPG_Item_No"] == slct_ppg, brand_col].unique()
    ppg_brand_list = model_df.loc[
        (model_df[brand_col].isin(ppg_brand))
        & (model_df["PPG_Item_No"].isin(PPG) | model_df["PPG_Item_No"] == slct_ppg),
        "PPG_Item_No",
    ].unique()

    # Pack size criteria (within +/- 10%)
    ppg_pack_size = model_df.loc[
        model_df["PPG_Item_No"] == slct_ppg, pack_size_col
    ].mean()
    ppg_pack_size_list = model_df.loc[
        (model_df[pack_size_col] < (1.1 * ppg_pack_size))
        & (model_df[pack_size_col] > (0.9 * ppg_pack_size))
        & (model_df["PPG_Item_No"].isin(PPG) | model_df["PPG_Item_No"] == slct_ppg),
        "PPG_Item_No",
    ].unique()
    ppg_pack_size_list_in_brand = [i for i in ppg_pack_size_list if i in ppg_brand_list]

    # Selling price criteria (within +/- 1 in Z score)
    ppg_mean_price = model_df.loc[model_df["PPG_Item_No"] == slct_ppg, price_col].mean()
    ppg_sd_price = model_df.loc[model_df["PPG_Item_No"] == slct_ppg, price_col].std()

    temp_1 = model_df[
        (model_df["PPG_Item_No"].isin(PPG)) | (model_df["PPG_Item_No"] == slct_ppg)
    ]
    temp_2 = temp_1.groupby(by=["PPG_Item_No", brand_col], as_index=False).agg(
        {price_col: np.mean}
    )
    temp_2 = temp_2.rename(columns={price_col: "mean_price"})
    temp_2["z_val"] = (temp_2["mean_price"] - ppg_mean_price) / ppg_sd_price

    ppg_price_list_1_sigma = temp_2.loc[
        (temp_2["z_val"] > (-1)) & (temp_2["z_val"] < 1), "PPG_Item_No"
    ].unique()
    ppg_price_list_1_sigma_in_brand = [
        i for i in ppg_price_list_1_sigma if i in ppg_brand_list
    ]

    # Add similar PPGs' datapoints to selected PPG
    if (len(ppg_price_list_1_sigma_in_brand) + len(ppg_pack_size_list_in_brand)) > 2:
        slct_ppg_model_df = model_df.loc[
            (model_df["PPG_Item_No"].isin(ppg_price_list_1_sigma_in_brand))
            | (model_df["PPG_Item_No"].isin(ppg_pack_size_list_in_brand))
        ].reset_index(drop=True)
    elif len(ppg_brand_list) > 1:
        slct_ppg_model_df = model_df.loc[
            model_df["PPG_Item_No"].isin(ppg_brand_list)
        ].reset_index(drop=True)
    elif len(ppg_pack_size_list) > 1:
        slct_ppg_model_df = model_df.loc[
            model_df["PPG_Item_No"].isin(ppg_pack_size_list)
        ].reset_index(drop=True)
    elif len(ppg_price_list_1_sigma) > 1:
        slct_ppg_model_df = model_df.loc[
            model_df["PPG_Item_No"].isin(ppg_price_list_1_sigma)
        ].reset_index(drop=True)
    elif (
        model_df.loc[
            (model_df["PPG_Item_No"].isin(PPG)) | (model_df["PPG_Item_No"] == slct_ppg),
            "PPG_Item_No",
        ].nunique()
        < 20
    ):
        slct_ppg_model_df = model_df.loc[
            (model_df["PPG_Item_No"].isin(PPG)) | (model_df["PPG_Item_No"] == slct_ppg)
        ].reset_index(drop=True)
    else:
        return df

    return slct_ppg_model_df


# Base Volume Calculation
@pf.register_dataframe_method
def tpr_acv_smoothing(df):
    """Smoothen TPR ACV for Base volume estimation."""
    min_date = df["Date"].min()
    df["ACV_Selling"] = df.apply(
        lambda x: min(x["ACV_Selling"], x["median_acv_selling"])
        if x["tpr_discount_byppg"] != 0 and x["Date"] != min_date
        else x["ACV_Selling"],
        axis=1,
    )
    df["lead_acv_selling_1"] = df.groupby(by=["PPG_Item_No"])["ACV_Selling"].shift(-1)
    df["ACV_Selling"] = df.apply(
        lambda x: x["lead_acv_selling_1"]
        if x["tpr_discount_byppg"] != 0 and x["Date"] == min_date
        else x["ACV_Selling"],
        axis=1,
    )
    df["ACV_Selling"] = df.groupby("PPG_Item_No")["ACV_Selling"].fillna(method="bfill")
    df = df.drop(columns=["median_acv_selling", "lead_acv_selling_1"])

    return df


@pf.register_dataframe_method
def edlp_acv_smoothing(df):
    """Smoothen EDLP ACV for Base volume estimation."""
    num_lag = 7
    for i in np.arange(1, num_lag + 1):
        df["lag_acv_selling" + "_" + str(i)] = df.groupby("PPG_Item_No")[
            "ACV_Selling"
        ].shift(i, fill_value=None)

    lag_cols = ["lag_acv_selling" + "_" + str(i) for i in np.arange(1, num_lag + 1)]
    df["median_acv_selling"] = df[lag_cols].apply(np.nanmedian, axis=1)

    # Imputation
    df["median_acv_selling"] = df.groupby("PPG_Item_No")["median_acv_selling"].fillna(
        method="ffill"
    )

    df["Promotion"] = 1 - (df["wk_sold_avg_price_byppg"] / df["Final_baseprice"])
    temp_fil = df["Promotion"] > 0.04
    df.loc[temp_fil, "ACV_Selling"] = df.loc[
        temp_fil, ["ACV_Selling", "median_acv_selling"]
    ].min(axis=1)
    df = df.drop(columns=["Promotion"])
    df["ACV_Selling"] = df.groupby("PPG_Item_No")["ACV_Selling"].fillna(method="bfill")
    df = df.drop(columns=lag_cols + ["median_acv_selling"])

    return df


@pf.register_dataframe_method
def estimate_base_volume(
    df,
    ppg: str,
    model,
    box_matrix: pd.DataFrame,
    temp_2: pd.DataFrame,
    model_df: pd.DataFrame,
):
    """Get estimation of Base volume."""
    df = df[df["Date"].isin(temp_2["Date"])]
    df["pred_vol"] = np.exp(model.predict(box_matrix))

    # Compute Baseline Volume for Retailer PPGs
    if "_ROM" not in ppg:
        temp_box_matrix = box_matrix.copy().reset_index()

        # Set values
        if "wk_sold_median_base_price_byppg_log" in temp_box_matrix.columns:
            temp_box_matrix = temp_box_matrix.merge(
                df[["Date", "Final_baseprice"]].drop_duplicates(), how="left", on="Date"
            )
            # temp_box_matrix = temp_box_matrix.rename(columns={"Final_baseprice_y": "Final_baseprice"}).drop(columns=["Final_baseprice_x"])
            temp_box_matrix["Final_baseprice"] = temp_box_matrix[
                "Final_baseprice"
            ].astype(np.float64)
            temp_box_matrix["wk_sold_median_base_price_byppg_log"] = np.log(
                temp_box_matrix["Final_baseprice"]
            )
            temp_box_matrix = temp_box_matrix.drop(columns=["Final_baseprice"])
        if "tpr_discount_byppg" in temp_box_matrix.columns:
            temp_box_matrix["tpr_discount_byppg"] = 0
        if temp_box_matrix.columns.str.contains(
            ".*PromotedDiscount.*PromotedDiscount", regex=True
        ).any():
            temp_box_matrix.loc[
                :,
                temp_box_matrix.columns.str.contains(
                    ".*PromotedDiscount.*PromotedDiscount", regex=True
                ),
            ] = 0
        if temp_box_matrix.columns.str.contains(
            ".*RegularPrice.*RegularPrice", regex=True
        ).any():
            rp_interaction_cols = [
                col
                for col in temp_box_matrix.columns
                if re.search(".*RegularPrice.*RegularPrice", col) is not None
            ]
            for col in rp_interaction_cols:
                col_adj = re.sub(ppg, "", col)
                col_adj = re.sub("_RegularPrice_", "", col_adj)
                col_adj = re.sub("_RegularPrice", "", col_adj)
                temp_box_matrix = temp_box_matrix.merge(
                    df.loc[df["PPG_Item_No"] == ppg, ["Date", "Final_baseprice"]],
                    how="left",
                    on="Date",
                )
                temp = model_df.loc[
                    model_df["PPG_Item_No"] == col_adj,
                    ["Date", "wk_sold_median_base_price_byppg_log"],
                ]
                temp = temp.rename(
                    columns={"wk_sold_median_base_price_byppg_log": "wk_price_log"}
                )
                temp_box_matrix = temp_box_matrix.merge(
                    temp[["Date", "wk_price_log"]], how="left", on="Date"
                )
                temp_box_matrix[col] = (
                    np.log(temp_box_matrix["Final_baseprice"])
                    * temp_box_matrix["wk_price_log"]
                )
                temp_box_matrix = temp_box_matrix.drop(
                    columns=["Final_baseprice", "wk_price_log"]
                )
        if temp_box_matrix.columns.isin(
            ["ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp"]
        ).any():
            temp_box_matrix[
                [
                    col
                    for col in temp_box_matrix.columns
                    if col in ["ACV_Feat_Only", "ACV_Disp_Only", "ACV_Feat_Disp"]
                ]
            ] = 0
        if "ACV_Selling" in temp_box_matrix.columns:
            temp_box_matrix = temp_box_matrix.merge(
                df[["Date", "ACV_Selling"]].drop_duplicates(), how="left", on="Date"
            )
            temp_box_matrix = temp_box_matrix.rename(
                columns={"ACV_Selling_y": "ACV_Selling"}
            ).drop(columns=["ACV_Selling_x"])

        temp_box_matrix = temp_box_matrix.drop(columns=["Date"])
        base_volume = pd.DataFrame(
            np.exp(model.predict(temp_box_matrix)), columns=["Prediction"]
        )
        df["base_vol"] = base_volume["Prediction"]

    else:
        df["base_vol"] = np.exp(model.predict(box_matrix))

    return df


# Cannibalization Dollar Sales Calculation
def cannibalisation_module(
    ppg, model, box_matrix, model_coefficients, ppg_list_to_model, model_df_1
):
    """Compute cannibalisation in ``Dollar Sales``.

    Parameters
    ----------
    ppg : str
        Selected PPG to compute cannibalised sales
    model : Estimator class
        Elasticity model object to estimate cannibalised sales
    box_matrix : pd.DataFame
        pd.DataFrame consisting of IDVs and DV
    model_coefficients : pd.DataFrame
        DataFrame consisting of coefficients of elasticity model
    ppg_list_to_model : list of str
        PPGs selected for elasticity modelling
    model_df_1 : Estimator class
        Dataframe consisting of IDVs and DV

    Returns
    -------
    pd.DataFrame
    """
    # Pick cannibalizing PPG
    cannibal_ppg = model_coefficients.loc[
        model_coefficients["model_coefficient_name"].str.contains(
            "^(ITEM([0-9]|[a-z]|[A-Z])+)|([0-9]+)\\_Retailer"
        ),
        "model_coefficient_name",
    ]
    cannibal_ppg = cannibal_ppg[~cannibal_ppg.str.contains("\\_ROM")].to_list()
    cannibal_ppg = [
        col
        for col in cannibal_ppg
        if re.sub("(\\_RegularPrice)|(\\_PromotedDiscount)", "", col)
        in ppg_list_to_model
    ]

    # Pick pantry variables
    model_coefficients_check_pantry = model_coefficients[
        (
            model_coefficients["model_coefficient_name"].isin(
                ["tpr_discount_byppg_lag1", "tpr_discount_byppg_lag2"]
            )
        )
        & (model_coefficients["model_coefficient_value"] < 0)
    ]

    # Initialization
    cannibal_vol = []
    ppg_measure = None
    model_cannibal_df = pd.DataFrame(
        columns=["Cannibal_PPG", "Cannibalised_PPG", "Measure", "Date", "Cannibal_Doll"]
    )
    pred_vol = np.exp(model.predict(box_matrix))

    # Cannibalisation Qty. due to TPR and EDLP effects
    for i in cannibal_ppg:
        i_adj = re.sub("(_RegularPrice)|(_PromotedDiscount)", "", i)
        temp_box_matrix = box_matrix.copy().reset_index()
        if "_PromotedDiscount" in i:
            temp_box_matrix[i] = 0
            temp_box_matrix = temp_box_matrix.set_index("Date")
            cannibal_vol = np.exp(model.predict(temp_box_matrix[box_matrix.columns]))
            ppg_measure = "Promoted Discount"
        else:
            temp_box_matrix = temp_box_matrix.merge(
                model_df_1.loc[
                    model_df_1["PPG_Item_No"]
                    == re.sub("_(PromotedDiscount|RegularPrice)", "", i),
                    ["Date", "Final_baseprice"],
                ],
                how="left",
                on="Date",
            )
            temp_box_matrix[i] = np.log(temp_box_matrix["Final_baseprice"])
            temp_box_matrix = temp_box_matrix.drop(columns=["Final_baseprice"])
            temp_box_matrix = temp_box_matrix.set_index("Date")
            cannibal_vol = np.exp(model.predict(temp_box_matrix[box_matrix.columns]))
            ppg_measure = "Regular Price"
        temp_cannibal = model_df_1[model_df_1["PPG_Item_No"] == ppg]
        cannibal_vol = (cannibal_vol - pred_vol) * temp_cannibal.loc[
            temp_cannibal["Date"].isin(temp_box_matrix.index), "wk_sold_avg_price_byppg"
        ].to_numpy()
        cannibal_vol = [i if i > 0 else 0 for i in cannibal_vol]
        temp_1 = pd.DataFrame(
            {
                "Cannibal_PPG": [i_adj] * len(temp_box_matrix),
                "Cannibalised_PPG": [ppg] * len(temp_box_matrix),
                "Measure": [ppg_measure] * len(temp_box_matrix),
                "Date": temp_box_matrix.index,
                "Cannibal_Doll": cannibal_vol,
            }
        )
        model_cannibal_df = model_cannibal_df.append(temp_1, ignore_index=True)

    # Cannibalisation Qty. due to Pantry Loading
    if len(model_coefficients_check_pantry) > 0 and ("_ROM" not in ppg):
        pred_vol = np.exp(model.predict(box_matrix))
        temp_box_matrix = box_matrix.copy()

        # TPR - Lag 1
        if "tpr_discount_byppg_lag1" in temp_box_matrix.columns:
            temp_box_matrix["tpr_discount_byppg_lag1"] = 0
            cannibal_vol = np.exp(model.predict(temp_box_matrix[box_matrix.columns]))
            temp_cannibal = model_df_1[model_df_1["PPG_Item_No"] == ppg]
            cannibal_vol = (cannibal_vol - pred_vol) * temp_cannibal.loc[
                temp_cannibal["Date"].isin(temp_box_matrix.index),
                "wk_sold_avg_price_byppg",
            ].to_numpy()
            cannibal_vol = [i if i > 0 else 0 for i in cannibal_vol]
        else:
            cannibal_vol = [0] * len(temp_box_matrix)
            # temp_box_matrix = temp_box_matrix.set_index("Date")
        ppg_measure = "Pantry Loading 1"
        cannibal_vol = np.append(cannibal_vol[1:], [0])  # TODO - Check with the NPP
        temp_1 = pd.DataFrame(
            {
                "Cannibal_PPG": [ppg] * len(temp_box_matrix),
                "Cannibalised_PPG": [ppg] * len(temp_box_matrix),
                "Measure": [ppg_measure] * len(temp_box_matrix),
                "Date": temp_box_matrix.index,
                "Cannibal_Doll": cannibal_vol,
            }
        )
        model_cannibal_df = model_cannibal_df.append(temp_1, ignore_index=True)
        del temp_1

        # TPR - Lag 2
        temp_box_matrix = box_matrix.copy()
        if "tpr_discount_byppg_lag2" in temp_box_matrix.columns:
            temp_box_matrix["tpr_discount_byppg_lag2"] = 0
            cannibal_vol = np.exp(model.predict(temp_box_matrix[box_matrix.columns]))
            temp_cannibal = model_df_1[model_df_1["PPG_Item_No"] == ppg]
            cannibal_vol = (cannibal_vol - pred_vol) * temp_cannibal.loc[
                temp_cannibal["Date"].isin(temp_box_matrix.index),
                "wk_sold_avg_price_byppg",
            ].to_numpy()
            cannibal_vol = [i if i > 0 else 0 for i in cannibal_vol]
        else:
            cannibal_vol = [0] * len(temp_box_matrix)
        ppg_measure = "Pantry Loading 2"
        cannibal_vol = np.append(cannibal_vol[2:], [0, 0])  # TODO - Check with the NPP
        temp_1 = pd.DataFrame(
            {
                "Cannibal_PPG": [ppg] * len(temp_box_matrix),
                "Cannibalised_PPG": [ppg] * len(temp_box_matrix),
                "Measure": [ppg_measure] * len(temp_box_matrix),
                "Date": temp_box_matrix.index,
                "Cannibal_Doll": cannibal_vol,
            }
        )
        model_cannibal_df = model_cannibal_df.append(temp_1, ignore_index=True)
        del temp_1

        model_cannibal_df = model_cannibal_df[model_cannibal_df["Cannibal_Doll"] > 0]

    return model_cannibal_df


# Cross Validation
def cross_validation(
    ppg, box_matrix, temp_2, temporary_df, lwr_bound=None, upr_bound=None
):
    """Perform 5-fold cross-validation.

    Parameters
    ----------
    ppg : str
        Selected PPG to perform cross-validation
    box_matrix : pd.DataFame
        pd.DataFrame consisting of IDVs and DV
    temp_2 : pd.DataFame
        pd.DataFrame consisting of IDVs and DV. Additionally, contains few identifiers.
    temporary_df : pd.DataFrame
        pd.DataFrame consisting of TPR weeks
    lwr_bound : list of int
        Lower bound for model coefficient
    upr_bound : list of int
        Upper bound for model coefficient

    Returns
    -------
    pd.DataFrame
    """
    box_matrix = box_matrix.merge(
        temporary_df, how="left", left_index=True, right_index=True
    )  # Gets DV and tpr_temp column
    box_matrix["tpr_flag"] = box_matrix["tpr_temp"] > 0

    random.seed(123)
    skf = StratifiedKFold(n_splits=5)
    folds = [
        (train_index, test_index)
        for train_index, test_index in skf.split(
            box_matrix.drop(columns=["tpr_flag"]), box_matrix["tpr_flag"]
        )
    ]
    model_results_cv = pd.DataFrame([])
    for fold in range(5):
        train_index = folds[fold][0]
        test_index = folds[fold][1]
        train_data = box_matrix.iloc[train_index]
        test_data = box_matrix.iloc[test_index]

        train_data_edlp = train_data[train_data["tpr_temp"] == 0]
        train_data_tpr = train_data[train_data["tpr_temp"] > 0]
        test_data_edlp = test_data[test_data["tpr_temp"] == 0]
        test_data_tpr = test_data[test_data["tpr_temp"] > 0]

        temp_cols = train_data.drop(
            columns=["DV", "tpr_flag", "tpr_temp"]
        ).columns.to_list()
        ppg_adj = (
            re.sub("_ROM", "_Retailer", ppg)
            if "_ROM" in ppg
            else re.sub("_Retailer", "_ROM", ppg)
        )
        pen_factor = [
            col != "wk_sold_median_base_price_byppg_log"
            and col != "tpr_discount_byppg"
            and col != "tpr_discount_byppg_lag1"
            and col != "tpr_discount_byppg_lag2"
            and col != ppg_adj
            for col in temp_cols
        ]
        if sum(pen_factor) > 0:
            model = CustomSKLLassoCV(
                max_iter=10 ** 5, cv=10, random_state=123, selection="random"
            )
            model.fit(train_data[temp_cols], train_data["DV"])
        else:
            model = CustomSKLLassoCV(
                max_iter=10 ** 5, cv=10, random_state=123, selection="random"
            )
            model.fit(train_data[temp_cols], train_data["DV"])

        train_set_vol = pd.DataFrame(
            {
                "PPG_Item_No": [ppg] * len(train_data.index),
                "Date": train_data.index,
                "Pred": np.exp(model.predict(train_data[temp_cols])),
            },
        ).set_index("Date")
        test_set_vol = pd.DataFrame(
            {
                "PPG_Item_No": [ppg] * len(test_data.index),
                "Date": test_data.index,
                "Pred": np.exp(model.predict(test_data[temp_cols])),
            }
        ).set_index("Date")
        train_MAPE = mean_absolute_error(
            np.array([1] * len(train_data["DV"])),
            train_set_vol["Pred"] / np.exp(train_data["DV"]),
        )
        test_MAPE = mean_absolute_error(
            np.array([1] * len(test_data["DV"])),
            test_set_vol["Pred"] / np.exp(test_data["DV"]),
        )
        train_rsq = r2_score(
            (train_data["DV"]), np.log(train_set_vol["Pred"])
        )  # r2_score(np.exp(train_data["DV"]),train_set_vol["Pred"])
        # cv_mse_mean = model.mse_path_[np.where(model.alphas_==model.alpha_)[0]].mean()
        # cv_mse_sd = model.mse_path_[np.where(model.alphas_==model.alpha_)[0]].std()
        cv_mse_mean, cv_mse_sd = model.get_cv_metrics()

        train_set_vol_edlp = pd.DataFrame(
            {
                "PPG_Item_No": [ppg] * len(train_data_edlp.index),
                "Date": train_data_edlp.index,
                "Pred": np.exp(model.predict(train_data_edlp[temp_cols])),
            }
        ).set_index("Date")
        test_set_vol_edlp = pd.DataFrame(
            {
                "PPG_Item_No": [ppg] * len(test_data_edlp),
                "Date": test_data_edlp.index,
                "Pred": np.exp(model.predict(test_data_edlp[temp_cols])),
            }
        ).set_index("Date")
        train_edlp_MAPE = mean_absolute_error(
            np.array([1] * len(train_data_edlp["DV"])),
            train_set_vol_edlp["Pred"] / np.exp(train_data_edlp["DV"]),
        )
        test_edlp_MAPE = mean_absolute_error(
            np.array([1] * len(test_data_edlp["DV"])),
            test_set_vol_edlp["Pred"] / np.exp(test_data_edlp["DV"]),
        )

        if len(train_data_tpr) > 0:
            train_set_vol_tpr = pd.DataFrame(
                {
                    "PPG_Item_No": [ppg] * len(train_data_tpr.index),
                    "Date": train_data_tpr.index,
                    "Pred": np.exp(model.predict(train_data_tpr[temp_cols])),
                }
            ).set_index("Date")
            train_tpr_MAPE = mean_absolute_error(
                np.array([1] * len(train_data_tpr["DV"])),
                train_set_vol_tpr["Pred"] / np.exp(train_data_tpr["DV"]),
            )
        else:
            train_tpr_MAPE = "No TPR Event"
        if len(test_data_tpr) > 0:
            test_set_vol_tpr = pd.DataFrame(
                {
                    "PPG_Item_No": [ppg] * len(test_data_tpr.index),
                    "Date": test_data_tpr.index,
                    "Pred": np.exp(model.predict(test_data_tpr[temp_cols])),
                }
            ).set_index("Date")
            test_tpr_MAPE = mean_absolute_error(
                np.array([1] * len(test_data_tpr["DV"])),
                test_set_vol_tpr["Pred"] / np.exp(test_data_tpr["DV"]),
            )
        else:
            test_tpr_MAPE = "No TPR Event"

        temp_4 = temp_2[
            ["PPG_Cat", "PPG_MFG", "PPG_Item_No", "PPG_Description"]
        ].drop_duplicates()
        temp_4["model_RSq"] = train_rsq
        temp_4["model_CVErrorMean"] = cv_mse_mean
        temp_4["model_CVErrorSD"] = cv_mse_sd
        temp_4["TrainMAPE_edlp"] = train_edlp_MAPE
        temp_4["TrainMAPE_tpr"] = train_tpr_MAPE
        temp_4["TestMAPE_edlp"] = test_edlp_MAPE
        temp_4["TestMAPE_tpr"] = test_tpr_MAPE
        temp_4["TrainMape_overall"] = train_MAPE
        temp_4["TestMape_overall"] = test_MAPE
        temp_4["no_of_tpr_events_train"] = len(train_data_tpr)
        temp_4["no_of_tpr_events_test"] = len(test_data_tpr)
        temp_4["fold"] = fold

        model_results_cv = model_results_cv.append(temp_4)
    return model_results_cv


def extract_pack_size(x):
    """Extract Pack Size from PPG Description."""

    temp_1 = re.findall("[\\d.]+OZ|[\\d.]+ LB|[\\d.]+LB|[\\d.]+ OZ", x)
    size = temp_1[0] if len(temp_1) > 0 else np.nan

    if size is np.nan:
        temp_2 = re.findall("[\\d.]CT|[\\d.]+ CT", x)
        size = temp_2[0] if len(temp_2) > 0 else np.nan

    size = str(size)
    temp_3 = re.findall("[\\d.]+", size)
    qty = temp_3[0] if len(temp_3) > 0 else np.nan

    temp_4 = re.findall("LB|CT|OZ", size)
    unit = temp_4[0] if len(temp_4) > 0 else np.nan
    qty = qty * 12 if unit == "LB" else qty

    return float(qty)
