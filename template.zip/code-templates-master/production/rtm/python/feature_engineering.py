"""Processors for the feature engineering step of the worklow.

The step loads cleaned training data, processes the data for outliers,
missing values and any other cleaning steps based on business rules/intuition.

The trained pipeline and any artifacts are then saved to be used in
training/scoring pipelines.
"""
import logging
import os.path as op

from category_encoders import TargetEncoder,OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer

from ta_lib.core.api import (get_dataframe,
                             get_feature_names_from_column_transformer,
                             get_package_path, hash_object, load_dataset,
                             register_processor, save_pipeline)
from ta_lib.core.tracking import tracker
from ta_lib.data_processing.api import Outlier
import ta_lib.core.dataset as dataset

logger = logging.getLogger(__name__)

@register_processor("feat-engg", "transform-features")
def transform_features(context, params):
    """Transform dataset to create training datasets."""
    input_features_ds = "train/master_data/features"
    input_target_ds = "train/master_data/target"
    artifacts_folder = op.join(get_package_path(), "artifacts")

    

    # load datasets
    train_X = dataset.load_dataset(context, input_features_ds)
    train_y = dataset.load_dataset(context, input_target_ds)
   

    cat_columns = train_X.select_dtypes("object").columns
    num_columns = train_X.select_dtypes("number").columns

    
    
    
    ## Transform Features
    features_transformer = ColumnTransformer([
    
    ## categorical columns
    ('tgt_enc', OneHotEncoder(return_df=False, use_cat_names=True),
     list(set(cat_columns) - set(['business_model', 'sales_throughout_year']))),
    
    ## numeric columns
    ('num_enc', SimpleImputer(fill_value=0), num_columns),
    
    ])


    # Check if the data should be sampled. This could be useful to quickly run
    # the pipeline for testing/debugging purposes (udersample)
    # or profiling purposes (oversample).
    sample_frac = params.get("sampling_fraction", None)
    if sample_frac is not None:
        logger.warn(f"The data has been sample by fraction: {sample_frac}")
        sample_X = train_X.sample(frac=sample_frac, random_state=context.random_seed)
    else:
        sample_X = train_X
    sample_y = train_y.loc[sample_X.index]
    
    
    # Train the feature engg. pipeline prepared earlier. Note that the pipeline is
    # fitted on only the **training data** and not the full dataset.
    # This avoids leaking information about the test dataset when training the model.
    train_X = get_dataframe(
        features_transformer.fit_transform(train_X, train_y),
        get_feature_names_from_column_transformer(features_transformer),
    )

    # Note: we can create a transformer/feature selector that simply drops
    # a specified set of columns. But, we don't do that here to illustrate
    # what to do when transformations don't cleanly fall into the sklearn
    # pattern.
	
    curated_columns = ['csv_of_outlet','log_total_visits', 'outlet_surface']

    # saving the list of relevant columns and the pipeline.
    save_pipeline(
        curated_columns, op.abspath(op.join(artifacts_folder, "curated_columns.joblib"))
    )
    save_pipeline(
        features_transformer, op.abspath(op.join(artifacts_folder, "features.joblib"))
    )

    