"""Processors for the data cleaning step of the worklow.

The processors in this step, apply the various cleaning steps identified
during EDA to create the training datasets.
"""
import numpy as np
import pandas as pd
import scripts

from ta_lib.core.api import (
    hash_object,
    load_dataset,
    register_processor,
    save_dataset,
    tracker,
)

import ta_lib.core.dataset as dataset
from ta_lib.core.api import string_cleaning, register_processor


@register_processor("data-cleaning", "store")
def clean_store_table(context, params):
    # input and output datasets for the task
    input_dataset = "raw/store_database"
    output_dataset = "cleaned/store"

    
    # load dataset
    store_df = dataset.load_dataset(context, input_dataset)

   
    
    unwanted_cols = ['City', '2019 Freq. rating', '2020 Freq. rating']

    store_df_clean = (
    store_df
    # while iterating on testing, it's good to copy the dataset(or a subset)
    # as the following steps will mutate the input dataframe. The copy should be
    # removed in the production code to avoid introducing perf. bottlenecks.
    .copy()

    # set dtypes : nothing to do here
    .passthrough()
    
    .drop(unwanted_cols, axis=1)
    
    # Cleaning shelf meters from '5m' to 5.0
    .shelfmeter('Shelf meters Dog')
    .shelfmeter('Shelf meters Cat')
    .shelfmeter('Shelf meters Choc')
    
    # set dtypes
    .convert_to_int('Banner Code')
    
    .dropna()
    
    .clean_names(case_type='snake')
    )

   

    # save the dataset
    dataset.save_dataset(context, store_df_clean, output_dataset)



@register_processor("data-cleaning", "sales")
def clean_sales_table(context, params):
    # input and output datasets for the task
    input_dataset = "raw/rsv_sales"
    output_dataset = "cleaned/sales"

    
    # load dataset
    sales_df = dataset.load_dataset(context,input_dataset)


    
    sales_clean_df = (
    sales_df
    
    .copy()
    
    # set dtypes
    .change_type(['Banner Code'], np.int64)
    
    # clean column names                                                                                                                                   
    .clean_names(case_type='snake')
    
    )

    
    # save dataset
    dataset.save_dataset(context, sales_clean_df, output_dataset)
    
@register_processor("data-cleaning", "sales_proxy")
def clean_sales_proxy_table(context, params):
    # input and output datasets for the task
    input_dataset = "raw/sales_proxy"
    output_dataset = "cleaned/sales_proxy"

    
    # load dataset
    sales_proxy_df = dataset.load_dataset(context,input_dataset)


    
    sales_proxy_clean_df = (
    sales_proxy_df
    
    .copy()
    
    # set dtypes
    .change_type(['Banner Code'], np.int64)
    
    # clean column names                                                                                                                                   
    .clean_names(case_type='snake')
    
    )

    
    # save dataset
    dataset.save_dataset(context, sales_proxy_clean_df, output_dataset)

@register_processor("data-cleaning", "callexecution")
def clean_callexecution_table(context, params):
    # input and output datasets for the task
    input_dataset = "raw/call_file"
    output_dataset = "cleaned/callexecution"

    

    # load dataset
    callexecution_df = dataset.load_dataset(context,input_dataset)

    
    
    callexecution_clean_df= (
    callexecution_df
   
    .copy()

    # set dtypes : nothing to do here
    .passthrough()
    
    #convert object to int
    .fillwithzero('Banner Code')
    .convert_to_int('Banner Code')
    
    .clean_names(case_type='snake')
    )
   

    # save dataset
    dataset.save_dataset(context, callexecution_clean_df, output_dataset)
    
@register_processor("data-cleaning", "thirdparty_callexecution")
def clean_thirdparty_callexecution_table(context, params):
    # input and output datasets for the task
    input_dataset = "raw/thirdparty"
    output_dataset = "cleaned/thirdparty_callexecution"

   
    # load dataset
    thirdparty_callexecution_df = dataset.load_dataset(context,input_dataset)

    
    thirdparty_callexecution_clean_df = (
    thirdparty_callexecution_df
   
    .copy()

    # set dtypes : nothing to do here
    .passthrough()
    
    .replace({'(NA)': np.NaN})
    
    
    .clean_names(case_type='snake')
    )
   
    # save dataset
    dataset.save_dataset(context, thirdparty_callexecution_clean_df, output_dataset)
    

@register_processor("data-cleaning", "weekly_promotions")
def clean_weekly_promotions_table(context, params):
    # input and output datasets for the task
    input_dataset = "raw/weekly_promotions"
    output_dataset = "cleaned/weekly_promotions"

    

    # load dataset
    weekly_promotions_df = dataset.load_dataset(context,input_dataset)

    

    
    weekly_promotions_clean_df = (
    weekly_promotions_df
   
    .copy()

    # set dtypes : nothing to do here
    .passthrough()
    
    .replace({'(NA)': np.NaN})
    
    
    .clean_names(case_type='snake')
    )
    
    

    # save dataset
    dataset.save_dataset(context, weekly_promotions_clean_df, output_dataset)
    




@register_processor("data-cleaning", "master")
def clean_master_table(context, params):
    
    input_store_ds = "cleaned/store"
    output_dataset = "processed/master"

    
    # load datasets
    store_df = dataset.load_dataset(context, input_store_ds)
    

    df=(
    store_df
    .add_feature_sales(context)
    .add_feature_promo(context)
    .add_feature_thirdparty(context)
    .add_feature_callexec(context)
    .add_feature_totcallexec(context)
    )

   
    

    dataset.save_dataset(context, df, output_dataset)
    return df


@register_processor("data-cleaning", "train-test")
def create_training_datasets(context, params):
    """Split the ``SALES`` table into ``train`` and ``test`` datasets."""

    input_dataset = "processed/master"
    output_train_features = "train/master_data/features"
    output_train_target = "train/master_data/target"
    output_test_features = "/test/master_data/features"
    output_test_target = "/test/master_data/target"

   

    # load dataset
    master = dataset.load_dataset(context, input_dataset)

   

    ##creating additional features that are not affected by train test split. These are features that are processed globally
    #########first time customer(02_data_processing.ipynb)################
    target_col = "value"

    train_X, train_y = (
        master
        .get_features_targets(target_col)
    )

    

    # save the train dataset
    dataset.save_dataset(context, train_X, output_train_features)
    dataset.save_dataset(context, train_y, output_train_target)

    # split test dataset into features and target
    test_X, test_y = (
    master.iloc[:0,:]
    .get_features_targets(target_col)
    )
    

    # save the datasets
    dataset.save_dataset(context, test_X, output_test_features)
    dataset.save_dataset(context, test_y, output_test_target)
