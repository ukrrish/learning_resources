"""Module for listing down additional custom functions required for the notebooks"""

import pandas as pd
import pandas_flavor as pf
from ta_lib.core import dataset
import numpy as np

import re

def replacement(x):
    x=re.sub(',','.',x)
    x=re.sub('[^0-9.]','',x)
    if x!='':
        return float(x)
    
def conversion(x):
    if x=='(NA)':
        return np.NaN
    elif x=='-':
        return np.NaN
    elif x=='.':
        return np.NaN
    elif x=='Jumbo':
        return np.NaN
    elif x=='n/a':
        return np.NaN
    elif x=='nb':
        return np.NaN
    elif x=='P':
        return np.NaN
    elif x=='PPP':
        return np.NaN
    else:
        return int(x) if int(x) !=0 else np.NaN
    
@pf.register_dataframe_method
def convert_to_int(df,col):
    result=map(conversion,df[col])
    df[col]=list(result)
    return df
    
    

@pf.register_dataframe_method
def shelfmeter(df,col):
    result=map(replacement,df[col])
    df[col]=list(result)
    return df

@pf.register_dataframe_method
def fillwithzero(df,col):
    df[col]=df[col].fillna(0)
    return df



@pf.register_dataframe_method
def add_feature_sales(df,context):
    df = df.copy()
    sales_df=dataset.load_dataset(context,'cleaned/sales')
    sales_df = pd.pivot_table(sales_df, index=['banner_code','banner','year','week'], columns=['category'], values=['value','units'])
    sales_df.columns = sales_df.columns.map('_'.join).str.strip('_')
    sales_df = sales_df.reset_index()
    sales_df['units'] = sales_df['units_Chocolate']+sales_df['units_Petcare']
    sales_df['value'] = sales_df['value_Chocolate']+sales_df['value_Petcare']    
    sales_df = sales_df.groupby(["banner_code","banner","year"])[["value","units",'value_Petcare','value_Chocolate']].sum().reset_index()
    sales_df["avg_val_per_unit"] = sales_df["value"]/sales_df["units"]
    
    dataset.save_dataset(context, sales_df, 'processed/sales')
    df = df.merge(sales_df, on=["banner","banner_code"], how='inner')
    proxy_df = dataset.load_dataset(context, 'cleaned/sales_proxy')
    df = df.merge(proxy_df, on=['banner', 'banner_code', 'year'], how='inner')
    return(df)

@pf.register_dataframe_method
def add_feature_promo(df,context):
    df = df.copy()
    wpromo_df=dataset.load_dataset(context,'/cleaned/weekly_promotions')
    wpromo_df['tailormade']=wpromo_df['chocolate_tailormade']+wpromo_df['petcare_tailormade']+wpromo_df['others_tailormade']
    wpromo_df['not_tailormade']=wpromo_df['chocolate_not_tailormade']+wpromo_df['petcare_not_tailormade']+wpromo_df['others_not_tailormade']
    wpromo_df['prod_promoted_tailormade']=wpromo_df['tailormade'] * wpromo_df['prodcts_promoted_tailormade']
    wpromo_df['prod_promoted_not_tailormade']=wpromo_df['not_tailormade'] * wpromo_df['prodcts_promoted_not_tailormade']
    wpromo_df = wpromo_df.groupby(["partner_id","banner","year"]).apply(lambda x: pd.Series({'Total_TM_Promotions':x['tailormade'].sum(),
                                                                                        'nWeeks_TM_Promotions':x['tailormade'].ne(0).sum(),
                                                                                        'Total_NTM_Promotions':x['not_tailormade'].sum(),
                                                                                     'nWeeks_NTM_Promotions':x['not_tailormade'].ne(0).sum(),
                                                                                   'Total_nProducts_TM':x['prod_promoted_tailormade'].sum(),
                                                                             'Total_nProducts_NTM':x['prod_promoted_not_tailormade'].sum()}))
    
    wpromo_df = wpromo_df.reset_index()
    dataset.save_dataset(context, wpromo_df, 'processed/promotion') 
    df = df.merge(wpromo_df, on=["partner_id", "banner", "year"], how='left')


    return(df)

def extract_features_callexec(call_exec_req):
    call_exec_req["date"] = call_exec_req["date"].apply(pd.to_datetime)
    call_exec_req['year'] = call_exec_req['date'].dt.year
    call_exec_req = call_exec_req.sort_values(by=['partner_id','date'])
    call_exec_req["visit_frequency"] = call_exec_req.groupby(['partner_id','year'])["date"].apply(lambda x: x.diff())
    call_exec_req.reset_index(inplace=True,drop=True)
    call_exec_req["visit_frequency"] = call_exec_req["visit_frequency"].apply(lambda x:x.days)
    call_exec_req["visit_time_end_start_"] = call_exec_req["visit_time_end_start_"].astype(str)   \
                                              .apply(lambda x:int(x.replace(",","")))
    call_exec_req = call_exec_req.groupby(["partner_id","banner","year"])   \
                                 .agg({"visit_time_end_start_":['count',"mean","std"],"visit_frequency":"std"}).reset_index()
    
    call_exec_req.columns = ['_'.join(tup).rstrip('_') for tup in call_exec_req.columns.values]
    call_exec_req.rename(columns={"visit_time_end_start__count":"total_visits",
                                  "visit_time_end_start__mean":"avg_duration",
                                  "visit_time_end_start__std":"visits_freq_std",
                                  "visit_frequency_std":"duration_std"},inplace=True)
    call_exec_req["visits_freq_std"].fillna(0,inplace=True)
    call_exec_req["duration_std"].fillna(0,inplace=True)
    return call_exec_req


@pf.register_dataframe_method
def add_feature_thirdparty(df,context):
    df = df.copy()
    tpcallexec_df = dataset.load_dataset(context,'/cleaned/thirdparty_callexecution')
    tpcallexec_df = tpcallexec_df.merge(df[["partner_id","banner"]],on="partner_id")
    tpcallexec_df.drop("banner_x",axis=1,inplace=True)
    tpcallexec_df.rename(columns={"banner_y":"banner"},inplace=True)
    fil1 = ((tpcallexec_df["visit_cancelled"] == "Bezoek")|(tpcallexec_df["visit_cancelled"] == "Yes"))
    fil2 = ((~tpcallexec_df["partner_id"].isna()) & (tpcallexec_df["partner_id"]!=0))
    tpcallexec_df = tpcallexec_df[fil1 & fil2]
    tpcallexec_df = tpcallexec_df[tpcallexec_df['duration']!=0]
    tpcallexec_df = tpcallexec_df.groupby(['partner_id','banner','sales_rep','date_of_visit'])['duration'].sum().rename("visit_time_end_start_").reset_index()
    tpcallexec_df.rename(columns={'date_of_visit':'date'}, inplace=True)
    tpcallexec_df.drop('sales_rep', axis=1, inplace=True)
    tpcallexec_df['type']='3rd_party'
    dataset.save_dataset(context, tpcallexec_df, 'processed/thridparty_execution')
    return df

@pf.register_dataframe_method
def add_feature_callexec(df,context):
    df = df.copy()
    callexec_df = dataset.load_dataset(context,'/cleaned/callexecution')
    callexec_df = callexec_df[callexec_df["visit_time_end_start_"]!=0]
    callexec_df = callexec_df.groupby(['partner_id','banner','employee_name','date'])['visit_time_end_start_'].sum().reset_index()
    callexec_df.drop('employee_name', axis=1, inplace=True)
    callexec_df['type']='FT'
    dataset.save_dataset(context, callexec_df, 'processed/call_execution')
    return df

@pf.register_dataframe_method
def add_feature_totcallexec(df,context):
    df = df.copy()
    tpcallexec_df = dataset.load_dataset(context,'processed/thridparty_execution')
    callexec_df = dataset.load_dataset(context,'processed/call_execution')
    total_callexec = pd.concat([callexec_df[['partner_id', 'banner', 'date','visit_time_end_start_','type']],tpcallexec_df])
    
    callexec_df = extract_features_callexec(callexec_df)
    tpcallexec_df = extract_features_callexec(tpcallexec_df)
    total_callexec = extract_features_callexec(total_callexec)
    tpcallexec_df.columns = ['partner_id', 'banner', 'year', 'thirdparty_visits','thirdparty_avg_duration','thirdparty_visits_freq_std','thirdparty_duration_std']
    callexec_df.columns = ['partner_id', 'banner', 'year', 'Fulltime_visits', 'Fulltime_avg_duration','Fulltime_visits_freq_std', 'Fulltime_duration_std']
    total_callexec['log_total_visits'] = np.log(total_callexec.total_visits+1)
    
    dataset.save_dataset(context, tpcallexec_df, 'processed/thridparty_execution')
    dataset.save_dataset(context, callexec_df, 'processed/call_execution')

    
    df = df.merge(total_callexec, on=['partner_id', 'banner', 'year'], how='left')
    df = df.merge(callexec_df, on=['partner_id', 'banner', 'year'], how='left')
    df = df.merge(tpcallexec_df, on=['partner_id', 'banner', 'year'], how='left')
    
    return df  


@pf.register_dataframe_method
def get_features_targets(df,col):
    df=df.copy()
    target=df[[col]]
    df=df.loc[:,df.columns!=col]
    return df,target
