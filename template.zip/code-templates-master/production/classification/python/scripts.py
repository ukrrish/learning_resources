"""Module for listing down additional custom functions required for production."""

import numpy as np
import pandas as pd
import pandas_flavor as pf
from dateutil.relativedelta import relativedelta
from sklearn.base import BaseEstimator, TransformerMixin
from xverse.transformer import WOE

import ta_lib.core.api as dataset


def custom_data_transform(df, cols2keep=[]):
    """Drop columns in the data.

    Parameters
    ----------
        df - pd.DataFrame
        cols2keep - columns to keep in the dataframe
    """
    if len(cols2keep):
        return df.select_columns(cols2keep)
    else:
        return df


class CustomFeatureGeneration(BaseEstimator, TransformerMixin):
    """Feature engineering class."""

    def __init__(self, context, ref_date):
        self.context = context
        self.ref_date = ref_date

    def fit(self, X, y=None):
        pass

    def add_features(self, df, context, ref_date):
        data = (
            df.add_features_primary_sales(context, ref_date)
            .add_features_seconday_sales(context, ref_date)
            .add_features_no_objection_data(context, ref_date)
            .add_features_order_alloc_data(context, ref_date)
            .add_features_coverage_data(context, ref_date)
            .add_features_order_alloc_reason(context, ref_date)
            .add_features_profit_data(context, ref_date)
            .add_features_retail_program_data(context, ref_date)
            .add_features_business_data(context, ref_date)
            .add_features_ordered_withapp_data(context, ref_date)
            .add_features_ordered_withoutapp_data(context, ref_date)
            .add_features_retail_invoices_data(context, ref_date)
            .add_days_in_business_feature(context, ref_date)
        )
        return data

    def transform(self, X, y=None):
        return self.add_features(X, self.context, self.ref_date)

    def fit_transform(self, X, y=None):
        return self.add_features(X, self.context, self.ref_date)


def get_months_data(series, window=6, method="mean", sale_col="sec_netvalue"):
    """Filter data from month_start date to a max date available."""

    series = series.sort_values("month_start_date")
    if method == "mean":
        max_date = series["month_start_date"].max()
        min_date = max_date - relativedelta(months=window)
        val = series[
            (series.month_start_date >= min_date)
            & (series.month_start_date <= max_date)
        ][sale_col].mean()
    elif method == "lag":
        max_date = series["month_start_date"].max()
        min_date = max_date - relativedelta(months=window)
        val = series[(series.month_start_date == min_date)][sale_col]
        if len(val):
            pass
        else:
            val = pd.Series([np.nan], name=sale_col)
    return val


def get_quarter_from_month(dt):
    """Get the quarted for a particular month."""

    mth = dt.month
    quarter = 0
    yr = int(dt.year)
    if mth in [1, 2, 3]:
        yr = yr - 1
        quarter = 4
    elif mth in [4, 5, 6]:
        quarter = 1
    elif mth in [7, 8, 9]:
        quarter = 2
    elif mth in [10, 11, 12]:
        quarter = 3
    return quarter


@pf.register_dataframe_method
def add_features_primary_sales(df, context, ref_date="2013-05-01"):
    """Addition of Primary Sales Features in to the data."""
    df = df.copy()
    customers = df.customer_code.unique().tolist()
    pri_df = dataset.load_dataset(context, "/cleaned/pri_bpm")
    pri_df_slice = pri_df[(pri_df.customer_code.isin(customers))]
    pri_df_slice = pri_df_slice[pri_df_slice.month_start_date <= ref_date]
    last6months = (
        pri_df_slice.groupby("customer_code")
        .apply(lambda x: get_months_data(x, sale_col="pri_sales_amount"))
        .rename("last_6_months_avg_sales_pri")
    )
    last3months = (
        pri_df_slice.groupby("customer_code")
        .apply(lambda x: get_months_data(x, window=3, sale_col="pri_sales_amount"))
        .rename("last_3_months_avg_sales_pri")
    )
    overall = (
        pri_df_slice.groupby("customer_code")["pri_sales_amount"]
        .mean()
        .rename("overall_avg_sales_pri")
    )
    features = pd.concat([overall, last6months, last3months], axis=1)
    features = features.reset_index()
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


@pf.register_dataframe_method
def add_features_seconday_sales(df, context, ref_date="2013-05-01"):
    """Addition of Secondary Sales Features in to the data."""
    df = df.copy()
    customers = df.customer_code.unique().tolist()
    sec_df = dataset.load_dataset(context, "/cleaned/sec_bpm")
    sec_df_slice = sec_df[(sec_df.customer_code.isin(customers))]
    sec_df_slice = sec_df_slice[sec_df_slice.month_start_date <= ref_date]

    last6months = (
        sec_df_slice.groupby("customer_code")
        .apply(lambda x: get_months_data(x, sale_col="sec_ind_bpm_actuals"))
        .rename("last_6_months_avg_sec_ind_bpm_actuals")
    )
    last3months = (
        sec_df_slice.groupby("customer_code")
        .apply(lambda x: get_months_data(x, window=3, sale_col="sec_ind_bpm_actuals"))
        .rename("last_3_months_avg_sec_ind_bpm_actuals")
    )
    overall = (
        sec_df_slice.groupby("customer_code")["sec_ind_bpm_actuals"]
        .mean()
        .rename("overall_avg_sec_ind_bpm_actuals")
    )
    features = pd.concat([overall, last6months, last3months], axis=1)
    features = features.reset_index()
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


@pf.register_dataframe_method
def add_features_no_objection_data(df, context, ref_date="2013-05-01"):
    """Addition of no objection data Feature in to the data."""
    df = df.copy()
    customers = df.customer_code.unique().tolist()
    ref_date = pd.to_datetime(ref_date)
    no_obj_df = dataset.load_dataset(context, "/cleaned/no_obj").query(
        "(customer_code in @customers)", engine="python"
    )
    no_obj_df_slice = no_obj_df[
        (no_obj_df.claim_year <= ref_date.year)
        | (
            (no_obj_df.claim_year == ref_date.year)
            & (
                no_obj_df.quarter.str.replace("P", "").astype(int)
                <= get_quarter_from_month(ref_date)
            )
        )
    ]
    features = (
        no_obj_df_slice.groupby(["customer_code", "policy_flag"])
        .size()
        .rename("policy_count")
        .reset_index()
        .pivot(index="customer_code", columns="policy_flag")
        .fillna(0)
    )
    features.columns = [x[0] + "_" + x[1].lower() for x in features.columns]
    features = features.reset_index()
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


@pf.register_dataframe_method
def add_features_order_alloc_data(df, context, ref_date="2013-05-01"):
    """Addition of order_allocation feature  to the data."""
    df = df.copy()
    customers = df.customer_code.unique().tolist()
    ref_date = pd.to_datetime(ref_date)
    order_alloc_df = dataset.load_dataset(context, "/cleaned/order_alloc")
    order_alloc_df = order_alloc_df[
        (order_alloc_df.month_start_date <= ref_date)
        & (order_alloc_df.customer_code.isin(customers))
    ]
    features = (
        order_alloc_df.groupby("customer_code")["simple avg allocated percent"]
        .mean()
        .rename("overall_mean_simple_avg_allocated_percent")
        .reset_index()
    )
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


@pf.register_dataframe_method
def add_features_coverage_data(df, context, ref_date="2013-05-01"):
    """Addition of Coverage data Feature in to the data."""
    df = df.copy()
    customers = df.customer_code.unique().tolist()
    cov_df = dataset.load_dataset(context, "/cleaned/coverage")
    cov_df_slice = cov_df[(cov_df.customer_code.isin(customers))]
    cov_df_slice = cov_df_slice[cov_df_slice.month_start_date <= ref_date]
    last6months = cov_df_slice.groupby("customer_code").apply(
        lambda x: get_months_data(x, sale_col="daily_coverage_perc")
    )
    features = pd.concat([last6months], axis=1)
    features.columns = ["last_6_months_avg_coverage"]
    features = features.reset_index()
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


@pf.register_dataframe_method
def add_features_order_alloc_reason(df, context, ref_date="2013-05-01"):
    """Addition of Order Allocation reason to the dataframe."""
    df = df.copy()
    customers = df.customer_code.unique().tolist()
    features = (
        dataset.load_dataset(context, "/cleaned/orders_and_allocated_reason")
        .query(
            f"(customer_code in @customers) & (month_start_date<='{ref_date}')",
            engine="python",
        )
        .groupby(["customer_code", "reason_code_description_new_new"])[
            ["order_qty_in_cases", "allocated_qty_in_cases"]
        ]
        .apply(
            lambda x: x["allocated_qty_in_cases"].sum() / x["order_qty_in_cases"].sum()
        )
        .rename("allocated_percent_reason_")
        .reset_index()
        .pivot(index="customer_code", columns="reason_code_description_new_new")
        .fillna(0)
    )
    features.columns = [x[0] + "_" + x[1].lower() for x in features.columns]
    features = features.reset_index()
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


@pf.register_dataframe_method
def add_features_profit_data(df, context, ref_date="2013-05-01"):
    """Addition of profit features in to the data."""

    df = df.copy()
    customers = df.customer_code.unique().tolist()
    return_df = dataset.load_dataset(context, "/cleaned/returns")
    return_df = return_df.replace([np.inf, -np.inf], np.nan)
    return_df_slice = return_df[(return_df.customer_code.isin(customers))]
    return_df_slice = return_df_slice[return_df_slice.month_start_date <= ref_date]
    features = pd.DataFrame(
        {"customer_code": return_df_slice.customer_code.unique().tolist()}
    )

    for i in [
        "profit_with_udaan_without_sub",
        "profit_without_udaan_with_sub",
        "profit_with_udaan_with_sub",
        "roi_without_udaan_sub",
        "roi_with_udaan_without_sub",
        "roi_without_udaan_with_sub",
        "roi_with_udaan_with_sub",
    ]:
        last6months = (
            return_df_slice.groupby("customer_code")
            .apply(lambda x: get_months_data(x, sale_col=i))
            .rename("last_6_months_avg_" + i)
        )
        last3months = (
            return_df_slice.groupby("customer_code")
            .apply(lambda x: get_months_data(x, window=3, sale_col=i))
            .rename("last_3_months_avg_" + i)
        )
        overall = (
            return_df_slice.groupby("customer_code")[i]
            .apply(lambda x: np.nanmean(x))
            .rename("overall_avg_" + i)
        )
        atemp = pd.concat([overall, last6months, last3months], axis=1)
        atemp = atemp.reset_index()
        features = features.merge(atemp, on="customer_code", how="left", validate="1:1")
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


@pf.register_dataframe_method
def add_features_retail_program_data(df, context, ref_date="2013-05-01"):
    """Addition of retail program Feature in to the data."""
    df = df.copy()
    customers = df.customer_code.unique().tolist()
    retail_program_df = dataset.load_dataset(context, "/cleaned/retail_program")
    retail_program_df_slice = retail_program_df[
        (retail_program_df.customer_code.isin(customers))
    ]
    retail_program_df_slice = retail_program_df_slice[
        retail_program_df_slice.month_start_date <= ref_date
    ]
    features = pd.DataFrame(
        {"customer_code": retail_program_df_slice.customer_code.unique().tolist()}
    )

    for i in [
        "sec_netvalue",
        "bandhan_net_val",
        "wholesale_net_value",
        "otherpgrm_net_val",
        "non_wholesale_net_value",
    ]:
        last6months = (
            retail_program_df_slice.groupby("customer_code")
            .apply(lambda x: get_months_data(x, sale_col=i))
            .rename("last_6_months_avg_" + i)
        )
        last3months = (
            retail_program_df_slice.groupby("customer_code")
            .apply(lambda x: get_months_data(x, window=3, sale_col=i))
            .rename("last_3_months_avg_" + i)
        )
        overall = (
            retail_program_df_slice.groupby("customer_code")[i]
            .mean()
            .rename("overall_avg_" + i)
        )
        atemp = pd.concat([overall, last6months, last3months], axis=1)
        atemp = atemp.reset_index()
        features = features.merge(atemp, on="customer_code", how="left", validate="1:1")
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


@pf.register_dataframe_method
def add_features_business_data(df, context, ref_date="2013-05-01"):
    """Addition of ec business features  to the data."""
    df = df.copy()
    customers = df.customer_code.unique().tolist()
    business_df = dataset.load_dataset(context, "/cleaned/ec")
    business_df_slice = business_df[(business_df.customer_code.isin(customers))]
    business_df_slice = business_df_slice[
        business_df_slice.month_start_date <= ref_date
    ]
    last6months = (
        business_df_slice.groupby("customer_code")
        .apply(lambda x: get_months_data(x, sale_col="ec"))
        .rename("last_6_months_avg_eci")
    )
    last3months = (
        business_df_slice.groupby("customer_code")
        .apply(lambda x: get_months_data(x, window=3, sale_col="ec"))
        .rename("last_3_months_avg_ec")
    )
    overall = (
        business_df_slice.groupby("customer_code")["ec"].mean().rename("overall_avg_ec")
    )
    features = pd.concat([overall, last6months, last3months], axis=1)
    features = features.reset_index()
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


@pf.register_dataframe_method
def add_features_ordered_withapp_data(df, context, ref_date="2013-05-01"):
    """Addition of ordered with app feature to the data."""
    df = df.copy()
    customers = df.customer_code.unique().tolist()
    ordered_withapp_df = dataset.load_dataset(context, "/cleaned/ordered_with_app")
    ordered_withapp_df_slice = ordered_withapp_df[
        (ordered_withapp_df.customer_code.isin(customers))
    ]
    ordered_withapp_df_slice = ordered_withapp_df_slice[
        ordered_withapp_df_slice.month_start_date <= ref_date
    ]
    last6months = ordered_withapp_df_slice.groupby("customer_code").apply(
        lambda x: get_months_data(x, sale_col="labor_in_person_days")
    )
    last3months = ordered_withapp_df_slice.groupby("customer_code").apply(
        lambda x: get_months_data(x, window=3, sale_col="labor_in_person_days")
    )
    features = pd.concat([last6months, last3months], axis=1)
    features.columns = [
        "last_6_months_avg_withapp_labor",
        "last_3_months_avg_withapp_labor",
    ]
    features = features.reset_index()
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


@pf.register_dataframe_method
def add_features_ordered_withoutapp_data(df, context, ref_date="2013-05-01"):
    """Addition of ordered without app feature to the data."""
    df = df.copy()
    customers = df.customer_code.unique().tolist()
    ordered_withoutapp_df = dataset.load_dataset(
        context, "/cleaned/ordered_without_app"
    )
    ordered_withoutapp_df_slice = ordered_withoutapp_df[
        (ordered_withoutapp_df.customer_code.isin(customers))
    ]
    ordered_withoutapp_df_slice = ordered_withoutapp_df_slice[
        ordered_withoutapp_df_slice.month_start_date <= ref_date
    ]
    last6months = ordered_withoutapp_df_slice.groupby("customer_code").apply(
        lambda x: get_months_data(x, sale_col="labor_in_person_days")
    )
    last3months = ordered_withoutapp_df_slice.groupby("customer_code").apply(
        lambda x: get_months_data(x, window=3, sale_col="labor_in_person_days")
    )
    features = pd.concat([last6months, last3months], axis=1)
    features.columns = [
        "last_6_months_avg_withoutapp_labor",
        "last_3_months_avg_withoutapp_labor",
    ]
    features = features.reset_index()
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


@pf.register_dataframe_method
def add_features_retail_invoices_data(df, context, ref_date="2013-05-01"):
    """Addition of retail invoices feature to the data."""
    df = df.copy()
    customers = df.customer_code.unique().tolist()
    retail_invoices_df = dataset.load_dataset(context, "/cleaned/dist_retail_invoice")
    retail_invoices_df_slice = retail_invoices_df[
        (retail_invoices_df.customer_code.isin(customers))
    ]
    retail_invoices_df_slice = retail_invoices_df_slice[
        retail_invoices_df_slice.month_start_date <= ref_date
    ]
    features = pd.DataFrame(
        {"customer_code": retail_invoices_df_slice.customer_code.unique().tolist()}
    )
    for i in ["invoice_count", "unique_retailers"]:
        last6months = retail_invoices_df_slice.groupby("customer_code").apply(
            lambda x: get_months_data(x, sale_col=i)
        )
        last3months = retail_invoices_df_slice.groupby("customer_code").apply(
            lambda x: get_months_data(x, window=3, sale_col=i)
        )
        atemp = pd.concat([last6months, last3months], axis=1)
        atemp.columns = ["last_6_months_" + i, "last_3_months_" + i]
        atemp = atemp.reset_index()
        features = features.merge(atemp, on="customer_code", how="left", validate="1:1")
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


@pf.register_dataframe_method
def add_days_in_business_feature(df, context, ref_date="2013-05-01"):
    """Addition of days in business feature to the data."""
    df = df.copy()
    customers = df.customer_code.unique().tolist()
    features = (
        dataset.load_dataset(context, "/cleaned/doj")
        .query("customer_code in @customers", engine="python")
        .set_index("customer_code")["date_of_joining"]
        .apply(lambda x: (pd.to_datetime(ref_date) - x).days)
        .rename("days_in_business")
        .reset_index()
    )
    df = df.merge(features, on="customer_code", how="left", validate="1:1")
    return df


def woe_binning(x_train, x_test, y_train, col_bin):
    """Bin numeric variables using WOE(weight of evidence).

    Input: x_train : Training dataset.
           x_test   : Test dataset.
           y_train : Target vairble of training dataset. (Binary/Dichotomous)
           col_bin : Numeric variable to bucket.

    Output: The functions generated an EDA report and writes the model outputs to a csv file.
    """

    woe_binning = WOE(treat_missing="mode").fit(x_train[[col_bin]], y_train)
    x_train["WOE"] = woe_binning.transform(x_train[[col_bin]])
    x_test["WOE"] = woe_binning.transform(x_test[[col_bin]])
    df_bin = woe_binning.woe_df[["WOE", "Category"]].rename(
        columns={"Category": col_bin + "_woebinning"}
    )
    x_train = x_train.merge(df_bin, on="WOE").drop("WOE", axis=1)
    x_test = x_test.merge(df_bin, on="WOE").drop("WOE", axis=1)
    x_test.drop(col_bin, axis=1, inplace=True)
    x_train.drop(col_bin, axis=1, inplace=True)
    return x_train, x_test
