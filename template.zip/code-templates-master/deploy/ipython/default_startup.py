import os
import os.path as op
import shutil
import sys

import numpy as np
import pandas as pd
import yaml
import IPython
from IPython.core import getipython

import ta_lib.core.api as ta_core
import ta_lib.eda.api as ta_eda
import ta_lib.reports.api as ta_reports

getipython.get_ipython().magic(u"%reload_ext autoreload")
getipython.get_ipython().magic(u"%autoreload 2")


default_config_path = op.join(
    ta_core.get_package_path(), "ta_lib", "conf", "dev.yml"
)
context = ta_core.create_context(default_config_path)
