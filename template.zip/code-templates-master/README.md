# Introduction

This repo is a collection of reference code for solving frequent usecases and projects.


# Pre-requisites

* Ensure you have `Miniconda` installed and can be run from your shell. If not, download the installer for your platform here: https://docs.conda.io/en/latest/miniconda.html

     **NOTE**
     
     * If you already have `Anaconda` installed, pls. still go ahead and install `Miniconda` and use it for development. 
     * If `conda` cmd is not in your path, you can configure your shell by running `conda init`. 


* Ensure you have `git` installed and can be run from your shell

     **NOTE**
     
     * If you have installed `Git Bash` or `Git Desktop` then the `git` cli is not accessible by default from cmdline. 
       If so, you can add the path to `git.exe` to your system path. Here are the paths on a recent setup
      
```
        %LOCALAPPDATA%\Programs\Git\git-bash.exe
        %LOCALAPPDATA%\GitHubDesktop\app-<ver>\resources\app\git\mingw64\bin\git.exe
```


* Ensure `GITHUB_OAUTH_TOKEN` is added as an environment variable by running the following command in respective terminals.
     * Windows Powershell
     ```
           $env:GITHUB_OAUTH_TOKEN="<token>" 
     ```
     * Windown CMD
     ```
           set GITHUB_OAUTH_TOKEN="<token>" 
     ```
     * Linux Shell
     ```
           export GITHUB_OAUTH_TOKEN="<token>" 
     ```


     **NOTE**
     
     * If you dont have a personal access token, Please follow the instructions described [here](https://docs.github.com/en/free-pro-team@latest/github/authenticating-to-github/creating-a-personal-access-token) and generate one.
      
```
        %LOCALAPPDATA%\Programs\Git\git-bash.exe
        %LOCALAPPDATA%\GitHubDesktop\app-<ver>\resources\app\git\mingw64\bin\git.exe
```





* Ensure [invoke](http://www.pyinvoke.org/index.html) tool and pyyaml are installed in your `base` `conda` environment. If not, run

```
(base):~$ pip install invoke
(base):~$ pip install pyyaml
```




# Getting started

* Clone the current repo to some local folder and switch to the root folder
```
(base):~$ git clone git@github.com:tigerrepository/code-templates
(base):~$ cd code-templates
```

* A collection of workflow automation tasks can be seen as follows
```
(base):~/code-templates$ inv -l
```

* To verify pre-requisites, run
```
(base)~/code-templates$ inv debug.check-reqs
```
and check no error messages (`Error: ...`) are printed.


* Setup a development environment by running:
```
(base):~/code-templates$ inv dev.setup-env
```

The above command should create a conda python environment named `ta-lib-dev` and install the code in the current repository along with all required dependencies.

In case of installation issues, remove and recreate. You can remove by running:
```
(base):~/code-templates$ conda remove --name ta-lib-dev --all -y
```


**NOTE**: The following setup of vendor packages like TigerML and BayesLearning is required for developers so as to keep track of latest developments in these packages.

## TigerML Setup

For a development setup, pls. clone `TigerML` and checkout the branch `master`
```
(base):~/$ git clone git@github.com:tigerrepository/TigerML
(base):~/$ cd TigerML 
(base):~/TigerML$ git checkout master
```

and from the cloned repository folder, install as follows

```
(base):~/TigerML$ conda activate ta-lib-dev
(ta-lib-dev):~/TigerML$ pip install -e python --no-deps
```

For production scenarios, we will bundle a particular version of the `TigerML` code as part of the archive generated and so a separate install is not required.


## BayesianLearning Setup (Specific to TPO Template)

For a development setup, pls. clone `BayesianLearning` and make sure you are in `master` branch
```
(base):~/$ git clone git@github.com:tigerrepository/BayesianLearning.git
(base):~/$ cd BayesianLearning 
(base):~/BayesianLearning$ git checkout master
```

and from the cloned repository folder, install as follows

```
(base):~/BayesianLearning$ conda activate ta-lib-dev
(ta-lib-dev):~/BayesianLearning$ pip install -e . --no-deps
```

For production scenarios, we will bundle a particular version of the `BayesianLearning` code as part of the archive generated and so a separate install is not required.

## Launching Jupyter Notebooks

- In order to launch a jupyter notebook locally in the web server, run

    ```
    (ta-lib-dev):~/code_templates$ inv launch.jupyterlab
    ```
     After running the command, type [localhost:8080](localhost:8080) to see the launched JupyterLab.
     
- The `inv` command has a built-in help facility available for each of the invoke builtins. To use it, type `--help` followed by the command:
    ```
    (ta-lib-dev):~/code_templates$ inv launch.jupyterlab --help
    ```
- On running the ``help`` command, you get to see the different options supported by it.

    ```
    Usage: inv[oke] [--core-opts] launch.jupyterlab [--options] [other tasks here ...]

    Options:
    -a STRING, --password=STRING
    -e STRING, --env=STRING
    -i STRING, --ip=STRING
    -o INT, --port=INT
    -p STRING, --platform=STRING
    -t STRING, --token=STRING
    ```
# Testing

## Testing .py code

### Format QC

Use the inv task `test.qc` for fixing code standard issues

    ```
    (ta-lib-dev):~/code-templates$ inv test.qc
    ```

- If you see `I001 isort` or `BLK100` issues, use this to autoformat and resolve these `inv test.qc`
- If you are not able to resolve any issues reach code templates team.


### Code testing

- All the test cases will go into `tests\` folder.
- Look at the existing test scripts to learn writing test cases. More can be found in **developer guide** on readthedocs.


## Testing notebooks

- Before merging with master or commiting changes, we need to test the notebooks and production code does not break. Testing production `.py` scripts can be done using testing tasks. For testing or refreshing notebook below can be used:

    ```
    (ta-lib-dev):~/code-templates$ inv dev.run-notebooks
    ```

- To test one usecase.

    ```
    (ta-lib-dev):~/code-templates$ inv dev.run-notebooks -t <usecase>
    ```

- To test one notebook.

    ```
    (ta-lib-dev):~/code-templates$ inv dev.run-notebooks -t <usecase> - n <notebook no>
    ```

- On running the ``inv dev.run-notebooks --help`` command, you get to see the all the options supported in this task.

    ```
    Usage: inv[oke] [--core-opts] dev.run-notebooks [--options] [other tasks here ...]

    Docstring:
        Run notebooks to checks for any errors.

    
    Options:
    -e STRING, --env=STRING
    -i INT, --timeout=INT           Maximum execution time beyond which the notebook returns
                                    an exception. default is 600 secs.
    -n STRING, --notebookid=STRING  Specifies id of notebooks. Must be one of ``{01|02|03|all}``
    -p STRING, --platform=STRING
    -r, --refresh                   If `True`, notebooks are run and if successful refresh is
                                    also done else, notebooks are run for errors.
    -t STRING, --template=STRING    Specifies the template folder to run``{regression|classification|all}``If all then all the templates are run.
    ```

# Create archive

The final code will be delivered as a zip file. This zip file is built from this repo. Selective picking and customization are built into tasks in `scripts\code_archive\tasks.py`

* As mentioned above,  `inv -l` gives the list of tasks
* `inv dev.create-archive` is for generating code archive
* `inv dev.create-archive --help` to see options.

## Generate code archive for usecase

1. Add your `usecase` definition in dictonary `CONFIG_TEMPLATES` at `scripts\code_archive\constants.py`
2. `inv dev.create-archive -t <usecase>` will generate archive. `usecase` here in the dictonary key defined in the above step.
3. Generated core archives will be present in `scripts\code_archive\<usecase>`

**NOTE** : Install `conda-lock` package to generate archives. This package works well in linux machines, if using windows, use `ubuntu app` to generate archives.

# Documentation

All the files(.rst) and folders (images, downloads) related to documentation are created with as much detail as required in the `docs/source` folder. 


**NOTE** : Refer to the [reStructuredText syntax](https://www.sphinx-doc.org/en/master/usage/restructuredtext/basics.html) or this [documentation guide](https://www.writethedocs.org/guide/writing/beginners-guide-to-docs/#id1) if you need help.

* For a development setup, to edit, build and rebuild to see how the doc looks, run

     ```
     (ta-lib-dev):~/code_templates$ inv build.docs
     ```

    All the `.rst` files get built into `.html` in your documentation output directory (typically `docs/build/html/`)

* To launch your docs locally in the web browser, run

    ```
    (ta-lib-dev):~/code_templates$ inv launch.docs
    ```

    After launching the docs, type [localhost:8081](localhost:8081) or [127.0.0.1:8081](127.0.0.1:8081) to see the built documentation.

Once you have the final Sphinx documentation in a public repository, you can start using Read the Docs by importing your docs.

**NOTE**: Refer to the [sample document](https://github.com/tigerrepository/code-templates/blob/master/docs/source/code_templates/regression.rst) to understand the different types of `reST` syntax used for building technical documentation.

# Frequently Asked Questions

The FAQ for code templates during setting up, testing, development and adoption phases are available 
[here](https://docs.google.com/document/d/1vdRhHHdPOzYNnEHKaoZgztGNd0PnsP5XaEJlDNHxrQ0/edit?usp=sharing)
