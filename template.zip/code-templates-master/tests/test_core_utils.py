"""Module contains all the relevant test-casesunit-tests for the utils module."""

import os
from tempfile import TemporaryDirectory
from hypothesis import given, settings
from hypothesis import strategies as st
from hypothesis.extra.pandas import column, data_frames, columns, range_indexes
from hypothesis.extra.numpy import arrays
from pandas._testing import assert_frame_equal, assert_series_equal
from sklearn.model_selection import ShuffleSplit
import pandas as pd
import numpy as np
from functools import partial

import pytest

import ta_lib.core.utils as utils


# Dataframe with minimum 1 and max 10 data points
temp_df1 = data_frames(
    index=range_indexes(min_size=1, max_size=10),
    columns=columns("A B D".split(), dtype="int64"),
)

temp_df2 = data_frames(
    index=range_indexes(min_size=1, max_size=10),
    columns=columns("A B C".split(), dtype=float) + [(column("D", dtype="int64"))],
)

temp_df3 = data_frames(
    index=range_indexes(min_size=1, max_size=10),
    columns=columns("A".split(), dtype=float) + [(column("D", dtype="int64"))],
)

# Dataframe with minimum 5 and max 10 data points
temp_df4 = data_frames(
    index=range_indexes(min_size=5, max_size=10),
    columns=columns("A B".split(), dtype=float) + [(column("D", dtype="int64"))],
)


@pytest.mark.sanity
def test_package_version():
    """Sanity test to ensure version file is package and installed properly."""
    version = utils.get_package_version()
    assert version != "???"


def test_display_as_tabs():
    # creating a test dataframe that contains infinite values##
    temp = pd.DataFrame({"a": [[np.Inf, pd.NaT, np.nan, 1, 2, 3]]})
    out = utils.display_as_tabs([("ex", temp)])
    with TemporaryDirectory() as temp_dir:
        out.save(os.path.join(temp_dir, "abc.html"))


def test_package_path():
    path = utils.get_package_path()
    assert path.endswith("src")
    assert os.path.exists(path)


def test_data_dir_path():
    path = utils.get_data_dir_path()
    assert path.endswith("data")
    assert os.path.exists(path)


@pytest.mark.parametrize(
    "path, expected",
    [
        (os.path.join("code-templates", "data"), True),
        (os.path.abspath(os.path.join("code-templates", "data")), False),
    ],
)
def test_relative_path(path, expected):
    result = utils.is_relative_path(path)
    assert isinstance(result, bool)
    assert result == expected


def test_load_yaml():
    temp_yml = {
        "Module": "TA-Lib",
        "version": 1,
        "Submodule": {"version": 2.0, "value": [1, 2], "mod1": np.inf, "mod2": None},
    }
    with TemporaryDirectory() as temp_dir:
        utils.create_yml(os.path.join(temp_dir, "temp.yml"), temp_yml)
        result = utils.load_yml(os.path.join(temp_dir, "temp.yml"))
    assert isinstance(result, dict)
    assert result == temp_yml


@settings(deadline=None)
@given(temp_df=temp_df1)
def test_load_csv(temp_df):
    with TemporaryDirectory() as temp_dir:
        temp_df.to_csv(os.path.join(temp_dir, "temp.csv"), index=False)
        result = utils.load_csv(os.path.join(temp_dir, "temp.csv"))
    assert isinstance(result, pd.core.frame.DataFrame)
    assert_frame_equal(result, temp_df)


@settings(deadline=None)
@given(temp_df=temp_df1)
def test_save_csv(temp_df):
    with TemporaryDirectory() as temp_dir:
        utils.save_csv(temp_df, os.path.join(temp_dir, "temp.csv"), index=False)
        result = utils.load_csv(os.path.join(temp_dir, "temp.csv"))
    assert isinstance(result, pd.core.frame.DataFrame)
    assert_frame_equal(result, temp_df)


@settings(deadline=None)
@given(temp_df=temp_df1)
def test_load_parquet(temp_df):
    with TemporaryDirectory() as temp_dir:
        temp_df.to_parquet(os.path.join(temp_dir, "temp.parquet"))
        result = utils.load_parquet(os.path.join(temp_dir, "temp.parquet"))
    assert isinstance(result, pd.core.frame.DataFrame)
    assert_frame_equal(result, temp_df)


@settings(deadline=None)
@given(temp_df=temp_df1)
def test_save_parquet(temp_df):
    with TemporaryDirectory() as temp_dir:
        utils.save_parquet(temp_df, os.path.join(temp_dir, "temp.parquet"))
        result = utils.load_parquet(os.path.join(temp_dir, "temp.parquet"))
    assert isinstance(result, pd.core.frame.DataFrame)
    assert_frame_equal(result, temp_df)


@settings(deadline=None)
@given(temp_df=temp_df1)
def test_df_to_X_y(temp_df):
    target_col = "D"
    result = utils.df_to_X_y(temp_df, target_col)
    assert len(result) == 2
    X = result[0]
    y = result[1]
    assert X.shape[1] == temp_df.shape[1] - 1
    assert X.shape[0] == temp_df.shape[0]
    assert X.shape[0] == y.shape[0]
    assert isinstance(X, (pd.core.frame.DataFrame, pd.core.series.Series))
    assert isinstance(y, (pd.core.frame.DataFrame, pd.core.series.Series))
    assert_frame_equal(X, temp_df.drop([target_col], axis=1))
    assert_series_equal(y, temp_df[target_col])


@given(st.integers(min_value=0, max_value=10000000))
def test_initialize_random_seed(seed):
    np.random.seed(seed)
    seed_value = np.random.randint(100)
    result = utils.initialize_random_seed(seed)
    seed_value_after_init = np.random.randint(100)
    assert isinstance(result, int)
    assert result == seed
    assert seed_value == seed_value_after_init


@pytest.mark.parametrize(
    "func",
    [
        utils.setanalyse,
        partial(utils.setanalyse, simplify=False),
        partial(utils.setanalyse, exceptions_only=True),
        partial(utils.setanalyse, simplify=False, exceptions_only=True),
    ],
)
@given(st.lists(st.integers()), st.lists(st.integers()))
def test_setanalyse(func, list1, list2):
    result = func(list1, list2)
    assert isinstance(result, dict)
    assert len(result) == 4
    assert all([i in ["A-B", "B-A", "AuB", "A^B"] for i in result.keys()])


@settings(deadline=None)
@pytest.mark.parametrize(
    "func",
    [
        utils.setanalyse_df,
        partial(utils.setanalyse_df, simplify=False),
        partial(utils.setanalyse_df, exceptions_only=True),
        partial(utils.setanalyse_df, simplify=False, exceptions_only=True),
        partial(utils.setanalyse_df, key_cols=["A", "D"]),
    ],
)
@given(
    temp_df1=temp_df1, temp_df2=temp_df2,
)
def test_setanalyse_df(func, temp_df1, temp_df2):
    result = func(temp_df1, temp_df2)
    assert isinstance(result, dict)
    assert len(result) == 4
    assert all([i in ["A-B", "B-A", "AuB", "A^B"] for i in result.keys()])


@settings(deadline=None)
@given(arrays(np.float, (5, 3), elements=st.floats(-1, 1)))
def test_get_dataframe(array):
    feature_names = [str(i) for i in range(array.shape[1])]
    temp_df = pd.DataFrame(array, columns=feature_names)
    result = utils.get_dataframe(array, feature_names)
    assert isinstance(result, pd.core.frame.DataFrame)
    assert_frame_equal(result, temp_df)


@settings(deadline=None)
@given(temp_df=temp_df2)
def test_add_column_from_dt(temp_df):
    col = "A"
    new_col = "D"
    op = sum
    result = utils.add_column_from_dt(temp_df, col, new_col, op)
    assert isinstance(result, pd.core.frame.DataFrame)
    assert result.shape == temp_df.shape


@settings(deadline=None)
@pytest.mark.parametrize(
    "keep_first, col_names",
    [
        (True, ["A", "B", "D"]),
        (False, ["A", "B"]),
        (True, ["D"]),
        [False, ["A", "B", "D"]],
    ],
)
@given(temp_df=temp_df1)
def test_remove_duplicate_rows(keep_first, col_names, temp_df):
    result = utils.remove_duplicate_rows(temp_df, col_names, keep_first)
    keep = "first" if keep_first else "last"
    assert isinstance(result, pd.core.frame.DataFrame)
    assert_frame_equal(result, temp_df.drop_duplicates(col_names, keep=keep))


@settings(deadline=None)
@given(temp_df=temp_df1)
def test_passthrough(temp_df):
    result = utils.passthrough(temp_df)
    assert isinstance(result, pd.core.frame.DataFrame)
    assert_frame_equal(result, temp_df)


@settings(deadline=None)
@given(
    temp_df1=temp_df1, temp_df2=temp_df2, temp_df3=temp_df3,
)
def test_merge_info(temp_df1, temp_df2, temp_df3):
    result = utils.merge_info(temp_df1, temp_df2, temp_df3)
    expected = pd.DataFrame(
        [temp_df1.T.shape, temp_df2.T.shape, temp_df3.T.shape],
        columns=["n_cols", "n_rows"],
        index=["left_df", "right_df", "merged_df"],
    )
    assert isinstance(result, pd.core.frame.DataFrame)
    assert_frame_equal(result, expected)


@settings(deadline=None)
@given(temp_df=temp_df1)
def test_load_dataframe(temp_df):
    with TemporaryDirectory() as temp_dir:
        temp_df.to_parquet(os.path.join(temp_dir, "temp.parquet"))
        result = utils.load_dataframe(os.path.join(temp_dir, "temp.parquet"))
    assert isinstance(result, pd.core.frame.DataFrame)
    assert_frame_equal(result, temp_df)


@settings(deadline=None)
@pytest.mark.parametrize(
    "test_size, n_splits", [(0.2, 5), (0.25, 10), (0.3, 20), (0.5, 2),],
)
@given(temp_df=temp_df4)
def test_custom_train_test_split(test_size, n_splits, temp_df):
    splitter = ShuffleSplit(test_size=test_size, n_splits=n_splits)
    result = utils.custom_train_test_split(temp_df, splitter=splitter, by="D")
    train_size = 1 - test_size
    assert isinstance(result, list)
    assert len(result) == n_splits * 2
    assert all(
        [
            result[i].shape[0] == int(temp_df.shape[0] * train_size)
            for i in range(0, len(result), 2)
        ]
    )
    assert all(
        [
            result[i].shape[0] == temp_df.shape[0] - int(temp_df.shape[0] * train_size)
            for i in range(1, len(result), 2)
        ]
    )
    assert all([result[i].shape[1] == temp_df.shape[1] for i in range(1, len(result))])
