import pytest
from sklearn.utils.estimator_checks import (
    check_estimator,
    parametrize_with_checks,
)

from ta_lib.classification.estimators import SKLStatsmodelLogit
from statsmodels.tools.sm_exceptions import PerfectSeparationError


@parametrize_with_checks(
    [SKLStatsmodelLogit(), SKLStatsmodelLogit(fit_intercept=False)]
)
def test_sklearn_compatible_estimator(estimator, check):
    try:
        check(estimator)
    except PerfectSeparationError:
        pytest.skip("PerfectSeparationError")
