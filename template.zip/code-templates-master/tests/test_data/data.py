import numpy as np
import pandas as pd


def get_variable_summary():
    ## Test Case 1

    input_df = pd.DataFrame(
        {"Names": ["Chris", "Charles", "Ted", "Ted"], "Age": [10, 20, 10, 40]}
    )
    input_df1 = pd.DataFrame(
        {"Names": ["Chris", "Charles", "", "Ted"], "Age": [10, 20, np.nan, 40]}
    )

    output_df = pd.DataFrame(
        {
            "Variable Name": {"Names": "Names", "Age": "Age"},
            "Datatype": {"Names": "object", "Age": "int64"},
            "No of Unique": {"Names": 3, "Age": 3},
            "Samples": {"Names": ["Chris", "Charles", "Ted"], "Age": [10, 20, 40]},
        }
    )
    output_df = output_df.astype("object")
    ##Test Case 2
    output_df1 = pd.DataFrame(
        {
            "Variable Name": {"Names": "Names", "Age": "Age"},
            "Datatype": {"Names": "object", "Age": "float64"},
            "No of Unique": {"Names": 4, "Age": 3},
            "Samples": {
                "Names": ["Chris", "Charles", "", "Ted"],
                "Age": [10.0, 20.0, np.nan, 40.0],
            },
        }
    )
    output_df1 = output_df1.astype("object")
    return [(input_df, output_df), (input_df1, output_df1)]


def get_data_health_summary():
    ##Test Case 1
    input_df = pd.DataFrame(
        {"Names": ["Chris", "Charles", "Ted", "Ted"], "Age": [10, 20, 10, 40]}
    )
    input_df1 = pd.DataFrame(
        {"Names": ["Chris", "Charles", "", "Ted"], "Age": [10, 20, np.nan, 40]}
    )

    output_df = pd.DataFrame(
        {
            "values": {
                ("Datatypes", "Numeric"): 50.0,
                ("Datatypes", "Others"): 50.0,
                ("Missing Values", "Available"): 100.0,
                ("Missing Values", "Missing"): 0.0,
                ("Duplicate Values", "Unique"): 100.0,
                ("Duplicate Values", "Duplicate"): 0.0,
                ("Duplicate Columns", "Unique"): 100.0,
                ("Duplicate Columns", "Duplicate"): 0.0,
            }
        }
    )
    output_df = output_df.rename_axis(["type", "labels"])

    ##Test Case 2
    output_df1 = pd.DataFrame(
        {
            "values": {
                ("Datatypes", "Numeric"): 50.0,
                ("Datatypes", "Others"): 50.0,
                ("Missing Values", "Available"): 87.5,
                ("Missing Values", "Missing"): 12.5,
                ("Duplicate Values", "Unique"): 100.0,
                ("Duplicate Values", "Duplicate"): 0.0,
                ("Duplicate Columns", "Unique"): 100.0,
                ("Duplicate Columns", "Duplicate"): 0.0,
            }
        }
    )
    output_df1 = output_df1.rename_axis(["type", "labels"])

    return [(input_df, output_df), (input_df1, output_df1)]


def get_duplicate_columns():
    input_df = pd.DataFrame(
        {
            "Names": ["Chris", "Charles", "Hannah", "Ted"],
            "Kids": ["Chris", "Charles", "Hannah", "Ted"],
            "Age": [10, 20, 10, 40],
        }
    )
    input_df1 = pd.DataFrame(
        {
            "Names": ["Chris", "Charles", "", "Ted"],
            "Age": [10, 20, np.nan, 40],
            "Age2": [10, 20, np.nan, 40],
        }
    )

    output_df = pd.DataFrame({"Variable Name": {0: "Names"}, "Duplicates": {0: "Kids"}})
    output_df1 = pd.DataFrame({"Variable Name": {0: "Age"}, "Duplicates": {0: "Age2"}})

    return [(input_df, output_df), (input_df1, output_df1)]


def get_outliers():
    input_df = pd.DataFrame(
        {"Numbers": [1, 2, 31, 1, 1, 1, 1, 1, 1, 1, 1, 110000000000]}
    )
    input_df1 = pd.DataFrame(
        {
            "Numbers": [
                -1,
                np.nan,
                np.inf,
                -np.inf,
                1,
                2,
                31,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                1,
                110000000000,
            ]
        }
    )

    input1_describe = input_df.describe()
    input2_describe = input_df1.describe()
    output_df = pd.DataFrame(
        {
            "< (mean-3*std)": {"Numbers": np.sum(input_df['Numbers'] < (input1_describe.T['mean'].values - 3 * input1_describe.T['std'].values)[0])},
            "> (mean+3*std)": {"Numbers": np.sum(input_df['Numbers'] > (input1_describe.T['mean'].values + 3 * input1_describe.T['std'].values)[0])},
            "< (1stQ - 1.5 * IQR)": {"Numbers": np.sum(input_df['Numbers'] < (input1_describe.T['25%'].values - 1.5 * (input1_describe.T['75%'].values-input1_describe.T['25%'].values))[0])},
            "> (3rdQ + 1.5 * IQR)": {"Numbers": np.sum(input_df['Numbers'] > (input1_describe.T['75%'].values + 1.5 * (input1_describe.T['75%'].values-input1_describe.T['25%'].values))[0])},
            "-inf": {"Numbers": 0},
            "+inf": {"Numbers": 0},
        }
    )
    output_df1 = pd.DataFrame(
        {
            "< (mean-3*std)": {"Numbers": np.sum(input_df1['Numbers'] < (input2_describe.T['mean'].values - 3 * input2_describe.T['std'].values)[0])},
            "> (mean+3*std)": {"Numbers": np.sum(input_df1['Numbers'] > (input2_describe.T['mean'].values + 3 * input2_describe.T['std'].values)[0])},
            "< (1stQ - 1.5 * IQR)": {"Numbers": np.sum(input_df1['Numbers'] < (input2_describe.T['25%'].values - 1.5 * (input2_describe.T['75%'].values-input2_describe.T['25%'].values))[0])},
            "> (3rdQ + 1.5 * IQR)": {"Numbers": np.sum(input_df1['Numbers'] > (input2_describe.T['75%'].values + 1.5 * (input2_describe.T['75%'].values-input2_describe.T['25%'].values))[0])},
            "-inf": {"Numbers": 1},
            "+inf": {"Numbers": 1},
        }
    )
    level1_col = "Data Shape:"+str(input_df.shape)
    level2_cols = output_df.columns.to_list()
    col_arrays = [[level1_col]*len(level2_cols), level2_cols]
    index = pd.MultiIndex.from_tuples(list(zip(*col_arrays)), names=['', 'feature'])
    output_df.columns = index

    level1_col = "Data Shape:"+str(input_df1.shape)
    level2_cols = output_df1.columns.to_list()
    col_arrays = [[level1_col]*len(level2_cols), level2_cols]
    index = pd.MultiIndex.from_tuples(list(zip(*col_arrays)), names=['', 'feature'])
    output_df1.columns = index

    return [(input_df, output_df), (input_df1, output_df1)]


def get_correlation_table():
    input_df = pd.DataFrame(
        {
            "X1": [50, 30, 80, 100, 10, 43, 69, 55, 99],
            "X2": [54, 36, 89, 100, 454, 999, -65, -55, 0],
            "X3": [-50, -30, -80, -100, -10, -43, -69, -55, -99],
        }
    )
    input_df1 = pd.DataFrame(
        {
            "X1": [np.inf, 30, np.nan, 100, 100, 433, 693, 550, -np.inf],
            "X2": [np.nan, 36, 89, 100, 454, 999, -65, -55, 0],
            "X3": [-50, -30, -80, -100, -10, -43, -69, -55, -99],
        }
    )

    output_df = pd.DataFrame(
        {
            "Variable 1": {0: "X1", 1: "X1", 2: "X2"},
            "Variable 2": {0: "X3", 1: "X2", 2: "X3"},
            "Coer Coef": {0: -1.0, 1: -0.41958060086481663, 2: 0.41958060086481663},
            "Abs Coer Coef": {0: 1.0, 1: 0.41958060086481663, 2: 0.41958060086481663},
        }
    )
    output_df1 = pd.DataFrame(
        {
            "Variable 1": {0: "X2", 1: "X1", 2: "X1"},
            "Variable 2": {0: "X3", 1: "X3", 2: "X2"},
            "Coer Coef": {
                0: 0.4428464075548217,
                1: -0.25378006465799946,
                2: -0.09169528325767874,
            },
            "Abs Coer Coef": {
                0: 0.4428464075548217,
                1: 0.25378006465799946,
                2: 0.09169528325767874,
            },
        }
    )
    return [(input_df, output_df), (input_df1, output_df1)]


def calc_vif():
    input_df = pd.DataFrame(
        {
            "X1": [50, 30, 80, 100, 10, 43, 69, 55, 10],
            "X2": [54, 36, 89, 100, 454, 999, -65, -55, 0],
            "X3": [-50, -30, -80, -100, -10, -43, -69, -55, -99],
        }
    )
    input_df1 = pd.DataFrame(
        {
            "X1": [501, 301, 800, -10, 30, 4334, 69, 5509, 1071],
            "X2": [1543, 3634, 8209, 12100, 4678, 0, -615, -550, 0],
            "X3": [-50, -30, -80, -100, -10, -43, -69, -55, -99],
        }
    )

    output_df = pd.DataFrame(
        {
            "variables": {0: "X1", 1: "X2", 2: "X3"},
            "VIF": {0: 5.123503325771861, 1: 1.113287024667442, 2: 4.984758542752185},
        }
    )
    output_df1 = pd.DataFrame(
        {
            "variables": {0: "X1", 1: "X2", 2: "X3"},
            "VIF": {0: 1.5742808397655255, 1: 2.040318515183488, 2: 2.6830759375524957},
        }
    )
    return [(input_df, output_df), (input_df1, output_df1)]


def _key_to_tuple():
    input_df = "/Downloads/test_repo/code-templates"
    input_df1 = "/Downloads/test_repo/code-templates/ta_lib/eda/"
    output_df = ["Downloads", "test_repo", "code-templates"]
    output_df1 = ["Downloads", "test_repo", "code-templates", "ta_lib", "eda"]
    return [(input_df, output_df), (input_df1, output_df1)]


def _get_val():
    input_df = dict({"time": "value", "shall": "done"})
    input_df1 = dict({"code": "debug", "run": "error"})
    key = "time"
    key1 = "code"
    output_df = "value"
    output_df1 = "debug"
    return [((input_df, key), output_df), ((input_df1, key1), output_df1)]


def list_datasets():
    input_df = "raw/sales"
    input_df1 = "clean/sales"
    output_df = ["/raw/sales", "/raw/doj"]
    output_df1 = []
    return [(input_df, output_df), (input_df1, output_df1)]


def load_dataset():
    input_df = "raw/sales"
    output_df = pd.DataFrame()
    return [(input_df, output_df)]


def load_dataset_multiple_files():
    input_df = "raw/orders"
    output_df = pd.DataFrame()
    return [(input_df, output_df)]


def save_dataset():
    input_df = "/raw/sales"
    input_df1 = "/raw/doj"
    key = "sales"
    key1 = "doj"
    return [(input_df, key), (input_df1, key1)]


def _get_uri_from_template():
    """Data for dynamic uri test case."""
    uris = [
        r"/a/b/{aaa}/abcd/{fdsfs}",
        r"/a/b/{aaa}/abcd/{fdsfs}"
    ]
    args = [
        {'aaa':1, 'fdsfs':2},
        {'aaa':'1', 'fdsfs':'2'}
    ]
    exp = [
        "/a/b/1/abcd/2",
        "/a/b/1/abcd/2"
    ]

    fn = [((x,args[i]),exp[i]) for i,x in enumerate(uris)]
    return(fn)
