import os.path as op

import numpy as np
import pandas as pd
import pytest
from hypothesis import assume, given
from hypothesis import strategies as st
from hypothesis.extra.pandas import column, columns, data_frames, range_indexes
from pandas.testing import assert_frame_equal

import ta_lib.core.dataset as dataset
import test_data.data as datasets
from ta_lib.core.api import create_context, get_package_path

config_path = op.join(get_package_path(), "..","tests", "test_conf", "test.yml")
context = create_context(config_path)


@given(key=st.text())
@pytest.mark.parametrize("test_input, expected", datasets._key_to_tuple())
def test_key_to_tuple(key, test_input, expected):
    df = dataset._key_to_tuple(key)
    assert isinstance(df, list)
    assert dataset._key_to_tuple(test_input) == expected


@pytest.mark.parametrize("test_input, expected", datasets._get_val())
def test_get_val(test_input, expected):
    assert dataset._get_val(test_input[0], test_input[1]) == expected


@pytest.mark.parametrize("test_input, expected", datasets.list_datasets())
def test_list_dataset(test_input, expected):
    assert isinstance(dataset.list_datasets(context, test_input), type(expected))


@pytest.mark.parametrize("test_input, expected", datasets.load_dataset())
def test_load_dataset(test_input, expected):
    df = dataset.load_dataset(context, test_input)
    assert isinstance(df, type(expected))
    assert df.shape == (14, 14)


@pytest.mark.parametrize("test_input, expected", datasets.load_dataset_multiple_files())
def test_load_dataset_multiple_files(test_input, expected):
    df = dataset.load_dataset(context, test_input)
    assert isinstance(df, type(expected))
    assert df.shape == (18, 25)


@pytest.mark.parametrize("test_input", datasets.save_dataset())
def test_save_dataset(test_input):
    assert (
        dataset.save_dataset(
            context,
            dataset.load_dataset(context, test_input[0]),
            "/cleaned/" + test_input[1],
        )
        == None
    )
    assert isinstance(
        dataset.load_dataset(context, "/cleaned/" + test_input[0].split("/")[-1]),
        pd.DataFrame,
    )


@pytest.mark.parametrize("test_input, expected", datasets._get_uri_from_template())
def test_dynamic_uri_parse(test_input, expected):
    assert dataset._get_uri_from_template(*test_input) == expected
