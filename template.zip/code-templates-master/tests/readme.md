## Testcases 

Notes for  running the test_case scripts for **TA_LIB**

We would use `pytest testing_script` for running the test_case. 

* In tests folder we have all the testing scripts 
* `tests/test_data/` folder consists of some data files and `data.py` file which contains manual test_cases 
* All test scripts within `tests` folder have a **prefix**  `test_module_name` added to the base file 

```
For eg:- basefile ta_lib/core/datasets.py file will have testcase file as test_core_dataset.py 

```

* Ensure to download the test datasets which are used in test scripts:

gdrive-link : https://drive.google.com/file/d/1c00H_nBDO_uEJMk4nO15c3KK3SxT6Dty/view?usp=sharing