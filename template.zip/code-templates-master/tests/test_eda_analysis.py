import hypothesis
import numpy as np
import pandas as pd
import pytest
from hypothesis import assume, given
from hypothesis import strategies as st
from hypothesis.extra.pandas import column, columns, data_frames, range_indexes
from pandas.testing import assert_frame_equal

import ta_lib.eda.analysis as analysis
import test_data.data as datasets

# Not providing object alone to column as the test_case is failing. Testcase not working if column is a list object.


input_value = data_frames(
    index=range_indexes(min_size=30, max_size=60),
    columns=[
        column(name="A", dtype=int),
        column(
            name="B",
            dtype=float,
            elements=st.sampled_from(
                [
                    0,
                    np.nan,
                    np.inf,
                    -np.inf,
                    -100,
                    100.99,
                    10000000100,
                    45444444,
                    32.44455,
                ]
            ),
        ),
        column(
            name="C",
            dtype="object",
            elements=st.sampled_from(
                [st.text(), st.datetimes(), np.inf, -np.inf, np.nan, "",]
            ),
        ),
    ],
)

@hypothesis.settings(deadline=None)
@given(input_value=input_value)
@pytest.mark.parametrize("test_input,expected", datasets.get_variable_summary())
def test_get_variable_summary(input_value, test_input, expected):
    df = analysis.get_variable_summary(input_value)
    assert df[df["Variable Name"] == "A"].Datatype[0] in ("int32","int64")
    assert df[df["Variable Name"] == "B"].Datatype[0] == "float64"
    assert isinstance(df, pd.DataFrame)
    assert_frame_equal(analysis.get_variable_summary(test_input), expected)

@hypothesis.settings(deadline=None)
@given(input_value=input_value)
@pytest.mark.parametrize("test_input,expected", datasets.get_data_health_summary())
def test_get_data_health_summary(input_value, test_input, expected):
    df = analysis.get_data_health_summary(input_value)
    assert df["values"].dtype == "float64"
    assert isinstance(df, pd.DataFrame)
    assert_frame_equal(
        analysis.get_data_health_summary(test_input).sort_index(), expected
    )

@hypothesis.settings(deadline=None)
@given(input_value=input_value)
@pytest.mark.parametrize("test_input,expected", datasets.get_duplicate_columns())
def test_get_duplicate_columns(input_value, test_input, expected):
    df = analysis.get_duplicate_columns(input_value)
    if isinstance(df, str):
        assert "No duplicate variables" == df
    else:
        assert isinstance(df, pd.DataFrame)
        assert isinstance(df["Variable Name"][0], str)
    assert_frame_equal(analysis.get_duplicate_columns(test_input), expected)


@hypothesis.settings(deadline=None)
@given(input_value=input_value)
@pytest.mark.parametrize("test_input,expected", datasets.get_outliers())
def test_get_outliers(input_value, test_input, expected):
    df = analysis.get_outliers(input_value)
    if isinstance(df, str):
        assert "No Outlier Values" == df
    else:
        assert isinstance(df, pd.DataFrame)
    assert_frame_equal(analysis.get_outliers(test_input), expected)

@hypothesis.settings(deadline=None)
@given(input_value=input_value)
@pytest.mark.parametrize("test_input,expected", datasets.get_correlation_table())
def test_get_correlation_table(input_value, test_input, expected):
    df = analysis.get_correlation_table(input_value)
    assert df["Coer Coef"].dtype == "float64"
    assert isinstance(df, pd.DataFrame)
    assert_frame_equal(analysis.get_correlation_table(test_input), expected)


## test conditions with numerical values excluding inf and nans
@hypothesis.settings(deadline=None)
@given(
    value=data_frames(
        index=range_indexes(min_size=5, max_size=10),
        columns=columns(["A", "B"], dtype=float, unique=True),
        rows=st.tuples(
            st.floats(
                allow_nan=False,
                allow_infinity=False,
                min_value=-1000000000000,
                max_value=1000000000000,
            ),
            st.floats(
                allow_nan=False,
                allow_infinity=False,
                min_value=-1000000000000,
                max_value=1000000000000,
            ),
        ),
    )
)
@pytest.mark.parametrize("test_input,expected", datasets.calc_vif())
def test_calc_vif(value, test_input, expected):
    df = analysis.calc_vif(value)
    assert df["VIF"].dtype == "float64"
    assert isinstance(df, pd.DataFrame)
    assert_frame_equal(analysis.calc_vif(test_input), expected)
