import pytest
from sklearn.utils.estimator_checks import (
    check_estimator,
    parametrize_with_checks,
)

from ta_lib.regression.estimators import SKLStatsmodelOLS


@parametrize_with_checks([SKLStatsmodelOLS()])
def test_sklearn_compatible_estimator(estimator, check):
    check(estimator)
