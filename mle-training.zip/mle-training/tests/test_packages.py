import os

import pytest

os.system("conda list")
