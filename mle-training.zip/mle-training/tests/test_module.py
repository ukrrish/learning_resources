import pytest
import unittest
from src import ingest_data, train

ingest_data
from src import score
