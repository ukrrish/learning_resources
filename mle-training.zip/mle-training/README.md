# Clone the repository
git clone https://github.com/Mownika07/mle-training.git

# Median housing value prediction

The housing data can be downloaded from https://raw.githubusercontent.com/ageron/handson-ml/master/. The script has codes to download the data. We have modelled the median house value on given housing data. 

The following techniques have been used: 

 - Linear regression
 - Decision Tree
 - Random Forest

## Steps performed
 - We prepare and clean the data. We check and impute for missing values.
 - Features are generated and the variables are checked for correlation.
 - Multiple sampling techinuqies are evaluated. The data set is split into train and test.
 - All the above said modelling techniques are tried and evaluated. The final metric used to evaluate is mean squared error.

## To activate python environment
### conda env create -f env.yml

## To excute the script
### 1. Clone the repository 
     git clone https://github.com/Mownika07/mle-training     
### 2. Make mle-training as the working directory
     cd mle-training     
### 3. Activate environment using the following commands :      
     conda env create -f env.yml
     conda activate mle-dev     
### 4. Install the package
     pip install -e .
### 5. Verify correct installations
     cd tests
#####   For testing conda installations:        
      python test_packages.py
#####   For testing all files:      
     python test_module.py
### Running the ML Scripts:
##### Make mle-training as the working directory using cd commands, then run the commands:
       cd src
#### 1. To download and create training and validation datasets:
       python ingest_data.py
##### OR
       python ingest_data.py --output_folder <Location>
##### The following options can be used for the logs:
       -lp or --log_path
       -ll or --log_level
       -ncl or --no_console_log
#### 2. Training the models:
       python train.py 
##### OR
       python train.py -if <Input_Data_Location> -of <Output_model_pickle_location>
##### OR
       python train.py -input_folder <Input_Data_Location> -output_folder <Output_model_pickle_location>
##### The following options can be used for the logs:
       -lp or --log_path
       -ll or --log_level
       -ncl or --no_console_log
#### 3. Calculating the model scores:
       python score.py 
##### OR
       python score.py -idataf <Input_Data_Location> -imodelf <Input_model_pickle_location> -of <Output_score_file> 
##### OR
       python score.py -input_dataset_folder <Input_Data_Location> -input_model_folder <Input_model_pickle_location> -output_file <Output_score_file> 
##### The following options can be used for the logs:
       -lp or --log_path
       -ll or --log_level
       -ncl or --no_console_log

### Running Complete set of tests:
##### Make the the mle-training folder as the working directory using cd commands, then run the command:
        pytest

### Development
##### .tar.gz distribution packaging file
       python setup.py sdist

##### .whl distribution packaging file
       python setup.py bdist_wheel