import argparse
import logging
import os
import pathlib
import pickle

import pandas as pd
from scipy.stats import randint
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.tree import DecisionTreeRegressor

# Argpasrse for takeing custom input

parser = argparse.ArgumentParser(description="A script to create models.")
parser.add_argument(
    "-if",
    "--input_folder",
    metavar="",
    type=str,
    help="Input folder containing processed data",
)
parser.add_argument(
    "-of",
    "--output_folder",
    metavar="",
    type=str,
    help="Output folder for stroring the model pickles",
)
parser.add_argument("-lp", "--log_path", type=str, help="Specify the log file path.")
parser.add_argument("-ll", "--log_level", type=str, help="Specify the log level ")
parser.add_argument(
    "-ncl",
    "--no_console_log",
    action="store_false",
    help="Toggle whether or not to write logs to the console ",
)
args = parser.parse_args()
logger = logging.getLogger()

if args.log_level is None:
    args.log_level = "DEBUG"

if args.log_path or args.no_console_log:
    for hdlr in logger.handlers:
        logger.removeHandler(hdlr)

    if args.log_path:
        fh = logging.FileHandler(args.log_path + "train.log")
        formatter = logging.Formatter(
            "%(asctime)s %(name)-12s %(levelname)-8s %(message)s"
        )
        fh.setFormatter(formatter)
        logger.addHandler(fh)
        logger.setLevel(args.log_level)

    if args.no_console_log:
        sh = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s %(name)-12s %(levelname)-8s %(message)s"
        )
        sh.setFormatter(formatter)
        logger.addHandler(sh)
        logger.setLevel(args.log_level)


# Setting default path
path = pathlib.Path(__file__).parent.absolute()


inf = ""

if args.input_folder is None:
    inf = os.path.join(path.parent, "data", "processed", "")
else:
    inf = os.path.join(args.input_folder, "")


outf = ""

if args.output_folder is None:
    outf = os.path.join(path.parent, "artifacts")
else:
    outf = os.path.join(args.output_folder, "")

# Data read
try:
    strat_train_set = pd.read_csv(inf + "train.csv")
# strat_test_set = pd.read_csv(inf + "test.csv")
except:
    logger.error("Cannot read file")
housing_prepared = strat_train_set.copy()
housing_prepared = strat_train_set.drop("median_house_value", axis=1)
housing_labels = strat_train_set["median_house_value"].copy()

# Train on various models

# Linear Rigression
logger.debug("Training Linear regression model")

lin_reg = LinearRegression()
linear_model = lin_reg.fit(housing_prepared, housing_labels)
logger.info("Generating pickle file for Linear model")
pickle.dump(linear_model, open(outf + "/linear_model.pkl", "wb"))

# DecisionTree Regressor
logger.debug("Training Desicion Tree Regression  model")

tree_reg = DecisionTreeRegressor(random_state=42)
decission_model = tree_reg.fit(housing_prepared, housing_labels)
logger.info("Generating pickle file for Descision Tree model")
pickle.dump(decission_model, open(outf + "/decission_model.pkl", "wb"))

# Random Forest Regressor
logger.debug("Training Random forest regression model")

param_distribs = {
    "n_estimators": randint(low=1, high=200),
    "max_features": randint(low=1, high=8),
}

forest_reg = RandomForestRegressor(random_state=42)
rnd_search = RandomizedSearchCV(
    forest_reg,
    param_distributions=param_distribs,
    n_iter=10,
    cv=5,
    scoring="neg_mean_squared_error",
    random_state=42,
)
rnd_search.fit(housing_prepared, housing_labels)

param_grid = [
    # try 12 (3×4) combinations of hyperparameters
    {"n_estimators": [3, 10, 30], "max_features": [2, 4, 6, 8]},
    # then try 6 (2×3) combinations with bootstrap set as False
    {"bootstrap": [False], "n_estimators": [3, 10], "max_features": [2, 3, 4]},
]

forest_reg = RandomForestRegressor(random_state=42)
# train across 5 folds, that's a total of (12+6)*5=90 rounds of training
grid_search = GridSearchCV(
    forest_reg,
    param_grid,
    cv=5,
    scoring="neg_mean_squared_error",
    return_train_score=True,
)
grid_search.fit(housing_prepared, housing_labels)

grid_search.best_params_
cvres = grid_search.cv_results_


feature_importances = grid_search.best_estimator_.feature_importances_
sorted(zip(feature_importances, housing_prepared.columns), reverse=True)


forest_model = grid_search.best_estimator_

logger.info("Generating pickle file for Random Forest model")
pickle.dump(forest_model, open(outf + "/forest_model.pkl", "wb"))
