import argparse
import logging
import os
import pathlib
import pickle

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import cross_val_score

# Argpasrse for takeing custom input

parser = argparse.ArgumentParser(description="A script to find the model score.")
parser.add_argument(
    "-idataf",
    "--input_dataset_folder",
    metavar="",
    type=str,
    help="Input folder containing processed data",
)
parser.add_argument(
    "-imodelf",
    "--input_model_folder",
    metavar="",
    type=str,
    help="Input folder containing model pickles",
)
parser.add_argument(
    "-of",
    "--output_file",
    metavar="",
    type=str,
    help="Output file for storing the output",
)
parser.add_argument("-lp", "--log_path", type=str, help="Specify the log file path.")
parser.add_argument("-ll", "--log_level", type=str, help="Specify the log level ")
parser.add_argument(
    "-ncl",
    "--no_console_log",
    action="store_false",
    help="Toggle whether or not to write logs to the console ",
)

args = parser.parse_args()
logger = logging.getLogger()

if args.log_level is None:
    args.log_level = "DEBUG"

if args.log_path or args.no_console_log:
    for hdlr in logger.handlers:
        logger.removeHandler(hdlr)

    if args.log_path:
        fh = logging.FileHandler(args.log_path + "score.log")
        formatter = logging.Formatter(
            "%(asctime)s %(name)-12s %(levelname)-8s %(message)s"
        )
        fh.setFormatter(formatter)
        logger.addHandler(fh)
        logger.setLevel(args.log_level)

    if args.no_console_log:
        sh = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s %(name)-12s %(levelname)-8s %(message)s"
        )
        sh.setFormatter(formatter)
        logger.addHandler(sh)
        logger.setLevel(args.log_level)

# Setting default path
path = pathlib.Path(__file__).parent.absolute()
print(path)
idf = ""
if args.input_dataset_folder is None:
    idf = os.path.join(path.parent, "data", "processed", "")
else:
    idf = os.path.join(args.input_folder, "")

imf = ""
if args.input_model_folder is None:
    imf = os.path.join(path.parent, "artifacts")
else:
    imf = os.path.join(args.input_folder, "")

outf = ""

if args.output_file is None:
    outf = os.path.join(path.parent, "artifacts/score.txt")
else:
    outf = os.path.join(args.output_folder, "score.txt")

try:
    strat_train_set = pd.read_csv(idf + "train.csv")
    strat_test_set = pd.read_csv(idf + "test.csv")
except:
    logger.error("Cannot read file")

logger.debug("Opening score file to store scores")
f = open(outf, "a")
housing_prepared = strat_test_set.copy()
housing_prepared = strat_test_set.drop("median_house_value", axis=1)
housing_labels = strat_test_set["median_house_value"].copy()


# Score for Liner Regression
logger.info("Calculating scores for Linear model")
try:
    linear_model = pickle.load(open(imf + "/linear_model.pkl", "rb"))
except:
    logger.error("Pickle file not found")
housing_predictions = linear_model.predict(housing_prepared)

lin_mse = mean_squared_error(housing_labels, housing_predictions)
lin_rmse = np.sqrt(lin_mse)
lin_mae = mean_absolute_error(housing_labels, housing_predictions)

r2 = r2_score(housing_labels, housing_predictions)

lin_scores = cross_val_score(
    linear_model,
    housing_prepared,
    housing_labels,
    scoring="neg_mean_squared_error",
    cv=10,
)
lin_rmse_scores = np.sqrt(-lin_scores)
f.write("Liner Regression Score:- \n \n")
f.write("R2 : {:10.4f} \n".format(r2))
f.write("Mean Absolute Error : {:10.4f} \n".format(lin_mae))
f.write("Root Mean Squared Error : {:10.4f} \n".format(lin_rmse))
f.write("Mean : {:10.4f} \n".format(lin_rmse_scores.mean()))
f.write("Standard deviation : {:10.4f} \n \n".format(lin_rmse_scores.std()))


# Score for DecisionTree Regression
logger.info("Calculating scores for Decision Tree model")
try:
    decission_model = pickle.load(open(imf + "/decission_model.pkl", "rb"))
except:
    logger.error("Pickle file not found")
housing_predictions = decission_model.predict(housing_prepared)

tree_mse = mean_squared_error(housing_labels, housing_predictions)
tree_rmse = np.sqrt(tree_mse)
tree_mae = mean_absolute_error(housing_labels, housing_predictions)

r2 = r2_score(housing_labels, housing_predictions)

tree_scores = cross_val_score(
    decission_model,
    housing_prepared,
    housing_labels,
    scoring="neg_mean_squared_error",
    cv=10,
)
tree_rmse_scores = np.sqrt(-tree_scores)
f.write("Decision Tree Regressior Score:- \n \n")
f.write("R2 : {:10.4f} \n".format(r2))
f.write("Mean Absolute Error : {:10.4f} \n".format(tree_mae))
f.write("Root Mean Squared Error : {:10.4f} \n".format(tree_rmse))
f.write("Mean : {:10.4f} \n".format(tree_rmse_scores.mean()))
f.write("Standard deviation : {:10.4f} \n \n".format(tree_rmse_scores.std()))


# Score for Random Forest Regression
logger.info("Calculating scores for Random Forest model")
try:
    forest_model = pickle.load(open(imf + "/forest_model.pkl", "rb"))
except:
    logger.error("Pickle file not found")
housing_predictions = forest_model.predict(housing_prepared)

forest_mse = mean_squared_error(housing_labels, housing_predictions)
forest_rmse = np.sqrt(forest_mse)
forest_mae = mean_absolute_error(housing_labels, housing_predictions)

r2 = r2_score(housing_labels, housing_predictions)

forest_scores = cross_val_score(
    forest_model,
    housing_prepared,
    housing_labels,
    scoring="neg_mean_squared_error",
    cv=10,
)
forest_rmse_scores = np.sqrt(-forest_scores)
f.write("Random Forest Regressior Score:- \n \n")
f.write("R2 : {:10.4f} \n".format(r2))
f.write("Mean Absolute Error : {:10.4f} \n".format(forest_mae))
f.write("Root Mean Squared Error : {:10.4f} \n".format(forest_rmse))
f.write("Mean : {:10.4f} \n".format(forest_rmse_scores.mean()))
f.write("Standard deviation : {:10.4f} \n \n".format(forest_rmse_scores.std()))
