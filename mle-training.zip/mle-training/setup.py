from setuptools  import find_packages, setup

setup(
   name='housing_prediction',
   version='1.0',
   description="Median Housing Value Prediction",
   author='Mownika',
   author_email='mownika.gonella@tigeranalytics.com',
   install_requires=[
        "pandas",
        "numpy",
        "argparse",
        "six",
        "sklearn",
        "sphinx",
        "pytest",
        "pypandoc>=1.4",
        "pathlib",
    ],
    packages=find_packages(),  #same as name
   #external packages as dependencies
)